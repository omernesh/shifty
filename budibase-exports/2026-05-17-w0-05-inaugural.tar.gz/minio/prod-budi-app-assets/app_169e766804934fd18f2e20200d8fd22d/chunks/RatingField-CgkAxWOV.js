import { g as W, p as n, l as C, i as m, j as e, k as Y, m as Z, S as $, d as P, B as s, b1 as V, A as B, w as ee, z as c, f as I, r as k, T as te, c as E, I as ae, t as le, a as H, ap as re, e as f, H as ne } from "./index-CMyk0zjR.js";
import { F as se } from "./Field-DlAvOihk.js";
var ie = I('<button type="button"><div><!></div></button>'), oe = I('<div class="rating-container svelte-1np9d43"></div>');
function fe(O, l) {
  W(l, !1);
  const w = c(), z = c(), d = c();
  let p = n(l, "colour", 8, ""), T = n(l, "disabled", 8, !1), X = n(l, "readonly", 8, !1), j = n(l, "field", 8), q = n(l, "label", 8), G = n(l, "numberOfStars", 8, 5), y = n(l, "size", 8, "L"), N = n(l, "type", 8, "star"), b = n(l, "variant", 8, "Primary"), U = n(l, "validation", 8), R = n(l, "onChange", 8), u = c(null), i = c(), h = c(), A = c();
  const D = {
    Primary: "var(--primaryColor)",
    Secondary: "var(--primaryColorHover)",
    Mono: "var(--spectrum-global-color-gray-900)",
    Gold: "var(--spectrum-global-color-yellow-500)",
    Red: "var(--spectrum-global-color-red-500)",
    Custom: "var(--primaryColor)"
  }, F = { XS: 0.25, S: 0.5, M: 1, L: 1.5, XL: 2 }, M = (t) => {
    if (e(d)) {
      const v = e(h)?.setValue(t);
      R() && v && R()({ value: t });
    }
  }, g = (t, v) => typeof t == "number" && t >= v + 1;
  C(() => (m(b()), m(p())), () => {
    s(w, b() === "Custom" && p() ? p() : D[b()] || "var(--primaryColor)");
  }), C(() => m(y()), () => {
    s(z, F[y()] || F.M);
  }), C(() => e(i), () => {
    s(d, !e(i)?.disabled && !e(i)?.readonly);
  }), Y(), Z(), se(O, {
    get label() {
      return q();
    },
    get field() {
      return j();
    },
    get disabled() {
      return T();
    },
    get readonly() {
      return X();
    },
    get validation() {
      return U();
    },
    get type() {
      return m(V), B(() => V.NUMBER);
    },
    defaultValue: "0",
    get fieldState() {
      return e(i);
    },
    set fieldState(t) {
      s(i, t);
    },
    get fieldApi() {
      return e(h);
    },
    set fieldApi(t) {
      s(h, t);
    },
    get fieldSchema() {
      return e(A);
    },
    set fieldSchema(t) {
      s(A, t);
    },
    children: (t, v) => {
      var _ = oe();
      $(_, 5, () => ({ length: G() }), te, (J, de, o) => {
        var r = ie();
        let x;
        var S = E(r);
        let L;
        var K = E(S);
        {
          let a = ne(() => (e(u), e(i), B(() => g(e(u), o) || g(e(i)?.value, o) ? "fill" : "regular")));
          ae(K, {
            get name() {
              return N();
            },
            get size() {
              return y();
            },
            get color() {
              return e(w);
            },
            get weight() {
              return e(a);
            }
          });
        }
        k(S), k(r), le(
          (a, Q) => {
            x = H(r, 1, "rating-icon-wrapper svelte-1np9d43", null, x, a), re(r, `padding: 0 ${e(z) ?? ""}px;`), L = H(S, 1, "icon-container svelte-1np9d43", null, L, Q);
          },
          [
            () => ({ disabled: e(i)?.disabled }),
            () => ({
              "hover-preview": g(e(u), o) && !g(e(i)?.value, o)
            })
          ]
        ), f("mouseover", r, function(...a) {
          (e(d) ? () => s(u, o + 1) : null)?.apply(this, a);
        }), f("mouseleave", r, function(...a) {
          (e(d) ? () => s(u, null) : null)?.apply(this, a);
        }), f("focus", r, function(...a) {
          (e(d) ? () => s(u, o + 1) : null)?.apply(this, a);
        }), f("blur", r, function(...a) {
          (e(d) ? () => s(u, null) : null)?.apply(this, a);
        }), f("keydown", r, (a) => e(d) && a.key === "Enter" && M(o + 1)), f("click", r, () => M(o + 1)), P(J, r);
      }), k(_), P(t, _);
    },
    $$slots: { default: !0 },
    $$legacy: !0
  }), ee();
}
export {
  fe as default
};
