import { g as wt, p as u, h as q, Z as Ct, l as m, i as Y, j as t, k as kt, m as Pt, R as a, n as Mt, q as N, S as tt, d as P, H as g, _ as At, w as Tt, x as G, aj as Ft, y as Rt, z as v, a7 as zt, aR as et, B as b, s as M, u as ot, A as S, r as Bt, t as Dt, a as It, cN as jt, aM as qt, f as H } from "./index-CMyk0zjR.js";
import { a as Nt, F as Gt } from "./FormBlockComponent-CgimH4gK.js";
var Ht = H("<!> <!>", 1), Ot = H("<div></div>"), Ut = H("<!> <!> <!> <!>", 1);
function Jt(rt, s) {
  wt(s, !1);
  const y = () => G(W, "$component", A), O = () => G(Ft, "$builderStore", A), at = () => G(Z, "$context", A), [A, st] = Rt(), T = v(), F = v(), R = v(), x = v();
  let w = u(s, "actionType", 8), nt = u(s, "rowId", 8), lt = u(s, "noRowsMessage", 8), U = u(s, "steps", 8), f = u(s, "dataSource", 8), V = u(s, "buttonPosition", 8, "bottom"), ct = u(s, "size", 8);
  const { fetchDatasourceSchema: it, generateGoldenSample: ut } = q("sdk"), W = q("component"), Z = q("context"), E = zt(1);
  Ct("current-step", E);
  let C = v();
  const J = () => {
    const e = et(W).id, c = et(Z)[`${e}-provider`]?.rows || [], r = ut(c);
    return { [`${e}-repeater`]: r };
  }, dt = (e, c, r) => {
    if (!c)
      return;
    let i = Math.min(r || 0, e.length - 1);
    i = Math.max(i, 0), E.set(i + 1);
  }, pt = async (e) => {
    b(C, await it(e) || {});
  }, mt = (e, c) => e?.length ? e.filter((r) => r.active) : Object.values(c || {}).filter((r) => !r.autocolumn).map((r) => ({ name: r.name, active: !0 })), gt = (e, c, r) => {
    const i = e?.length ? e : [{}];
    return i.map((z, k) => {
      const { title: B, fields: $, buttons: o } = z, _ = jt({
        _id: r,
        stepCount: i.length,
        currentStep: k,
        actionType: w(),
        dataSource: f()
      });
      return {
        ...z,
        _stepId: qt(),
        fields: mt($ || [], c),
        title: B ?? _.title,
        buttons: o || _.buttons
      };
    });
  };
  m(() => y(), () => {
    b(T, y().id);
  }), m(() => y(), () => {
    b(F, y().selected);
  }), m(() => O(), () => {
    b(R, O().metadata?.step);
  }), m(() => Y(f()), () => {
    pt(f());
  }), m(() => (Y(U()), t(C), t(T)), () => {
    b(x, gt(U(), t(C), t(T)));
  }), m(() => (t(x), t(F), t(R)), () => {
    dt(t(x), t(F), t(R));
  }), kt();
  var ft = { getAdditionalDataContext: J };
  Pt(), Nt(rt, {
    get actionType() {
      return w();
    },
    get dataSource() {
      return f();
    },
    get rowId() {
      return nt();
    },
    get noRowsMessage() {
      return lt();
    },
    children: (e, c) => {
      {
        let r = g(() => ({
          size: ct(),
          dataSource: f(),
          actionType: w() === "Create" ? "Create" : "Update",
          readonly: w() === "View"
        }));
        a(e, {
          type: "form",
          context: "form",
          get props() {
            return t(r);
          },
          styles: {
            normal: {
              width: "600px",
              "margin-left": "auto",
              "margin-right": "auto"
            }
          },
          children: (i, z) => {
            var k = Mt(), B = N(k);
            tt(B, 3, () => t(x), ($) => $._stepId, ($, o, _) => {
              {
                let _t = g(() => ({
                  step: t(_) + 1,
                  _instanceName: `Step ${t(_) + 1}`
                }));
                a($, {
                  type: "formstep",
                  get props() {
                    return t(_t);
                  },
                  children: (ht, Vt) => {
                    a(ht, {
                      type: "container",
                      props: {
                        gap: "M",
                        direction: "column",
                        hAlign: "stretch",
                        vAlign: "top",
                        size: "shrink"
                      },
                      children: (vt, Wt) => {
                        var K = Ut(), L = N(K);
                        a(L, {
                          type: "container",
                          props: { direction: "column", gap: "S" },
                          order: 0,
                          children: (n, D) => {
                            a(n, {
                              type: "container",
                              props: {
                                direction: "row",
                                hAlign: "stretch",
                                vAlign: "center",
                                gap: "M",
                                wrap: !0
                              },
                              order: 0,
                              children: (d, I) => {
                                var l = Ht(), p = N(l);
                                {
                                  let h = g(() => (t(o), S(() => ({ text: `## ${t(o).title}` }))));
                                  a(p, {
                                    type: "textv2",
                                    get props() {
                                      return t(h);
                                    }
                                  });
                                }
                                var j = M(p, 2);
                                {
                                  var yt = (h) => {
                                    {
                                      let xt = g(() => (t(o), S(() => ({ buttons: t(o).buttons }))));
                                      a(h, {
                                        type: "buttongroup",
                                        get props() {
                                          return t(xt);
                                        }
                                      });
                                    }
                                  };
                                  ot(j, (h) => {
                                    V() === "top" && h(yt);
                                  });
                                }
                                P(d, l);
                              },
                              $$slots: { default: !0 }
                            });
                          },
                          $$slots: { default: !0 }
                        });
                        var Q = M(L, 2);
                        {
                          let n = g(() => (t(o), S(() => ({ text: t(o).desc }))));
                          a(Q, {
                            type: "textv2",
                            get props() {
                              return t(n);
                            },
                            order: 1
                          });
                        }
                        var X = M(Q, 2);
                        a(X, {
                          type: "container",
                          order: 2,
                          children: (n, D) => {
                            var d = Ot();
                            let I;
                            tt(d, 7, () => (t(o), S(() => t(o).fields)), (l, p) => `${l.field || l.name}_${p}`, (l, p, j) => {
                              Gt(l, {
                                get field() {
                                  return t(p);
                                },
                                get schema() {
                                  return t(C);
                                },
                                get order() {
                                  return t(j);
                                }
                              });
                            }), Bt(d), Dt((l) => I = It(d, 1, "form-block fields svelte-6gdv45", null, I, l), [() => ({ mobile: at().device.mobile })]), P(n, d);
                          },
                          $$slots: { default: !0 }
                        });
                        var bt = M(X, 2);
                        {
                          var St = (n) => {
                            {
                              let D = g(() => (t(o), S(() => ({
                                buttons: t(o).buttons,
                                collapsed: t(o).buttonsCollapsed,
                                collapsedText: t(o).buttonsCollapsedText
                              }))));
                              a(n, {
                                type: "buttongroup",
                                get props() {
                                  return t(D);
                                },
                                order: 3
                              });
                            }
                          };
                          ot(bt, (n) => {
                            V() === "bottom" && n(St);
                          });
                        }
                        P(vt, K);
                      },
                      $$slots: { default: !0 }
                    });
                  },
                  $$slots: { default: !0 }
                });
              }
            }), P(i, k);
          },
          $$slots: { default: !0 }
        });
      }
    },
    $$slots: { default: !0 }
  }), At(s, "getAdditionalDataContext", J);
  var $t = Tt(ft);
  return st(), $t;
}
export {
  Jt as default
};
