import { bJ as Oe, g as Qe, p as i, h as w, bf as Re, o as Ue, l as F, i as s, j as r, k as We, m as Ye, n as L, q as k, u as T, d, w as Ze, x as le, y as $e, z as A, a7 as se, H as he, A as c, B as p, cw as et, E as ye, c as _, al as tt, r as b, X as at, t as M, a2 as Se, a as xe, b as re, e as Fe, s as N, v as lt, f as V, I as ke } from "./index-CMyk0zjR.js";
import Ae from "./Placeholder-DdLpQoxl.js";
import { I as st } from "./InnerForm-DfbhhpVQ.js";
var rt = V("<label> </label>"), ot = V('<div class="error svelte-16ch0tk"><!> <span class="svelte-16ch0tk"> </span></div>'), it = V('<div class="helpText svelte-16ch0tk"><!> <span class="svelte-16ch0tk"> </span></div>'), nt = V("<!> <!>", 1), dt = V('<div><!> <div class="spectrum-Form-itemField svelte-16ch0tk"><!></div></div>');
function ft(Ie, e) {
  const Pe = Oe(e, ["children", "$$slots", "$$events", "$$legacy"]);
  Qe(e, !1);
  const n = () => le(ze, "$component", K), X = () => le(Be, "$formStep", K), oe = () => le(ve, "$fieldInfo", K), [K, Ce] = $e(), q = A(), ie = A(), ne = A();
  let de = i(e, "label", 24, () => {
  }), O = i(e, "field", 24, () => {
  }), o = i(e, "fieldState", 12), z = i(e, "fieldApi", 12), v = i(e, "fieldSchema", 12), Q = i(e, "defaultValue", 24, () => {
  }), g = i(e, "type", 8), j = i(e, "disabled", 8, !1), I = i(e, "readonly", 8, !1), R = i(e, "validation", 8), B = i(e, "span", 8, 6), fe = i(e, "helpText", 24, () => {
  });
  const ce = w("form"), we = w("form-step"), Le = w("field-group"), { styleable: Te, builderStore: Ve, Provider: qe } = w("sdk"), ze = w("component"), je = ce?.formApi, U = Le?.labelPosition || "above";
  let W = A(), Y = A(!1), D = A();
  const Be = we || se(1), ve = Re({
    field: O() || n().name,
    type: g(),
    defaultValue: Q(),
    disabled: j(),
    readonly: I(),
    validation: R(),
    formStep: X() || 1
  }), De = (a) => {
    p(W, je?.registerField(a.field, a.type, a.defaultValue, a.disabled, a.readonly, a.validation, a.formStep));
  }, Ee = (a) => {
    if (r(Y)) {
      const Z = a.target;
      Ve.actions.updateProp("label", Z.textContent);
    }
    p(Y, !1);
  };
  Ue(() => {
    z()?.deregister(), r(ie)?.();
  }), F(
    () => (s(O()), n(), s(g()), s(Q()), s(j()), s(I()), s(R()), X()),
    () => {
      ve.set({
        field: O() || n().name,
        type: g(),
        defaultValue: Q(),
        disabled: j(),
        readonly: I(),
        validation: R(),
        formStep: X() || 1
      });
    }
  ), F(() => oe(), () => {
    De(oe());
  }), F(() => r(W), () => {
    p(ie, r(W)?.subscribe((a) => {
      o(a?.fieldState), z(a?.fieldApi), v(a?.fieldSchema);
    }));
  }), F(() => s(v()), () => {
    p(q, v()?.type !== "formula" && v()?.type !== "bigint" ? v()?.type : "string");
  }), F(() => (n(), r(D)), () => {
    n().editing && r(D)?.focus();
  }), F(() => {
  }, () => {
    p(ne, U === "above" ? "" : `spectrum-FieldLabel--${U}`);
  }), We(), Ye();
  {
    let a = he(() => (s(o()), c(() => ({ value: o()?.value }))));
    qe(Ie, {
      get data() {
        return r(a);
      },
      children: (Z, ct) => {
        var ue = L(), Ge = k(ue);
        {
          var He = (h) => {
            {
              let u = he(() => (s(se), c(() => se(1))));
              st(h, {
                get disabled() {
                  return j();
                },
                get readonly() {
                  return I();
                },
                get currentStep() {
                  return r(u);
                },
                provideContext: !1,
                children: (E, $) => {
                  var P = L(), ee = k(P);
                  ft(ee, et(() => Pe, {
                    get fieldState() {
                      return o();
                    },
                    set fieldState(f) {
                      o(f);
                    },
                    get fieldApi() {
                      return z();
                    },
                    set fieldApi(f) {
                      z(f);
                    },
                    get fieldSchema() {
                      return v();
                    },
                    set fieldSchema(f) {
                      v(f);
                    },
                    children: (f, me) => {
                      var l = L(), t = k(l);
                      ye(t, e, "default", {}, null), d(f, l);
                    },
                    $$slots: { default: !0 },
                    $$legacy: !0
                  })), d(E, P);
                },
                $$slots: { default: !0 }
              });
            }
          }, Je = (h) => {
            var u = dt();
            let E;
            var $ = _(u);
            tt($, () => (n(), c(() => n().editing)), (l) => {
              var t = rt();
              let G;
              var te = _(t, !0);
              b(t), at(t, (m) => p(D, m), () => r(D)), M(
                (m) => {
                  Se(t, "contenteditable", (n(), c(() => n().editing))), Se(t, "for", (s(o()), c(() => o()?.fieldId))), G = xe(t, 1, `spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${r(ne)}`, "svelte-16ch0tk", G, m), re(te, de() || " ");
                },
                [() => ({ hidden: !de(), readonly: I() })]
              ), Fe("blur", t, function(...m) {
                (n().editing ? Ee : null)?.apply(this, m);
              }), Fe("input", t, () => p(Y, !0)), d(l, t);
            });
            var P = N($, 2), ee = _(P);
            {
              var f = (l) => {
                Ae(l, {});
              }, me = (l) => {
                var t = L(), G = k(t);
                {
                  var te = (y) => {
                    Ae(y, {
                      text: "This Field setting is the wrong data type for this component"
                    });
                  }, m = (y) => {
                    var pe = nt(), _e = k(pe);
                    ye(_e, e, "default", {}, null);
                    var Me = N(_e, 2);
                    {
                      var Ne = (S) => {
                        var x = ot(), H = _(x);
                        ke(H, { name: "warning" });
                        var J = N(H, 2), C = _(J, !0);
                        b(J), b(x), M(() => re(C, (s(o()), c(() => o().error)))), d(S, x);
                      }, Xe = (S) => {
                        var x = L(), H = k(x);
                        {
                          var J = (C) => {
                            var ae = it(), be = _(ae);
                            ke(be, { name: "question" });
                            var ge = N(be, 2), Ke = _(ge, !0);
                            b(ge), b(ae), M(() => re(Ke, fe())), d(C, ae);
                          };
                          T(
                            H,
                            (C) => {
                              fe() && C(J);
                            },
                            !0
                          );
                        }
                        d(S, x);
                      };
                      T(Me, (S) => {
                        s(o()), c(() => o().error) ? S(Ne) : S(Xe, !1);
                      });
                    }
                    d(y, pe);
                  };
                  T(
                    G,
                    (y) => {
                      r(q), s(g()), c(() => r(q) && r(q) !== g() && !["options", "longform"].includes(g())) ? y(te) : y(m, !1);
                    },
                    !0
                  );
                }
                d(l, t);
              };
              T(ee, (l) => {
                o() ? l(me, !1) : l(f);
              });
            }
            b(P), b(u), lt(u, (l, t) => Te?.(l, t), () => n().styles), M((l) => E = xe(u, 1, "spectrum-Form-item svelte-16ch0tk", null, E, l), [
              () => ({
                "span-2": B() === 2,
                "span-3": B() === 3,
                "span-6": B() === 6 || !B(),
                above: U === "above"
              })
            ]), d(h, u);
          };
          T(Ge, (h) => {
            ce ? h(Je, !1) : h(He);
          });
        }
        d(Z, ue);
      },
      $$slots: { default: !0 }
    });
  }
  Ze(), Ce();
}
export {
  ft as F
};
