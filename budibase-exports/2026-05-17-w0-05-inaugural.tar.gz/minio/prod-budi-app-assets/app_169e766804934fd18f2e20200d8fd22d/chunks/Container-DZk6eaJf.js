import { g as U, y as ve, p as b, h as F, bf as xe, W as ze, j as e, B as a, l, cu as H, cv as G, k as V, m as ue, c as fe, u as le, s as ie, r as J, X as $e, v as me, am as pe, e as ge, t as he, a as be, a2 as K, d as R, w as Y, x as L, z as n, a7 as Ae, q as P, S as re, T as ce, n as Q, E as Z, f as I, i as N, aH as Ee, bJ as qe, bt as Me, cw as Oe } from "./index-CMyk0zjR.js";
var Se = I('<div class="placeholder-h svelte-18tp3wn"></div>'), He = I('<div class="placeholder-v svelte-18tp3wn"></div>'), Le = I('<div class="underlay-h svelte-18tp3wn"></div> <div class="underlay-v svelte-18tp3wn"></div>', 1), Ne = I("<div><!> <!></div>");
function je(j, o) {
  U(o, !1);
  const M = () => L(k, "$builderStore", d), c = () => L(T, "$component", d), x = () => L(X, "$children", d), p = () => L(D, "$context", d), z = () => L(te, "$styles", d), [d, $] = ve(), u = n(), A = n(), v = n(), E = n(), q = n(), _ = n(), w = n(), y = n();
  let O = b(o, "onClick", 8);
  const T = F("component"), { styleable: W, builderStore: k } = F("sdk"), D = F("context");
  let B = n(), g = n(), C = n(), X = Ae({}), ee = n(!1), te = xe({});
  const _e = (t, s, i) => {
    const m = s ? "mobileRowEnd" : "desktopRowEnd";
    let r = 2;
    for (let h of Object.keys(t))
      t[h][m] > r && (r = t[h][m]);
    let S = r - 1;
    return i ? Math.ceil((S + 10) / 10) * 10 : S;
  }, se = (t) => {
    X.update((s) => ({
      ...s,
      [t.dataset.id]: {
        desktopRowEnd: parseInt(t.dataset.gridDesktopRowEnd),
        mobileRowEnd: parseInt(t.dataset.gridMobileRowEnd)
      }
    }));
  }, we = (t) => {
    X.update((s) => (delete s[t.dataset.id], { ...s }));
  }, ye = (t) => {
    const s = new ResizeObserver((i) => {
      if (!i?.[0])
        return;
      const m = i[0].target;
      a(B, m.clientWidth), a(g, m.clientHeight);
    });
    return s.observe(t), s;
  };
  ze(() => {
    let t, s;
    return s = ye(e(C)), t = new MutationObserver((i) => {
      for (let m of i) {
        const { target: r, type: S, addedNodes: h, removedNodes: oe } = m;
        r === e(C) ? h[0]?.classList?.contains("component") ? se(h[0]) : oe[0]?.classList?.contains("component") && we(oe[0]) : S === "attributes" && r.parentNode === e(C) && r.classList.contains("component") && se(r);
      }
    }), t.observe(e(C), {
      childList: !0,
      attributes: !0,
      subtree: !0,
      attributeFilter: ["data-grid-desktop-row-end", "data-grid-mobile-row-end"]
    }), a(ee, !0), () => {
      t?.disconnect(), s?.disconnect();
    };
  }), l(() => M(), () => {
    a(u, M().inBuilder);
  }), l(() => (c(), e(u)), () => {
    a(A, c().isRoot && e(u));
  }), l(() => p(), () => {
    a(w, p().device.mobile);
  }), l(() => (x(), e(w), e(A)), () => {
    a(v, _e(x(), e(w), e(A)));
  }), l(() => (e(v), H), () => {
    a(E, e(v) * H);
  }), l(() => (e(g), H), () => {
    a(q, Math.floor(e(g) / H));
  }), l(() => (e(v), e(q)), () => {
    a(_, Math.max(e(v), e(q)));
  }), l(() => (e(B), G), () => {
    a(y, e(B) / G);
  }), l(
    () => (c(), e(E), e(_), e(y), H),
    () => {
      te.set({
        ...c().styles,
        normal: {
          ...c().styles?.normal,
          "--height": `${e(E)}px`,
          "--min-height": c().styles?.normal?.height || 0,
          "--cols": G,
          "--rows": e(_),
          "--col-size": e(y),
          "--row-size": H
        }
      });
    }
  ), V(), ue();
  var f = Ne();
  let ae;
  var ne = fe(f);
  {
    var ke = (t) => {
      var s = Le(), i = P(s);
      re(i, 5, () => ({ length: e(_) }), ce, (r, S) => {
        var h = Se();
        R(r, h);
      }), J(i);
      var m = ie(i, 2);
      re(m, 5, () => ({ length: G }), ce, (r, S) => {
        var h = He();
        R(r, h);
      }), J(m), R(t, s);
    };
    le(ne, (t) => {
      e(u) && t(ke);
    });
  }
  var Ce = ie(ne, 2);
  {
    var Re = (t) => {
      var s = Q(), i = P(s);
      Z(i, o, "default", {}, null), R(t, s);
    };
    le(Ce, (t) => {
      e(ee) && t(Re);
    });
  }
  J(f), $e(f, (t) => a(C, t), () => e(C)), me(f, (t, s) => W?.(t, s), z), pe(() => ge("click", f, function(...t) {
    O()?.apply(this, t);
  })), he(
    (t) => {
      ae = be(f, 1, "grid svelte-18tp3wn", null, ae, t), K(f, "data-cols", G), K(f, "data-col-size", e(y)), K(f, "data-required-rows", e(v));
    },
    [() => ({ mobile: e(w), clickable: !!O() })]
  ), R(j, f), Y(), $();
}
var Be = I("<div><!></div>");
function de(j, o) {
  U(o, !1);
  const M = () => L(E, "$component", c), [c, x] = ve(), p = n(), z = n(), d = n(), $ = n(), u = n(), A = n(), { styleable: v } = F("sdk"), E = F("component");
  let q = b(o, "direction", 8), _ = b(o, "hAlign", 8), w = b(o, "vAlign", 8), y = b(o, "size", 8), O = b(o, "gap", 8), T = b(o, "wrap", 8), W = b(o, "onClick", 8);
  l(() => N(q()), () => {
    a(p, q() ? `flex-container direction-${q()}` : "");
  }), l(() => N(_()), () => {
    a(z, _() ? `hAlign-${_()}` : "");
  }), l(() => N(w()), () => {
    a(d, w() ? `vAlign-${w()}` : "");
  }), l(() => N(y()), () => {
    a($, y() ? `size-${y()}` : "");
  }), l(() => N(O()), () => {
    a(u, O() ? `gap-${O()}` : "");
  }), l(
    () => (e(p), e(z), e(d), e($), e(u)),
    () => {
      a(A, [
        e(p),
        e(z),
        e(d),
        e($),
        e(u)
      ].join(" "));
    }
  ), V(), ue();
  var k = Be();
  let D;
  var B = fe(k);
  Z(B, o, "default", {}, null), J(k), me(k, (g, C) => v?.(g, C), () => M().styles), pe(() => ge("click", k, function(...g) {
    W()?.apply(this, g);
  })), he((g) => D = be(k, 1, Ee(e(A)), "svelte-11rnque", D, g), [() => ({ clickable: !!W(), wrap: T() })]), R(j, k), Y(), x();
}
function Fe(j, o) {
  const M = qe(o, ["children", "$$slots", "$$events", "$$legacy"]);
  U(o, !1);
  const c = n();
  let x = b(o, "layout", 8, "flex");
  l(() => (N(x()), de), () => {
    a(c, x() === "grid" ? je : de);
  }), V();
  var p = Q(), z = P(p);
  Me(z, () => e(c), (d, $) => {
    $(d, Oe(() => M, {
      children: (u, A) => {
        var v = Q(), E = P(v);
        Z(E, o, "default", {}, null), R(u, v);
      },
      $$slots: { default: !0 }
    }));
  }), R(j, p), Y();
}
export {
  Fe as default
};
