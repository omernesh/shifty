import { au as g, cz as d, bh as c, bi as y, cM as m } from "./index-CMyk0zjR.js";
const h = {
  string: "stringfield",
  options: "optionsfield",
  number: "numberfield",
  bigint: "bigintfield",
  datetime: "datetimefield",
  boolean: "booleanfield",
  formula: "stringfield"
}, b = async (a, i) => {
  if (!a?.length || !i)
    return [];
  let o = [];
  for (let t of a) {
    let e = i[t]?.type;
    if (t.includes(".")) {
      const s = t.split("."), l = s[0], n = s.slice(1).join("."), f = i[l];
      f?.type === "link" && (e = (await g.fetchTableDefinition(f.tableId))?.schema?.[n]?.type);
    }
    const r = h[e];
    r && o.push({
      name: t,
      componentType: r,
      type: e
    });
  }
  return o.slice(0, 5);
}, T = (a, i, o) => {
  if (!i?.length)
    return a;
  const t = [];
  return i?.forEach((e) => {
    const r = e.name.split(".").map(d).join("."), s = e.type === "string" || e.type === "formula", l = e.type === "datetime", n = `${d(o)}.${r}`;
    if (l) {
      t.push({
        field: e.name,
        type: e.type,
        operator: "rangeLow",
        valueType: "Binding",
        value: `{{ ${n} }}`
      });
      let p = `{{ date (add (date ${n} "x") 86399999) "YYYY-MM-DDTHH:mm:ss.SSSZ" }}`;
      p = `{{#if ${n} }}${p}{{/if}}`, t.push({
        field: e.name,
        type: e.type,
        operator: "rangeHigh",
        valueType: "Binding",
        value: p
      });
    } else
      t.push({
        field: e.name,
        type: e.type,
        operator: s ? c.STRING : c.EQUAL,
        valueType: "Binding",
        value: `{{ ${n} }}`
      });
  }), {
    logicalOperator: y.ALL,
    onEmptyFilter: m.RETURN_ALL,
    groups: [
      ...a?.groups || [],
      {
        logicalOperator: y.ALL,
        filters: t
      }
    ]
  };
};
export {
  T as a,
  b as e
};
