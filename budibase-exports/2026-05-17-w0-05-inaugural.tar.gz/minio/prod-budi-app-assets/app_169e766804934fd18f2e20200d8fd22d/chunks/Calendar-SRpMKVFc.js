import { g as Fr, p as N, W as zr, j as E, B as z, l as V, i as M, k as Ur, m as Wr, X as Qt, t as Lr, d as jr, _ as Ns, w as Vr, z as W, f as Gr, a as Qr, aH as Os, ap as Hs, h as Pn, v as Ps, a2 as Bs, y as Fs, c as zs, r as Us, x as Ws } from "./index-CMyk0zjR.js";
var _t, S, qr, Yr, Ne, Ee, Bn, Zr, $r, gt = {}, Jr = [], Ls = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
function ae(t, e) {
  for (var n in e) t[n] = e[n];
  return t;
}
function Kr(t) {
  var e = t.parentNode;
  e && e.removeChild(t);
}
function u(t, e, n) {
  var r, i, s, l = {};
  for (s in e) s == "key" ? r = e[s] : s == "ref" ? i = e[s] : l[s] = e[s];
  if (arguments.length > 2 && (l.children = arguments.length > 3 ? _t.call(arguments, 2) : n), typeof t == "function" && t.defaultProps != null) for (s in t.defaultProps) l[s] === void 0 && (l[s] = t.defaultProps[s]);
  return ot(t, l, r, i, null);
}
function ot(t, e, n, r, i) {
  var s = { type: t, props: e, key: n, ref: r, __k: null, __: null, __b: 0, __e: null, __d: void 0, __c: null, __h: null, constructor: void 0, __v: i ?? ++qr };
  return i == null && S.vnode != null && S.vnode(s), s;
}
function L() {
  return { current: null };
}
function k(t) {
  return t.children;
}
function js(t, e, n, r, i) {
  var s;
  for (s in n) s === "children" || s === "key" || s in e || pt(t, s, null, n[s], r);
  for (s in e) i && typeof e[s] != "function" || s === "children" || s === "key" || s === "value" || s === "checked" || n[s] === e[s] || pt(t, s, e[s], n[s], r);
}
function Fn(t, e, n) {
  e[0] === "-" ? t.setProperty(e, n ?? "") : t[e] = n == null ? "" : typeof n != "number" || Ls.test(e) ? n : n + "px";
}
function pt(t, e, n, r, i) {
  var s;
  e: if (e === "style") if (typeof n == "string") t.style.cssText = n;
  else {
    if (typeof r == "string" && (t.style.cssText = r = ""), r) for (e in r) n && e in n || Fn(t.style, e, "");
    if (n) for (e in n) r && n[e] === r[e] || Fn(t.style, e, n[e]);
  }
  else if (e[0] === "o" && e[1] === "n") s = e !== (e = e.replace(/Capture$/, "")), e = e.toLowerCase() in t ? e.toLowerCase().slice(2) : e.slice(2), t.l || (t.l = {}), t.l[e + s] = n, n ? r || t.addEventListener(e, s ? Un : zn, s) : t.removeEventListener(e, s ? Un : zn, s);
  else if (e !== "dangerouslySetInnerHTML") {
    if (i) e = e.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
    else if (e !== "width" && e !== "height" && e !== "href" && e !== "list" && e !== "form" && e !== "tabIndex" && e !== "download" && e in t) try {
      t[e] = n ?? "";
      break e;
    } catch {
    }
    typeof n == "function" || (n == null || n === !1 && e.indexOf("-") == -1 ? t.removeAttribute(e) : t.setAttribute(e, n));
  }
}
function zn(t) {
  Ne = !0;
  try {
    return this.l[t.type + !1](S.event ? S.event(t) : t);
  } finally {
    Ne = !1;
  }
}
function Un(t) {
  Ne = !0;
  try {
    return this.l[t.type + !0](S.event ? S.event(t) : t);
  } finally {
    Ne = !1;
  }
}
function G(t, e) {
  this.props = t, this.context = e;
}
function Le(t, e) {
  if (e == null) return t.__ ? Le(t.__, t.__.__k.indexOf(t) + 1) : null;
  for (var n; e < t.__k.length; e++) if ((n = t.__k[e]) != null && n.__e != null) return n.__e;
  return typeof t.type == "function" ? Le(t) : null;
}
function Xr(t) {
  var e, n;
  if ((t = t.__) != null && t.__c != null) {
    for (t.__e = t.__c.base = null, e = 0; e < t.__k.length; e++) if ((n = t.__k[e]) != null && n.__e != null) {
      t.__e = t.__c.base = n.__e;
      break;
    }
    return Xr(t);
  }
}
function Vs(t) {
  Ne ? setTimeout(t) : Zr(t);
}
function qt(t) {
  (!t.__d && (t.__d = !0) && Ee.push(t) && !mt.__r++ || Bn !== S.debounceRendering) && ((Bn = S.debounceRendering) || Vs)(mt);
}
function mt() {
  var t, e, n, r, i, s, l, a;
  for (Ee.sort(function(o, d) {
    return o.__v.__b - d.__v.__b;
  }); t = Ee.shift(); ) t.__d && (e = Ee.length, r = void 0, i = void 0, l = (s = (n = t).__v).__e, (a = n.__P) && (r = [], (i = ae({}, s)).__v = s.__v + 1, on(a, s, i, n.__n, a.ownerSVGElement !== void 0, s.__h != null ? [l] : null, r, l ?? Le(s), s.__h), ii(r, s), s.__e != l && Xr(s)), Ee.length > e && Ee.sort(function(o, d) {
    return o.__v.__b - d.__v.__b;
  }));
  mt.__r = 0;
}
function ei(t, e, n, r, i, s, l, a, o, d) {
  var c, g, h, f, m, y, v, b = r && r.__k || Jr, A = b.length;
  for (n.__k = [], c = 0; c < e.length; c++) if ((f = n.__k[c] = (f = e[c]) == null || typeof f == "boolean" ? null : typeof f == "string" || typeof f == "number" || typeof f == "bigint" ? ot(null, f, null, null, f) : Array.isArray(f) ? ot(k, { children: f }, null, null, null) : f.__b > 0 ? ot(f.type, f.props, f.key, f.ref ? f.ref : null, f.__v) : f) != null) {
    if (f.__ = n, f.__b = n.__b + 1, (h = b[c]) === null || h && f.key == h.key && f.type === h.type) b[c] = void 0;
    else for (g = 0; g < A; g++) {
      if ((h = b[g]) && f.key == h.key && f.type === h.type) {
        b[g] = void 0;
        break;
      }
      h = null;
    }
    on(t, f, h = h || gt, i, s, l, a, o, d), m = f.__e, (g = f.ref) && h.ref != g && (v || (v = []), h.ref && v.push(h.ref, null, f), v.push(g, f.__c || m, f)), m != null ? (y == null && (y = m), typeof f.type == "function" && f.__k === h.__k ? f.__d = o = ti(f, o, t) : o = ni(t, f, h, b, m, o), typeof n.type == "function" && (n.__d = o)) : o && h.__e == o && o.parentNode != t && (o = Le(h));
  }
  for (n.__e = y, c = A; c--; ) b[c] != null && (typeof n.type == "function" && b[c].__e != null && b[c].__e == n.__d && (n.__d = ri(r).nextSibling), li(b[c], b[c]));
  if (v) for (c = 0; c < v.length; c++) si(v[c], v[++c], v[++c]);
}
function ti(t, e, n) {
  for (var r, i = t.__k, s = 0; i && s < i.length; s++) (r = i[s]) && (r.__ = t, e = typeof r.type == "function" ? ti(r, e, n) : ni(n, r, r, i, r.__e, e));
  return e;
}
function vt(t, e) {
  return e = e || [], t == null || typeof t == "boolean" || (Array.isArray(t) ? t.some(function(n) {
    vt(n, e);
  }) : e.push(t)), e;
}
function ni(t, e, n, r, i, s) {
  var l, a, o;
  if (e.__d !== void 0) l = e.__d, e.__d = void 0;
  else if (n == null || i != s || i.parentNode == null) e: if (s == null || s.parentNode !== t) t.appendChild(i), l = null;
  else {
    for (a = s, o = 0; (a = a.nextSibling) && o < r.length; o += 1) if (a == i) break e;
    t.insertBefore(i, s), l = s;
  }
  return l !== void 0 ? l : i.nextSibling;
}
function ri(t) {
  var e, n, r;
  if (t.type == null || typeof t.type == "string") return t.__e;
  if (t.__k) {
    for (e = t.__k.length - 1; e >= 0; e--) if ((n = t.__k[e]) && (r = ri(n))) return r;
  }
  return null;
}
function on(t, e, n, r, i, s, l, a, o) {
  var d, c, g, h, f, m, y, v, b, A, w, D, F, x, P, _ = e.type;
  if (e.constructor !== void 0) return null;
  n.__h != null && (o = n.__h, a = e.__e = n.__e, e.__h = null, s = [a]), (d = S.__b) && d(e);
  try {
    e: if (typeof _ == "function") {
      if (v = e.props, b = (d = _.contextType) && r[d.__c], A = d ? b ? b.props.value : d.__ : r, n.__c ? y = (c = e.__c = n.__c).__ = c.__E : ("prototype" in _ && _.prototype.render ? e.__c = c = new _(v, A) : (e.__c = c = new G(v, A), c.constructor = _, c.render = Qs), b && b.sub(c), c.props = v, c.state || (c.state = {}), c.context = A, c.__n = r, g = c.__d = !0, c.__h = [], c._sb = []), c.__s == null && (c.__s = c.state), _.getDerivedStateFromProps != null && (c.__s == c.state && (c.__s = ae({}, c.__s)), ae(c.__s, _.getDerivedStateFromProps(v, c.__s))), h = c.props, f = c.state, c.__v = e, g) _.getDerivedStateFromProps == null && c.componentWillMount != null && c.componentWillMount(), c.componentDidMount != null && c.__h.push(c.componentDidMount);
      else {
        if (_.getDerivedStateFromProps == null && v !== h && c.componentWillReceiveProps != null && c.componentWillReceiveProps(v, A), !c.__e && c.shouldComponentUpdate != null && c.shouldComponentUpdate(v, c.__s, A) === !1 || e.__v === n.__v) {
          for (e.__v !== n.__v && (c.props = v, c.state = c.__s, c.__d = !1), e.__e = n.__e, e.__k = n.__k, e.__k.forEach(function(K) {
            K && (K.__ = e);
          }), w = 0; w < c._sb.length; w++) c.__h.push(c._sb[w]);
          c._sb = [], c.__h.length && l.push(c);
          break e;
        }
        c.componentWillUpdate != null && c.componentWillUpdate(v, c.__s, A), c.componentDidUpdate != null && c.__h.push(function() {
          c.componentDidUpdate(h, f, m);
        });
      }
      if (c.context = A, c.props = v, c.__P = t, D = S.__r, F = 0, "prototype" in _ && _.prototype.render) {
        for (c.state = c.__s, c.__d = !1, D && D(e), d = c.render(c.props, c.state, c.context), x = 0; x < c._sb.length; x++) c.__h.push(c._sb[x]);
        c._sb = [];
      } else do
        c.__d = !1, D && D(e), d = c.render(c.props, c.state, c.context), c.state = c.__s;
      while (c.__d && ++F < 25);
      c.state = c.__s, c.getChildContext != null && (r = ae(ae({}, r), c.getChildContext())), g || c.getSnapshotBeforeUpdate == null || (m = c.getSnapshotBeforeUpdate(h, f)), P = d != null && d.type === k && d.key == null ? d.props.children : d, ei(t, Array.isArray(P) ? P : [P], e, n, r, i, s, l, a, o), c.base = e.__e, e.__h = null, c.__h.length && l.push(c), y && (c.__E = c.__ = null), c.__e = !1;
    } else s == null && e.__v === n.__v ? (e.__k = n.__k, e.__e = n.__e) : e.__e = Gs(n.__e, e, n, r, i, s, l, o);
    (d = S.diffed) && d(e);
  } catch (K) {
    e.__v = null, (o || s != null) && (e.__e = a, e.__h = !!o, s[s.indexOf(a)] = null), S.__e(K, e, n);
  }
}
function ii(t, e) {
  S.__c && S.__c(e, t), t.some(function(n) {
    try {
      t = n.__h, n.__h = [], t.some(function(r) {
        r.call(n);
      });
    } catch (r) {
      S.__e(r, n.__v);
    }
  });
}
function Gs(t, e, n, r, i, s, l, a) {
  var o, d, c, g = n.props, h = e.props, f = e.type, m = 0;
  if (f === "svg" && (i = !0), s != null) {
    for (; m < s.length; m++) if ((o = s[m]) && "setAttribute" in o == !!f && (f ? o.localName === f : o.nodeType === 3)) {
      t = o, s[m] = null;
      break;
    }
  }
  if (t == null) {
    if (f === null) return document.createTextNode(h);
    t = i ? document.createElementNS("http://www.w3.org/2000/svg", f) : document.createElement(f, h.is && h), s = null, a = !1;
  }
  if (f === null) g === h || a && t.data === h || (t.data = h);
  else {
    if (s = s && _t.call(t.childNodes), d = (g = n.props || gt).dangerouslySetInnerHTML, c = h.dangerouslySetInnerHTML, !a) {
      if (s != null) for (g = {}, m = 0; m < t.attributes.length; m++) g[t.attributes[m].name] = t.attributes[m].value;
      (c || d) && (c && (d && c.__html == d.__html || c.__html === t.innerHTML) || (t.innerHTML = c && c.__html || ""));
    }
    if (js(t, h, g, i, a), c) e.__k = [];
    else if (m = e.props.children, ei(t, Array.isArray(m) ? m : [m], e, n, r, i && f !== "foreignObject", s, l, s ? s[0] : n.__k && Le(n, 0), a), s != null) for (m = s.length; m--; ) s[m] != null && Kr(s[m]);
    a || ("value" in h && (m = h.value) !== void 0 && (m !== t.value || f === "progress" && !m || f === "option" && m !== g.value) && pt(t, "value", m, g.value, !1), "checked" in h && (m = h.checked) !== void 0 && m !== t.checked && pt(t, "checked", m, g.checked, !1));
  }
  return t;
}
function si(t, e, n) {
  try {
    typeof t == "function" ? t(e) : t.current = e;
  } catch (r) {
    S.__e(r, n);
  }
}
function li(t, e, n) {
  var r, i;
  if (S.unmount && S.unmount(t), (r = t.ref) && (r.current && r.current !== t.__e || si(r, null, e)), (r = t.__c) != null) {
    if (r.componentWillUnmount) try {
      r.componentWillUnmount();
    } catch (s) {
      S.__e(s, e);
    }
    r.base = r.__P = null, t.__c = void 0;
  }
  if (r = t.__k) for (i = 0; i < r.length; i++) r[i] && li(r[i], e, n || typeof t.type != "function");
  n || t.__e == null || Kr(t.__e), t.__ = t.__e = t.__d = void 0;
}
function Qs(t, e, n) {
  return this.constructor(t, n);
}
function je(t, e, n) {
  var r, i, s;
  S.__ && S.__(t, e), i = (r = !1) ? null : e.__k, s = [], on(e, t = e.__k = u(k, null, [t]), i || gt, gt, e.ownerSVGElement !== void 0, i ? null : e.firstChild ? _t.call(e.childNodes) : null, s, i ? i.__e : e.firstChild, r), ii(s, t);
}
function qs(t, e) {
  var n = { __c: e = "__cC" + $r++, __: t, Consumer: function(r, i) {
    return r.children(i);
  }, Provider: function(r) {
    var i, s;
    return this.getChildContext || (i = [], (s = {})[e] = this, this.getChildContext = function() {
      return s;
    }, this.shouldComponentUpdate = function(l) {
      this.props.value !== l.value && i.some(function(a) {
        a.__e = !0, qt(a);
      });
    }, this.sub = function(l) {
      i.push(l);
      var a = l.componentWillUnmount;
      l.componentWillUnmount = function() {
        i.splice(i.indexOf(l), 1), a && a.call(l);
      };
    }), r.children;
  } };
  return n.Provider.__ = n.Consumer.contextType = n;
}
_t = Jr.slice, S = { __e: function(t, e, n, r) {
  for (var i, s, l; e = e.__; ) if ((i = e.__c) && !i.__) try {
    if ((s = i.constructor) && s.getDerivedStateFromError != null && (i.setState(s.getDerivedStateFromError(t)), l = i.__d), i.componentDidCatch != null && (i.componentDidCatch(t, r || {}), l = i.__d), l) return i.__E = i;
  } catch (a) {
    t = a;
  }
  throw t;
} }, qr = 0, Yr = function(t) {
  return t != null && t.constructor === void 0;
}, Ne = !1, G.prototype.setState = function(t, e) {
  var n;
  n = this.__s != null && this.__s !== this.state ? this.__s : this.__s = ae({}, this.state), typeof t == "function" && (t = t(ae({}, n), this.props)), t && ae(n, t), t != null && this.__v && (e && this._sb.push(e), qt(this));
}, G.prototype.forceUpdate = function(t) {
  this.__v && (this.__e = !0, t && this.__h.push(t), qt(this));
}, G.prototype.render = k, Ee = [], Zr = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, mt.__r = 0, $r = 0;
var $, Mt, Wn, ai = [], It = [], Ln = S.__b, jn = S.__r, Vn = S.diffed, Gn = S.__c, Qn = S.unmount;
function Ys() {
  for (var t; t = ai.shift(); ) if (t.__P && t.__H) try {
    t.__H.__h.forEach(ct), t.__H.__h.forEach(Yt), t.__H.__h = [];
  } catch (e) {
    t.__H.__h = [], S.__e(e, t.__v);
  }
}
S.__b = function(t) {
  $ = null, Ln && Ln(t);
}, S.__r = function(t) {
  jn && jn(t);
  var e = ($ = t.__c).__H;
  e && (Mt === $ ? (e.__h = [], $.__h = [], e.__.forEach(function(n) {
    n.__N && (n.__ = n.__N), n.__V = It, n.__N = n.i = void 0;
  })) : (e.__h.forEach(ct), e.__h.forEach(Yt), e.__h = [])), Mt = $;
}, S.diffed = function(t) {
  Vn && Vn(t);
  var e = t.__c;
  e && e.__H && (e.__H.__h.length && (ai.push(e) !== 1 && Wn === S.requestAnimationFrame || ((Wn = S.requestAnimationFrame) || Zs)(Ys)), e.__H.__.forEach(function(n) {
    n.i && (n.__H = n.i), n.__V !== It && (n.__ = n.__V), n.i = void 0, n.__V = It;
  })), Mt = $ = null;
}, S.__c = function(t, e) {
  e.some(function(n) {
    try {
      n.__h.forEach(ct), n.__h = n.__h.filter(function(r) {
        return !r.__ || Yt(r);
      });
    } catch (r) {
      e.some(function(i) {
        i.__h && (i.__h = []);
      }), e = [], S.__e(r, n.__v);
    }
  }), Gn && Gn(t, e);
}, S.unmount = function(t) {
  Qn && Qn(t);
  var e, n = t.__c;
  n && n.__H && (n.__H.__.forEach(function(r) {
    try {
      ct(r);
    } catch (i) {
      e = i;
    }
  }), n.__H = void 0, e && S.__e(e, n.__v));
};
var qn = typeof requestAnimationFrame == "function";
function Zs(t) {
  var e, n = function() {
    clearTimeout(r), qn && cancelAnimationFrame(e), setTimeout(t);
  }, r = setTimeout(n, 100);
  qn && (e = requestAnimationFrame(n));
}
function ct(t) {
  var e = $, n = t.__c;
  typeof n == "function" && (t.__c = void 0, n()), $ = e;
}
function Yt(t) {
  var e = $;
  t.__c = t.__(), $ = e;
}
function $s(t, e) {
  for (var n in e) t[n] = e[n];
  return t;
}
function Yn(t, e) {
  for (var n in t) if (n !== "__source" && !(n in e)) return !0;
  for (var r in e) if (r !== "__source" && t[r] !== e[r]) return !0;
  return !1;
}
function Zn(t) {
  this.props = t;
}
(Zn.prototype = new G()).isPureReactComponent = !0, Zn.prototype.shouldComponentUpdate = function(t, e) {
  return Yn(this.props, t) || Yn(this.state, e);
};
var $n = S.__b;
S.__b = function(t) {
  t.type && t.type.__f && t.ref && (t.props.ref = t.ref, t.ref = null), $n && $n(t);
};
var Js = S.__e;
S.__e = function(t, e, n, r) {
  if (t.then) {
    for (var i, s = e; s = s.__; ) if ((i = s.__c) && i.__c) return e.__e == null && (e.__e = n.__e, e.__k = n.__k), i.__c(t, e);
  }
  Js(t, e, n, r);
};
var Jn = S.unmount;
function oi(t, e, n) {
  return t && (t.__c && t.__c.__H && (t.__c.__H.__.forEach(function(r) {
    typeof r.__c == "function" && r.__c();
  }), t.__c.__H = null), (t = $s({}, t)).__c != null && (t.__c.__P === n && (t.__c.__P = e), t.__c = null), t.__k = t.__k && t.__k.map(function(r) {
    return oi(r, e, n);
  })), t;
}
function ci(t, e, n) {
  return t && (t.__v = null, t.__k = t.__k && t.__k.map(function(r) {
    return ci(r, e, n);
  }), t.__c && t.__c.__P === e && (t.__e && n.insertBefore(t.__e, t.__d), t.__c.__e = !0, t.__c.__P = n)), t;
}
function Nt() {
  this.__u = 0, this.t = null, this.__b = null;
}
function di(t) {
  var e = t.__.__c;
  return e && e.__a && e.__a(t);
}
function et() {
  this.u = null, this.o = null;
}
S.unmount = function(t) {
  var e = t.__c;
  e && e.__R && e.__R(), e && t.__h === !0 && (t.type = null), Jn && Jn(t);
}, (Nt.prototype = new G()).__c = function(t, e) {
  var n = e.__c, r = this;
  r.t == null && (r.t = []), r.t.push(n);
  var i = di(r.__v), s = !1, l = function() {
    s || (s = !0, n.__R = null, i ? i(a) : a());
  };
  n.__R = l;
  var a = function() {
    if (!--r.__u) {
      if (r.state.__a) {
        var d = r.state.__a;
        r.__v.__k[0] = ci(d, d.__c.__P, d.__c.__O);
      }
      var c;
      for (r.setState({ __a: r.__b = null }); c = r.t.pop(); ) c.forceUpdate();
    }
  }, o = e.__h === !0;
  r.__u++ || o || r.setState({ __a: r.__b = r.__v.__k[0] }), t.then(l, l);
}, Nt.prototype.componentWillUnmount = function() {
  this.t = [];
}, Nt.prototype.render = function(t, e) {
  if (this.__b) {
    if (this.__v.__k) {
      var n = document.createElement("div"), r = this.__v.__k[0].__c;
      this.__v.__k[0] = oi(this.__b, n, r.__O = r.__P);
    }
    this.__b = null;
  }
  var i = e.__a && u(k, null, t.fallback);
  return i && (i.__h = null), [u(k, null, e.__a ? null : t.children), i];
};
var Kn = function(t, e, n) {
  if (++n[1] === n[0] && t.o.delete(e), t.props.revealOrder && (t.props.revealOrder[0] !== "t" || !t.o.size)) for (n = t.u; n; ) {
    for (; n.length > 3; ) n.pop()();
    if (n[1] < n[0]) break;
    t.u = n = n[2];
  }
};
function Ks(t) {
  return this.getChildContext = function() {
    return t.context;
  }, t.children;
}
function Xs(t) {
  var e = this, n = t.i;
  e.componentWillUnmount = function() {
    je(null, e.l), e.l = null, e.i = null;
  }, e.i && e.i !== n && e.componentWillUnmount(), t.__v ? (e.l || (e.i = n, e.l = { nodeType: 1, parentNode: n, childNodes: [], appendChild: function(r) {
    this.childNodes.push(r), e.i.appendChild(r);
  }, insertBefore: function(r, i) {
    this.childNodes.push(r), e.i.appendChild(r);
  }, removeChild: function(r) {
    this.childNodes.splice(this.childNodes.indexOf(r) >>> 1, 1), e.i.removeChild(r);
  } }), je(u(Ks, { context: e.context }, t.__v), e.l)) : e.l && e.componentWillUnmount();
}
function el(t, e) {
  var n = u(Xs, { __v: t, i: e });
  return n.containerInfo = e, n;
}
(et.prototype = new G()).__a = function(t) {
  var e = this, n = di(e.__v), r = e.o.get(t);
  return r[0]++, function(i) {
    var s = function() {
      e.props.revealOrder ? (r.push(i), Kn(e, t, r)) : i();
    };
    n ? n(s) : s();
  };
}, et.prototype.render = function(t) {
  this.u = null, this.o = /* @__PURE__ */ new Map();
  var e = vt(t.children);
  t.revealOrder && t.revealOrder[0] === "b" && e.reverse();
  for (var n = e.length; n--; ) this.o.set(e[n], this.u = [1, 0, this.u]);
  return t.children;
}, et.prototype.componentDidUpdate = et.prototype.componentDidMount = function() {
  var t = this;
  this.o.forEach(function(e, n) {
    Kn(t, n, e);
  });
};
var tl = typeof Symbol < "u" && Symbol.for && /* @__PURE__ */ Symbol.for("react.element") || 60103, nl = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/, rl = typeof document < "u", il = function(t) {
  return (typeof Symbol < "u" && typeof /* @__PURE__ */ Symbol() == "symbol" ? /fil|che|rad/i : /fil|che|ra/i).test(t);
};
G.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach(function(t) {
  Object.defineProperty(G.prototype, t, { configurable: !0, get: function() {
    return this["UNSAFE_" + t];
  }, set: function(e) {
    Object.defineProperty(this, t, { configurable: !0, writable: !0, value: e });
  } });
});
var Xn = S.event;
function sl() {
}
function ll() {
  return this.cancelBubble;
}
function al() {
  return this.defaultPrevented;
}
S.event = function(t) {
  return Xn && (t = Xn(t)), t.persist = sl, t.isPropagationStopped = ll, t.isDefaultPrevented = al, t.nativeEvent = t;
};
var er = { configurable: !0, get: function() {
  return this.class;
} }, tr = S.vnode;
S.vnode = function(t) {
  var e = t.type, n = t.props, r = n;
  if (typeof e == "string") {
    var i = e.indexOf("-") === -1;
    for (var s in r = {}, n) {
      var l = n[s];
      rl && s === "children" && e === "noscript" || s === "value" && "defaultValue" in n && l == null || (s === "defaultValue" && "value" in n && n.value == null ? s = "value" : s === "download" && l === !0 ? l = "" : /ondoubleclick/i.test(s) ? s = "ondblclick" : /^onchange(textarea|input)/i.test(s + e) && !il(n.type) ? s = "oninput" : /^onfocus$/i.test(s) ? s = "onfocusin" : /^onblur$/i.test(s) ? s = "onfocusout" : /^on(Ani|Tra|Tou|BeforeInp|Compo)/.test(s) ? s = s.toLowerCase() : i && nl.test(s) ? s = s.replace(/[A-Z0-9]/g, "-$&").toLowerCase() : l === null && (l = void 0), /^oninput$/i.test(s) && (s = s.toLowerCase(), r[s] && (s = "oninputCapture")), r[s] = l);
    }
    e == "select" && r.multiple && Array.isArray(r.value) && (r.value = vt(n.children).forEach(function(a) {
      a.props.selected = r.value.indexOf(a.props.value) != -1;
    })), e == "select" && r.defaultValue != null && (r.value = vt(n.children).forEach(function(a) {
      a.props.selected = r.multiple ? r.defaultValue.indexOf(a.props.value) != -1 : r.defaultValue == a.props.value;
    })), t.props = r, n.class != n.className && (er.enumerable = "className" in n, n.className != null && (r.class = n.className), Object.defineProperty(r, "className", er));
  }
  t.$$typeof = tl, tr && tr(t);
};
var nr = S.__r;
S.__r = function(t) {
  nr && nr(t), t.__c;
};
const ui = [], Zt = /* @__PURE__ */ new Map();
function Rt(t) {
  ui.push(t), Zt.forEach((e) => {
    hi(e, t);
  });
}
function ol(t) {
  t.isConnected && // sometimes true if SSR system simulates DOM
  t.getRootNode && fi(t.getRootNode());
}
function fi(t) {
  let e = Zt.get(t);
  if (!e || !e.isConnected) {
    if (e = t.querySelector("style[data-fullcalendar]"), !e) {
      e = document.createElement("style"), e.setAttribute("data-fullcalendar", "");
      const n = dl();
      n && (e.nonce = n);
      const r = t === document ? document.head : t, i = t === document ? r.querySelector("script,link[rel=stylesheet],link[as=style],style") : r.firstChild;
      r.insertBefore(e, i);
    }
    Zt.set(t, e), cl(e);
  }
}
function cl(t) {
  for (const e of ui)
    hi(t, e);
}
function hi(t, e) {
  const { sheet: n } = t, r = n.cssRules.length;
  e.split("}").forEach((i, s) => {
    i = i.trim(), i && n.insertRule(i + "}", r + s);
  });
}
let Ot;
function dl() {
  return Ot === void 0 && (Ot = ul()), Ot;
}
function ul() {
  const t = document.querySelector('meta[name="csp-nonce"]');
  if (t && t.hasAttribute("content"))
    return t.getAttribute("content");
  const e = document.querySelector("script[nonce]");
  return e && e.nonce || "";
}
typeof document < "u" && fi(document);
var fl = ':root{--fc-small-font-size:.85em;--fc-page-bg-color:#fff;--fc-neutral-bg-color:hsla(0,0%,82%,.3);--fc-neutral-text-color:grey;--fc-border-color:#ddd;--fc-button-text-color:#fff;--fc-button-bg-color:#2c3e50;--fc-button-border-color:#2c3e50;--fc-button-hover-bg-color:#1e2b37;--fc-button-hover-border-color:#1a252f;--fc-button-active-bg-color:#1a252f;--fc-button-active-border-color:#151e27;--fc-event-bg-color:#3788d8;--fc-event-border-color:#3788d8;--fc-event-text-color:#fff;--fc-event-selected-overlay-color:rgba(0,0,0,.25);--fc-more-link-bg-color:#d0d0d0;--fc-more-link-text-color:inherit;--fc-event-resizer-thickness:8px;--fc-event-resizer-dot-total-width:8px;--fc-event-resizer-dot-border-width:1px;--fc-non-business-color:hsla(0,0%,84%,.3);--fc-bg-event-color:#8fdf82;--fc-bg-event-opacity:0.3;--fc-highlight-color:rgba(188,232,241,.3);--fc-today-bg-color:rgba(255,220,40,.15);--fc-now-indicator-color:red}.fc-not-allowed,.fc-not-allowed .fc-event{cursor:not-allowed}.fc{display:flex;flex-direction:column;font-size:1em}.fc,.fc *,.fc :after,.fc :before{box-sizing:border-box}.fc table{border-collapse:collapse;border-spacing:0;font-size:1em}.fc th{text-align:center}.fc td,.fc th{padding:0;vertical-align:top}.fc a[data-navlink]{cursor:pointer}.fc a[data-navlink]:hover{text-decoration:underline}.fc-direction-ltr{direction:ltr;text-align:left}.fc-direction-rtl{direction:rtl;text-align:right}.fc-theme-standard td,.fc-theme-standard th{border:1px solid var(--fc-border-color)}.fc-liquid-hack td,.fc-liquid-hack th{position:relative}@font-face{font-family:fcicons;font-style:normal;font-weight:400;src:url("data:application/x-font-ttf;charset=utf-8;base64,AAEAAAALAIAAAwAwT1MvMg8SBfAAAAC8AAAAYGNtYXAXVtKNAAABHAAAAFRnYXNwAAAAEAAAAXAAAAAIZ2x5ZgYydxIAAAF4AAAFNGhlYWQUJ7cIAAAGrAAAADZoaGVhB20DzAAABuQAAAAkaG10eCIABhQAAAcIAAAALGxvY2ED4AU6AAAHNAAAABhtYXhwAA8AjAAAB0wAAAAgbmFtZXsr690AAAdsAAABhnBvc3QAAwAAAAAI9AAAACAAAwPAAZAABQAAApkCzAAAAI8CmQLMAAAB6wAzAQkAAAAAAAAAAAAAAAAAAAABEAAAAAAAAAAAAAAAAAAAAABAAADpBgPA/8AAQAPAAEAAAAABAAAAAAAAAAAAAAAgAAAAAAADAAAAAwAAABwAAQADAAAAHAADAAEAAAAcAAQAOAAAAAoACAACAAIAAQAg6Qb//f//AAAAAAAg6QD//f//AAH/4xcEAAMAAQAAAAAAAAAAAAAAAQAB//8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAABAWIAjQKeAskAEwAAJSc3NjQnJiIHAQYUFwEWMjc2NCcCnuLiDQ0MJAz/AA0NAQAMJAwNDcni4gwjDQwM/wANIwz/AA0NDCMNAAAAAQFiAI0CngLJABMAACUBNjQnASYiBwYUHwEHBhQXFjI3AZ4BAA0N/wAMJAwNDeLiDQ0MJAyNAQAMIw0BAAwMDSMM4uINIwwNDQAAAAIA4gC3Ax4CngATACcAACUnNzY0JyYiDwEGFB8BFjI3NjQnISc3NjQnJiIPAQYUHwEWMjc2NCcB87e3DQ0MIw3VDQ3VDSMMDQ0BK7e3DQ0MJAzVDQ3VDCQMDQ3zuLcMJAwNDdUNIwzWDAwNIwy4twwkDA0N1Q0jDNYMDA0jDAAAAgDiALcDHgKeABMAJwAAJTc2NC8BJiIHBhQfAQcGFBcWMjchNzY0LwEmIgcGFB8BBwYUFxYyNwJJ1Q0N1Q0jDA0Nt7cNDQwjDf7V1Q0N1QwkDA0Nt7cNDQwkDLfWDCMN1Q0NDCQMt7gMIw0MDNYMIw3VDQ0MJAy3uAwjDQwMAAADAFUAAAOrA1UAMwBoAHcAABMiBgcOAQcOAQcOARURFBYXHgEXHgEXHgEzITI2Nz4BNz4BNz4BNRE0JicuAScuAScuASMFITIWFx4BFx4BFx4BFREUBgcOAQcOAQcOASMhIiYnLgEnLgEnLgE1ETQ2Nz4BNz4BNz4BMxMhMjY1NCYjISIGFRQWM9UNGAwLFQkJDgUFBQUFBQ4JCRULDBgNAlYNGAwLFQkJDgUFBQUFBQ4JCRULDBgN/aoCVgQIBAQHAwMFAQIBAQIBBQMDBwQECAT9qgQIBAQHAwMFAQIBAQIBBQMDBwQECASAAVYRGRkR/qoRGRkRA1UFBAUOCQkVDAsZDf2rDRkLDBUJCA4FBQUFBQUOCQgVDAsZDQJVDRkLDBUJCQ4FBAVVAgECBQMCBwQECAX9qwQJAwQHAwMFAQICAgIBBQMDBwQDCQQCVQUIBAQHAgMFAgEC/oAZEhEZGRESGQAAAAADAFUAAAOrA1UAMwBoAIkAABMiBgcOAQcOAQcOARURFBYXHgEXHgEXHgEzITI2Nz4BNz4BNz4BNRE0JicuAScuAScuASMFITIWFx4BFx4BFx4BFREUBgcOAQcOAQcOASMhIiYnLgEnLgEnLgE1ETQ2Nz4BNz4BNz4BMxMzFRQWMzI2PQEzMjY1NCYrATU0JiMiBh0BIyIGFRQWM9UNGAwLFQkJDgUFBQUFBQ4JCRULDBgNAlYNGAwLFQkJDgUFBQUFBQ4JCRULDBgN/aoCVgQIBAQHAwMFAQIBAQIBBQMDBwQECAT9qgQIBAQHAwMFAQIBAQIBBQMDBwQECASAgBkSEhmAERkZEYAZEhIZgBEZGREDVQUEBQ4JCRUMCxkN/asNGQsMFQkIDgUFBQUFBQ4JCBUMCxkNAlUNGQsMFQkJDgUEBVUCAQIFAwIHBAQIBf2rBAkDBAcDAwUBAgICAgEFAwMHBAMJBAJVBQgEBAcCAwUCAQL+gIASGRkSgBkSERmAEhkZEoAZERIZAAABAOIAjQMeAskAIAAAExcHBhQXFjI/ARcWMjc2NC8BNzY0JyYiDwEnJiIHBhQX4uLiDQ0MJAzi4gwkDA0N4uINDQwkDOLiDCQMDQ0CjeLiDSMMDQ3h4Q0NDCMN4uIMIw0MDOLiDAwNIwwAAAABAAAAAQAAa5n0y18PPPUACwQAAAAAANivOVsAAAAA2K85WwAAAAADqwNVAAAACAACAAAAAAAAAAEAAAPA/8AAAAQAAAAAAAOrAAEAAAAAAAAAAAAAAAAAAAALBAAAAAAAAAAAAAAAAgAAAAQAAWIEAAFiBAAA4gQAAOIEAABVBAAAVQQAAOIAAAAAAAoAFAAeAEQAagCqAOoBngJkApoAAQAAAAsAigADAAAAAAACAAAAAAAAAAAAAAAAAAAAAAAAAA4ArgABAAAAAAABAAcAAAABAAAAAAACAAcAYAABAAAAAAADAAcANgABAAAAAAAEAAcAdQABAAAAAAAFAAsAFQABAAAAAAAGAAcASwABAAAAAAAKABoAigADAAEECQABAA4ABwADAAEECQACAA4AZwADAAEECQADAA4APQADAAEECQAEAA4AfAADAAEECQAFABYAIAADAAEECQAGAA4AUgADAAEECQAKADQApGZjaWNvbnMAZgBjAGkAYwBvAG4Ac1ZlcnNpb24gMS4wAFYAZQByAHMAaQBvAG4AIAAxAC4AMGZjaWNvbnMAZgBjAGkAYwBvAG4Ac2ZjaWNvbnMAZgBjAGkAYwBvAG4Ac1JlZ3VsYXIAUgBlAGcAdQBsAGEAcmZjaWNvbnMAZgBjAGkAYwBvAG4Ac0ZvbnQgZ2VuZXJhdGVkIGJ5IEljb01vb24uAEYAbwBuAHQAIABnAGUAbgBlAHIAYQB0AGUAZAAgAGIAeQAgAEkAYwBvAE0AbwBvAG4ALgAAAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=") format("truetype")}.fc-icon{speak:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;display:inline-block;font-family:fcicons!important;font-style:normal;font-variant:normal;font-weight:400;height:1em;line-height:1;text-align:center;text-transform:none;-webkit-user-select:none;-moz-user-select:none;user-select:none;width:1em}.fc-icon-chevron-left:before{content:"\\e900"}.fc-icon-chevron-right:before{content:"\\e901"}.fc-icon-chevrons-left:before{content:"\\e902"}.fc-icon-chevrons-right:before{content:"\\e903"}.fc-icon-minus-square:before{content:"\\e904"}.fc-icon-plus-square:before{content:"\\e905"}.fc-icon-x:before{content:"\\e906"}.fc .fc-button{border-radius:0;font-family:inherit;font-size:inherit;line-height:inherit;margin:0;overflow:visible;text-transform:none}.fc .fc-button:focus{outline:1px dotted;outline:5px auto -webkit-focus-ring-color}.fc .fc-button{-webkit-appearance:button}.fc .fc-button:not(:disabled){cursor:pointer}.fc .fc-button{background-color:transparent;border:1px solid transparent;border-radius:.25em;display:inline-block;font-size:1em;font-weight:400;line-height:1.5;padding:.4em .65em;text-align:center;-webkit-user-select:none;-moz-user-select:none;user-select:none;vertical-align:middle}.fc .fc-button:hover{text-decoration:none}.fc .fc-button:focus{box-shadow:0 0 0 .2rem rgba(44,62,80,.25);outline:0}.fc .fc-button:disabled{opacity:.65}.fc .fc-button-primary{background-color:var(--fc-button-bg-color);border-color:var(--fc-button-border-color);color:var(--fc-button-text-color)}.fc .fc-button-primary:hover{background-color:var(--fc-button-hover-bg-color);border-color:var(--fc-button-hover-border-color);color:var(--fc-button-text-color)}.fc .fc-button-primary:disabled{background-color:var(--fc-button-bg-color);border-color:var(--fc-button-border-color);color:var(--fc-button-text-color)}.fc .fc-button-primary:focus{box-shadow:0 0 0 .2rem rgba(76,91,106,.5)}.fc .fc-button-primary:not(:disabled).fc-button-active,.fc .fc-button-primary:not(:disabled):active{background-color:var(--fc-button-active-bg-color);border-color:var(--fc-button-active-border-color);color:var(--fc-button-text-color)}.fc .fc-button-primary:not(:disabled).fc-button-active:focus,.fc .fc-button-primary:not(:disabled):active:focus{box-shadow:0 0 0 .2rem rgba(76,91,106,.5)}.fc .fc-button .fc-icon{font-size:1.5em;vertical-align:middle}.fc .fc-button-group{display:inline-flex;position:relative;vertical-align:middle}.fc .fc-button-group>.fc-button{flex:1 1 auto;position:relative}.fc .fc-button-group>.fc-button.fc-button-active,.fc .fc-button-group>.fc-button:active,.fc .fc-button-group>.fc-button:focus,.fc .fc-button-group>.fc-button:hover{z-index:1}.fc-direction-ltr .fc-button-group>.fc-button:not(:first-child){border-bottom-left-radius:0;border-top-left-radius:0;margin-left:-1px}.fc-direction-ltr .fc-button-group>.fc-button:not(:last-child){border-bottom-right-radius:0;border-top-right-radius:0}.fc-direction-rtl .fc-button-group>.fc-button:not(:first-child){border-bottom-right-radius:0;border-top-right-radius:0;margin-right:-1px}.fc-direction-rtl .fc-button-group>.fc-button:not(:last-child){border-bottom-left-radius:0;border-top-left-radius:0}.fc .fc-toolbar{align-items:center;display:flex;justify-content:space-between}.fc .fc-toolbar.fc-header-toolbar{margin-bottom:1.5em}.fc .fc-toolbar.fc-footer-toolbar{margin-top:1.5em}.fc .fc-toolbar-title{font-size:1.75em;margin:0}.fc-direction-ltr .fc-toolbar>*>:not(:first-child){margin-left:.75em}.fc-direction-rtl .fc-toolbar>*>:not(:first-child){margin-right:.75em}.fc-direction-rtl .fc-toolbar-ltr{flex-direction:row-reverse}.fc .fc-scroller{-webkit-overflow-scrolling:touch;position:relative}.fc .fc-scroller-liquid{height:100%}.fc .fc-scroller-liquid-absolute{bottom:0;left:0;position:absolute;right:0;top:0}.fc .fc-scroller-harness{direction:ltr;overflow:hidden;position:relative}.fc .fc-scroller-harness-liquid{height:100%}.fc-direction-rtl .fc-scroller-harness>.fc-scroller{direction:rtl}.fc-theme-standard .fc-scrollgrid{border:1px solid var(--fc-border-color)}.fc .fc-scrollgrid,.fc .fc-scrollgrid table{table-layout:fixed;width:100%}.fc .fc-scrollgrid table{border-left-style:hidden;border-right-style:hidden;border-top-style:hidden}.fc .fc-scrollgrid{border-bottom-width:0;border-collapse:separate;border-right-width:0}.fc .fc-scrollgrid-liquid{height:100%}.fc .fc-scrollgrid-section,.fc .fc-scrollgrid-section table,.fc .fc-scrollgrid-section>td{height:1px}.fc .fc-scrollgrid-section-liquid>td{height:100%}.fc .fc-scrollgrid-section>*{border-left-width:0;border-top-width:0}.fc .fc-scrollgrid-section-footer>*,.fc .fc-scrollgrid-section-header>*{border-bottom-width:0}.fc .fc-scrollgrid-section-body table,.fc .fc-scrollgrid-section-footer table{border-bottom-style:hidden}.fc .fc-scrollgrid-section-sticky>*{background:var(--fc-page-bg-color);position:sticky;z-index:3}.fc .fc-scrollgrid-section-header.fc-scrollgrid-section-sticky>*{top:0}.fc .fc-scrollgrid-section-footer.fc-scrollgrid-section-sticky>*{bottom:0}.fc .fc-scrollgrid-sticky-shim{height:1px;margin-bottom:-1px}.fc-sticky{position:sticky}.fc .fc-view-harness{flex-grow:1;position:relative}.fc .fc-view-harness-active>.fc-view{bottom:0;left:0;position:absolute;right:0;top:0}.fc .fc-col-header-cell-cushion{display:inline-block;padding:2px 4px}.fc .fc-bg-event,.fc .fc-highlight,.fc .fc-non-business{bottom:0;left:0;position:absolute;right:0;top:0}.fc .fc-non-business{background:var(--fc-non-business-color)}.fc .fc-bg-event{background:var(--fc-bg-event-color);opacity:var(--fc-bg-event-opacity)}.fc .fc-bg-event .fc-event-title{font-size:var(--fc-small-font-size);font-style:italic;margin:.5em}.fc .fc-highlight{background:var(--fc-highlight-color)}.fc .fc-cell-shaded,.fc .fc-day-disabled{background:var(--fc-neutral-bg-color)}a.fc-event,a.fc-event:hover{text-decoration:none}.fc-event.fc-event-draggable,.fc-event[href]{cursor:pointer}.fc-event .fc-event-main{position:relative;z-index:2}.fc-event-dragging:not(.fc-event-selected){opacity:.75}.fc-event-dragging.fc-event-selected{box-shadow:0 2px 7px rgba(0,0,0,.3)}.fc-event .fc-event-resizer{display:none;position:absolute;z-index:4}.fc-event-selected .fc-event-resizer,.fc-event:hover .fc-event-resizer{display:block}.fc-event-selected .fc-event-resizer{background:var(--fc-page-bg-color);border-color:inherit;border-radius:calc(var(--fc-event-resizer-dot-total-width)/2);border-style:solid;border-width:var(--fc-event-resizer-dot-border-width);height:var(--fc-event-resizer-dot-total-width);width:var(--fc-event-resizer-dot-total-width)}.fc-event-selected .fc-event-resizer:before{bottom:-20px;content:"";left:-20px;position:absolute;right:-20px;top:-20px}.fc-event-selected,.fc-event:focus{box-shadow:0 2px 5px rgba(0,0,0,.2)}.fc-event-selected:before,.fc-event:focus:before{bottom:0;content:"";left:0;position:absolute;right:0;top:0;z-index:3}.fc-event-selected:after,.fc-event:focus:after{background:var(--fc-event-selected-overlay-color);bottom:-1px;content:"";left:-1px;position:absolute;right:-1px;top:-1px;z-index:1}.fc-h-event{background-color:var(--fc-event-bg-color);border:1px solid var(--fc-event-border-color);display:block}.fc-h-event .fc-event-main{color:var(--fc-event-text-color)}.fc-h-event .fc-event-main-frame{display:flex}.fc-h-event .fc-event-time{max-width:100%;overflow:hidden}.fc-h-event .fc-event-title-container{flex-grow:1;flex-shrink:1;min-width:0}.fc-h-event .fc-event-title{display:inline-block;left:0;max-width:100%;overflow:hidden;right:0;vertical-align:top}.fc-h-event.fc-event-selected:before{bottom:-10px;top:-10px}.fc-direction-ltr .fc-daygrid-block-event:not(.fc-event-start),.fc-direction-rtl .fc-daygrid-block-event:not(.fc-event-end){border-bottom-left-radius:0;border-left-width:0;border-top-left-radius:0}.fc-direction-ltr .fc-daygrid-block-event:not(.fc-event-end),.fc-direction-rtl .fc-daygrid-block-event:not(.fc-event-start){border-bottom-right-radius:0;border-right-width:0;border-top-right-radius:0}.fc-h-event:not(.fc-event-selected) .fc-event-resizer{bottom:0;top:0;width:var(--fc-event-resizer-thickness)}.fc-direction-ltr .fc-h-event:not(.fc-event-selected) .fc-event-resizer-start,.fc-direction-rtl .fc-h-event:not(.fc-event-selected) .fc-event-resizer-end{cursor:w-resize;left:calc(var(--fc-event-resizer-thickness)*-.5)}.fc-direction-ltr .fc-h-event:not(.fc-event-selected) .fc-event-resizer-end,.fc-direction-rtl .fc-h-event:not(.fc-event-selected) .fc-event-resizer-start{cursor:e-resize;right:calc(var(--fc-event-resizer-thickness)*-.5)}.fc-h-event.fc-event-selected .fc-event-resizer{margin-top:calc(var(--fc-event-resizer-dot-total-width)*-.5);top:50%}.fc-direction-ltr .fc-h-event.fc-event-selected .fc-event-resizer-start,.fc-direction-rtl .fc-h-event.fc-event-selected .fc-event-resizer-end{left:calc(var(--fc-event-resizer-dot-total-width)*-.5)}.fc-direction-ltr .fc-h-event.fc-event-selected .fc-event-resizer-end,.fc-direction-rtl .fc-h-event.fc-event-selected .fc-event-resizer-start{right:calc(var(--fc-event-resizer-dot-total-width)*-.5)}.fc .fc-popover{box-shadow:0 2px 6px rgba(0,0,0,.15);position:absolute;z-index:9999}.fc .fc-popover-header{align-items:center;display:flex;flex-direction:row;justify-content:space-between;padding:3px 4px}.fc .fc-popover-title{margin:0 2px}.fc .fc-popover-close{cursor:pointer;font-size:1.1em;opacity:.65}.fc-theme-standard .fc-popover{background:var(--fc-page-bg-color);border:1px solid var(--fc-border-color)}.fc-theme-standard .fc-popover-header{background:var(--fc-neutral-bg-color)}';
Rt(fl);
class cn {
  constructor(e) {
    this.drainedOption = e, this.isRunning = !1, this.isDirty = !1, this.pauseDepths = {}, this.timeoutId = 0;
  }
  request(e) {
    this.isDirty = !0, this.isPaused() || (this.clearTimeout(), e == null ? this.tryDrain() : this.timeoutId = setTimeout(
      // NOT OPTIMAL! TODO: look at debounce
      this.tryDrain.bind(this),
      e
    ));
  }
  pause(e = "") {
    let { pauseDepths: n } = this;
    n[e] = (n[e] || 0) + 1, this.clearTimeout();
  }
  resume(e = "", n) {
    let { pauseDepths: r } = this;
    e in r && (n ? delete r[e] : (r[e] -= 1, r[e] <= 0 && delete r[e]), this.tryDrain());
  }
  isPaused() {
    return Object.keys(this.pauseDepths).length;
  }
  tryDrain() {
    if (!this.isRunning && !this.isPaused()) {
      for (this.isRunning = !0; this.isDirty; )
        this.isDirty = !1, this.drained();
      this.isRunning = !1;
    }
  }
  clear() {
    this.clearTimeout(), this.isDirty = !1, this.pauseDepths = {};
  }
  clearTimeout() {
    this.timeoutId && (clearTimeout(this.timeoutId), this.timeoutId = 0);
  }
  drained() {
    this.drainedOption && this.drainedOption();
  }
}
function hl(t) {
  t.parentNode && t.parentNode.removeChild(t);
}
function X(t, e) {
  if (t.closest)
    return t.closest(e);
  if (!document.documentElement.contains(t))
    return null;
  do {
    if (gl(t, e))
      return t;
    t = t.parentElement || t.parentNode;
  } while (t !== null && t.nodeType === 1);
  return null;
}
function gl(t, e) {
  return (t.matches || t.matchesSelector || t.msMatchesSelector).call(t, e);
}
function pl(t, e) {
  let n = t instanceof HTMLElement ? [t] : t, r = [];
  for (let i = 0; i < n.length; i += 1) {
    let s = n[i].querySelectorAll(e);
    for (let l = 0; l < s.length; l += 1)
      r.push(s[l]);
  }
  return r;
}
const ml = /(top|left|right|bottom|width|height)$/i;
function vl(t, e) {
  for (let n in e)
    gi(t, n, e[n]);
}
function gi(t, e, n) {
  n == null ? t.style[e] = "" : typeof n == "number" && ml.test(e) ? t.style[e] = `${n}px` : t.style[e] = n;
}
function yl(t) {
  var e, n;
  return (n = (e = t.composedPath) === null || e === void 0 ? void 0 : e.call(t)[0]) !== null && n !== void 0 ? n : t.target;
}
let rr = 0;
function de() {
  return rr += 1, "fc-dom-" + rr;
}
function bl(t, e) {
  return (n) => {
    let r = X(n.target, t);
    r && e.call(r, n, r);
  };
}
function pi(t, e, n, r) {
  let i = bl(n, r);
  return t.addEventListener(e, i), () => {
    t.removeEventListener(e, i);
  };
}
function Al(t, e, n, r) {
  let i;
  return pi(t, "mouseover", e, (s, l) => {
    if (l !== i) {
      i = l, n(s, l);
      let a = (o) => {
        i = null, r(o, l), l.removeEventListener("mouseleave", a);
      };
      l.addEventListener("mouseleave", a);
    }
  });
}
function mi(t) {
  return Object.assign({ onClick: t }, vi(t));
}
function vi(t) {
  return {
    tabIndex: 0,
    onKeyDown(e) {
      (e.key === "Enter" || e.key === " ") && (t(e), e.preventDefault());
    }
  };
}
let ir = 0;
function De() {
  return ir += 1, String(ir);
}
function El(t) {
  let e = [], n = [], r, i;
  for (typeof t == "string" ? n = t.split(/\s*,\s*/) : typeof t == "function" ? n = [t] : Array.isArray(t) && (n = t), r = 0; r < n.length; r += 1)
    i = n[r], typeof i == "string" ? e.push(i.charAt(0) === "-" ? { field: i.substring(1), order: -1 } : { field: i, order: 1 }) : typeof i == "function" && e.push({ func: i });
  return e;
}
function Cl(t, e, n) {
  let r, i;
  for (r = 0; r < n.length; r += 1)
    if (i = Sl(t, e, n[r]), i)
      return i;
  return 0;
}
function Sl(t, e, n) {
  return n.func ? n.func(t, e) : Dl(t[n.field], e[n.field]) * (n.order || 1);
}
function Dl(t, e) {
  return !t && !e ? 0 : e == null ? -1 : t == null ? 1 : typeof t == "string" || typeof e == "string" ? String(t).localeCompare(String(e)) : t - e;
}
function ke(t, e) {
  let n = String(t);
  return "000".substr(0, e - n.length) + n;
}
function ze(t, e, n) {
  return typeof t == "function" ? t(...e) : typeof t == "string" ? e.reduce((r, i, s) => r.replace("$" + s, i || ""), t) : n;
}
function dt(t) {
  return t % 1 === 0;
}
function wl(t) {
  let e = t.querySelector(".fc-scrollgrid-shrink-frame"), n = t.querySelector(".fc-scrollgrid-shrink-cushion");
  if (!e)
    throw new Error("needs fc-scrollgrid-shrink-frame className");
  if (!n)
    throw new Error("needs fc-scrollgrid-shrink-cushion className");
  return t.getBoundingClientRect().width - e.getBoundingClientRect().width + // the cell padding+border
  n.getBoundingClientRect().width;
}
const sr = ["years", "months", "days", "milliseconds"], _l = /^(-?)(?:(\d+)\.)?(\d+):(\d\d)(?::(\d\d)(?:\.(\d\d\d))?)?/;
function R(t, e) {
  return typeof t == "string" ? Rl(t) : typeof t == "object" && t ? lr(t) : typeof t == "number" ? lr({ [e || "milliseconds"]: t }) : null;
}
function Rl(t) {
  let e = _l.exec(t);
  if (e) {
    let n = e[1] ? -1 : 1;
    return {
      years: 0,
      months: 0,
      days: n * (e[2] ? parseInt(e[2], 10) : 0),
      milliseconds: n * ((e[3] ? parseInt(e[3], 10) : 0) * 60 * 60 * 1e3 + // hours
      (e[4] ? parseInt(e[4], 10) : 0) * 60 * 1e3 + // minutes
      (e[5] ? parseInt(e[5], 10) : 0) * 1e3 + // seconds
      (e[6] ? parseInt(e[6], 10) : 0))
    };
  }
  return null;
}
function lr(t) {
  let e = {
    years: t.years || t.year || 0,
    months: t.months || t.month || 0,
    days: t.days || t.day || 0,
    milliseconds: (t.hours || t.hour || 0) * 60 * 60 * 1e3 + // hours
    (t.minutes || t.minute || 0) * 60 * 1e3 + // minutes
    (t.seconds || t.second || 0) * 1e3 + // seconds
    (t.milliseconds || t.millisecond || t.ms || 0)
    // ms
  }, n = t.weeks || t.week;
  return n && (e.days += n * 7, e.specifiedWeeks = !0), e;
}
function Tl(t, e) {
  return t.years === e.years && t.months === e.months && t.days === e.days && t.milliseconds === e.milliseconds;
}
function $t(t, e) {
  return {
    years: t.years + e.years,
    months: t.months + e.months,
    days: t.days + e.days,
    milliseconds: t.milliseconds + e.milliseconds
  };
}
function xl(t, e) {
  return {
    years: t.years - e.years,
    months: t.months - e.months,
    days: t.days - e.days,
    milliseconds: t.milliseconds - e.milliseconds
  };
}
function kl(t, e) {
  return {
    years: t.years * e,
    months: t.months * e,
    days: t.days * e,
    milliseconds: t.milliseconds * e
  };
}
function Ml(t) {
  return Me(t) / 365;
}
function Il(t) {
  return Me(t) / 30;
}
function Me(t) {
  return q(t) / 864e5;
}
function q(t) {
  return t.years * (365 * 864e5) + t.months * (30 * 864e5) + t.days * 864e5 + t.milliseconds;
}
function dn(t, e) {
  let n = null;
  for (let r = 0; r < sr.length; r += 1) {
    let i = sr[r];
    if (e[i]) {
      let s = t[i] / e[i];
      if (!dt(s) || n !== null && n !== s)
        return null;
      n = s;
    } else if (t[i])
      return null;
  }
  return n;
}
function Jt(t) {
  let e = t.milliseconds;
  if (e) {
    if (e % 1e3 !== 0)
      return { unit: "millisecond", value: e };
    if (e % (1e3 * 60) !== 0)
      return { unit: "second", value: e / 1e3 };
    if (e % (1e3 * 60 * 60) !== 0)
      return { unit: "minute", value: e / (1e3 * 60) };
    if (e)
      return { unit: "hour", value: e / (1e3 * 60 * 60) };
  }
  return t.days ? t.specifiedWeeks && t.days % 7 === 0 ? { unit: "week", value: t.days / 7 } : { unit: "day", value: t.days } : t.months ? { unit: "month", value: t.months } : t.years ? { unit: "year", value: t.years } : { unit: "millisecond", value: 0 };
}
function ue(t, e, n) {
  if (t === e)
    return !0;
  let r = t.length, i;
  if (r !== e.length)
    return !1;
  for (i = 0; i < r; i += 1)
    if (!(n ? n(t[i], e[i]) : t[i] === e[i]))
      return !1;
  return !0;
}
const Nl = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
function ar(t, e) {
  let n = oe(t);
  return n[2] += e * 7, j(n);
}
function B(t, e) {
  let n = oe(t);
  return n[2] += e, j(n);
}
function fe(t, e) {
  let n = oe(t);
  return n[6] += e, j(n);
}
function Ol(t, e) {
  return ge(t, e) / 7;
}
function ge(t, e) {
  return (e.valueOf() - t.valueOf()) / (1e3 * 60 * 60 * 24);
}
function Hl(t, e) {
  return (e.valueOf() - t.valueOf()) / (1e3 * 60 * 60);
}
function Pl(t, e) {
  return (e.valueOf() - t.valueOf()) / (1e3 * 60);
}
function Bl(t, e) {
  return (e.valueOf() - t.valueOf()) / 1e3;
}
function Fl(t, e) {
  let n = I(t), r = I(e);
  return {
    years: 0,
    months: 0,
    days: Math.round(ge(n, r)),
    milliseconds: e.valueOf() - r.valueOf() - (t.valueOf() - n.valueOf())
  };
}
function zl(t, e) {
  let n = yt(t, e);
  return n !== null && n % 7 === 0 ? n / 7 : null;
}
function yt(t, e) {
  return ce(t) === ce(e) ? Math.round(ge(t, e)) : null;
}
function I(t) {
  return j([
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate()
  ]);
}
function Ul(t) {
  return j([
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate(),
    t.getUTCHours()
  ]);
}
function Wl(t) {
  return j([
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate(),
    t.getUTCHours(),
    t.getUTCMinutes()
  ]);
}
function Ll(t) {
  return j([
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate(),
    t.getUTCHours(),
    t.getUTCMinutes(),
    t.getUTCSeconds()
  ]);
}
function jl(t, e, n) {
  let r = t.getUTCFullYear(), i = Ht(t, r, e, n);
  if (i < 1)
    return Ht(t, r - 1, e, n);
  let s = Ht(t, r + 1, e, n);
  return s >= 1 ? Math.min(i, s) : i;
}
function Ht(t, e, n, r) {
  let i = j([e, 0, 1 + Vl(e, n, r)]), s = I(t), l = Math.round(ge(i, s));
  return Math.floor(l / 7) + 1;
}
function Vl(t, e, n) {
  let r = 7 + e - n;
  return -((7 + j([t, 0, r]).getUTCDay() - e) % 7) + r - 1;
}
function or(t) {
  return [
    t.getFullYear(),
    t.getMonth(),
    t.getDate(),
    t.getHours(),
    t.getMinutes(),
    t.getSeconds(),
    t.getMilliseconds()
  ];
}
function cr(t) {
  return new Date(
    t[0],
    t[1] || 0,
    t[2] == null ? 1 : t[2],
    // day of month
    t[3] || 0,
    t[4] || 0,
    t[5] || 0
  );
}
function oe(t) {
  return [
    t.getUTCFullYear(),
    t.getUTCMonth(),
    t.getUTCDate(),
    t.getUTCHours(),
    t.getUTCMinutes(),
    t.getUTCSeconds(),
    t.getUTCMilliseconds()
  ];
}
function j(t) {
  return t.length === 1 && (t = t.concat([0])), new Date(Date.UTC(...t));
}
function yi(t) {
  return !isNaN(t.valueOf());
}
function ce(t) {
  return t.getUTCHours() * 1e3 * 60 * 60 + t.getUTCMinutes() * 1e3 * 60 + t.getUTCSeconds() * 1e3 + t.getUTCMilliseconds();
}
function bi(t, e, n = !1) {
  let r = t.toISOString();
  return r = r.replace(".000", ""), n && (r = r.replace("T00:00:00Z", "")), r.length > 10 && (e == null ? r = r.replace("Z", "") : e !== 0 && (r = r.replace("Z", un(e, !0)))), r;
}
function Qe(t) {
  return t.toISOString().replace(/T.*$/, "");
}
function Gl(t) {
  return t.toISOString().match(/^\d{4}-\d{2}/)[0];
}
function Ql(t) {
  return ke(t.getUTCHours(), 2) + ":" + ke(t.getUTCMinutes(), 2) + ":" + ke(t.getUTCSeconds(), 2);
}
function un(t, e = !1) {
  let n = t < 0 ? "-" : "+", r = Math.abs(t), i = Math.floor(r / 60), s = Math.round(r % 60);
  return e ? `${n + ke(i, 2)}:${ke(s, 2)}` : `GMT${n}${i}${s ? `:${ke(s, 2)}` : ""}`;
}
function C(t, e, n) {
  let r, i;
  return function(...s) {
    if (!r)
      i = t.apply(this, s);
    else if (!ue(r, s)) {
      let l = t.apply(this, s);
      (!e || !e(l, i)) && (i = l);
    }
    return r = s, i;
  };
}
function ut(t, e, n) {
  let r, i;
  return (s) => (r ? Y(r, s) || (i = t.call(this, s)) : i = t.call(this, s), r = s, i);
}
const Pt = {
  week: 3,
  separator: 9,
  omitZeroMinute: 9,
  meridiem: 9,
  omitCommas: 9
}, bt = {
  timeZoneName: 7,
  era: 6,
  year: 5,
  month: 4,
  day: 2,
  weekday: 2,
  hour: 1,
  minute: 1,
  second: 1
}, tt = /\s*([ap])\.?m\.?/i, ql = /,/g, Yl = /\s+/g, Zl = /\u200e/g, $l = /UTC|GMT/;
class Jl {
  constructor(e) {
    let n = {}, r = {}, i = 9;
    for (let s in e)
      s in Pt ? (r[s] = e[s], Pt[s] < 9 && (i = Math.min(Pt[s], i))) : (n[s] = e[s], s in bt && (i = Math.min(bt[s], i)));
    this.standardDateProps = n, this.extendedSettings = r, this.smallestUnitNum = i, this.buildFormattingFunc = C(dr);
  }
  format(e, n) {
    return this.buildFormattingFunc(this.standardDateProps, this.extendedSettings, n)(e);
  }
  formatRange(e, n, r, i) {
    let { standardDateProps: s, extendedSettings: l } = this, a = ra(e.marker, n.marker, r.calendarSystem);
    if (!a)
      return this.format(e, r);
    let o = a;
    o > 1 && // the two dates are different in a way that's larger scale than time
    (s.year === "numeric" || s.year === "2-digit") && (s.month === "numeric" || s.month === "2-digit") && (s.day === "numeric" || s.day === "2-digit") && (o = 1);
    let d = this.format(e, r), c = this.format(n, r);
    if (d === c)
      return d;
    let g = ia(s, o), h = dr(g, l, r), f = h(e), m = h(n), y = sa(d, f, c, m), v = l.separator || i || r.defaultSeparator || "";
    return y ? y.before + f + v + m + y.after : d + v + c;
  }
  getSmallestUnit() {
    switch (this.smallestUnitNum) {
      case 7:
      case 6:
      case 5:
        return "year";
      case 4:
        return "month";
      case 3:
        return "week";
      case 2:
        return "day";
      default:
        return "time";
    }
  }
}
function dr(t, e, n) {
  let r = Object.keys(t).length;
  return r === 1 && t.timeZoneName === "short" ? (i) => un(i.timeZoneOffset) : r === 0 && e.week ? (i) => na(n.computeWeekNumber(i.marker), n.weekText, n.weekTextLong, n.locale, e.week) : Kl(t, e, n);
}
function Kl(t, e, n) {
  t = Object.assign({}, t), e = Object.assign({}, e), Xl(t, e), t.timeZone = "UTC";
  let r = new Intl.DateTimeFormat(n.locale.codes, t), i;
  if (e.omitZeroMinute) {
    let s = Object.assign({}, t);
    delete s.minute, i = new Intl.DateTimeFormat(n.locale.codes, s);
  }
  return (s) => {
    let { marker: l } = s, a;
    i && !l.getUTCMinutes() ? a = i : a = r;
    let o = a.format(l);
    return ea(o, s, t, e, n);
  };
}
function Xl(t, e) {
  t.timeZoneName && (t.hour || (t.hour = "2-digit"), t.minute || (t.minute = "2-digit")), t.timeZoneName === "long" && (t.timeZoneName = "short"), e.omitZeroMinute && (t.second || t.millisecond) && delete e.omitZeroMinute;
}
function ea(t, e, n, r, i) {
  return t = t.replace(Zl, ""), n.timeZoneName === "short" && (t = ta(t, i.timeZone === "UTC" || e.timeZoneOffset == null ? "UTC" : (
    // important to normalize for IE, which does "GMT"
    un(e.timeZoneOffset)
  ))), r.omitCommas && (t = t.replace(ql, "").trim()), r.omitZeroMinute && (t = t.replace(":00", "")), r.meridiem === !1 ? t = t.replace(tt, "").trim() : r.meridiem === "narrow" ? t = t.replace(tt, (s, l) => l.toLocaleLowerCase()) : r.meridiem === "short" ? t = t.replace(tt, (s, l) => `${l.toLocaleLowerCase()}m`) : r.meridiem === "lowercase" && (t = t.replace(tt, (s) => s.toLocaleLowerCase())), t = t.replace(Yl, " "), t = t.trim(), t;
}
function ta(t, e) {
  let n = !1;
  return t = t.replace($l, () => (n = !0, e)), n || (t += ` ${e}`), t;
}
function na(t, e, n, r, i) {
  let s = [];
  return i === "long" ? s.push(n) : (i === "short" || i === "narrow") && s.push(e), (i === "long" || i === "short") && s.push(" "), s.push(r.simpleNumberFormat.format(t)), r.options.direction === "rtl" && s.reverse(), s.join("");
}
function ra(t, e, n) {
  return n.getMarkerYear(t) !== n.getMarkerYear(e) ? 5 : n.getMarkerMonth(t) !== n.getMarkerMonth(e) ? 4 : n.getMarkerDay(t) !== n.getMarkerDay(e) ? 2 : ce(t) !== ce(e) ? 1 : 0;
}
function ia(t, e) {
  let n = {};
  for (let r in t)
    (!(r in bt) || // not a date part prop (like timeZone)
    bt[r] <= e) && (n[r] = t[r]);
  return n;
}
function sa(t, e, n, r) {
  let i = 0;
  for (; i < t.length; ) {
    let s = t.indexOf(e, i);
    if (s === -1)
      break;
    let l = t.substr(0, s);
    i = s + e.length;
    let a = t.substr(i), o = 0;
    for (; o < n.length; ) {
      let d = n.indexOf(r, o);
      if (d === -1)
        break;
      let c = n.substr(0, d);
      o = d + r.length;
      let g = n.substr(o);
      if (l === c && a === g)
        return {
          before: l,
          after: a
        };
    }
  }
  return null;
}
function ur(t, e) {
  let n = e.markerToArray(t.marker);
  return {
    marker: t.marker,
    timeZoneOffset: t.timeZoneOffset,
    array: n,
    year: n[0],
    month: n[1],
    day: n[2],
    hour: n[3],
    minute: n[4],
    second: n[5],
    millisecond: n[6]
  };
}
function At(t, e, n, r) {
  let i = ur(t, n.calendarSystem), s = e ? ur(e, n.calendarSystem) : null;
  return {
    date: i,
    start: i,
    end: s,
    timeZone: n.timeZone,
    localeCodes: n.locale.codes,
    defaultSeparator: r || n.defaultSeparator
  };
}
class la {
  constructor(e) {
    this.cmdStr = e;
  }
  format(e, n, r) {
    return n.cmdFormatter(this.cmdStr, At(e, null, n, r));
  }
  formatRange(e, n, r, i) {
    return r.cmdFormatter(this.cmdStr, At(e, n, r, i));
  }
}
class aa {
  constructor(e) {
    this.func = e;
  }
  format(e, n, r) {
    return this.func(At(e, null, n, r));
  }
  formatRange(e, n, r, i) {
    return this.func(At(e, n, r, i));
  }
}
function O(t) {
  return typeof t == "object" && t ? new Jl(t) : typeof t == "string" ? new la(t) : typeof t == "function" ? new aa(t) : null;
}
const fr = {
  navLinkDayClick: p,
  navLinkWeekClick: p,
  duration: R,
  bootstrapFontAwesome: p,
  buttonIcons: p,
  customButtons: p,
  defaultAllDayEventDuration: R,
  defaultTimedEventDuration: R,
  nextDayThreshold: R,
  scrollTime: R,
  scrollTimeReset: Boolean,
  slotMinTime: R,
  slotMaxTime: R,
  dayPopoverFormat: O,
  slotDuration: R,
  snapDuration: R,
  headerToolbar: p,
  footerToolbar: p,
  defaultRangeSeparator: String,
  titleRangeSeparator: String,
  forceEventDuration: Boolean,
  dayHeaders: Boolean,
  dayHeaderFormat: O,
  dayHeaderClassNames: p,
  dayHeaderContent: p,
  dayHeaderDidMount: p,
  dayHeaderWillUnmount: p,
  dayCellClassNames: p,
  dayCellContent: p,
  dayCellDidMount: p,
  dayCellWillUnmount: p,
  initialView: String,
  aspectRatio: Number,
  weekends: Boolean,
  weekNumberCalculation: p,
  weekNumbers: Boolean,
  weekNumberClassNames: p,
  weekNumberContent: p,
  weekNumberDidMount: p,
  weekNumberWillUnmount: p,
  editable: Boolean,
  viewClassNames: p,
  viewDidMount: p,
  viewWillUnmount: p,
  nowIndicator: Boolean,
  nowIndicatorSnap: p,
  nowIndicatorClassNames: p,
  nowIndicatorContent: p,
  nowIndicatorDidMount: p,
  nowIndicatorWillUnmount: p,
  showNonCurrentDates: Boolean,
  lazyFetching: Boolean,
  startParam: String,
  endParam: String,
  timeZoneParam: String,
  timeZone: String,
  locales: p,
  locale: p,
  themeSystem: String,
  dragRevertDuration: Number,
  dragScroll: Boolean,
  allDayMaintainDuration: Boolean,
  unselectAuto: Boolean,
  dropAccept: p,
  eventOrder: El,
  eventOrderStrict: Boolean,
  handleWindowResize: Boolean,
  windowResizeDelay: Number,
  longPressDelay: Number,
  eventDragMinDistance: Number,
  expandRows: Boolean,
  height: p,
  contentHeight: p,
  direction: String,
  weekNumberFormat: O,
  eventResizableFromStart: Boolean,
  displayEventTime: Boolean,
  displayEventEnd: Boolean,
  weekText: String,
  weekTextLong: String,
  progressiveEventRendering: Boolean,
  businessHours: p,
  initialDate: p,
  now: p,
  eventDataTransform: p,
  stickyHeaderDates: p,
  stickyFooterScrollbar: p,
  viewHeight: p,
  defaultAllDay: Boolean,
  eventSourceFailure: p,
  eventSourceSuccess: p,
  eventDisplay: String,
  eventStartEditable: Boolean,
  eventDurationEditable: Boolean,
  eventOverlap: p,
  eventConstraint: p,
  eventAllow: p,
  eventBackgroundColor: String,
  eventBorderColor: String,
  eventTextColor: String,
  eventColor: String,
  eventClassNames: p,
  eventContent: p,
  eventDidMount: p,
  eventWillUnmount: p,
  selectConstraint: p,
  selectOverlap: p,
  selectAllow: p,
  droppable: Boolean,
  unselectCancel: String,
  slotLabelFormat: p,
  slotLaneClassNames: p,
  slotLaneContent: p,
  slotLaneDidMount: p,
  slotLaneWillUnmount: p,
  slotLabelClassNames: p,
  slotLabelContent: p,
  slotLabelDidMount: p,
  slotLabelWillUnmount: p,
  dayMaxEvents: p,
  dayMaxEventRows: p,
  dayMinWidth: Number,
  slotLabelInterval: R,
  allDayText: String,
  allDayClassNames: p,
  allDayContent: p,
  allDayDidMount: p,
  allDayWillUnmount: p,
  slotMinWidth: Number,
  navLinks: Boolean,
  eventTimeFormat: O,
  rerenderDelay: Number,
  moreLinkText: p,
  moreLinkHint: p,
  selectMinDistance: Number,
  selectable: Boolean,
  selectLongPressDelay: Number,
  eventLongPressDelay: Number,
  selectMirror: Boolean,
  eventMaxStack: Number,
  eventMinHeight: Number,
  eventMinWidth: Number,
  eventShortHeight: Number,
  slotEventOverlap: Boolean,
  plugins: p,
  firstDay: Number,
  dayCount: Number,
  dateAlignment: String,
  dateIncrement: R,
  hiddenDays: p,
  fixedWeekCount: Boolean,
  validRange: p,
  visibleRange: p,
  titleFormat: p,
  eventInteractive: Boolean,
  // only used by list-view, but languages define the value, so we need it in base options
  noEventsText: String,
  viewHint: p,
  navLinkHint: p,
  closeHint: String,
  timeHint: String,
  eventHint: String,
  moreLinkClick: p,
  moreLinkClassNames: p,
  moreLinkContent: p,
  moreLinkDidMount: p,
  moreLinkWillUnmount: p,
  monthStartFormat: O,
  // for connectors
  // (can't be part of plugin system b/c must be provided at runtime)
  handleCustomRendering: p,
  customRenderingMetaMap: p,
  customRenderingReplaces: Boolean
}, Ue = {
  eventDisplay: "auto",
  defaultRangeSeparator: " - ",
  titleRangeSeparator: " – ",
  defaultTimedEventDuration: "01:00:00",
  defaultAllDayEventDuration: { day: 1 },
  forceEventDuration: !1,
  nextDayThreshold: "00:00:00",
  dayHeaders: !0,
  initialView: "",
  aspectRatio: 1.35,
  headerToolbar: {
    start: "title",
    center: "",
    end: "today prev,next"
  },
  weekends: !0,
  weekNumbers: !1,
  weekNumberCalculation: "local",
  editable: !1,
  nowIndicator: !1,
  scrollTime: "06:00:00",
  scrollTimeReset: !0,
  slotMinTime: "00:00:00",
  slotMaxTime: "24:00:00",
  showNonCurrentDates: !0,
  lazyFetching: !0,
  startParam: "start",
  endParam: "end",
  timeZoneParam: "timeZone",
  timeZone: "local",
  locales: [],
  locale: "",
  themeSystem: "standard",
  dragRevertDuration: 500,
  dragScroll: !0,
  allDayMaintainDuration: !1,
  unselectAuto: !0,
  dropAccept: "*",
  eventOrder: "start,-duration,allDay,title",
  dayPopoverFormat: { month: "long", day: "numeric", year: "numeric" },
  handleWindowResize: !0,
  windowResizeDelay: 100,
  longPressDelay: 1e3,
  eventDragMinDistance: 5,
  expandRows: !1,
  navLinks: !1,
  selectable: !1,
  eventMinHeight: 15,
  eventMinWidth: 30,
  eventShortHeight: 30,
  monthStartFormat: { month: "long", day: "numeric" },
  nowIndicatorSnap: "auto"
}, hr = {
  datesSet: p,
  eventsSet: p,
  eventAdd: p,
  eventChange: p,
  eventRemove: p,
  windowResize: p,
  eventClick: p,
  eventMouseEnter: p,
  eventMouseLeave: p,
  select: p,
  unselect: p,
  loading: p,
  // internal
  _unmount: p,
  _beforeprint: p,
  _afterprint: p,
  _noEventDrop: p,
  _noEventResize: p,
  _resize: p,
  _scrollRequest: p
}, gr = {
  buttonText: p,
  buttonHints: p,
  views: p,
  plugins: p,
  initialEvents: p,
  events: p,
  eventSources: p
}, be = {
  headerToolbar: Ae,
  footerToolbar: Ae,
  buttonText: Ae,
  buttonHints: Ae,
  buttonIcons: Ae,
  dateIncrement: Ae,
  plugins: nt,
  events: nt,
  eventSources: nt,
  resources: nt
};
function Ae(t, e) {
  return typeof t == "object" && typeof e == "object" && t && e ? Y(t, e) : t === e;
}
function nt(t, e) {
  return Array.isArray(t) && Array.isArray(e) ? ue(t, e) : t === e;
}
const oa = {
  type: String,
  component: p,
  buttonText: String,
  buttonTextKey: String,
  dateProfileGeneratorClass: p,
  usesMinMaxTime: Boolean,
  classNames: p,
  content: p,
  didMount: p,
  willUnmount: p
};
function Bt(t) {
  return hn(t, be);
}
function fn(t, e) {
  let n = {}, r = {};
  for (let i in e)
    i in t && (n[i] = e[i](t[i]));
  for (let i in t)
    i in e || (r[i] = t[i]);
  return { refined: n, extra: r };
}
function p(t) {
  return t;
}
const { hasOwnProperty: Et } = Object.prototype;
function hn(t, e) {
  let n = {};
  if (e) {
    for (let r in e)
      if (e[r] === Ae) {
        let i = [];
        for (let s = t.length - 1; s >= 0; s -= 1) {
          let l = t[s][r];
          if (typeof l == "object" && l)
            i.unshift(l);
          else if (l !== void 0) {
            n[r] = l;
            break;
          }
        }
        i.length && (n[r] = hn(i));
      }
  }
  for (let r = t.length - 1; r >= 0; r -= 1) {
    let i = t[r];
    for (let s in i)
      s in n || (n[s] = i[s]);
  }
  return n;
}
function Oe(t, e) {
  let n = {};
  for (let r in t)
    e(t[r], r) && (n[r] = t[r]);
  return n;
}
function Se(t, e) {
  let n = {};
  for (let r in t)
    n[r] = e(t[r], r);
  return n;
}
function Ai(t) {
  let e = {};
  for (let n of t)
    e[n] = !0;
  return e;
}
function gn(t) {
  let e = [];
  for (let n in t)
    e.push(t[n]);
  return e;
}
function Y(t, e) {
  if (t === e)
    return !0;
  for (let n in t)
    if (Et.call(t, n) && !(n in e))
      return !1;
  for (let n in e)
    if (Et.call(e, n) && t[n] !== e[n])
      return !1;
  return !0;
}
const ca = /^on[A-Z]/;
function da(t, e) {
  const n = ua(t, e);
  for (let r of n)
    if (!ca.test(r))
      return !1;
  return !0;
}
function ua(t, e) {
  let n = [];
  for (let r in t)
    Et.call(t, r) && (r in e || n.push(r));
  for (let r in e)
    Et.call(e, r) && t[r] !== e[r] && n.push(r);
  return n;
}
function Ft(t, e, n = {}) {
  if (t === e)
    return !0;
  for (let r in e)
    if (!(r in t && fa(t[r], e[r], n[r]))) return !1;
  for (let r in t)
    if (!(r in e))
      return !1;
  return !0;
}
function fa(t, e, n) {
  return t === e || n === !0 ? !0 : n ? n(t, e) : !1;
}
function ha(t, e = 0, n, r = 1) {
  let i = [];
  n == null && (n = Object.keys(t).length);
  for (let s = e; s < n; s += r) {
    let l = t[s];
    l !== void 0 && i.push(l);
  }
  return i;
}
let Ei = {};
function ga(t, e) {
  Ei[t] = e;
}
function pa(t) {
  return new Ei[t]();
}
class ma {
  getMarkerYear(e) {
    return e.getUTCFullYear();
  }
  getMarkerMonth(e) {
    return e.getUTCMonth();
  }
  getMarkerDay(e) {
    return e.getUTCDate();
  }
  arrayToMarker(e) {
    return j(e);
  }
  markerToArray(e) {
    return oe(e);
  }
}
ga("gregory", ma);
const va = /^\s*(\d{4})(-?(\d{2})(-?(\d{2})([T ](\d{2}):?(\d{2})(:?(\d{2})(\.(\d+))?)?(Z|(([-+])(\d{2})(:?(\d{2}))?))?)?)?)?$/;
function ya(t) {
  let e = va.exec(t);
  if (e) {
    let n = new Date(Date.UTC(Number(e[1]), e[3] ? Number(e[3]) - 1 : 0, Number(e[5] || 1), Number(e[7] || 0), Number(e[8] || 0), Number(e[10] || 0), e[12] ? +`0.${e[12]}` * 1e3 : 0));
    if (yi(n)) {
      let r = null;
      return e[13] && (r = (e[15] === "-" ? -1 : 1) * (Number(e[16] || 0) * 60 + Number(e[18] || 0))), {
        marker: n,
        isTimeUnspecified: !e[6],
        timeZoneOffset: r
      };
    }
  }
  return null;
}
class ba {
  constructor(e) {
    let n = this.timeZone = e.timeZone, r = n !== "local" && n !== "UTC";
    e.namedTimeZoneImpl && r && (this.namedTimeZoneImpl = new e.namedTimeZoneImpl(n)), this.canComputeOffset = !!(!r || this.namedTimeZoneImpl), this.calendarSystem = pa(e.calendarSystem), this.locale = e.locale, this.weekDow = e.locale.week.dow, this.weekDoy = e.locale.week.doy, e.weekNumberCalculation === "ISO" && (this.weekDow = 1, this.weekDoy = 4), typeof e.firstDay == "number" && (this.weekDow = e.firstDay), typeof e.weekNumberCalculation == "function" && (this.weekNumberFunc = e.weekNumberCalculation), this.weekText = e.weekText != null ? e.weekText : e.locale.options.weekText, this.weekTextLong = (e.weekTextLong != null ? e.weekTextLong : e.locale.options.weekTextLong) || this.weekText, this.cmdFormatter = e.cmdFormatter, this.defaultSeparator = e.defaultSeparator;
  }
  // Creating / Parsing
  createMarker(e) {
    let n = this.createMarkerMeta(e);
    return n === null ? null : n.marker;
  }
  createNowMarker() {
    return this.canComputeOffset ? this.timestampToMarker((/* @__PURE__ */ new Date()).valueOf()) : j(or(/* @__PURE__ */ new Date()));
  }
  createMarkerMeta(e) {
    if (typeof e == "string")
      return this.parse(e);
    let n = null;
    return typeof e == "number" ? n = this.timestampToMarker(e) : e instanceof Date ? (e = e.valueOf(), isNaN(e) || (n = this.timestampToMarker(e))) : Array.isArray(e) && (n = j(e)), n === null || !yi(n) ? null : { marker: n, isTimeUnspecified: !1, forcedTzo: null };
  }
  parse(e) {
    let n = ya(e);
    if (n === null)
      return null;
    let { marker: r } = n, i = null;
    return n.timeZoneOffset !== null && (this.canComputeOffset ? r = this.timestampToMarker(r.valueOf() - n.timeZoneOffset * 60 * 1e3) : i = n.timeZoneOffset), { marker: r, isTimeUnspecified: n.isTimeUnspecified, forcedTzo: i };
  }
  // Accessors
  getYear(e) {
    return this.calendarSystem.getMarkerYear(e);
  }
  getMonth(e) {
    return this.calendarSystem.getMarkerMonth(e);
  }
  getDay(e) {
    return this.calendarSystem.getMarkerDay(e);
  }
  // Adding / Subtracting
  add(e, n) {
    let r = this.calendarSystem.markerToArray(e);
    return r[0] += n.years, r[1] += n.months, r[2] += n.days, r[6] += n.milliseconds, this.calendarSystem.arrayToMarker(r);
  }
  subtract(e, n) {
    let r = this.calendarSystem.markerToArray(e);
    return r[0] -= n.years, r[1] -= n.months, r[2] -= n.days, r[6] -= n.milliseconds, this.calendarSystem.arrayToMarker(r);
  }
  addYears(e, n) {
    let r = this.calendarSystem.markerToArray(e);
    return r[0] += n, this.calendarSystem.arrayToMarker(r);
  }
  addMonths(e, n) {
    let r = this.calendarSystem.markerToArray(e);
    return r[1] += n, this.calendarSystem.arrayToMarker(r);
  }
  // Diffing Whole Units
  diffWholeYears(e, n) {
    let { calendarSystem: r } = this;
    return ce(e) === ce(n) && r.getMarkerDay(e) === r.getMarkerDay(n) && r.getMarkerMonth(e) === r.getMarkerMonth(n) ? r.getMarkerYear(n) - r.getMarkerYear(e) : null;
  }
  diffWholeMonths(e, n) {
    let { calendarSystem: r } = this;
    return ce(e) === ce(n) && r.getMarkerDay(e) === r.getMarkerDay(n) ? r.getMarkerMonth(n) - r.getMarkerMonth(e) + (r.getMarkerYear(n) - r.getMarkerYear(e)) * 12 : null;
  }
  // Range / Duration
  greatestWholeUnit(e, n) {
    let r = this.diffWholeYears(e, n);
    return r !== null ? { unit: "year", value: r } : (r = this.diffWholeMonths(e, n), r !== null ? { unit: "month", value: r } : (r = zl(e, n), r !== null ? { unit: "week", value: r } : (r = yt(e, n), r !== null ? { unit: "day", value: r } : (r = Hl(e, n), dt(r) ? { unit: "hour", value: r } : (r = Pl(e, n), dt(r) ? { unit: "minute", value: r } : (r = Bl(e, n), dt(r) ? { unit: "second", value: r } : { unit: "millisecond", value: n.valueOf() - e.valueOf() }))))));
  }
  countDurationsBetween(e, n, r) {
    let i;
    return r.years && (i = this.diffWholeYears(e, n), i !== null) ? i / Ml(r) : r.months && (i = this.diffWholeMonths(e, n), i !== null) ? i / Il(r) : r.days && (i = yt(e, n), i !== null) ? i / Me(r) : (n.valueOf() - e.valueOf()) / q(r);
  }
  // Start-Of
  // these DON'T return zoned-dates. only UTC start-of dates
  startOf(e, n) {
    return n === "year" ? this.startOfYear(e) : n === "month" ? this.startOfMonth(e) : n === "week" ? this.startOfWeek(e) : n === "day" ? I(e) : n === "hour" ? Ul(e) : n === "minute" ? Wl(e) : n === "second" ? Ll(e) : null;
  }
  startOfYear(e) {
    return this.calendarSystem.arrayToMarker([
      this.calendarSystem.getMarkerYear(e)
    ]);
  }
  startOfMonth(e) {
    return this.calendarSystem.arrayToMarker([
      this.calendarSystem.getMarkerYear(e),
      this.calendarSystem.getMarkerMonth(e)
    ]);
  }
  startOfWeek(e) {
    return this.calendarSystem.arrayToMarker([
      this.calendarSystem.getMarkerYear(e),
      this.calendarSystem.getMarkerMonth(e),
      e.getUTCDate() - (e.getUTCDay() - this.weekDow + 7) % 7
    ]);
  }
  // Week Number
  computeWeekNumber(e) {
    return this.weekNumberFunc ? this.weekNumberFunc(this.toDate(e)) : jl(e, this.weekDow, this.weekDoy);
  }
  // TODO: choke on timeZoneName: long
  format(e, n, r = {}) {
    return n.format({
      marker: e,
      timeZoneOffset: r.forcedTzo != null ? r.forcedTzo : this.offsetForMarker(e)
    }, this);
  }
  formatRange(e, n, r, i = {}) {
    return i.isEndExclusive && (n = fe(n, -1)), r.formatRange({
      marker: e,
      timeZoneOffset: i.forcedStartTzo != null ? i.forcedStartTzo : this.offsetForMarker(e)
    }, {
      marker: n,
      timeZoneOffset: i.forcedEndTzo != null ? i.forcedEndTzo : this.offsetForMarker(n)
    }, this, i.defaultSeparator);
  }
  /*
  DUMB: the omitTime arg is dumb. if we omit the time, we want to omit the timezone offset. and if we do that,
  might as well use buildIsoString or some other util directly
  */
  formatIso(e, n = {}) {
    let r = null;
    return n.omitTimeZoneOffset || (n.forcedTzo != null ? r = n.forcedTzo : r = this.offsetForMarker(e)), bi(e, r, n.omitTime);
  }
  // TimeZone
  timestampToMarker(e) {
    return this.timeZone === "local" ? j(or(new Date(e))) : this.timeZone === "UTC" || !this.namedTimeZoneImpl ? new Date(e) : j(this.namedTimeZoneImpl.timestampToArray(e));
  }
  offsetForMarker(e) {
    return this.timeZone === "local" ? -cr(oe(e)).getTimezoneOffset() : this.timeZone === "UTC" ? 0 : this.namedTimeZoneImpl ? this.namedTimeZoneImpl.offsetForArray(oe(e)) : null;
  }
  // Conversion
  toDate(e, n) {
    return this.timeZone === "local" ? cr(oe(e)) : this.timeZone === "UTC" ? new Date(e.valueOf()) : this.namedTimeZoneImpl ? new Date(e.valueOf() - this.namedTimeZoneImpl.offsetForArray(oe(e)) * 1e3 * 60) : new Date(e.valueOf() - (n || 0));
  }
}
class qe {
  constructor(e) {
    this.iconOverrideOption && this.setIconOverride(e[this.iconOverrideOption]);
  }
  setIconOverride(e) {
    let n, r;
    if (typeof e == "object" && e) {
      n = Object.assign({}, this.iconClasses);
      for (r in e)
        n[r] = this.applyIconOverridePrefix(e[r]);
      this.iconClasses = n;
    } else e === !1 && (this.iconClasses = {});
  }
  applyIconOverridePrefix(e) {
    let n = this.iconOverridePrefix;
    return n && e.indexOf(n) !== 0 && (e = n + e), e;
  }
  getClass(e) {
    return this.classes[e] || "";
  }
  getIconClass(e, n) {
    let r;
    return n && this.rtlIconClasses ? r = this.rtlIconClasses[e] || this.iconClasses[e] : r = this.iconClasses[e], r ? `${this.baseIconClass} ${r}` : "";
  }
  getCustomButtonIconClass(e) {
    let n;
    return this.iconOverrideCustomButtonOption && (n = e[this.iconOverrideCustomButtonOption], n) ? `${this.baseIconClass} ${this.applyIconOverridePrefix(n)}` : "";
  }
}
qe.prototype.classes = {};
qe.prototype.iconClasses = {};
qe.prototype.baseIconClass = "";
qe.prototype.iconOverridePrefix = "";
function Ct(t) {
  t();
  let e = S.debounceRendering, n = [];
  function r(i) {
    n.push(i);
  }
  for (S.debounceRendering = r, je(u(Aa, {}), document.createElement("div")); n.length; )
    n.shift()();
  S.debounceRendering = e;
}
class Aa extends G {
  render() {
    return u("div", {});
  }
  componentDidMount() {
    this.setState({});
  }
}
function Ci(t) {
  let e = qs(t), n = e.Provider;
  return e.Provider = function() {
    let r = !this.getChildContext, i = n.apply(this, arguments);
    if (r) {
      let s = [];
      this.shouldComponentUpdate = (l) => {
        this.props.value !== l.value && s.forEach((a) => {
          a.context = l.value, a.forceUpdate();
        });
      }, this.sub = (l) => {
        s.push(l);
        let a = l.componentWillUnmount;
        l.componentWillUnmount = () => {
          s.splice(s.indexOf(l), 1), a && a.call(l);
        };
      };
    }
    return i;
  }, e;
}
class Ea {
  constructor(e, n, r, i) {
    this.execFunc = e, this.emitter = n, this.scrollTime = r, this.scrollTimeReset = i, this.handleScrollRequest = (s) => {
      this.queuedRequest = Object.assign({}, this.queuedRequest || {}, s), this.drain();
    }, n.on("_scrollRequest", this.handleScrollRequest), this.fireInitialScroll();
  }
  detach() {
    this.emitter.off("_scrollRequest", this.handleScrollRequest);
  }
  update(e) {
    e && this.scrollTimeReset ? this.fireInitialScroll() : this.drain();
  }
  fireInitialScroll() {
    this.handleScrollRequest({
      time: this.scrollTime
    });
  }
  drain() {
    this.queuedRequest && this.execFunc(this.queuedRequest) && (this.queuedRequest = null);
  }
}
const ie = Ci({});
function Ca(t, e, n, r, i, s, l, a, o, d, c, g, h, f) {
  return {
    dateEnv: i,
    nowManager: s,
    options: n,
    pluginHooks: a,
    emitter: c,
    dispatch: o,
    getCurrentData: d,
    calendarApi: g,
    viewSpec: t,
    viewApi: e,
    dateProfileGenerator: r,
    theme: l,
    isRtl: n.direction === "rtl",
    addResizeHandler(m) {
      c.on("_resize", m);
    },
    removeResizeHandler(m) {
      c.off("_resize", m);
    },
    createScrollResponder(m) {
      return new Ea(m, c, R(n.scrollTime), n.scrollTimeReset);
    },
    registerInteractiveComponent: h,
    unregisterInteractiveComponent: f
  };
}
class we extends G {
  // debug: boolean
  shouldComponentUpdate(e, n) {
    return !Ft(
      this.props,
      e,
      this.propEquality
      /*, this.debug */
    ) || !Ft(
      this.state,
      n,
      this.stateEquality
      /*, this.debug */
    );
  }
  // HACK for freakin' React StrictMode
  safeSetState(e) {
    Ft(this.state, Object.assign(Object.assign({}, this.state), e), this.stateEquality) || this.setState(e);
  }
}
we.addPropsEquality = Sa;
we.addStateEquality = Da;
we.contextType = ie;
we.prototype.propEquality = {};
we.prototype.stateEquality = {};
class T extends we {
}
T.contextType = ie;
function Sa(t) {
  let e = Object.create(this.prototype.propEquality);
  Object.assign(e, t), this.prototype.propEquality = e;
}
function Da(t) {
  let e = Object.create(this.prototype.stateEquality);
  Object.assign(e, t), this.prototype.stateEquality = e;
}
function J(t, e) {
  typeof t == "function" ? t(e) : t && (t.current = e);
}
class pn extends T {
  constructor() {
    super(...arguments), this.id = De(), this.queuedDomNodes = [], this.currentDomNodes = [], this.handleEl = (e) => {
      const { options: n } = this.context, { generatorName: r } = this.props;
      (!n.customRenderingReplaces || !Kt(r, n)) && this.updateElRef(e);
    }, this.updateElRef = (e) => {
      this.props.elRef && J(this.props.elRef, e);
    };
  }
  render() {
    const { props: e, context: n } = this, { options: r } = n, { customGenerator: i, defaultGenerator: s, renderProps: l } = e, a = Si(e, [], this.handleEl);
    let o = !1, d, c = [], g;
    if (i != null) {
      const h = typeof i == "function" ? i(l, u) : i;
      if (h === !0)
        o = !0;
      else {
        const f = h && typeof h == "object";
        f && "html" in h ? a.dangerouslySetInnerHTML = { __html: h.html } : f && "domNodes" in h ? c = Array.prototype.slice.call(h.domNodes) : (f ? Yr(h) : typeof h != "function") ? d = h : g = h;
      }
    } else
      o = !Kt(e.generatorName, r);
    return o && s && (d = s(l)), this.queuedDomNodes = c, this.currentGeneratorMeta = g, u(e.elTag, a, d);
  }
  componentDidMount() {
    this.applyQueueudDomNodes(), this.triggerCustomRendering(!0);
  }
  componentDidUpdate() {
    this.applyQueueudDomNodes(), this.triggerCustomRendering(!0);
  }
  componentWillUnmount() {
    this.triggerCustomRendering(!1);
  }
  triggerCustomRendering(e) {
    var n;
    const { props: r, context: i } = this, { handleCustomRendering: s, customRenderingMetaMap: l } = i.options;
    if (s) {
      const a = (n = this.currentGeneratorMeta) !== null && n !== void 0 ? n : l?.[r.generatorName];
      a && s(Object.assign(Object.assign({
        id: this.id,
        isActive: e,
        containerEl: this.base,
        reportNewContainerEl: this.updateElRef,
        // front-end framework tells us about new container els
        generatorMeta: a
      }, r), { elClasses: (r.elClasses || []).filter(wa) }));
    }
  }
  applyQueueudDomNodes() {
    const { queuedDomNodes: e, currentDomNodes: n } = this, r = this.base;
    if (!ue(e, n)) {
      n.forEach(hl);
      for (let i of e)
        r.appendChild(i);
      this.currentDomNodes = e;
    }
  }
}
pn.addPropsEquality({
  elClasses: ue,
  elStyle: Y,
  elAttrs: da,
  renderProps: Y
});
function Kt(t, e) {
  var n;
  return !!(e.handleCustomRendering && t && (!((n = e.customRenderingMetaMap) === null || n === void 0) && n[t]));
}
function Si(t, e, n) {
  const r = Object.assign(Object.assign({}, t.elAttrs), { ref: n });
  return (t.elClasses || e) && (r.className = (t.elClasses || []).concat(e || []).concat(r.className || []).filter(Boolean).join(" ")), t.elStyle && (r.style = t.elStyle), r;
}
function wa(t) {
  return !!t;
}
const Di = Ci(0);
class U extends G {
  constructor() {
    super(...arguments), this.InnerContent = _a.bind(void 0, this), this.handleEl = (e) => {
      this.el = e, this.props.elRef && (J(this.props.elRef, e), e && this.didMountMisfire && this.componentDidMount());
    };
  }
  render() {
    const { props: e } = this, n = Ra(e.classNameGenerator, e.renderProps);
    if (e.children) {
      const r = Si(e, n, this.handleEl), i = e.children(this.InnerContent, e.renderProps, r);
      return e.elTag ? u(e.elTag, r, i) : i;
    } else
      return u(pn, Object.assign(Object.assign({}, e), { elRef: this.handleEl, elTag: e.elTag || "div", elClasses: (e.elClasses || []).concat(n), renderId: this.context }));
  }
  componentDidMount() {
    var e, n;
    this.el ? (n = (e = this.props).didMount) === null || n === void 0 || n.call(e, Object.assign(Object.assign({}, this.props.renderProps), { el: this.el })) : this.didMountMisfire = !0;
  }
  componentWillUnmount() {
    var e, n;
    (n = (e = this.props).willUnmount) === null || n === void 0 || n.call(e, Object.assign(Object.assign({}, this.props.renderProps), { el: this.el }));
  }
}
U.contextType = Di;
function _a(t, e) {
  const n = t.props;
  return u(pn, Object.assign({ renderProps: n.renderProps, generatorName: n.generatorName, customGenerator: n.customGenerator, defaultGenerator: n.defaultGenerator, renderId: t.context }, e));
}
function Ra(t, e) {
  const n = typeof t == "function" ? t(e) : t || [];
  return typeof n == "string" ? [n] : n;
}
class Ve extends T {
  render() {
    let { props: e, context: n } = this, { options: r } = n, i = { view: n.viewApi };
    return u(U, { elRef: e.elRef, elTag: e.elTag || "div", elAttrs: e.elAttrs, elClasses: [
      ...wi(e.viewSpec),
      ...e.elClasses || []
    ], elStyle: e.elStyle, renderProps: i, classNameGenerator: r.viewClassNames, generatorName: void 0, didMount: r.viewDidMount, willUnmount: r.viewWillUnmount }, () => e.children);
  }
}
function wi(t) {
  return [
    `fc-${t.type}-view`,
    "fc-view"
  ];
}
function Ta(t, e) {
  let n = null, r = null;
  return t.start && (n = e.createMarker(t.start)), t.end && (r = e.createMarker(t.end)), !n && !r || n && r && r < n ? null : { start: n, end: r };
}
function pr(t, e) {
  let n = [], { start: r } = e, i, s;
  for (t.sort(xa), i = 0; i < t.length; i += 1)
    s = t[i], s.start > r && n.push({ start: r, end: s.start }), s.end > r && (r = s.end);
  return r < e.end && n.push({ start: r, end: e.end }), n;
}
function xa(t, e) {
  return t.start.valueOf() - e.start.valueOf();
}
function he(t, e) {
  let { start: n, end: r } = t, i = null;
  return e.start !== null && (n === null ? n = e.start : n = new Date(Math.max(n.valueOf(), e.start.valueOf()))), e.end != null && (r === null ? r = e.end : r = new Date(Math.min(r.valueOf(), e.end.valueOf()))), (n === null || r === null || n < r) && (i = { start: n, end: r }), i;
}
function ka(t, e) {
  return (t.end === null || e.start === null || t.end > e.start) && (t.start === null || e.end === null || t.start < e.end);
}
function te(t, e) {
  return (t.start === null || e >= t.start) && (t.end === null || e < t.end);
}
function Ma(t, e) {
  return e.start != null && t < e.start ? e.start : e.end != null && t >= e.end ? new Date(e.end.valueOf() - 1) : t;
}
function _i(t) {
  let e = Math.floor(ge(t.start, t.end)) || 1, n = I(t.start), r = B(n, e);
  return { start: n, end: r };
}
function mn(t, e = R(0)) {
  let n = null, r = null;
  if (t.end) {
    r = I(t.end);
    let i = t.end.valueOf() - r.valueOf();
    i && i >= q(e) && (r = B(r, 1));
  }
  return t.start && (n = I(t.start), r && r <= n && (r = B(n, 1))), { start: n, end: r };
}
function Ia(t) {
  let e = mn(t);
  return ge(e.start, e.end) > 1;
}
function rt(t, e, n, r) {
  return r === "year" ? R(n.diffWholeYears(t, e), "year") : r === "month" ? R(n.diffWholeMonths(t, e), "month") : Fl(t, e);
}
class Ri {
  constructor(e) {
    this.props = e, this.initHiddenDays();
  }
  /* Date Range Computation
  ------------------------------------------------------------------------------------------------------------------*/
  // Builds a structure with info about what the dates/ranges will be for the "prev" view.
  buildPrev(e, n, r) {
    let { dateEnv: i } = this.props, s = i.subtract(
      i.startOf(n, e.currentRangeUnit),
      // important for start-of-month
      e.dateIncrement
    );
    return this.build(s, -1, r);
  }
  // Builds a structure with info about what the dates/ranges will be for the "next" view.
  buildNext(e, n, r) {
    let { dateEnv: i } = this.props, s = i.add(
      i.startOf(n, e.currentRangeUnit),
      // important for start-of-month
      e.dateIncrement
    );
    return this.build(s, 1, r);
  }
  // Builds a structure holding dates/ranges for rendering around the given date.
  // Optional direction param indicates whether the date is being incremented/decremented
  // from its previous value. decremented = -1, incremented = 1 (default).
  build(e, n, r = !0) {
    let { props: i } = this, s, l, a, o, d, c;
    return s = this.buildValidRange(), s = this.trimHiddenDays(s), r && (e = Ma(e, s)), l = this.buildCurrentRangeInfo(e, n), a = /^(year|month|week|day)$/.test(l.unit), o = this.buildRenderRange(this.trimHiddenDays(l.range), l.unit, a), o = this.trimHiddenDays(o), d = o, i.showNonCurrentDates || (d = he(d, l.range)), d = this.adjustActiveRange(d), d = he(d, s), c = ka(l.range, s), te(o, e) || (e = o.start), {
      currentDate: e,
      // constraint for where prev/next operations can go and where events can be dragged/resized to.
      // an object with optional start and end properties.
      validRange: s,
      // range the view is formally responsible for.
      // for example, a month view might have 1st-31st, excluding padded dates
      currentRange: l.range,
      // name of largest unit being displayed, like "month" or "week"
      currentRangeUnit: l.unit,
      isRangeAllDay: a,
      // dates that display events and accept drag-n-drop
      // will be `null` if no dates accept events
      activeRange: d,
      // date range with a rendered skeleton
      // includes not-active days that need some sort of DOM
      renderRange: o,
      // Duration object that denotes the first visible time of any given day
      slotMinTime: i.slotMinTime,
      // Duration object that denotes the exclusive visible end time of any given day
      slotMaxTime: i.slotMaxTime,
      isValid: c,
      // how far the current date will move for a prev/next operation
      dateIncrement: this.buildDateIncrement(l.duration)
      // pass a fallback (might be null) ^
    };
  }
  // Builds an object with optional start/end properties.
  // Indicates the minimum/maximum dates to display.
  // not responsible for trimming hidden days.
  buildValidRange() {
    let e = this.props.validRangeInput, n = typeof e == "function" ? e.call(this.props.calendarApi, this.props.dateEnv.toDate(this.props.nowManager.getDateMarker())) : e;
    return this.refineRange(n) || { start: null, end: null };
  }
  // Builds a structure with info about the "current" range, the range that is
  // highlighted as being the current month for example.
  // See build() for a description of `direction`.
  // Guaranteed to have `range` and `unit` properties. `duration` is optional.
  buildCurrentRangeInfo(e, n) {
    let { props: r } = this, i = null, s = null, l = null, a;
    return r.duration ? (i = r.duration, s = r.durationUnit, l = this.buildRangeFromDuration(e, n, i, s)) : (a = this.props.dayCount) ? (s = "day", l = this.buildRangeFromDayCount(e, n, a)) : (l = this.buildCustomVisibleRange(e)) ? s = r.dateEnv.greatestWholeUnit(l.start, l.end).unit : (i = this.getFallbackDuration(), s = Jt(i).unit, l = this.buildRangeFromDuration(e, n, i, s)), { duration: i, unit: s, range: l };
  }
  getFallbackDuration() {
    return R({ day: 1 });
  }
  // Returns a new activeRange to have time values (un-ambiguate)
  // slotMinTime or slotMaxTime causes the range to expand.
  adjustActiveRange(e) {
    let { dateEnv: n, usesMinMaxTime: r, slotMinTime: i, slotMaxTime: s } = this.props, { start: l, end: a } = e;
    return r && (Me(i) < 0 && (l = I(l), l = n.add(l, i)), Me(s) > 1 && (a = I(a), a = B(a, -1), a = n.add(a, s))), { start: l, end: a };
  }
  // Builds the "current" range when it is specified as an explicit duration.
  // `unit` is the already-computed greatestDurationDenominator unit of duration.
  buildRangeFromDuration(e, n, r, i) {
    let { dateEnv: s, dateAlignment: l } = this.props, a, o, d;
    if (!l) {
      let { dateIncrement: g } = this.props;
      g && q(g) < q(r) ? l = Jt(g).unit : l = i;
    }
    Me(r) <= 1 && this.isHiddenDay(a) && (a = this.skipHiddenDays(a, n), a = I(a));
    function c() {
      a = s.startOf(e, l), o = s.add(a, r), d = { start: a, end: o };
    }
    return c(), this.trimHiddenDays(d) || (e = this.skipHiddenDays(e, n), c()), d;
  }
  // Builds the "current" range when a dayCount is specified.
  buildRangeFromDayCount(e, n, r) {
    let { dateEnv: i, dateAlignment: s } = this.props, l = 0, a = e, o;
    s && (a = i.startOf(a, s)), a = I(a), a = this.skipHiddenDays(a, n), o = a;
    do
      o = B(o, 1), this.isHiddenDay(o) || (l += 1);
    while (l < r);
    return { start: a, end: o };
  }
  // Builds a normalized range object for the "visible" range,
  // which is a way to define the currentRange and activeRange at the same time.
  buildCustomVisibleRange(e) {
    let { props: n } = this, r = n.visibleRangeInput, i = typeof r == "function" ? r.call(n.calendarApi, n.dateEnv.toDate(e)) : r, s = this.refineRange(i);
    return s && (s.start == null || s.end == null) ? null : s;
  }
  // Computes the range that will represent the element/cells for *rendering*,
  // but which may have voided days/times.
  // not responsible for trimming hidden days.
  buildRenderRange(e, n, r) {
    return e;
  }
  // Compute the duration value that should be added/substracted to the current date
  // when a prev/next operation happens.
  buildDateIncrement(e) {
    let { dateIncrement: n } = this.props, r;
    return n || ((r = this.props.dateAlignment) ? R(1, r) : e || R({ days: 1 }));
  }
  refineRange(e) {
    if (e) {
      let n = Ta(e, this.props.dateEnv);
      return n && (n = mn(n)), n;
    }
    return null;
  }
  /* Hidden Days
  ------------------------------------------------------------------------------------------------------------------*/
  // Initializes internal variables related to calculating hidden days-of-week
  initHiddenDays() {
    let e = this.props.hiddenDays || [], n = [], r = 0, i;
    for (this.props.weekends === !1 && e.push(0, 6), i = 0; i < 7; i += 1)
      (n[i] = e.indexOf(i) !== -1) || (r += 1);
    if (!r)
      throw new Error("invalid hiddenDays");
    this.isHiddenDayHash = n;
  }
  // Remove days from the beginning and end of the range that are computed as hidden.
  // If the whole range is trimmed off, returns null
  trimHiddenDays(e) {
    let { start: n, end: r } = e;
    return n && (n = this.skipHiddenDays(n)), r && (r = this.skipHiddenDays(r, -1, !0)), n == null || r == null || n < r ? { start: n, end: r } : null;
  }
  // Is the current day hidden?
  // `day` is a day-of-week index (0-6), or a Date (used for UTC)
  isHiddenDay(e) {
    return e instanceof Date && (e = e.getUTCDay()), this.isHiddenDayHash[e];
  }
  // Incrementing the current day until it is no longer a hidden day, returning a copy.
  // DOES NOT CONSIDER validRange!
  // If the initial value of `date` is not a hidden day, don't do anything.
  // Pass `isExclusive` as `true` if you are dealing with an end date.
  // `inc` defaults to `1` (increment one day forward each time)
  skipHiddenDays(e, n = 1, r = !1) {
    for (; this.isHiddenDayHash[(e.getUTCDay() + (r ? n : 0) + 7) % 7]; )
      e = B(e, n);
    return e;
  }
}
function vn(t, e, n, r) {
  return {
    instanceId: De(),
    defId: t,
    range: e,
    forcedStartTzo: n ?? null,
    forcedEndTzo: r ?? null
  };
}
function Na(t, e, n, r) {
  for (let i = 0; i < r.length; i += 1) {
    let s = r[i].parse(t, n);
    if (s) {
      let { allDay: l } = t;
      return l == null && (l = e, l == null && (l = s.allDayGuess, l == null && (l = !1))), {
        allDay: l,
        duration: s.duration,
        typeData: s.typeData,
        typeId: i
      };
    }
  }
  return null;
}
function Ye(t, e, n) {
  let { dateEnv: r, pluginHooks: i, options: s } = n, { defs: l, instances: a } = t;
  a = Oe(a, (o) => !l[o.defId].recurringDef);
  for (let o in l) {
    let d = l[o];
    if (d.recurringDef) {
      let { duration: c } = d.recurringDef;
      c || (c = d.allDay ? s.defaultAllDayEventDuration : s.defaultTimedEventDuration);
      let g = Oa(d, c, e, r, i.recurringTypes);
      for (let h of g) {
        let f = vn(o, {
          start: h,
          end: r.add(h, c)
        });
        a[f.instanceId] = f;
      }
    }
  }
  return { defs: l, instances: a };
}
function Oa(t, e, n, r, i) {
  let l = i[t.recurringDef.typeId].expand(t.recurringDef.typeData, {
    start: r.subtract(n.start, e),
    end: n.end
  }, r);
  return t.allDay && (l = l.map(I)), l;
}
const ft = {
  id: String,
  groupId: String,
  title: String,
  url: String,
  interactive: Boolean
}, Ti = {
  start: p,
  end: p,
  date: p,
  allDay: Boolean
}, Ha = Object.assign(Object.assign(Object.assign({}, ft), Ti), { extendedProps: p });
function xi(t, e, n, r, i = yn(n), s, l) {
  let { refined: a, extra: o } = ki(t, n, i), d = Ba(e, n), c = Na(a, d, n.dateEnv, n.pluginHooks.recurringTypes);
  if (c) {
    let h = Xt(a, o, e ? e.sourceId : "", c.allDay, !!c.duration, n, s);
    return h.recurringDef = {
      typeId: c.typeId,
      typeData: c.typeData,
      duration: c.duration
    }, { def: h, instance: null };
  }
  let g = Pa(a, d, n, r);
  if (g) {
    let h = Xt(a, o, e ? e.sourceId : "", g.allDay, g.hasEnd, n, s), f = vn(h.defId, g.range, g.forcedStartTzo, g.forcedEndTzo);
    return l && h.publicId && l[h.publicId] && (f.instanceId = l[h.publicId]), { def: h, instance: f };
  }
  return null;
}
function ki(t, e, n = yn(e)) {
  return fn(t, n);
}
function yn(t) {
  return Object.assign(Object.assign(Object.assign({}, St), Ha), t.pluginHooks.eventRefiners);
}
function Xt(t, e, n, r, i, s, l) {
  let a = {
    title: t.title || "",
    groupId: t.groupId || "",
    publicId: t.id || "",
    url: t.url || "",
    recurringDef: null,
    defId: (l && t.id ? l[t.id] : "") || De(),
    sourceId: n,
    allDay: r,
    hasEnd: i,
    interactive: t.interactive,
    ui: Dt(t, s),
    extendedProps: Object.assign(Object.assign({}, t.extendedProps || {}), e)
  };
  for (let o of s.pluginHooks.eventDefMemberAdders)
    Object.assign(a, o(t));
  return Object.freeze(a.ui.classNames), Object.freeze(a.extendedProps), a;
}
function Pa(t, e, n, r) {
  let { allDay: i } = t, s, l = null, a = !1, o, d = null, c = t.start != null ? t.start : t.date;
  if (s = n.dateEnv.createMarkerMeta(c), s)
    l = s.marker;
  else if (!r)
    return null;
  return t.end != null && (o = n.dateEnv.createMarkerMeta(t.end)), i == null && (e != null ? i = e : i = (!s || s.isTimeUnspecified) && (!o || o.isTimeUnspecified)), i && l && (l = I(l)), o && (d = o.marker, i && (d = I(d)), l && d <= l && (d = null)), d ? a = !0 : r || (a = n.options.forceEventDuration || !1, d = n.dateEnv.add(l, i ? n.options.defaultAllDayEventDuration : n.options.defaultTimedEventDuration)), {
    allDay: i,
    hasEnd: a,
    range: { start: l, end: d },
    forcedStartTzo: s ? s.forcedTzo : null,
    forcedEndTzo: o ? o.forcedTzo : null
  };
}
function Ba(t, e) {
  let n = null;
  return t && (n = t.defaultAllDay), n == null && (n = e.options.defaultAllDay), n;
}
function Ge(t, e, n, r, i, s) {
  let l = re(), a = yn(n);
  for (let o of t) {
    let d = xi(o, e, n, r, a, i, s);
    d && en(d, l);
  }
  return l;
}
function en(t, e = re()) {
  return e.defs[t.def.defId] = t.def, t.instance && (e.instances[t.instance.instanceId] = t.instance), e;
}
function Fa(t, e) {
  let n = t.instances[e];
  if (n) {
    let r = t.defs[n.defId], i = An(t, (s) => za(r, s));
    return i.defs[r.defId] = r, i.instances[n.instanceId] = n, i;
  }
  return re();
}
function za(t, e) {
  return !!(t.groupId && t.groupId === e.groupId);
}
function re() {
  return { defs: {}, instances: {} };
}
function bn(t, e) {
  return {
    defs: Object.assign(Object.assign({}, t.defs), e.defs),
    instances: Object.assign(Object.assign({}, t.instances), e.instances)
  };
}
function An(t, e) {
  let n = Oe(t.defs, e), r = Oe(t.instances, (i) => n[i.defId]);
  return { defs: n, instances: r };
}
function Ua(t, e) {
  let { defs: n, instances: r } = t, i = {}, s = {};
  for (let l in n)
    e.defs[l] || (i[l] = n[l]);
  for (let l in r)
    !e.instances[l] && // not explicitly excluded
    i[r[l].defId] && (s[l] = r[l]);
  return {
    defs: i,
    instances: s
  };
}
function Wa(t, e) {
  return Array.isArray(t) ? Ge(t, null, e, !0) : typeof t == "object" && t ? Ge([t], null, e, !0) : t != null ? String(t) : null;
}
function mr(t) {
  return Array.isArray(t) ? t : typeof t == "string" ? t.split(/\s+/) : [];
}
const St = {
  display: String,
  editable: Boolean,
  startEditable: Boolean,
  durationEditable: Boolean,
  constraint: p,
  overlap: p,
  allow: p,
  className: mr,
  classNames: mr,
  color: String,
  backgroundColor: String,
  borderColor: String,
  textColor: String
}, La = {
  display: null,
  startEditable: null,
  durationEditable: null,
  constraints: [],
  overlap: null,
  allows: [],
  backgroundColor: "",
  borderColor: "",
  textColor: "",
  classNames: []
};
function Dt(t, e) {
  let n = Wa(t.constraint, e);
  return {
    display: t.display || null,
    startEditable: t.startEditable != null ? t.startEditable : t.editable,
    durationEditable: t.durationEditable != null ? t.durationEditable : t.editable,
    constraints: n != null ? [n] : [],
    overlap: t.overlap != null ? t.overlap : null,
    allows: t.allow != null ? [t.allow] : [],
    backgroundColor: t.backgroundColor || t.color || "",
    borderColor: t.borderColor || t.color || "",
    textColor: t.textColor || "",
    classNames: (t.className || []).concat(t.classNames || [])
    // join singular and plural
  };
}
function Mi(t) {
  return t.reduce(ja, La);
}
function ja(t, e) {
  return {
    display: e.display != null ? e.display : t.display,
    startEditable: e.startEditable != null ? e.startEditable : t.startEditable,
    durationEditable: e.durationEditable != null ? e.durationEditable : t.durationEditable,
    constraints: t.constraints.concat(e.constraints),
    overlap: typeof e.overlap == "boolean" ? e.overlap : t.overlap,
    allows: t.allows.concat(e.allows),
    backgroundColor: e.backgroundColor || t.backgroundColor,
    borderColor: e.borderColor || t.borderColor,
    textColor: e.textColor || t.textColor,
    classNames: t.classNames.concat(e.classNames)
  };
}
const Va = {
  id: String,
  defaultAllDay: Boolean,
  url: String,
  format: String,
  events: p,
  eventDataTransform: p,
  // for any network-related sources
  success: p,
  failure: p
};
function Ii(t, e, n = Ni(e)) {
  let r;
  if (typeof t == "string" ? r = { url: t } : typeof t == "function" || Array.isArray(t) ? r = { events: t } : typeof t == "object" && t && (r = t), r) {
    let { refined: i, extra: s } = fn(r, n), l = Ga(i, e);
    if (l)
      return {
        _raw: t,
        isFetching: !1,
        latestFetchId: "",
        fetchRange: null,
        defaultAllDay: i.defaultAllDay,
        eventDataTransform: i.eventDataTransform,
        success: i.success,
        failure: i.failure,
        publicId: i.id || "",
        sourceId: De(),
        sourceDefId: l.sourceDefId,
        meta: l.meta,
        ui: Dt(i, e),
        extendedProps: s
      };
  }
  return null;
}
function Ni(t) {
  return Object.assign(Object.assign(Object.assign({}, St), Va), t.pluginHooks.eventSourceRefiners);
}
function Ga(t, e) {
  let n = e.pluginHooks.eventSourceDefs;
  for (let r = n.length - 1; r >= 0; r -= 1) {
    let s = n[r].parseMeta(t);
    if (s)
      return { sourceDefId: r, meta: s };
  }
  return null;
}
function Qa(t, e, n, r, i) {
  switch (e.type) {
    case "RECEIVE_EVENTS":
      return qa(t, n[e.sourceId], e.fetchId, e.fetchRange, e.rawEvents, i);
    case "RESET_RAW_EVENTS":
      return Ya(t, n[e.sourceId], e.rawEvents, r.activeRange, i);
    case "ADD_EVENTS":
      return Za(
        t,
        e.eventStore,
        // new ones
        r ? r.activeRange : null,
        i
      );
    case "RESET_EVENTS":
      return e.eventStore;
    case "MERGE_EVENTS":
      return bn(t, e.eventStore);
    case "PREV":
    // TODO: how do we track all actions that affect dateProfile :(
    case "NEXT":
    case "CHANGE_DATE":
    case "CHANGE_VIEW_TYPE":
      return r ? Ye(t, r.activeRange, i) : t;
    case "REMOVE_EVENTS":
      return Ua(t, e.eventStore);
    case "REMOVE_EVENT_SOURCE":
      return Hi(t, e.sourceId);
    case "REMOVE_ALL_EVENT_SOURCES":
      return An(t, (s) => !s.sourceId);
    case "REMOVE_ALL_EVENTS":
      return re();
    default:
      return t;
  }
}
function qa(t, e, n, r, i, s) {
  if (e && // not already removed
  n === e.latestFetchId) {
    let l = Ge(Oi(i, e, s), e, s);
    return r && (l = Ye(l, r, s)), bn(Hi(t, e.sourceId), l);
  }
  return t;
}
function Ya(t, e, n, r, i) {
  const { defIdMap: s, instanceIdMap: l } = $a(t);
  let a = Ge(Oi(n, e, i), e, i, !1, s, l);
  return Ye(a, r, i);
}
function Oi(t, e, n) {
  let r = n.options.eventDataTransform, i = e ? e.eventDataTransform : null;
  return i && (t = vr(t, i)), r && (t = vr(t, r)), t;
}
function vr(t, e) {
  let n;
  if (!e)
    n = t;
  else {
    n = [];
    for (let r of t) {
      let i = e(r);
      i ? n.push(i) : i == null && n.push(r);
    }
  }
  return n;
}
function Za(t, e, n, r) {
  return n && (e = Ye(e, n, r)), bn(t, e);
}
function yr(t, e, n) {
  let { defs: r } = t, i = Se(t.instances, (s) => r[s.defId].allDay ? s : Object.assign(Object.assign({}, s), { range: {
    start: n.createMarker(e.toDate(s.range.start, s.forcedStartTzo)),
    end: n.createMarker(e.toDate(s.range.end, s.forcedEndTzo))
  }, forcedStartTzo: n.canComputeOffset ? null : s.forcedStartTzo, forcedEndTzo: n.canComputeOffset ? null : s.forcedEndTzo }));
  return { defs: r, instances: i };
}
function Hi(t, e) {
  return An(t, (n) => n.sourceId !== e);
}
function $a(t) {
  const { defs: e, instances: n } = t, r = {}, i = {};
  for (let s in e) {
    const l = e[s], { publicId: a } = l;
    a && (r[a] = s);
  }
  for (let s in n) {
    const l = n[s], a = e[l.defId], { publicId: o } = a;
    o && (i[o] = s);
  }
  return { defIdMap: r, instanceIdMap: i };
}
class Ja {
  constructor() {
    this.handlers = {}, this.thisContext = null;
  }
  setThisContext(e) {
    this.thisContext = e;
  }
  setOptions(e) {
    this.options = e;
  }
  on(e, n) {
    Ka(this.handlers, e, n);
  }
  off(e, n) {
    Xa(this.handlers, e, n);
  }
  trigger(e, ...n) {
    let r = this.handlers[e] || [], i = this.options && this.options[e], s = [].concat(i || [], r);
    for (let l of s)
      l.apply(this.thisContext, n);
  }
  hasHandlers(e) {
    return !!(this.handlers[e] && this.handlers[e].length || this.options && this.options[e]);
  }
}
function Ka(t, e, n) {
  (t[e] || (t[e] = [])).push(n);
}
function Xa(t, e, n) {
  n ? t[e] && (t[e] = t[e].filter((r) => r !== n)) : delete t[e];
}
const eo = {
  startTime: "09:00",
  endTime: "17:00",
  daysOfWeek: [1, 2, 3, 4, 5],
  display: "inverse-background",
  classNames: "fc-non-business",
  groupId: "_businessHours"
  // so multiple defs get grouped
};
function to(t, e) {
  return Ge(no(t), null, e);
}
function no(t) {
  let e;
  return t === !0 ? e = [{}] : Array.isArray(t) ? e = t.filter((n) => n.daysOfWeek) : typeof t == "object" && t ? e = [t] : e = [], e = e.map((n) => Object.assign(Object.assign({}, eo), n)), e;
}
function ro(t, e, n) {
  n.emitter.trigger("select", Object.assign(Object.assign({}, so(t, n)), { jsEvent: null, view: n.viewApi || n.calendarApi.view }));
}
function io(t, e) {
  e.emitter.trigger("unselect", {
    jsEvent: t ? t.origEvent : null,
    view: e.viewApi || e.calendarApi.view
  });
}
function so(t, e) {
  let n = {};
  for (let r of e.pluginHooks.dateSpanTransforms)
    Object.assign(n, r(t, e));
  return Object.assign(n, bo(t, e.dateEnv)), n;
}
function br(t, e, n) {
  let { dateEnv: r, options: i } = n, s = e;
  return t ? (s = I(s), s = r.add(s, i.defaultAllDayEventDuration)) : s = r.add(s, i.defaultTimedEventDuration), s;
}
function lo(t, e, n, r) {
  let i = Bi(t.defs, e), s = re();
  for (let l in t.defs) {
    let a = t.defs[l];
    s.defs[l] = ao(a, i[l], n, r);
  }
  for (let l in t.instances) {
    let a = t.instances[l], o = s.defs[a.defId];
    s.instances[l] = oo(a, o, i[a.defId], n, r);
  }
  return s;
}
function ao(t, e, n, r) {
  let i = n.standardProps || {};
  i.hasEnd == null && e.durationEditable && (n.startDelta || n.endDelta) && (i.hasEnd = !0);
  let s = Object.assign(Object.assign(Object.assign({}, t), i), { ui: Object.assign(Object.assign({}, t.ui), i.ui) });
  n.extendedProps && (s.extendedProps = Object.assign(Object.assign({}, s.extendedProps), n.extendedProps));
  for (let l of r.pluginHooks.eventDefMutationAppliers)
    l(s, n, r);
  return !s.hasEnd && r.options.forceEventDuration && (s.hasEnd = !0), s;
}
function oo(t, e, n, r, i) {
  let { dateEnv: s } = i, l = r.standardProps && r.standardProps.allDay === !0, a = r.standardProps && r.standardProps.hasEnd === !1, o = Object.assign({}, t);
  return l && (o.range = _i(o.range)), r.datesDelta && n.startEditable && (o.range = {
    start: s.add(o.range.start, r.datesDelta),
    end: s.add(o.range.end, r.datesDelta)
  }), r.startDelta && n.durationEditable && (o.range = {
    start: s.add(o.range.start, r.startDelta),
    end: o.range.end
  }), r.endDelta && n.durationEditable && (o.range = {
    start: o.range.start,
    end: s.add(o.range.end, r.endDelta)
  }), a && (o.range = {
    start: o.range.start,
    end: br(e.allDay, o.range.start, i)
  }), e.allDay && (o.range = {
    start: I(o.range.start),
    end: I(o.range.end)
  }), o.range.end < o.range.start && (o.range.end = br(e.allDay, o.range.start, i)), o;
}
class xe {
  constructor(e, n) {
    this.context = e, this.internalEventSource = n;
  }
  remove() {
    this.context.dispatch({
      type: "REMOVE_EVENT_SOURCE",
      sourceId: this.internalEventSource.sourceId
    });
  }
  refetch() {
    this.context.dispatch({
      type: "FETCH_EVENT_SOURCES",
      sourceIds: [this.internalEventSource.sourceId],
      isRefetch: !0
    });
  }
  get id() {
    return this.internalEventSource.publicId;
  }
  get url() {
    return this.internalEventSource.meta.url;
  }
  get format() {
    return this.internalEventSource.meta.format;
  }
}
class Q {
  // instance will be null if expressing a recurring event that has no current instances,
  // OR if trying to validate an incoming external event that has no dates assigned
  constructor(e, n, r) {
    this._context = e, this._def = n, this._instance = r || null;
  }
  /*
  TODO: make event struct more responsible for this
  */
  setProp(e, n) {
    if (e in Ti)
      console.warn("Could not set date-related prop 'name'. Use one of the date-related methods instead.");
    else if (e === "id")
      n = ft[e](n), this.mutate({
        standardProps: { publicId: n }
        // hardcoded internal name
      });
    else if (e in ft)
      n = ft[e](n), this.mutate({
        standardProps: { [e]: n }
      });
    else if (e in St) {
      let r = St[e](n);
      e === "color" ? r = { backgroundColor: n, borderColor: n } : e === "editable" ? r = { startEditable: n, durationEditable: n } : r = { [e]: n }, this.mutate({
        standardProps: { ui: r }
      });
    } else
      console.warn(`Could not set prop '${e}'. Use setExtendedProp instead.`);
  }
  setExtendedProp(e, n) {
    this.mutate({
      extendedProps: { [e]: n }
    });
  }
  setStart(e, n = {}) {
    let { dateEnv: r } = this._context, i = r.createMarker(e);
    if (i && this._instance) {
      let s = this._instance.range, l = rt(s.start, i, r, n.granularity);
      n.maintainDuration ? this.mutate({ datesDelta: l }) : this.mutate({ startDelta: l });
    }
  }
  setEnd(e, n = {}) {
    let { dateEnv: r } = this._context, i;
    if (!(e != null && (i = r.createMarker(e), !i)) && this._instance)
      if (i) {
        let s = rt(this._instance.range.end, i, r, n.granularity);
        this.mutate({ endDelta: s });
      } else
        this.mutate({ standardProps: { hasEnd: !1 } });
  }
  setDates(e, n, r = {}) {
    let { dateEnv: i } = this._context, s = { allDay: r.allDay }, l = i.createMarker(e), a;
    if (l && !(n != null && (a = i.createMarker(n), !a)) && this._instance) {
      let o = this._instance.range;
      r.allDay === !0 && (o = _i(o));
      let d = rt(o.start, l, i, r.granularity);
      if (a) {
        let c = rt(o.end, a, i, r.granularity);
        Tl(d, c) ? this.mutate({ datesDelta: d, standardProps: s }) : this.mutate({ startDelta: d, endDelta: c, standardProps: s });
      } else
        s.hasEnd = !1, this.mutate({ datesDelta: d, standardProps: s });
    }
  }
  moveStart(e) {
    let n = R(e);
    n && this.mutate({ startDelta: n });
  }
  moveEnd(e) {
    let n = R(e);
    n && this.mutate({ endDelta: n });
  }
  moveDates(e) {
    let n = R(e);
    n && this.mutate({ datesDelta: n });
  }
  setAllDay(e, n = {}) {
    let r = { allDay: e }, { maintainDuration: i } = n;
    i == null && (i = this._context.options.allDayMaintainDuration), this._def.allDay !== e && (r.hasEnd = i), this.mutate({ standardProps: r });
  }
  formatRange(e) {
    let { dateEnv: n } = this._context, r = this._instance, i = O(e);
    return this._def.hasEnd ? n.formatRange(r.range.start, r.range.end, i, {
      forcedStartTzo: r.forcedStartTzo,
      forcedEndTzo: r.forcedEndTzo
    }) : n.format(r.range.start, i, {
      forcedTzo: r.forcedStartTzo
    });
  }
  mutate(e) {
    let n = this._instance;
    if (n) {
      let r = this._def, i = this._context, { eventStore: s } = i.getCurrentData(), l = Fa(s, n.instanceId);
      l = lo(l, {
        "": {
          display: "",
          startEditable: !0,
          durationEditable: !0,
          constraints: [],
          overlap: null,
          allows: [],
          backgroundColor: "",
          borderColor: "",
          textColor: "",
          classNames: []
        }
      }, e, i);
      let o = new Q(i, r, n);
      this._def = l.defs[r.defId], this._instance = l.instances[n.instanceId], i.dispatch({
        type: "MERGE_EVENTS",
        eventStore: l
      }), i.emitter.trigger("eventChange", {
        oldEvent: o,
        event: this,
        relatedEvents: En(l, i, n),
        revert() {
          i.dispatch({
            type: "RESET_EVENTS",
            eventStore: s
            // the ORIGINAL store
          });
        }
      });
    }
  }
  remove() {
    let e = this._context, n = Pi(this);
    e.dispatch({
      type: "REMOVE_EVENTS",
      eventStore: n
    }), e.emitter.trigger("eventRemove", {
      event: this,
      relatedEvents: [],
      revert() {
        e.dispatch({
          type: "MERGE_EVENTS",
          eventStore: n
        });
      }
    });
  }
  get source() {
    let { sourceId: e } = this._def;
    return e ? new xe(this._context, this._context.getCurrentData().eventSources[e]) : null;
  }
  get start() {
    return this._instance ? this._context.dateEnv.toDate(this._instance.range.start) : null;
  }
  get end() {
    return this._instance && this._def.hasEnd ? this._context.dateEnv.toDate(this._instance.range.end) : null;
  }
  get startStr() {
    let e = this._instance;
    return e ? this._context.dateEnv.formatIso(e.range.start, {
      omitTime: this._def.allDay,
      forcedTzo: e.forcedStartTzo
    }) : "";
  }
  get endStr() {
    let e = this._instance;
    return e && this._def.hasEnd ? this._context.dateEnv.formatIso(e.range.end, {
      omitTime: this._def.allDay,
      forcedTzo: e.forcedEndTzo
    }) : "";
  }
  // computable props that all access the def
  // TODO: find a TypeScript-compatible way to do this at scale
  get id() {
    return this._def.publicId;
  }
  get groupId() {
    return this._def.groupId;
  }
  get allDay() {
    return this._def.allDay;
  }
  get title() {
    return this._def.title;
  }
  get url() {
    return this._def.url;
  }
  get display() {
    return this._def.ui.display || "auto";
  }
  // bad. just normalize the type earlier
  get startEditable() {
    return this._def.ui.startEditable;
  }
  get durationEditable() {
    return this._def.ui.durationEditable;
  }
  get constraint() {
    return this._def.ui.constraints[0] || null;
  }
  get overlap() {
    return this._def.ui.overlap;
  }
  get allow() {
    return this._def.ui.allows[0] || null;
  }
  get backgroundColor() {
    return this._def.ui.backgroundColor;
  }
  get borderColor() {
    return this._def.ui.borderColor;
  }
  get textColor() {
    return this._def.ui.textColor;
  }
  // NOTE: user can't modify these because Object.freeze was called in event-def parsing
  get classNames() {
    return this._def.ui.classNames;
  }
  get extendedProps() {
    return this._def.extendedProps;
  }
  toPlainObject(e = {}) {
    let n = this._def, { ui: r } = n, { startStr: i, endStr: s } = this, l = {
      allDay: n.allDay
    };
    return n.title && (l.title = n.title), i && (l.start = i), s && (l.end = s), n.publicId && (l.id = n.publicId), n.groupId && (l.groupId = n.groupId), n.url && (l.url = n.url), r.display && r.display !== "auto" && (l.display = r.display), e.collapseColor && r.backgroundColor && r.backgroundColor === r.borderColor ? l.color = r.backgroundColor : (r.backgroundColor && (l.backgroundColor = r.backgroundColor), r.borderColor && (l.borderColor = r.borderColor)), r.textColor && (l.textColor = r.textColor), r.classNames.length && (l.classNames = r.classNames), Object.keys(n.extendedProps).length && (e.collapseExtendedProps ? Object.assign(l, n.extendedProps) : l.extendedProps = n.extendedProps), l;
  }
  toJSON() {
    return this.toPlainObject();
  }
}
function Pi(t) {
  let e = t._def, n = t._instance;
  return {
    defs: { [e.defId]: e },
    instances: n ? { [n.instanceId]: n } : {}
  };
}
function En(t, e, n) {
  let { defs: r, instances: i } = t, s = [], l = n ? n.instanceId : "";
  for (let a in i) {
    let o = i[a], d = r[o.defId];
    o.instanceId !== l && s.push(new Q(e, d, o));
  }
  return s;
}
function tn(t, e, n, r) {
  let i = {}, s = {}, l = {}, a = [], o = [], d = Bi(t.defs, e);
  for (let c in t.defs) {
    let g = t.defs[c];
    d[g.defId].display === "inverse-background" && (g.groupId ? (i[g.groupId] = [], l[g.groupId] || (l[g.groupId] = g)) : s[c] = []);
  }
  for (let c in t.instances) {
    let g = t.instances[c], h = t.defs[g.defId], f = d[h.defId], m = g.range, y = !h.allDay && r ? mn(m, r) : m, v = he(y, n);
    v && (f.display === "inverse-background" ? h.groupId ? i[h.groupId].push(v) : s[g.defId].push(v) : f.display !== "none" && (f.display === "background" ? a : o).push({
      def: h,
      ui: f,
      instance: g,
      range: v,
      isStart: y.start && y.start.valueOf() === v.start.valueOf(),
      isEnd: y.end && y.end.valueOf() === v.end.valueOf()
    }));
  }
  for (let c in i) {
    let g = i[c], h = pr(g, n);
    for (let f of h) {
      let m = l[c], y = d[m.defId];
      a.push({
        def: m,
        ui: y,
        instance: null,
        range: f,
        isStart: !1,
        isEnd: !1
      });
    }
  }
  for (let c in s) {
    let g = s[c], h = pr(g, n);
    for (let f of h)
      a.push({
        def: t.defs[c],
        ui: d[c],
        instance: null,
        range: f,
        isStart: !1,
        isEnd: !1
      });
  }
  return { bg: a, fg: o };
}
function co(t) {
  return t.ui.display === "background" || t.ui.display === "inverse-background";
}
function Ar(t, e) {
  t.fcSeg = e;
}
function nn(t) {
  return t.fcSeg || t.parentNode.fcSeg || // for the harness
  null;
}
function Bi(t, e) {
  return Se(t, (n) => Fi(n, e));
}
function Fi(t, e) {
  let n = [];
  return e[""] && n.push(e[""]), e[t.defId] && n.push(e[t.defId]), n.push(t.ui), Mi(n);
}
function Cn(t, e) {
  let n = t.map(uo);
  return n.sort((r, i) => Cl(r, i, e)), n.map((r) => r._seg);
}
function uo(t) {
  let { eventRange: e } = t, n = e.def, r = e.instance ? e.instance.range : e.range, i = r.start ? r.start.valueOf() : 0, s = r.end ? r.end.valueOf() : 0;
  return Object.assign(Object.assign(Object.assign({}, n.extendedProps), n), {
    id: n.publicId,
    start: i,
    end: s,
    duration: s - i,
    allDay: Number(n.allDay),
    _seg: t
  });
}
function fo(t, e) {
  let { pluginHooks: n } = e, r = n.isDraggableTransformers, { def: i, ui: s } = t.eventRange, l = s.startEditable;
  for (let a of r)
    l = a(l, i, s, e);
  return l;
}
function ho(t, e) {
  return t.isStart && t.eventRange.ui.durationEditable && e.options.eventResizableFromStart;
}
function go(t, e) {
  return t.isEnd && t.eventRange.ui.durationEditable;
}
function We(t, e, n, r, i, s, l) {
  let { dateEnv: a, options: o } = n, { displayEventTime: d, displayEventEnd: c } = o, g = t.eventRange.def, h = t.eventRange.instance;
  d == null && (d = r !== !1), c == null && (c = i !== !1);
  let f = h.range.start, m = h.range.end, y = s || t.start || t.eventRange.range.start, v = l || t.end || t.eventRange.range.end, b = I(f).valueOf() === I(y).valueOf(), A = I(fe(m, -1)).valueOf() === I(fe(v, -1)).valueOf();
  return d && !g.allDay && (b || A) ? (y = b ? f : y, v = A ? m : v, c && g.hasEnd ? a.formatRange(y, v, e, {
    forcedStartTzo: s ? null : h.forcedStartTzo,
    forcedEndTzo: l ? null : h.forcedEndTzo
  }) : a.format(y, e, {
    forcedTzo: s ? null : h.forcedStartTzo
    // nooooo, same
  })) : "";
}
function ne(t, e, n) {
  let r = t.eventRange.range;
  return {
    isPast: r.end <= (n || e.start),
    isFuture: r.start >= (n || e.end),
    isToday: e && te(e, r.start)
  };
}
function po(t) {
  let e = ["fc-event"];
  return t.isMirror && e.push("fc-event-mirror"), t.isDraggable && e.push("fc-event-draggable"), (t.isStartResizable || t.isEndResizable) && e.push("fc-event-resizable"), t.isDragging && e.push("fc-event-dragging"), t.isResizing && e.push("fc-event-resizing"), t.isSelected && e.push("fc-event-selected"), t.isStart && e.push("fc-event-start"), t.isEnd && e.push("fc-event-end"), t.isPast && e.push("fc-event-past"), t.isToday && e.push("fc-event-today"), t.isFuture && e.push("fc-event-future"), e;
}
function zi(t) {
  return t.instance ? t.instance.instanceId : `${t.def.defId}:${t.range.start.toISOString()}`;
}
function Sn(t, e) {
  let { def: n, instance: r } = t.eventRange, { url: i } = n;
  if (i)
    return { href: i };
  let { emitter: s, options: l } = e, { eventInteractive: a } = l;
  return a == null && (a = n.interactive, a == null && (a = !!s.hasHandlers("eventClick"))), a ? vi((o) => {
    s.trigger("eventClick", {
      el: o.target,
      event: new Q(e, n, r),
      jsEvent: o,
      view: e.viewApi
    });
  }) : {};
}
const mo = {
  start: p,
  end: p,
  allDay: Boolean
};
function vo(t, e, n) {
  let r = yo(t, e), { range: i } = r;
  if (!i.start)
    return null;
  if (!i.end) {
    if (n == null)
      return null;
    i.end = e.add(i.start, n);
  }
  return r;
}
function yo(t, e) {
  let { refined: n, extra: r } = fn(t, mo), i = n.start ? e.createMarkerMeta(n.start) : null, s = n.end ? e.createMarkerMeta(n.end) : null, { allDay: l } = n;
  return l == null && (l = i && i.isTimeUnspecified && (!s || s.isTimeUnspecified)), Object.assign({ range: {
    start: i ? i.marker : null,
    end: s ? s.marker : null
  }, allDay: l }, r);
}
function bo(t, e) {
  return Object.assign(Object.assign({}, Wi(t.range, e, t.allDay)), { allDay: t.allDay });
}
function Ui(t, e, n) {
  return Object.assign(Object.assign({}, Wi(t, e, n)), { timeZone: e.timeZone });
}
function Wi(t, e, n) {
  return {
    start: e.toDate(t.start),
    end: e.toDate(t.end),
    startStr: e.formatIso(t.start, { omitTime: n }),
    endStr: e.formatIso(t.end, { omitTime: n })
  };
}
function Ao(t, e, n) {
  let r = ki({ editable: !1 }, n), i = Xt(
    r.refined,
    r.extra,
    "",
    // sourceId
    t.allDay,
    !0,
    // hasEnd
    n
  );
  return {
    def: i,
    ui: Fi(i, e),
    instance: vn(i.defId, t.range),
    range: t.range,
    isStart: !0,
    isEnd: !0
  };
}
function Eo(t, e, n) {
  let r = !1, i = function(a) {
    r || (r = !0, e(a));
  }, s = function(a) {
    r || (r = !0, n(a));
  }, l = t(i, s);
  l && typeof l.then == "function" && l.then(i, s);
}
class Er extends Error {
  constructor(e, n) {
    super(e), this.response = n;
  }
}
function Co(t, e, n) {
  t = t.toUpperCase();
  const r = {
    method: t
  };
  return t === "GET" ? e += (e.indexOf("?") === -1 ? "?" : "&") + new URLSearchParams(n) : (r.body = new URLSearchParams(n), r.headers = {
    "Content-Type": "application/x-www-form-urlencoded"
  }), fetch(e, r).then((i) => {
    if (i.ok)
      return i.json().then((s) => [s, i], () => {
        throw new Er("Failure parsing JSON", i);
      });
    throw new Er("Request failed", i);
  });
}
let zt;
function Li() {
  return zt == null && (zt = So()), zt;
}
function So() {
  if (typeof document > "u")
    return !0;
  let t = document.createElement("div");
  t.style.position = "absolute", t.style.top = "0px", t.style.left = "0px", t.innerHTML = "<table><tr><td><div></div></td></tr></table>", t.querySelector("table").style.height = "100px", t.querySelector("div").style.height = "100%", document.body.appendChild(t);
  let n = t.querySelector("div").offsetHeight > 0;
  return document.body.removeChild(t), n;
}
class Do extends T {
  constructor() {
    super(...arguments), this.state = {
      forPrint: !1
    }, this.handleBeforePrint = () => {
      Ct(() => {
        this.setState({ forPrint: !0 });
      });
    }, this.handleAfterPrint = () => {
      Ct(() => {
        this.setState({ forPrint: !1 });
      });
    };
  }
  render() {
    let { props: e } = this, { options: n } = e, { forPrint: r } = this.state, i = r || n.height === "auto" || n.contentHeight === "auto", s = !i && n.height != null ? n.height : "", l = [
      "fc",
      r ? "fc-media-print" : "fc-media-screen",
      `fc-direction-${n.direction}`,
      e.theme.getClass("root")
    ];
    return Li() || l.push("fc-liquid-hack"), e.children(l, s, i, r);
  }
  componentDidMount() {
    let { emitter: e } = this.props;
    e.on("_beforeprint", this.handleBeforePrint), e.on("_afterprint", this.handleAfterPrint);
  }
  componentWillUnmount() {
    let { emitter: e } = this.props;
    e.off("_beforeprint", this.handleBeforePrint), e.off("_afterprint", this.handleAfterPrint);
  }
}
class ji {
  constructor(e) {
    this.component = e.component, this.isHitComboAllowed = e.isHitComboAllowed || null;
  }
  destroy() {
  }
}
function wo(t, e) {
  return {
    component: t,
    el: e.el,
    useEventCenter: e.useEventCenter != null ? e.useEventCenter : !0,
    isHitComboAllowed: e.isHitComboAllowed || null
  };
}
const Cr = {};
class _e extends G {
  constructor(e, n) {
    super(e, n), this.handleRefresh = () => {
      let r = this.computeTiming();
      r.state.nowDate.valueOf() !== this.state.nowDate.valueOf() && this.setState(r.state), this.clearTimeout(), this.setTimeout(r.waitMs);
    }, this.handleVisibilityChange = () => {
      document.hidden || this.handleRefresh();
    }, this.state = this.computeTiming().state;
  }
  render() {
    let { props: e, state: n } = this;
    return e.children(n.nowDate, n.todayRange);
  }
  componentDidMount() {
    this.setTimeout(), this.context.nowManager.addResetListener(this.handleRefresh), document.addEventListener("visibilitychange", this.handleVisibilityChange);
  }
  componentDidUpdate(e) {
    e.unit !== this.props.unit && (this.clearTimeout(), this.setTimeout());
  }
  componentWillUnmount() {
    this.clearTimeout(), this.context.nowManager.removeResetListener(this.handleRefresh), document.removeEventListener("visibilitychange", this.handleVisibilityChange);
  }
  computeTiming() {
    let { props: e, context: n } = this, r = n.nowManager.getDateMarker(), { nowIndicatorSnap: i } = n.options;
    i === "auto" && (i = // large unit?
    /year|month|week|day/.test(e.unit) || // if slotDuration 30 mins for example, would NOT appear to snap (legacy behavior)
    (e.unitValue || 1) === 1);
    let s, l;
    return i ? (s = n.dateEnv.startOf(r, e.unit), l = n.dateEnv.add(s, R(1, e.unit)).valueOf() - r.valueOf()) : (s = r, l = 1e3 * 60), l = Math.min(1e3 * 60 * 60 * 24, l), {
      state: { nowDate: s, todayRange: _o(s) },
      waitMs: l
    };
  }
  setTimeout(e = this.computeTiming().waitMs) {
    this.timeoutId = setTimeout(() => {
      const n = this.computeTiming();
      this.setState(n.state, () => {
        this.setTimeout(n.waitMs);
      });
    }, e);
  }
  clearTimeout() {
    this.timeoutId && clearTimeout(this.timeoutId);
  }
}
_e.contextType = ie;
function _o(t) {
  let e = I(t), n = B(e, 1);
  return { start: e, end: n };
}
class Ro {
  getCurrentData() {
    return this.currentDataManager.getCurrentData();
  }
  dispatch(e) {
    this.currentDataManager.dispatch(e);
  }
  get view() {
    return this.getCurrentData().viewApi;
  }
  batchRendering(e) {
    e();
  }
  updateSize() {
    this.trigger("_resize", !0);
  }
  // Options
  // -----------------------------------------------------------------------------------------------------------------
  setOption(e, n) {
    this.dispatch({
      type: "SET_OPTION",
      optionName: e,
      rawOptionValue: n
    });
  }
  getOption(e) {
    return this.currentDataManager.currentCalendarOptionsInput[e];
  }
  getAvailableLocaleCodes() {
    return Object.keys(this.getCurrentData().availableRawLocales);
  }
  // Trigger
  // -----------------------------------------------------------------------------------------------------------------
  on(e, n) {
    let { currentDataManager: r } = this;
    r.currentCalendarOptionsRefiners[e] ? r.emitter.on(e, n) : console.warn(`Unknown listener name '${e}'`);
  }
  off(e, n) {
    this.currentDataManager.emitter.off(e, n);
  }
  // not meant for public use
  trigger(e, ...n) {
    this.currentDataManager.emitter.trigger(e, ...n);
  }
  // View
  // -----------------------------------------------------------------------------------------------------------------
  changeView(e, n) {
    this.batchRendering(() => {
      if (this.unselect(), n)
        if (n.start && n.end)
          this.dispatch({
            type: "CHANGE_VIEW_TYPE",
            viewType: e
          }), this.dispatch({
            type: "SET_OPTION",
            optionName: "visibleRange",
            rawOptionValue: n
          });
        else {
          let { dateEnv: r } = this.getCurrentData();
          this.dispatch({
            type: "CHANGE_VIEW_TYPE",
            viewType: e,
            dateMarker: r.createMarker(n)
          });
        }
      else
        this.dispatch({
          type: "CHANGE_VIEW_TYPE",
          viewType: e
        });
    });
  }
  // Forces navigation to a view for the given date.
  // `viewType` can be a specific view name or a generic one like "week" or "day".
  // needs to change
  zoomTo(e, n) {
    let r = this.getCurrentData(), i;
    n = n || "day", i = r.viewSpecs[n] || this.getUnitViewSpec(n), this.unselect(), i ? this.dispatch({
      type: "CHANGE_VIEW_TYPE",
      viewType: i.type,
      dateMarker: e
    }) : this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: e
    });
  }
  // Given a duration singular unit, like "week" or "day", finds a matching view spec.
  // Preference is given to views that have corresponding buttons.
  getUnitViewSpec(e) {
    let { viewSpecs: n, toolbarConfig: r } = this.getCurrentData(), i = [].concat(r.header ? r.header.viewsWithButtons : [], r.footer ? r.footer.viewsWithButtons : []), s, l;
    for (let a in n)
      i.push(a);
    for (s = 0; s < i.length; s += 1)
      if (l = n[i[s]], l && l.singleUnit === e)
        return l;
    return null;
  }
  // Current Date
  // -----------------------------------------------------------------------------------------------------------------
  prev() {
    this.unselect(), this.dispatch({ type: "PREV" });
  }
  next() {
    this.unselect(), this.dispatch({ type: "NEXT" });
  }
  prevYear() {
    let e = this.getCurrentData();
    this.unselect(), this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: e.dateEnv.addYears(e.currentDate, -1)
    });
  }
  nextYear() {
    let e = this.getCurrentData();
    this.unselect(), this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: e.dateEnv.addYears(e.currentDate, 1)
    });
  }
  today() {
    let e = this.getCurrentData();
    this.unselect(), this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: e.nowManager.getDateMarker()
    });
  }
  gotoDate(e) {
    let n = this.getCurrentData();
    this.unselect(), this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: n.dateEnv.createMarker(e)
    });
  }
  incrementDate(e) {
    let n = this.getCurrentData(), r = R(e);
    r && (this.unselect(), this.dispatch({
      type: "CHANGE_DATE",
      dateMarker: n.dateEnv.add(n.currentDate, r)
    }));
  }
  getDate() {
    let e = this.getCurrentData();
    return e.dateEnv.toDate(e.currentDate);
  }
  // Date Formatting Utils
  // -----------------------------------------------------------------------------------------------------------------
  formatDate(e, n) {
    let { dateEnv: r } = this.getCurrentData();
    return r.format(r.createMarker(e), O(n));
  }
  // `settings` is for formatter AND isEndExclusive
  formatRange(e, n, r) {
    let { dateEnv: i } = this.getCurrentData();
    return i.formatRange(i.createMarker(e), i.createMarker(n), O(r), r);
  }
  formatIso(e, n) {
    let { dateEnv: r } = this.getCurrentData();
    return r.formatIso(r.createMarker(e), { omitTime: n });
  }
  // Date Selection / Event Selection / DayClick
  // -----------------------------------------------------------------------------------------------------------------
  select(e, n) {
    let r;
    n == null ? e.start != null ? r = e : r = {
      start: e,
      end: null
    } : r = {
      start: e,
      end: n
    };
    let i = this.getCurrentData(), s = vo(r, i.dateEnv, R({ days: 1 }));
    s && (this.dispatch({ type: "SELECT_DATES", selection: s }), ro(s, null, i));
  }
  unselect(e) {
    let n = this.getCurrentData();
    n.dateSelection && (this.dispatch({ type: "UNSELECT_DATES" }), io(e, n));
  }
  // Public Events API
  // -----------------------------------------------------------------------------------------------------------------
  addEvent(e, n) {
    if (e instanceof Q) {
      let l = e._def, a = e._instance;
      return this.getCurrentData().eventStore.defs[l.defId] || (this.dispatch({
        type: "ADD_EVENTS",
        eventStore: en({ def: l, instance: a })
        // TODO: better util for two args?
      }), this.triggerEventAdd(e)), e;
    }
    let r = this.getCurrentData(), i;
    if (n instanceof xe)
      i = n.internalEventSource;
    else if (typeof n == "boolean")
      n && ([i] = gn(r.eventSources));
    else if (n != null) {
      let l = this.getEventSourceById(n);
      if (!l)
        return console.warn(`Could not find an event source with ID "${n}"`), null;
      i = l.internalEventSource;
    }
    let s = xi(e, i, r, !1);
    if (s) {
      let l = new Q(r, s.def, s.def.recurringDef ? null : s.instance);
      return this.dispatch({
        type: "ADD_EVENTS",
        eventStore: en(s)
      }), this.triggerEventAdd(l), l;
    }
    return null;
  }
  triggerEventAdd(e) {
    let { emitter: n } = this.getCurrentData();
    n.trigger("eventAdd", {
      event: e,
      relatedEvents: [],
      revert: () => {
        this.dispatch({
          type: "REMOVE_EVENTS",
          eventStore: Pi(e)
        });
      }
    });
  }
  // TODO: optimize
  getEventById(e) {
    let n = this.getCurrentData(), { defs: r, instances: i } = n.eventStore;
    e = String(e);
    for (let s in r) {
      let l = r[s];
      if (l.publicId === e) {
        if (l.recurringDef)
          return new Q(n, l, null);
        for (let a in i) {
          let o = i[a];
          if (o.defId === l.defId)
            return new Q(n, l, o);
        }
      }
    }
    return null;
  }
  getEvents() {
    let e = this.getCurrentData();
    return En(e.eventStore, e);
  }
  removeAllEvents() {
    this.dispatch({ type: "REMOVE_ALL_EVENTS" });
  }
  // Public Event Sources API
  // -----------------------------------------------------------------------------------------------------------------
  getEventSources() {
    let e = this.getCurrentData(), n = e.eventSources, r = [];
    for (let i in n)
      r.push(new xe(e, n[i]));
    return r;
  }
  getEventSourceById(e) {
    let n = this.getCurrentData(), r = n.eventSources;
    e = String(e);
    for (let i in r)
      if (r[i].publicId === e)
        return new xe(n, r[i]);
    return null;
  }
  addEventSource(e) {
    let n = this.getCurrentData();
    if (e instanceof xe)
      return n.eventSources[e.internalEventSource.sourceId] || this.dispatch({
        type: "ADD_EVENT_SOURCES",
        sources: [e.internalEventSource]
      }), e;
    let r = Ii(e, n);
    return r ? (this.dispatch({ type: "ADD_EVENT_SOURCES", sources: [r] }), new xe(n, r)) : null;
  }
  removeAllEventSources() {
    this.dispatch({ type: "REMOVE_ALL_EVENT_SOURCES" });
  }
  refetchEvents() {
    this.dispatch({ type: "FETCH_EVENT_SOURCES", isRefetch: !0 });
  }
  // Scroll
  // -----------------------------------------------------------------------------------------------------------------
  scrollToTime(e) {
    let n = R(e);
    n && this.trigger("_scrollRequest", { time: n });
  }
}
function To(t, e) {
  let n = {
    left: Math.max(t.left, e.left),
    right: Math.min(t.right, e.right),
    top: Math.max(t.top, e.top),
    bottom: Math.min(t.bottom, e.bottom)
  };
  return n.left < n.right && n.top < n.bottom ? n : !1;
}
const Ut = re();
class xo {
  constructor() {
    this.getKeysForEventDefs = C(this._getKeysForEventDefs), this.splitDateSelection = C(this._splitDateSpan), this.splitEventStore = C(this._splitEventStore), this.splitIndividualUi = C(this._splitIndividualUi), this.splitEventDrag = C(this._splitInteraction), this.splitEventResize = C(this._splitInteraction), this.eventUiBuilders = {};
  }
  splitProps(e) {
    let n = this.getKeyInfo(e), r = this.getKeysForEventDefs(e.eventStore), i = this.splitDateSelection(e.dateSelection), s = this.splitIndividualUi(e.eventUiBases, r), l = this.splitEventStore(e.eventStore, r), a = this.splitEventDrag(e.eventDrag), o = this.splitEventResize(e.eventResize), d = {};
    this.eventUiBuilders = Se(n, (c, g) => this.eventUiBuilders[g] || C(ko));
    for (let c in n) {
      let g = n[c], h = l[c] || Ut, f = this.eventUiBuilders[c];
      d[c] = {
        businessHours: g.businessHours || e.businessHours,
        dateSelection: i[c] || null,
        eventStore: h,
        eventUiBases: f(e.eventUiBases[""], g.ui, s[c]),
        eventSelection: h.instances[e.eventSelection] ? e.eventSelection : "",
        eventDrag: a[c] || null,
        eventResize: o[c] || null
      };
    }
    return d;
  }
  _splitDateSpan(e) {
    let n = {};
    if (e) {
      let r = this.getKeysForDateSpan(e);
      for (let i of r)
        n[i] = e;
    }
    return n;
  }
  _getKeysForEventDefs(e) {
    return Se(e.defs, (n) => this.getKeysForEventDef(n));
  }
  _splitEventStore(e, n) {
    let { defs: r, instances: i } = e, s = {};
    for (let l in r)
      for (let a of n[l])
        s[a] || (s[a] = re()), s[a].defs[l] = r[l];
    for (let l in i) {
      let a = i[l];
      for (let o of n[a.defId])
        s[o] && (s[o].instances[l] = a);
    }
    return s;
  }
  _splitIndividualUi(e, n) {
    let r = {};
    for (let i in e)
      if (i)
        for (let s of n[i])
          r[s] || (r[s] = {}), r[s][i] = e[i];
    return r;
  }
  _splitInteraction(e) {
    let n = {};
    if (e) {
      let r = this._splitEventStore(e.affectedEvents, this._getKeysForEventDefs(e.affectedEvents)), i = this._getKeysForEventDefs(e.mutatedEvents), s = this._splitEventStore(e.mutatedEvents, i), l = (a) => {
        n[a] || (n[a] = {
          affectedEvents: r[a] || Ut,
          mutatedEvents: s[a] || Ut,
          isEvent: e.isEvent
        });
      };
      for (let a in r)
        l(a);
      for (let a in s)
        l(a);
    }
    return n;
  }
}
function ko(t, e, n) {
  let r = [];
  t && r.push(t), e && r.push(e);
  let i = {
    "": Mi(r)
  };
  return n && Object.assign(i, n), i;
}
function Dn(t, e, n, r) {
  return {
    dow: t.getUTCDay(),
    isDisabled: !!(r && (!r.activeRange || !te(r.activeRange, t))),
    isOther: !!(r && !te(r.currentRange, t)),
    isToday: !!(e && te(e, t)),
    isPast: !!(n ? t < n : e && t < e.start),
    isFuture: !!(n ? t > n : e && t >= e.end)
  };
}
function Tt(t, e) {
  let n = [
    "fc-day",
    `fc-day-${Nl[t.dow]}`
  ];
  return t.isDisabled ? n.push("fc-day-disabled") : (t.isToday && (n.push("fc-day-today"), n.push(e.getClass("today"))), t.isPast && n.push("fc-day-past"), t.isFuture && n.push("fc-day-future"), t.isOther && n.push("fc-day-other")), n;
}
const Mo = O({ year: "numeric", month: "long", day: "numeric" }), Io = O({ week: "long" });
function He(t, e, n = "day", r = !0) {
  const { dateEnv: i, options: s, calendarApi: l } = t;
  let a = i.format(e, n === "week" ? Io : Mo);
  if (s.navLinks) {
    let o = i.toDate(e);
    const d = (c) => {
      let g = n === "day" ? s.navLinkDayClick : n === "week" ? s.navLinkWeekClick : null;
      typeof g == "function" ? g.call(l, i.toDate(e), c) : (typeof g == "string" && (n = g), l.zoomTo(e, n));
    };
    return Object.assign({ title: ze(s.navLinkHint, [a, o], a), "data-navlink": "" }, r ? mi(d) : { onClick: d });
  }
  return { "aria-label": a };
}
let Wt;
function No() {
  return Wt || (Wt = Oo()), Wt;
}
function Oo() {
  let t = document.createElement("div");
  t.style.overflow = "scroll", t.style.position = "absolute", t.style.top = "-9999px", t.style.left = "-9999px", document.body.appendChild(t);
  let e = Ho(t);
  return document.body.removeChild(t), e;
}
function Ho(t) {
  return {
    x: t.offsetHeight - t.clientHeight,
    y: t.offsetWidth - t.clientWidth
  };
}
function Po(t) {
  let e = Bo(t), n = t.getBoundingClientRect();
  for (let r of e) {
    let i = To(n, r.getBoundingClientRect());
    if (i)
      n = i;
    else
      return null;
  }
  return n;
}
function Bo(t) {
  let e = [];
  for (; t instanceof HTMLElement; ) {
    let n = window.getComputedStyle(t);
    if (n.position === "fixed")
      break;
    /(auto|scroll)/.test(n.overflow + n.overflowY + n.overflowX) && e.push(t), t = t.parentNode;
  }
  return e;
}
class Pe {
  constructor(e, n, r, i) {
    this.els = n;
    let s = this.originClientRect = e.getBoundingClientRect();
    r && this.buildElHorizontals(s.left), i && this.buildElVerticals(s.top);
  }
  // Populates the left/right internal coordinate arrays
  buildElHorizontals(e) {
    let n = [], r = [];
    for (let i of this.els) {
      let s = i.getBoundingClientRect();
      n.push(s.left - e), r.push(s.right - e);
    }
    this.lefts = n, this.rights = r;
  }
  // Populates the top/bottom internal coordinate arrays
  buildElVerticals(e) {
    let n = [], r = [];
    for (let i of this.els) {
      let s = i.getBoundingClientRect();
      n.push(s.top - e), r.push(s.bottom - e);
    }
    this.tops = n, this.bottoms = r;
  }
  // Given a left offset (from document left), returns the index of the el that it horizontally intersects.
  // If no intersection is made, returns undefined.
  leftToIndex(e) {
    let { lefts: n, rights: r } = this, i = n.length, s;
    for (s = 0; s < i; s += 1)
      if (e >= n[s] && e < r[s])
        return s;
  }
  // Given a top offset (from document top), returns the index of the el that it vertically intersects.
  // If no intersection is made, returns undefined.
  topToIndex(e) {
    let { tops: n, bottoms: r } = this, i = n.length, s;
    for (s = 0; s < i; s += 1)
      if (e >= n[s] && e < r[s])
        return s;
  }
  // Gets the width of the element at the given index
  getWidth(e) {
    return this.rights[e] - this.lefts[e];
  }
  // Gets the height of the element at the given index
  getHeight(e) {
    return this.bottoms[e] - this.tops[e];
  }
  similarTo(e) {
    return it(this.tops || [], e.tops || []) && it(this.bottoms || [], e.bottoms || []) && it(this.lefts || [], e.lefts || []) && it(this.rights || [], e.rights || []);
  }
}
function it(t, e) {
  const n = t.length;
  if (n !== e.length)
    return !1;
  for (let r = 0; r < n; r++)
    if (Math.round(t[r]) !== Math.round(e[r]))
      return !1;
  return !0;
}
class Z extends T {
  constructor() {
    super(...arguments), this.uid = De();
  }
  // Hit System
  // -----------------------------------------------------------------------------------------------------------------
  prepareHits() {
  }
  queryHit(e, n, r, i) {
    return null;
  }
  // Pointer Interaction Utils
  // -----------------------------------------------------------------------------------------------------------------
  isValidSegDownEl(e) {
    return !this.props.eventDrag && // HACK
    !this.props.eventResize && // HACK
    !X(e, ".fc-event-mirror");
  }
  isValidDateDownEl(e) {
    return !X(e, ".fc-event:not(.fc-bg-event)") && !X(e, ".fc-more-link") && // a "more.." link
    !X(e, "a[data-navlink]") && // a clickable nav link
    !X(e, ".fc-popover");
  }
}
class Vi {
  constructor(e = (n) => n.thickness || 1) {
    this.getEntryThickness = e, this.strictOrder = !1, this.allowReslicing = !1, this.maxCoord = -1, this.maxStackCnt = -1, this.levelCoords = [], this.entriesByLevel = [], this.stackCnts = {};
  }
  addSegs(e) {
    let n = [];
    for (let r of e)
      this.insertEntry(r, n);
    return n;
  }
  insertEntry(e, n) {
    let r = this.findInsertion(e);
    this.isInsertionValid(r, e) ? this.insertEntryAt(e, r) : this.handleInvalidInsertion(r, e, n);
  }
  isInsertionValid(e, n) {
    return (this.maxCoord === -1 || e.levelCoord + this.getEntryThickness(n) <= this.maxCoord) && (this.maxStackCnt === -1 || e.stackCnt < this.maxStackCnt);
  }
  handleInvalidInsertion(e, n, r) {
    if (this.allowReslicing && e.touchingEntry) {
      const i = Object.assign(Object.assign({}, n), { span: wn(n.span, e.touchingEntry.span) });
      r.push(i), this.splitEntry(n, e.touchingEntry, r);
    } else
      r.push(n);
  }
  /*
  Does NOT add what hit the `barrier` into hiddenEntries. Should already be done.
  */
  splitEntry(e, n, r) {
    let i = e.span, s = n.span;
    i.start < s.start && this.insertEntry({
      index: e.index,
      thickness: e.thickness,
      span: { start: i.start, end: s.start }
    }, r), i.end > s.end && this.insertEntry({
      index: e.index,
      thickness: e.thickness,
      span: { start: s.end, end: i.end }
    }, r);
  }
  insertEntryAt(e, n) {
    let { entriesByLevel: r, levelCoords: i } = this;
    n.lateral === -1 ? (Lt(i, n.level, n.levelCoord), Lt(r, n.level, [e])) : Lt(r[n.level], n.lateral, e), this.stackCnts[Ce(e)] = n.stackCnt;
  }
  /*
  does not care about limits
  */
  findInsertion(e) {
    let { levelCoords: n, entriesByLevel: r, strictOrder: i, stackCnts: s } = this, l = n.length, a = 0, o = -1, d = -1, c = null, g = 0;
    for (let m = 0; m < l; m += 1) {
      const y = n[m];
      if (!i && y >= a + this.getEntryThickness(e))
        break;
      let v = r[m], b, A = sn(v, e.span.start, rn), w = A[0] + A[1];
      for (
        ;
        // loop through entries that horizontally intersect
        (b = v[w]) && // but not past the whole entry list
        b.span.start < e.span.end;
      ) {
        let D = y + this.getEntryThickness(b);
        D > a && (a = D, c = b, o = m, d = w), D === a && (g = Math.max(g, s[Ce(b)] + 1)), w += 1;
      }
    }
    let h = 0;
    if (c)
      for (h = o + 1; h < l && n[h] < a; )
        h += 1;
    let f = -1;
    return h < l && n[h] === a && (f = sn(r[h], e.span.end, rn)[0]), {
      touchingLevel: o,
      touchingLateral: d,
      touchingEntry: c,
      stackCnt: g,
      levelCoord: a,
      level: h,
      lateral: f
    };
  }
  // sorted by levelCoord (lowest to highest)
  toRects() {
    let { entriesByLevel: e, levelCoords: n } = this, r = e.length, i = [];
    for (let s = 0; s < r; s += 1) {
      let l = e[s], a = n[s];
      for (let o of l)
        i.push(Object.assign(Object.assign({}, o), { thickness: this.getEntryThickness(o), levelCoord: a }));
    }
    return i;
  }
}
function rn(t) {
  return t.span.end;
}
function Ce(t) {
  return t.index + ":" + t.span.start;
}
function Fo(t) {
  let e = [];
  for (let n of t) {
    let r = [], i = {
      span: n.span,
      entries: [n]
    };
    for (let s of e)
      wn(s.span, i.span) ? i = {
        entries: s.entries.concat(i.entries),
        span: zo(s.span, i.span)
      } : r.push(s);
    r.push(i), e = r;
  }
  return e;
}
function zo(t, e) {
  return {
    start: Math.min(t.start, e.start),
    end: Math.max(t.end, e.end)
  };
}
function wn(t, e) {
  let n = Math.max(t.start, e.start), r = Math.min(t.end, e.end);
  return n < r ? { start: n, end: r } : null;
}
function Lt(t, e, n) {
  t.splice(e, 0, n);
}
function sn(t, e, n) {
  let r = 0, i = t.length;
  if (!i || e < n(t[r]))
    return [0, 0];
  if (e > n(t[i - 1]))
    return [i, 0];
  for (; r < i; ) {
    let s = Math.floor(r + (i - r) / 2), l = n(t[s]);
    if (e < l)
      i = s;
    else if (e > l)
      r = s + 1;
    else
      return [s, 1];
  }
  return [r, 0];
}
function Uo(t, e) {
  return !t || e > 10 ? O({ weekday: "short" }) : e > 1 ? O({ weekday: "short", month: "numeric", day: "numeric", omitCommas: !0 }) : O({ weekday: "long" });
}
const Gi = "fc-col-header-cell";
function Qi(t) {
  return t.text;
}
class Wo extends T {
  render() {
    let { dateEnv: e, options: n, theme: r, viewApi: i } = this.context, { props: s } = this, { date: l, dateProfile: a } = s, o = Dn(l, s.todayRange, null, a), d = [Gi].concat(Tt(o, r)), c = e.format(l, s.dayHeaderFormat), g = !o.isDisabled && s.colCnt > 1 ? He(this.context, l) : {}, h = e.toDate(l);
    e.namedTimeZoneImpl && (h = fe(h, 36e5));
    let f = Object.assign(Object.assign(Object.assign({ date: h, view: i }, s.extraRenderProps), { text: c }), o);
    return u(U, { elTag: "th", elClasses: d, elAttrs: Object.assign({ role: "columnheader", colSpan: s.colSpan, "data-date": o.isDisabled ? void 0 : Qe(l) }, s.extraDataAttrs), renderProps: f, generatorName: "dayHeaderContent", customGenerator: n.dayHeaderContent, defaultGenerator: Qi, classNameGenerator: n.dayHeaderClassNames, didMount: n.dayHeaderDidMount, willUnmount: n.dayHeaderWillUnmount }, (m) => u("div", { className: "fc-scrollgrid-sync-inner" }, !o.isDisabled && u(m, { elTag: "a", elAttrs: g, elClasses: [
      "fc-col-header-cell-cushion",
      s.isSticky && "fc-sticky"
    ] })));
  }
}
const Lo = O({ weekday: "long" });
class jo extends T {
  render() {
    let { props: e } = this, { dateEnv: n, theme: r, viewApi: i, options: s } = this.context, l = B(/* @__PURE__ */ new Date(2592e5), e.dow), a = {
      dow: e.dow,
      isDisabled: !1,
      isFuture: !1,
      isPast: !1,
      isToday: !1,
      isOther: !1
    }, o = n.format(l, e.dayHeaderFormat), d = Object.assign(Object.assign(Object.assign(Object.assign({
      // TODO: make this public?
      date: l
    }, a), { view: i }), e.extraRenderProps), { text: o });
    return u(U, { elTag: "th", elClasses: [
      Gi,
      ...Tt(a, r),
      ...e.extraClassNames || []
    ], elAttrs: Object.assign({ role: "columnheader", colSpan: e.colSpan }, e.extraDataAttrs), renderProps: d, generatorName: "dayHeaderContent", customGenerator: s.dayHeaderContent, defaultGenerator: Qi, classNameGenerator: s.dayHeaderClassNames, didMount: s.dayHeaderDidMount, willUnmount: s.dayHeaderWillUnmount }, (c) => u(
      "div",
      { className: "fc-scrollgrid-sync-inner" },
      u(c, { elTag: "a", elClasses: [
        "fc-col-header-cell-cushion",
        e.isSticky && "fc-sticky"
      ], elAttrs: {
        "aria-label": n.format(l, Lo)
      } })
    ));
  }
}
class qi extends T {
  constructor() {
    super(...arguments), this.createDayHeaderFormatter = C(Vo);
  }
  render() {
    let { context: e } = this, { dates: n, dateProfile: r, datesRepDistinctDays: i, renderIntro: s } = this.props, l = this.createDayHeaderFormatter(e.options.dayHeaderFormat, i, n.length);
    return u(_e, { unit: "day" }, (a, o) => u(
      "tr",
      { role: "row" },
      s && s("day"),
      n.map((d) => i ? u(Wo, { key: d.toISOString(), date: d, dateProfile: r, todayRange: o, colCnt: n.length, dayHeaderFormat: l }) : u(jo, { key: d.getUTCDay(), dow: d.getUTCDay(), dayHeaderFormat: l }))
    ));
  }
}
function Vo(t, e, n) {
  return t || Uo(e, n);
}
class Yi {
  constructor(e, n) {
    let r = e.start, { end: i } = e, s = [], l = [], a = -1;
    for (; r < i; )
      n.isHiddenDay(r) ? s.push(a + 0.5) : (a += 1, s.push(a), l.push(r)), r = B(r, 1);
    this.dates = l, this.indices = s, this.cnt = l.length;
  }
  sliceRange(e) {
    let n = this.getDateDayIndex(e.start), r = this.getDateDayIndex(B(e.end, -1)), i = Math.max(0, n), s = Math.min(this.cnt - 1, r);
    return i = Math.ceil(i), s = Math.floor(s), i <= s ? {
      firstIndex: i,
      lastIndex: s,
      isStart: n === i,
      isEnd: r === s
    } : null;
  }
  // Given a date, returns its chronolocial cell-index from the first cell of the grid.
  // If the date lies between cells (because of hiddenDays), returns a floating-point value between offsets.
  // If before the first offset, returns a negative number.
  // If after the last offset, returns an offset past the last cell offset.
  // Only works for *start* dates of cells. Will not work for exclusive end dates for cells.
  getDateDayIndex(e) {
    let { indices: n } = this, r = Math.floor(ge(this.dates[0], e));
    return r < 0 ? n[0] - 1 : r >= n.length ? n[n.length - 1] + 1 : n[r];
  }
}
class Zi {
  constructor(e, n) {
    let { dates: r } = e, i, s, l;
    if (n) {
      for (s = r[0].getUTCDay(), i = 1; i < r.length && r[i].getUTCDay() !== s; i += 1)
        ;
      l = Math.ceil(r.length / i);
    } else
      l = 1, i = r.length;
    this.rowCnt = l, this.colCnt = i, this.daySeries = e, this.cells = this.buildCells(), this.headerDates = this.buildHeaderDates();
  }
  buildCells() {
    let e = [];
    for (let n = 0; n < this.rowCnt; n += 1) {
      let r = [];
      for (let i = 0; i < this.colCnt; i += 1)
        r.push(this.buildCell(n, i));
      e.push(r);
    }
    return e;
  }
  buildCell(e, n) {
    let r = this.daySeries.dates[e * this.colCnt + n];
    return {
      key: r.toISOString(),
      date: r
    };
  }
  buildHeaderDates() {
    let e = [];
    for (let n = 0; n < this.colCnt; n += 1)
      e.push(this.cells[0][n].date);
    return e;
  }
  sliceRange(e) {
    let { colCnt: n } = this, r = this.daySeries.sliceRange(e), i = [];
    if (r) {
      let { firstIndex: s, lastIndex: l } = r, a = s;
      for (; a <= l; ) {
        let o = Math.floor(a / n), d = Math.min((o + 1) * n, l + 1);
        i.push({
          row: o,
          firstCol: a % n,
          lastCol: (d - 1) % n,
          isStart: r.isStart && a === s,
          isEnd: r.isEnd && d - 1 === l
        }), a = d;
      }
    }
    return i;
  }
}
class $i {
  constructor() {
    this.sliceBusinessHours = C(this._sliceBusinessHours), this.sliceDateSelection = C(this._sliceDateSpan), this.sliceEventStore = C(this._sliceEventStore), this.sliceEventDrag = C(this._sliceInteraction), this.sliceEventResize = C(this._sliceInteraction), this.forceDayIfListItem = !1;
  }
  sliceProps(e, n, r, i, ...s) {
    let { eventUiBases: l } = e, a = this.sliceEventStore(e.eventStore, l, n, r, ...s);
    return {
      dateSelectionSegs: this.sliceDateSelection(e.dateSelection, n, r, l, i, ...s),
      businessHourSegs: this.sliceBusinessHours(e.businessHours, n, r, i, ...s),
      fgEventSegs: a.fg,
      bgEventSegs: a.bg,
      eventDrag: this.sliceEventDrag(e.eventDrag, l, n, r, ...s),
      eventResize: this.sliceEventResize(e.eventResize, l, n, r, ...s),
      eventSelection: e.eventSelection
    };
  }
  sliceNowDate(e, n, r, i, ...s) {
    return this._sliceDateSpan(
      { range: { start: e, end: fe(e, 1) }, allDay: !1 },
      // add 1 ms, protect against null range
      n,
      r,
      {},
      i,
      ...s
    );
  }
  _sliceBusinessHours(e, n, r, i, ...s) {
    return e ? this._sliceEventStore(Ye(e, st(n, !!r), i), {}, n, r, ...s).bg : [];
  }
  _sliceEventStore(e, n, r, i, ...s) {
    if (e) {
      let l = tn(e, n, st(r, !!i), i);
      return {
        bg: this.sliceEventRanges(l.bg, s),
        fg: this.sliceEventRanges(l.fg, s)
      };
    }
    return { bg: [], fg: [] };
  }
  _sliceInteraction(e, n, r, i, ...s) {
    if (!e)
      return null;
    let l = tn(e.mutatedEvents, n, st(r, !!i), i);
    return {
      segs: this.sliceEventRanges(l.fg, s),
      affectedInstances: e.affectedEvents.instances,
      isEvent: e.isEvent
    };
  }
  _sliceDateSpan(e, n, r, i, s, ...l) {
    if (!e)
      return [];
    let a = st(n, !!r), o = he(e.range, a);
    if (o) {
      e = Object.assign(Object.assign({}, e), { range: o });
      let d = Ao(e, i, s), c = this.sliceRange(e.range, ...l);
      for (let g of c)
        g.eventRange = d;
      return c;
    }
    return [];
  }
  /*
  "complete" seg means it has component and eventRange
  */
  sliceEventRanges(e, n) {
    let r = [];
    for (let i of e)
      r.push(...this.sliceEventRange(i, n));
    return r;
  }
  /*
  "complete" seg means it has component and eventRange
  */
  sliceEventRange(e, n) {
    let r = e.range;
    this.forceDayIfListItem && e.ui.display === "list-item" && (r = {
      start: r.start,
      end: B(r.start, 1)
    });
    let i = this.sliceRange(r, ...n);
    for (let s of i)
      s.eventRange = e, s.isStart = e.isStart && s.isStart, s.isEnd = e.isEnd && s.isEnd;
    return i;
  }
}
function st(t, e) {
  let n = t.activeRange;
  return e ? n : {
    start: fe(n.start, t.slotMinTime.milliseconds),
    end: fe(n.end, t.slotMaxTime.milliseconds - 864e5)
    // 864e5 = ms in a day
  };
}
const lt = /^(visible|hidden)$/;
class Ji extends T {
  constructor() {
    super(...arguments), this.handleEl = (e) => {
      this.el = e, J(this.props.elRef, e);
    };
  }
  render() {
    let { props: e } = this, { liquid: n, liquidIsAbsolute: r } = e, i = n && r, s = ["fc-scroller"];
    return n && (r ? s.push("fc-scroller-liquid-absolute") : s.push("fc-scroller-liquid")), u("div", { ref: this.handleEl, className: s.join(" "), style: {
      overflowX: e.overflowX,
      overflowY: e.overflowY,
      left: i && -(e.overcomeLeft || 0) || "",
      right: i && -(e.overcomeRight || 0) || "",
      bottom: i && -(e.overcomeBottom || 0) || "",
      marginLeft: !i && -(e.overcomeLeft || 0) || "",
      marginRight: !i && -(e.overcomeRight || 0) || "",
      marginBottom: !i && -(e.overcomeBottom || 0) || "",
      maxHeight: e.maxHeight || ""
    } }, e.children);
  }
  needsXScrolling() {
    if (lt.test(this.props.overflowX))
      return !1;
    let { el: e } = this, n = this.el.getBoundingClientRect().width - this.getYScrollbarWidth(), { children: r } = e;
    for (let i = 0; i < r.length; i += 1)
      if (r[i].getBoundingClientRect().width > n)
        return !0;
    return !1;
  }
  needsYScrolling() {
    if (lt.test(this.props.overflowY))
      return !1;
    let { el: e } = this, n = this.el.getBoundingClientRect().height - this.getXScrollbarWidth(), { children: r } = e;
    for (let i = 0; i < r.length; i += 1)
      if (r[i].getBoundingClientRect().height > n)
        return !0;
    return !1;
  }
  getXScrollbarWidth() {
    return lt.test(this.props.overflowX) ? 0 : this.el.offsetHeight - this.el.clientHeight;
  }
  getYScrollbarWidth() {
    return lt.test(this.props.overflowY) ? 0 : this.el.offsetWidth - this.el.clientWidth;
  }
}
class ee {
  constructor(e) {
    this.masterCallback = e, this.currentMap = {}, this.depths = {}, this.callbackMap = {}, this.handleValue = (n, r) => {
      let { depths: i, currentMap: s } = this, l = !1, a = !1;
      n !== null ? (l = r in s, s[r] = n, i[r] = (i[r] || 0) + 1, a = !0) : (i[r] -= 1, i[r] || (delete s[r], delete this.callbackMap[r], l = !0)), this.masterCallback && (l && this.masterCallback(null, String(r)), a && this.masterCallback(n, String(r)));
    };
  }
  createRef(e) {
    let n = this.callbackMap[e];
    return n || (n = this.callbackMap[e] = (r) => {
      this.handleValue(r, String(e));
    }), n;
  }
  // TODO: check callers that don't care about order. should use getAll instead
  // NOTE: this method has become less valuable now that we are encouraged to map order by some other index
  // TODO: provide ONE array-export function, buildArray, which fails on non-numeric indexes. caller can manipulate and "collect"
  collect(e, n, r) {
    return ha(this.currentMap, e, n, r);
  }
  getAll() {
    return gn(this.currentMap);
  }
}
function Go(t) {
  let e = pl(t, ".fc-scrollgrid-shrink"), n = 0;
  for (let r of e)
    n = Math.max(n, wl(r));
  return Math.ceil(n);
}
function Ki(t, e) {
  return t.liquid && e.liquid;
}
function Qo(t, e) {
  return e.maxHeight != null || // if its possible for the height to max out, we might need scrollbars
  Ki(t, e);
}
function qo(t, e, n, r) {
  let { expandRows: i } = n;
  return typeof e.content == "function" ? e.content(n) : u("table", {
    role: "presentation",
    className: [
      e.tableClassName,
      t.syncRowHeights ? "fc-scrollgrid-sync-table" : ""
    ].join(" "),
    style: {
      minWidth: n.tableMinWidth,
      width: n.clientWidth,
      height: i ? n.clientHeight : ""
      // css `height` on a <table> serves as a min-height
    }
  }, n.tableColGroupNode, u(r ? "thead" : "tbody", {
    role: "presentation"
  }, typeof e.rowContent == "function" ? e.rowContent(n) : e.rowContent));
}
function Yo(t, e) {
  return ue(t, e, Y);
}
function Zo(t, e) {
  let n = [];
  for (let r of t) {
    let i = r.span || 1;
    for (let s = 0; s < i; s += 1)
      n.push(u("col", { style: {
        width: r.width === "shrink" ? $o(e) : r.width || "",
        minWidth: r.minWidth || ""
      } }));
  }
  return u("colgroup", {}, ...n);
}
function $o(t) {
  return t ?? 4;
}
function Jo(t) {
  for (let e of t)
    if (e.width === "shrink")
      return !0;
  return !1;
}
function Ko(t, e) {
  let n = [
    "fc-scrollgrid",
    e.theme.getClass("table")
  ];
  return t && n.push("fc-scrollgrid-liquid"), n;
}
function Xo(t, e) {
  let n = [
    "fc-scrollgrid-section",
    `fc-scrollgrid-section-${t.type}`,
    t.className
    // used?
  ];
  return e && t.liquid && t.maxHeight == null && n.push("fc-scrollgrid-section-liquid"), t.isSticky && n.push("fc-scrollgrid-section-sticky"), n;
}
function ln(t) {
  return u("div", { className: "fc-scrollgrid-sticky-shim", style: {
    width: t.clientWidth,
    minWidth: t.tableMinWidth
  } });
}
function wt(t) {
  let { stickyHeaderDates: e } = t;
  return (e == null || e === "auto") && (e = t.height === "auto" || t.viewHeight === "auto"), e;
}
function Xi(t) {
  let { stickyFooterScrollbar: e } = t;
  return (e == null || e === "auto") && (e = t.height === "auto" || t.viewHeight === "auto"), e;
}
class _n extends T {
  constructor() {
    super(...arguments), this.processCols = C((e) => e, Yo), this.renderMicroColGroup = C(Zo), this.scrollerRefs = new ee(), this.scrollerElRefs = new ee(this._handleScrollerEl.bind(this)), this.state = {
      shrinkWidth: null,
      forceYScrollbars: !1,
      scrollerClientWidths: {},
      scrollerClientHeights: {}
    }, this.handleSizing = () => {
      this.safeSetState(Object.assign({ shrinkWidth: this.computeShrinkWidth() }, this.computeScrollerDims()));
    };
  }
  render() {
    let { props: e, state: n, context: r } = this, i = e.sections || [], s = this.processCols(e.cols), l = this.renderMicroColGroup(s, n.shrinkWidth), a = Ko(e.liquid, r);
    e.collapsibleWidth && a.push("fc-scrollgrid-collapsible");
    let o = i.length, d = 0, c, g = [], h = [], f = [];
    for (; d < o && (c = i[d]).type === "header"; )
      g.push(this.renderSection(c, l, !0)), d += 1;
    for (; d < o && (c = i[d]).type === "body"; )
      h.push(this.renderSection(c, l, !1)), d += 1;
    for (; d < o && (c = i[d]).type === "footer"; )
      f.push(this.renderSection(c, l, !0)), d += 1;
    let m = !Li();
    const y = { role: "rowgroup" };
    return u("table", {
      role: "grid",
      className: a.join(" "),
      style: { height: e.height }
    }, !!(!m && g.length) && u("thead", y, ...g), !!(!m && h.length) && u("tbody", y, ...h), !!(!m && f.length) && u("tfoot", y, ...f), m && u("tbody", y, ...g, ...h, ...f));
  }
  renderSection(e, n, r) {
    return "outerContent" in e ? u(k, { key: e.key }, e.outerContent) : u("tr", { key: e.key, role: "presentation", className: Xo(e, this.props.liquid).join(" ") }, this.renderChunkTd(e, n, e.chunk, r));
  }
  renderChunkTd(e, n, r, i) {
    if ("outerContent" in r)
      return r.outerContent;
    let { props: s } = this, { forceYScrollbars: l, scrollerClientWidths: a, scrollerClientHeights: o } = this.state, d = Qo(s, e), c = Ki(s, e), g = s.liquid ? l ? "scroll" : d ? "auto" : "hidden" : "visible", h = e.key, f = qo(e, r, {
      tableColGroupNode: n,
      tableMinWidth: "",
      clientWidth: !s.collapsibleWidth && a[h] !== void 0 ? a[h] : null,
      clientHeight: o[h] !== void 0 ? o[h] : null,
      expandRows: e.expandRows,
      syncRowHeights: !1,
      rowSyncHeights: [],
      reportRowHeightChange: () => {
      }
    }, i);
    return u(i ? "th" : "td", {
      ref: r.elRef,
      role: "presentation"
    }, u(
      "div",
      { className: `fc-scroller-harness${c ? " fc-scroller-harness-liquid" : ""}` },
      u(Ji, { ref: this.scrollerRefs.createRef(h), elRef: this.scrollerElRefs.createRef(h), overflowY: g, overflowX: s.liquid ? "hidden" : "visible", maxHeight: e.maxHeight, liquid: c, liquidIsAbsolute: !0 }, f)
    ));
  }
  _handleScrollerEl(e, n) {
    let r = ec(this.props.sections, n);
    r && J(r.chunk.scrollerElRef, e);
  }
  componentDidMount() {
    this.handleSizing(), this.context.addResizeHandler(this.handleSizing);
  }
  componentDidUpdate() {
    this.handleSizing();
  }
  componentWillUnmount() {
    this.context.removeResizeHandler(this.handleSizing);
  }
  computeShrinkWidth() {
    return Jo(this.props.cols) ? Go(this.scrollerElRefs.getAll()) : 0;
  }
  computeScrollerDims() {
    let e = No(), { scrollerRefs: n, scrollerElRefs: r } = this, i = !1, s = {}, l = {};
    for (let a in n.currentMap) {
      let o = n.currentMap[a];
      if (o && o.needsYScrolling()) {
        i = !0;
        break;
      }
    }
    for (let a of this.props.sections) {
      let o = a.key, d = r.currentMap[o];
      if (d) {
        let c = d.parentNode;
        s[o] = Math.floor(c.getBoundingClientRect().width - (i ? e.y : 0)), l[o] = Math.floor(c.getBoundingClientRect().height);
      }
    }
    return { forceYScrollbars: i, scrollerClientWidths: s, scrollerClientHeights: l };
  }
}
_n.addStateEquality({
  scrollerClientWidths: Y,
  scrollerClientHeights: Y
});
function ec(t, e) {
  for (let n of t)
    if (n.key === e)
      return n;
  return null;
}
class xt extends T {
  constructor() {
    super(...arguments), this.buildPublicEvent = C((e, n, r) => new Q(e, n, r)), this.handleEl = (e) => {
      this.el = e, J(this.props.elRef, e), e && Ar(e, this.props.seg);
    };
  }
  render() {
    const { props: e, context: n } = this, { options: r } = n, { seg: i } = e, { eventRange: s } = i, { ui: l } = s, a = {
      event: this.buildPublicEvent(n, s.def, s.instance),
      view: n.viewApi,
      timeText: e.timeText,
      textColor: l.textColor,
      backgroundColor: l.backgroundColor,
      borderColor: l.borderColor,
      isDraggable: !e.disableDragging && fo(i, n),
      isStartResizable: !e.disableResizing && ho(i, n),
      isEndResizable: !e.disableResizing && go(i),
      isMirror: !!(e.isDragging || e.isResizing || e.isDateSelecting),
      isStart: !!i.isStart,
      isEnd: !!i.isEnd,
      isPast: !!e.isPast,
      isFuture: !!e.isFuture,
      isToday: !!e.isToday,
      isSelected: !!e.isSelected,
      isDragging: !!e.isDragging,
      isResizing: !!e.isResizing
    };
    return u(U, { elRef: this.handleEl, elTag: e.elTag, elAttrs: e.elAttrs, elClasses: [
      ...po(a),
      ...i.eventRange.ui.classNames,
      ...e.elClasses || []
    ], elStyle: e.elStyle, renderProps: a, generatorName: "eventContent", customGenerator: r.eventContent, defaultGenerator: e.defaultGenerator, classNameGenerator: r.eventClassNames, didMount: r.eventDidMount, willUnmount: r.eventWillUnmount }, e.children);
  }
  componentDidUpdate(e) {
    this.el && this.props.seg !== e.seg && Ar(this.el, this.props.seg);
  }
}
class Rn extends T {
  render() {
    let { props: e, context: n } = this, { options: r } = n, { seg: i } = e, { ui: s } = i.eventRange, l = r.eventTimeFormat || e.defaultTimeFormat, a = We(i, l, n, e.defaultDisplayEventTime, e.defaultDisplayEventEnd);
    return u(xt, Object.assign({}, e, { elTag: "a", elStyle: {
      borderColor: s.borderColor,
      backgroundColor: s.backgroundColor
    }, elAttrs: Sn(i, n), defaultGenerator: tc, timeText: a }), (o, d) => u(
      k,
      null,
      u(o, { elTag: "div", elClasses: ["fc-event-main"], elStyle: { color: d.textColor } }),
      !!d.isStartResizable && u("div", { className: "fc-event-resizer fc-event-resizer-start" }),
      !!d.isEndResizable && u("div", { className: "fc-event-resizer fc-event-resizer-end" })
    ));
  }
}
Rn.addPropsEquality({
  seg: Y
});
function tc(t) {
  return u(
    "div",
    { className: "fc-event-main-frame" },
    t.timeText && u("div", { className: "fc-event-time" }, t.timeText),
    u(
      "div",
      { className: "fc-event-title-container" },
      u("div", { className: "fc-event-title fc-sticky" }, t.event.title || u(k, null, " "))
    )
  );
}
const Tn = (t) => u(ie.Consumer, null, (e) => {
  let { options: n } = e, r = {
    isAxis: t.isAxis,
    date: e.dateEnv.toDate(t.date),
    view: e.viewApi
  };
  return u(U, { elRef: t.elRef, elTag: t.elTag || "div", elAttrs: t.elAttrs, elClasses: t.elClasses, elStyle: t.elStyle, renderProps: r, generatorName: "nowIndicatorContent", customGenerator: n.nowIndicatorContent, classNameGenerator: n.nowIndicatorClassNames, didMount: n.nowIndicatorDidMount, willUnmount: n.nowIndicatorWillUnmount }, t.children);
}), nc = O({ day: "numeric" });
class xn extends T {
  constructor() {
    super(...arguments), this.refineRenderProps = ut(rc);
  }
  render() {
    let { props: e, context: n } = this, { options: r } = n, i = this.refineRenderProps({
      date: e.date,
      dateProfile: e.dateProfile,
      todayRange: e.todayRange,
      isMonthStart: e.isMonthStart || !1,
      showDayNumber: e.showDayNumber,
      extraRenderProps: e.extraRenderProps,
      viewApi: n.viewApi,
      dateEnv: n.dateEnv,
      monthStartFormat: r.monthStartFormat
    });
    return u(U, { elRef: e.elRef, elTag: e.elTag, elAttrs: Object.assign(Object.assign({}, e.elAttrs), i.isDisabled ? {} : { "data-date": Qe(e.date) }), elClasses: [
      ...Tt(i, n.theme),
      ...e.elClasses || []
    ], elStyle: e.elStyle, renderProps: i, generatorName: "dayCellContent", customGenerator: r.dayCellContent, defaultGenerator: e.defaultGenerator, classNameGenerator: (
      // don't use custom classNames if disabled
      i.isDisabled ? void 0 : r.dayCellClassNames
    ), didMount: r.dayCellDidMount, willUnmount: r.dayCellWillUnmount }, e.children);
  }
}
function kn(t) {
  return !!(t.dayCellContent || Kt("dayCellContent", t));
}
function rc(t) {
  let { date: e, dateEnv: n, dateProfile: r, isMonthStart: i } = t, s = Dn(e, t.todayRange, null, r), l = t.showDayNumber ? n.format(e, i ? t.monthStartFormat : nc) : "";
  return Object.assign(Object.assign(Object.assign({ date: n.toDate(e), view: t.viewApi }, s), {
    isMonthStart: i,
    dayNumberText: l
  }), t.extraRenderProps);
}
class es extends T {
  render() {
    let { props: e } = this, { seg: n } = e;
    return u(xt, { elTag: "div", elClasses: ["fc-bg-event"], elStyle: { backgroundColor: n.eventRange.ui.backgroundColor }, defaultGenerator: ic, seg: n, timeText: "", isDragging: !1, isResizing: !1, isDateSelecting: !1, isSelected: !1, isPast: e.isPast, isFuture: e.isFuture, isToday: e.isToday, disableDragging: !0, disableResizing: !0 });
  }
}
function ic(t) {
  let { title: e } = t.event;
  return e && u("div", { className: "fc-event-title" }, t.event.title);
}
function ts(t) {
  return u("div", { className: `fc-${t}` });
}
const ns = (t) => u(ie.Consumer, null, (e) => {
  let { dateEnv: n, options: r } = e, { date: i } = t, s = r.weekNumberFormat || t.defaultFormat, l = n.computeWeekNumber(i), a = n.format(i, s), o = { num: l, text: a, date: i };
  return u(
    U,
    { elRef: t.elRef, elTag: t.elTag, elAttrs: t.elAttrs, elClasses: t.elClasses, elStyle: t.elStyle, renderProps: o, generatorName: "weekNumberContent", customGenerator: r.weekNumberContent, defaultGenerator: sc, classNameGenerator: r.weekNumberClassNames, didMount: r.weekNumberDidMount, willUnmount: r.weekNumberWillUnmount },
    t.children
  );
});
function sc(t) {
  return t.text;
}
const jt = 10;
class lc extends T {
  constructor() {
    super(...arguments), this.state = {
      titleId: de()
    }, this.handleRootEl = (e) => {
      this.rootEl = e, this.props.elRef && J(this.props.elRef, e);
    }, this.handleDocumentMouseDown = (e) => {
      const n = yl(e);
      this.rootEl.contains(n) || this.handleCloseClick();
    }, this.handleDocumentKeyDown = (e) => {
      e.key === "Escape" && this.handleCloseClick();
    }, this.handleCloseClick = () => {
      let { onClose: e } = this.props;
      e && e();
    };
  }
  render() {
    let { theme: e, options: n } = this.context, { props: r, state: i } = this, s = [
      "fc-popover",
      e.getClass("popover")
    ].concat(r.extraClassNames || []);
    return el(u(
      "div",
      Object.assign({}, r.extraAttrs, { id: r.id, className: s.join(" "), "aria-labelledby": i.titleId, ref: this.handleRootEl }),
      u(
        "div",
        { className: "fc-popover-header " + e.getClass("popoverHeader") },
        u("span", { className: "fc-popover-title", id: i.titleId }, r.title),
        u("span", { className: "fc-popover-close " + e.getIconClass("close"), title: n.closeHint, onClick: this.handleCloseClick })
      ),
      u("div", { className: "fc-popover-body " + e.getClass("popoverContent") }, r.children)
    ), r.parentEl);
  }
  componentDidMount() {
    document.addEventListener("mousedown", this.handleDocumentMouseDown), document.addEventListener("keydown", this.handleDocumentKeyDown), this.updateSize();
  }
  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleDocumentMouseDown), document.removeEventListener("keydown", this.handleDocumentKeyDown);
  }
  updateSize() {
    let { isRtl: e } = this.context, { alignmentEl: n, alignGridTop: r } = this.props, { rootEl: i } = this, s = Po(n);
    if (s) {
      let l = i.getBoundingClientRect(), a = r ? X(n, ".fc-scrollgrid").getBoundingClientRect().top : s.top, o = e ? s.right - l.width : s.left;
      a = Math.max(a, jt), o = Math.min(o, document.documentElement.clientWidth - jt - l.width), o = Math.max(o, jt);
      let d = i.offsetParent.getBoundingClientRect();
      vl(i, {
        top: a - d.top,
        left: o - d.left
      });
    }
  }
}
class ac extends Z {
  constructor() {
    super(...arguments), this.handleRootEl = (e) => {
      this.rootEl = e, e ? this.context.registerInteractiveComponent(this, {
        el: e,
        useEventCenter: !1
      }) : this.context.unregisterInteractiveComponent(this);
    };
  }
  render() {
    let { options: e, dateEnv: n } = this.context, { props: r } = this, { startDate: i, todayRange: s, dateProfile: l } = r, a = n.format(i, e.dayPopoverFormat);
    return u(xn, { elRef: this.handleRootEl, date: i, dateProfile: l, todayRange: s }, (o, d, c) => u(
      lc,
      { elRef: c.ref, id: r.id, title: a, extraClassNames: ["fc-more-popover"].concat(c.className || []), extraAttrs: c, parentEl: r.parentEl, alignmentEl: r.alignmentEl, alignGridTop: r.alignGridTop, onClose: r.onClose },
      kn(e) && u(o, { elTag: "div", elClasses: ["fc-more-popover-misc"] }),
      r.children
    ));
  }
  queryHit(e, n, r, i) {
    let { rootEl: s, props: l } = this;
    return e >= 0 && e < r && n >= 0 && n < i ? {
      dateProfile: l.dateProfile,
      dateSpan: Object.assign({ allDay: !l.forceTimed, range: {
        start: l.startDate,
        end: l.endDate
      } }, l.extraDateSpan),
      dayEl: s,
      rect: {
        left: 0,
        top: 0,
        right: r,
        bottom: i
      },
      layer: 1
      // important when comparing with hits from other components
    } : null;
  }
}
class rs extends T {
  constructor() {
    super(...arguments), this.state = {
      isPopoverOpen: !1,
      popoverId: de()
    }, this.handleLinkEl = (e) => {
      this.linkEl = e, this.props.elRef && J(this.props.elRef, e);
    }, this.handleClick = (e) => {
      let { props: n, context: r } = this, { moreLinkClick: i } = r.options, s = Sr(n).start;
      function l(a) {
        let { def: o, instance: d, range: c } = a.eventRange;
        return {
          event: new Q(r, o, d),
          start: r.dateEnv.toDate(c.start),
          end: r.dateEnv.toDate(c.end),
          isStart: a.isStart,
          isEnd: a.isEnd
        };
      }
      typeof i == "function" && (i = i({
        date: s,
        allDay: !!n.allDayDate,
        allSegs: n.allSegs.map(l),
        hiddenSegs: n.hiddenSegs.map(l),
        jsEvent: e,
        view: r.viewApi
      })), !i || i === "popover" ? this.setState({ isPopoverOpen: !0 }) : typeof i == "string" && r.calendarApi.zoomTo(s, i);
    }, this.handlePopoverClose = () => {
      this.setState({ isPopoverOpen: !1 });
    };
  }
  render() {
    let { props: e, state: n } = this;
    return u(ie.Consumer, null, (r) => {
      let { viewApi: i, options: s, calendarApi: l } = r, { moreLinkText: a } = s, { moreCnt: o } = e, d = Sr(e), c = typeof a == "function" ? a.call(l, o) : `+${o} ${a}`, g = ze(s.moreLinkHint, [o], c), h = {
        num: o,
        shortText: `+${o}`,
        text: c,
        view: i
      };
      return u(
        k,
        null,
        !!e.moreCnt && u(U, { elTag: e.elTag || "a", elRef: this.handleLinkEl, elClasses: [
          ...e.elClasses || [],
          "fc-more-link"
        ], elStyle: e.elStyle, elAttrs: Object.assign(Object.assign(Object.assign({}, e.elAttrs), mi(this.handleClick)), { title: g, "aria-expanded": n.isPopoverOpen, "aria-controls": n.isPopoverOpen ? n.popoverId : "" }), renderProps: h, generatorName: "moreLinkContent", customGenerator: s.moreLinkContent, defaultGenerator: e.defaultGenerator || oc, classNameGenerator: s.moreLinkClassNames, didMount: s.moreLinkDidMount, willUnmount: s.moreLinkWillUnmount }, e.children),
        n.isPopoverOpen && u(ac, { id: n.popoverId, startDate: d.start, endDate: d.end, dateProfile: e.dateProfile, todayRange: e.todayRange, extraDateSpan: e.extraDateSpan, parentEl: this.parentEl, alignmentEl: e.alignmentElRef ? e.alignmentElRef.current : this.linkEl, alignGridTop: e.alignGridTop, forceTimed: e.forceTimed, onClose: this.handlePopoverClose }, e.popoverContent())
      );
    });
  }
  componentDidMount() {
    this.updateParentEl();
  }
  componentDidUpdate() {
    this.updateParentEl();
  }
  updateParentEl() {
    this.linkEl && (this.parentEl = X(this.linkEl, ".fc-view-harness"));
  }
}
function oc(t) {
  return t.text;
}
function Sr(t) {
  if (t.allDayDate)
    return {
      start: t.allDayDate,
      end: B(t.allDayDate, 1)
    };
  let { hiddenSegs: e } = t;
  return {
    start: is(e),
    end: dc(e)
  };
}
function is(t) {
  return t.reduce(cc).eventRange.range.start;
}
function cc(t, e) {
  return t.eventRange.range.start < e.eventRange.range.start ? t : e;
}
function dc(t) {
  return t.reduce(uc).eventRange.range.end;
}
function uc(t, e) {
  return t.eventRange.range.end > e.eventRange.range.end ? t : e;
}
const fc = [], ss = {
  code: "en",
  week: {
    dow: 0,
    doy: 4
    // 4 days need to be within the year to be considered the first week
  },
  direction: "ltr",
  buttonText: {
    prev: "prev",
    next: "next",
    prevYear: "prev year",
    nextYear: "next year",
    year: "year",
    today: "today",
    month: "month",
    week: "week",
    day: "day",
    list: "list"
  },
  weekText: "W",
  weekTextLong: "Week",
  closeHint: "Close",
  timeHint: "Time",
  eventHint: "Event",
  allDayText: "all-day",
  moreLinkText: "more",
  noEventsText: "No events to display"
}, ls = Object.assign(Object.assign({}, ss), {
  // Includes things we don't want other locales to inherit,
  // things that derive from other translatable strings.
  buttonHints: {
    prev: "Previous $0",
    next: "Next $0",
    today(t, e) {
      return e === "day" ? "Today" : `This ${t}`;
    }
  },
  viewHint: "$0 view",
  navLinkHint: "Go to $0",
  moreLinkHint(t) {
    return `Show ${t} more event${t === 1 ? "" : "s"}`;
  }
});
function hc(t) {
  let e = t.length > 0 ? t[0].code : "en", n = fc.concat(t), r = {
    en: ls
  };
  for (let i of n)
    r[i.code] = i;
  return {
    map: r,
    defaultCode: e
  };
}
function as(t, e) {
  return typeof t == "object" && !Array.isArray(t) ? os(t.code, [t.code], t) : gc(t, e);
}
function gc(t, e) {
  let n = [].concat(t || []), r = pc(n, e) || ls;
  return os(t, n, r);
}
function pc(t, e) {
  for (let n = 0; n < t.length; n += 1) {
    let r = t[n].toLocaleLowerCase().split("-");
    for (let i = r.length; i > 0; i -= 1) {
      let s = r.slice(0, i).join("-");
      if (e[s])
        return e[s];
    }
  }
  return null;
}
function os(t, e, n) {
  let r = hn([ss, n], ["buttonText"]);
  delete r.code;
  let { week: i } = r;
  return delete r.week, {
    codeArg: t,
    codes: e,
    week: i,
    simpleNumberFormat: new Intl.NumberFormat(t),
    options: r
  };
}
function se(t) {
  return {
    id: De(),
    name: t.name,
    premiumReleaseDate: t.premiumReleaseDate ? new Date(t.premiumReleaseDate) : void 0,
    deps: t.deps || [],
    reducers: t.reducers || [],
    isLoadingFuncs: t.isLoadingFuncs || [],
    contextInit: [].concat(t.contextInit || []),
    eventRefiners: t.eventRefiners || {},
    eventDefMemberAdders: t.eventDefMemberAdders || [],
    eventSourceRefiners: t.eventSourceRefiners || {},
    isDraggableTransformers: t.isDraggableTransformers || [],
    eventDragMutationMassagers: t.eventDragMutationMassagers || [],
    eventDefMutationAppliers: t.eventDefMutationAppliers || [],
    dateSelectionTransformers: t.dateSelectionTransformers || [],
    datePointTransforms: t.datePointTransforms || [],
    dateSpanTransforms: t.dateSpanTransforms || [],
    views: t.views || {},
    viewPropsTransformers: t.viewPropsTransformers || [],
    isPropsValid: t.isPropsValid || null,
    externalDefTransforms: t.externalDefTransforms || [],
    viewContainerAppends: t.viewContainerAppends || [],
    eventDropTransformers: t.eventDropTransformers || [],
    componentInteractions: t.componentInteractions || [],
    calendarInteractions: t.calendarInteractions || [],
    themeClasses: t.themeClasses || {},
    eventSourceDefs: t.eventSourceDefs || [],
    cmdFormatter: t.cmdFormatter,
    recurringTypes: t.recurringTypes || [],
    namedTimeZonedImpl: t.namedTimeZonedImpl,
    initialView: t.initialView || "",
    elementDraggingImpl: t.elementDraggingImpl,
    optionChangeHandlers: t.optionChangeHandlers || {},
    scrollGridImpl: t.scrollGridImpl || null,
    listenerRefiners: t.listenerRefiners || {},
    optionRefiners: t.optionRefiners || {},
    propSetHandlers: t.propSetHandlers || {}
  };
}
function mc(t, e) {
  let n = {}, r = {
    premiumReleaseDate: void 0,
    reducers: [],
    isLoadingFuncs: [],
    contextInit: [],
    eventRefiners: {},
    eventDefMemberAdders: [],
    eventSourceRefiners: {},
    isDraggableTransformers: [],
    eventDragMutationMassagers: [],
    eventDefMutationAppliers: [],
    dateSelectionTransformers: [],
    datePointTransforms: [],
    dateSpanTransforms: [],
    views: {},
    viewPropsTransformers: [],
    isPropsValid: null,
    externalDefTransforms: [],
    viewContainerAppends: [],
    eventDropTransformers: [],
    componentInteractions: [],
    calendarInteractions: [],
    themeClasses: {},
    eventSourceDefs: [],
    cmdFormatter: null,
    recurringTypes: [],
    namedTimeZonedImpl: null,
    initialView: "",
    elementDraggingImpl: null,
    optionChangeHandlers: {},
    scrollGridImpl: null,
    listenerRefiners: {},
    optionRefiners: {},
    propSetHandlers: {}
  };
  function i(s) {
    for (let l of s) {
      const a = l.name, o = n[a];
      o === void 0 ? (n[a] = l.id, i(l.deps), r = yc(r, l)) : o !== l.id && console.warn(`Duplicate plugin '${a}'`);
    }
  }
  return t && i(t), i(e), r;
}
function vc() {
  let t = [], e = [], n;
  return (r, i) => ((!n || !ue(r, t) || !ue(i, e)) && (n = mc(r, i)), t = r, e = i, n);
}
function yc(t, e) {
  return {
    premiumReleaseDate: bc(t.premiumReleaseDate, e.premiumReleaseDate),
    reducers: t.reducers.concat(e.reducers),
    isLoadingFuncs: t.isLoadingFuncs.concat(e.isLoadingFuncs),
    contextInit: t.contextInit.concat(e.contextInit),
    eventRefiners: Object.assign(Object.assign({}, t.eventRefiners), e.eventRefiners),
    eventDefMemberAdders: t.eventDefMemberAdders.concat(e.eventDefMemberAdders),
    eventSourceRefiners: Object.assign(Object.assign({}, t.eventSourceRefiners), e.eventSourceRefiners),
    isDraggableTransformers: t.isDraggableTransformers.concat(e.isDraggableTransformers),
    eventDragMutationMassagers: t.eventDragMutationMassagers.concat(e.eventDragMutationMassagers),
    eventDefMutationAppliers: t.eventDefMutationAppliers.concat(e.eventDefMutationAppliers),
    dateSelectionTransformers: t.dateSelectionTransformers.concat(e.dateSelectionTransformers),
    datePointTransforms: t.datePointTransforms.concat(e.datePointTransforms),
    dateSpanTransforms: t.dateSpanTransforms.concat(e.dateSpanTransforms),
    views: Object.assign(Object.assign({}, t.views), e.views),
    viewPropsTransformers: t.viewPropsTransformers.concat(e.viewPropsTransformers),
    isPropsValid: e.isPropsValid || t.isPropsValid,
    externalDefTransforms: t.externalDefTransforms.concat(e.externalDefTransforms),
    viewContainerAppends: t.viewContainerAppends.concat(e.viewContainerAppends),
    eventDropTransformers: t.eventDropTransformers.concat(e.eventDropTransformers),
    calendarInteractions: t.calendarInteractions.concat(e.calendarInteractions),
    componentInteractions: t.componentInteractions.concat(e.componentInteractions),
    themeClasses: Object.assign(Object.assign({}, t.themeClasses), e.themeClasses),
    eventSourceDefs: t.eventSourceDefs.concat(e.eventSourceDefs),
    cmdFormatter: e.cmdFormatter || t.cmdFormatter,
    recurringTypes: t.recurringTypes.concat(e.recurringTypes),
    namedTimeZonedImpl: e.namedTimeZonedImpl || t.namedTimeZonedImpl,
    initialView: t.initialView || e.initialView,
    elementDraggingImpl: t.elementDraggingImpl || e.elementDraggingImpl,
    optionChangeHandlers: Object.assign(Object.assign({}, t.optionChangeHandlers), e.optionChangeHandlers),
    scrollGridImpl: e.scrollGridImpl || t.scrollGridImpl,
    listenerRefiners: Object.assign(Object.assign({}, t.listenerRefiners), e.listenerRefiners),
    optionRefiners: Object.assign(Object.assign({}, t.optionRefiners), e.optionRefiners),
    propSetHandlers: Object.assign(Object.assign({}, t.propSetHandlers), e.propSetHandlers)
  };
}
function bc(t, e) {
  return t === void 0 ? e : e === void 0 ? t : new Date(Math.max(t.valueOf(), e.valueOf()));
}
class pe extends qe {
}
pe.prototype.classes = {
  root: "fc-theme-standard",
  tableCellShaded: "fc-cell-shaded",
  buttonGroup: "fc-button-group",
  button: "fc-button fc-button-primary",
  buttonActive: "fc-button-active"
};
pe.prototype.baseIconClass = "fc-icon";
pe.prototype.iconClasses = {
  close: "fc-icon-x",
  prev: "fc-icon-chevron-left",
  next: "fc-icon-chevron-right",
  prevYear: "fc-icon-chevrons-left",
  nextYear: "fc-icon-chevrons-right"
};
pe.prototype.rtlIconClasses = {
  prev: "fc-icon-chevron-right",
  next: "fc-icon-chevron-left",
  prevYear: "fc-icon-chevrons-right",
  nextYear: "fc-icon-chevrons-left"
};
pe.prototype.iconOverrideOption = "buttonIcons";
pe.prototype.iconOverrideCustomButtonOption = "icon";
pe.prototype.iconOverridePrefix = "fc-icon-";
function Ac(t, e) {
  let n = {}, r;
  for (r in t)
    an(r, n, t, e);
  for (r in e)
    an(r, n, t, e);
  return n;
}
function an(t, e, n, r) {
  if (e[t])
    return e[t];
  let i = Ec(t, e, n, r);
  return i && (e[t] = i), i;
}
function Ec(t, e, n, r) {
  let i = n[t], s = r[t], l = (c) => i && i[c] !== null ? i[c] : s && s[c] !== null ? s[c] : null, a = l("component"), o = l("superType"), d = null;
  if (o) {
    if (o === t)
      throw new Error("Can't have a custom view type that references itself");
    d = an(o, e, n, r);
  }
  return !a && d && (a = d.component), a ? {
    type: t,
    component: a,
    defaults: Object.assign(Object.assign({}, d ? d.defaults : {}), i ? i.rawOptions : {}),
    overrides: Object.assign(Object.assign({}, d ? d.overrides : {}), s ? s.rawOptions : {})
  } : null;
}
function Dr(t) {
  return Se(t, Cc);
}
function Cc(t) {
  let e = typeof t == "function" ? { component: t } : t, { component: n } = e;
  return e.content ? n = wr(e) : n && !(n.prototype instanceof T) && (n = wr(Object.assign(Object.assign({}, e), { content: n }))), {
    superType: e.type,
    component: n,
    rawOptions: e
    // includes type and component too :(
  };
}
function wr(t) {
  return (e) => u(ie.Consumer, null, (n) => u(U, { elTag: "div", elClasses: wi(n.viewSpec), renderProps: Object.assign(Object.assign({}, e), { nextDayThreshold: n.options.nextDayThreshold }), generatorName: void 0, customGenerator: t.content, classNameGenerator: t.classNames, didMount: t.didMount, willUnmount: t.willUnmount }));
}
function Sc(t, e, n, r) {
  let i = Dr(t), s = Dr(e.views), l = Ac(i, s);
  return Se(l, (a) => Dc(a, s, e, n, r));
}
function Dc(t, e, n, r, i) {
  let s = t.overrides.duration || t.defaults.duration || r.duration || n.duration, l = null, a = "", o = "", d = {};
  if (s && (l = wc(s), l)) {
    let h = Jt(l);
    a = h.unit, h.value === 1 && (o = a, d = e[a] ? e[a].rawOptions : {});
  }
  let c = (h) => {
    let f = h.buttonText || {}, m = t.defaults.buttonTextKey;
    return m != null && f[m] != null ? f[m] : f[t.type] != null ? f[t.type] : f[o] != null ? f[o] : null;
  }, g = (h) => {
    let f = h.buttonHints || {}, m = t.defaults.buttonTextKey;
    return m != null && f[m] != null ? f[m] : f[t.type] != null ? f[t.type] : f[o] != null ? f[o] : null;
  };
  return {
    type: t.type,
    component: t.component,
    duration: l,
    durationUnit: a,
    singleUnit: o,
    optionDefaults: t.defaults,
    optionOverrides: Object.assign(Object.assign({}, d), t.overrides),
    buttonTextOverride: c(r) || c(n) || // constructor-specified buttonText lookup hash takes precedence
    t.overrides.buttonText,
    buttonTextDefault: c(i) || t.defaults.buttonText || c(Ue) || t.type,
    // not DRY
    buttonTitleOverride: g(r) || g(n) || t.overrides.buttonHint,
    buttonTitleDefault: g(i) || t.defaults.buttonHint || g(Ue)
    // will eventually fall back to buttonText
  };
}
let _r = {};
function wc(t) {
  let e = JSON.stringify(t), n = _r[e];
  return n === void 0 && (n = R(t), _r[e] = n), n;
}
function _c(t, e) {
  return e.type === "CHANGE_VIEW_TYPE" && (t = e.viewType), t;
}
function Rc(t, e) {
  return e.type === "CHANGE_DATE" ? e.dateMarker : t;
}
function Tc(t, e, n) {
  let r = t.initialDate;
  return r != null ? e.createMarker(r) : n.getDateMarker();
}
function xc(t, e) {
  return e.type === "SET_OPTION" ? Object.assign(Object.assign({}, t), { [e.optionName]: e.rawOptionValue }) : t;
}
function kc(t, e, n, r) {
  let i;
  switch (e.type) {
    case "CHANGE_VIEW_TYPE":
      return r.build(e.dateMarker || n);
    case "CHANGE_DATE":
      return r.build(e.dateMarker);
    case "PREV":
      if (i = r.buildPrev(t, n), i.isValid)
        return i;
      break;
    case "NEXT":
      if (i = r.buildNext(t, n), i.isValid)
        return i;
      break;
  }
  return t;
}
function Mc(t, e, n) {
  let r = e ? e.activeRange : null;
  return ds({}, Fc(t, n), r, n);
}
function Ic(t, e, n, r) {
  let i = n ? n.activeRange : null;
  switch (e.type) {
    case "ADD_EVENT_SOURCES":
      return ds(t, e.sources, i, r);
    case "REMOVE_EVENT_SOURCE":
      return Oc(t, e.sourceId);
    case "PREV":
    // TODO: how do we track all actions that affect dateProfile :(
    case "NEXT":
    case "CHANGE_DATE":
    case "CHANGE_VIEW_TYPE":
      return n ? us(t, i, r) : t;
    case "FETCH_EVENT_SOURCES":
      return Mn(t, e.sourceIds ? (
        // why no type?
        Ai(e.sourceIds)
      ) : fs(t, r), i, e.isRefetch || !1, r);
    case "RECEIVE_EVENTS":
    case "RECEIVE_EVENT_ERROR":
      return Bc(t, e.sourceId, e.fetchId, e.fetchRange);
    case "REMOVE_ALL_EVENT_SOURCES":
      return {};
    default:
      return t;
  }
}
function Nc(t, e, n) {
  let r = e ? e.activeRange : null;
  return Mn(t, fs(t, n), r, !0, n);
}
function cs(t) {
  for (let e in t)
    if (t[e].isFetching)
      return !0;
  return !1;
}
function ds(t, e, n, r) {
  let i = {};
  for (let s of e)
    i[s.sourceId] = s;
  return n && (i = us(i, n, r)), Object.assign(Object.assign({}, t), i);
}
function Oc(t, e) {
  return Oe(t, (n) => n.sourceId !== e);
}
function us(t, e, n) {
  return Mn(t, Oe(t, (r) => Hc(r, e, n)), e, !1, n);
}
function Hc(t, e, n) {
  return hs(t, n) ? !n.options.lazyFetching || !t.fetchRange || t.isFetching || // always cancel outdated in-progress fetches
  e.start < t.fetchRange.start || e.end > t.fetchRange.end : !t.latestFetchId;
}
function Mn(t, e, n, r, i) {
  let s = {};
  for (let l in t) {
    let a = t[l];
    e[l] ? s[l] = Pc(a, n, r, i) : s[l] = a;
  }
  return s;
}
function Pc(t, e, n, r) {
  let { options: i, calendarApi: s } = r, l = r.pluginHooks.eventSourceDefs[t.sourceDefId], a = De();
  return l.fetch({
    eventSource: t,
    range: e,
    isRefetch: n,
    context: r
  }, (o) => {
    let { rawEvents: d } = o;
    i.eventSourceSuccess && (d = i.eventSourceSuccess.call(s, d, o.response) || d), t.success && (d = t.success.call(s, d, o.response) || d), r.dispatch({
      type: "RECEIVE_EVENTS",
      sourceId: t.sourceId,
      fetchId: a,
      fetchRange: e,
      rawEvents: d
    });
  }, (o) => {
    let d = !1;
    i.eventSourceFailure && (i.eventSourceFailure.call(s, o), d = !0), t.failure && (t.failure(o), d = !0), d || console.warn(o.message, o), r.dispatch({
      type: "RECEIVE_EVENT_ERROR",
      sourceId: t.sourceId,
      fetchId: a,
      fetchRange: e,
      error: o
    });
  }), Object.assign(Object.assign({}, t), { isFetching: !0, latestFetchId: a });
}
function Bc(t, e, n, r) {
  let i = t[e];
  return i && // not already removed
  n === i.latestFetchId ? Object.assign(Object.assign({}, t), { [e]: Object.assign(Object.assign({}, i), { isFetching: !1, fetchRange: r }) }) : t;
}
function fs(t, e) {
  return Oe(t, (n) => hs(n, e));
}
function Fc(t, e) {
  let n = Ni(e), r = [].concat(t.eventSources || []), i = [];
  t.initialEvents && r.unshift(t.initialEvents), t.events && r.unshift(t.events);
  for (let s of r) {
    let l = Ii(s, e, n);
    l && i.push(l);
  }
  return i;
}
function hs(t, e) {
  return !e.pluginHooks.eventSourceDefs[t.sourceDefId].ignoreRange;
}
function zc(t, e) {
  switch (e.type) {
    case "UNSELECT_DATES":
      return null;
    case "SELECT_DATES":
      return e.selection;
    default:
      return t;
  }
}
function Uc(t, e) {
  switch (e.type) {
    case "UNSELECT_EVENT":
      return "";
    case "SELECT_EVENT":
      return e.eventInstanceId;
    default:
      return t;
  }
}
function Wc(t, e) {
  let n;
  switch (e.type) {
    case "UNSET_EVENT_DRAG":
      return null;
    case "SET_EVENT_DRAG":
      return n = e.state, {
        affectedEvents: n.affectedEvents,
        mutatedEvents: n.mutatedEvents,
        isEvent: n.isEvent
      };
    default:
      return t;
  }
}
function Lc(t, e) {
  let n;
  switch (e.type) {
    case "UNSET_EVENT_RESIZE":
      return null;
    case "SET_EVENT_RESIZE":
      return n = e.state, {
        affectedEvents: n.affectedEvents,
        mutatedEvents: n.mutatedEvents,
        isEvent: n.isEvent
      };
    default:
      return t;
  }
}
function jc(t, e, n, r, i) {
  let s = t.headerToolbar ? Rr(t.headerToolbar, t, e, n, r, i) : null, l = t.footerToolbar ? Rr(t.footerToolbar, t, e, n, r, i) : null;
  return { header: s, footer: l };
}
function Rr(t, e, n, r, i, s) {
  let l = {}, a = [], o = !1;
  for (let d in t) {
    let c = t[d], g = Vc(c, e, n, r, i, s);
    l[d] = g.widgets, a.push(...g.viewsWithButtons), o = o || g.hasTitle;
  }
  return { sectionWidgets: l, viewsWithButtons: a, hasTitle: o };
}
function Vc(t, e, n, r, i, s) {
  let l = e.direction === "rtl", a = e.customButtons || {}, o = n.buttonText || {}, d = e.buttonText || {}, c = n.buttonHints || {}, g = e.buttonHints || {}, h = t ? t.split(" ") : [], f = [], m = !1;
  return { widgets: h.map((v) => v.split(",").map((b) => {
    if (b === "title")
      return m = !0, { buttonName: b };
    let A, w, D, F, x, P;
    if (A = a[b])
      D = (_) => {
        A.click && A.click.call(_.target, _, _.target);
      }, (F = r.getCustomButtonIconClass(A)) || (F = r.getIconClass(b, l)) || (x = A.text), P = A.hint || A.text;
    else if (w = i[b]) {
      f.push(b), D = () => {
        s.changeView(b);
      }, (x = w.buttonTextOverride) || (F = r.getIconClass(b, l)) || (x = w.buttonTextDefault);
      let _ = w.buttonTextOverride || w.buttonTextDefault;
      P = ze(
        w.buttonTitleOverride || w.buttonTitleDefault || e.viewHint,
        [_, b],
        // view-name = buttonName
        _
      );
    } else if (s[b])
      if (D = () => {
        s[b]();
      }, (x = o[b]) || (F = r.getIconClass(b, l)) || (x = d[b]), b === "prevYear" || b === "nextYear") {
        let _ = b === "prevYear" ? "prev" : "next";
        P = ze(c[_] || g[_], [
          d.year || "year",
          "year"
        ], d[b]);
      } else
        P = (_) => ze(c[b] || g[b], [
          d[_] || _,
          _
        ], d[b]);
    return { buttonName: b, buttonClick: D, buttonIcon: F, buttonText: x, buttonHint: P };
  })), viewsWithButtons: f, hasTitle: m };
}
class Gc {
  constructor(e, n, r) {
    this.type = e, this.getCurrentData = n, this.dateEnv = r;
  }
  get calendar() {
    return this.getCurrentData().calendarApi;
  }
  get title() {
    return this.getCurrentData().viewTitle;
  }
  get activeStart() {
    return this.dateEnv.toDate(this.getCurrentData().dateProfile.activeRange.start);
  }
  get activeEnd() {
    return this.dateEnv.toDate(this.getCurrentData().dateProfile.activeRange.end);
  }
  get currentStart() {
    return this.dateEnv.toDate(this.getCurrentData().dateProfile.currentRange.start);
  }
  get currentEnd() {
    return this.dateEnv.toDate(this.getCurrentData().dateProfile.currentRange.end);
  }
  getOption(e) {
    return this.getCurrentData().options[e];
  }
}
let Qc = {
  ignoreRange: !0,
  parseMeta(t) {
    return Array.isArray(t.events) ? t.events : null;
  },
  fetch(t, e) {
    e({
      rawEvents: t.eventSource.meta
    });
  }
};
const qc = se({
  name: "array-event-source",
  eventSourceDefs: [Qc]
});
let Yc = {
  parseMeta(t) {
    return typeof t.events == "function" ? t.events : null;
  },
  fetch(t, e, n) {
    const { dateEnv: r } = t.context, i = t.eventSource.meta;
    Eo(i.bind(null, Ui(t.range, r)), (s) => e({ rawEvents: s }), n);
  }
};
const Zc = se({
  name: "func-event-source",
  eventSourceDefs: [Yc]
}), $c = {
  method: String,
  extraParams: p,
  startParam: String,
  endParam: String,
  timeZoneParam: String
};
let Jc = {
  parseMeta(t) {
    return t.url && (t.format === "json" || !t.format) ? {
      url: t.url,
      format: "json",
      method: (t.method || "GET").toUpperCase(),
      extraParams: t.extraParams,
      startParam: t.startParam,
      endParam: t.endParam,
      timeZoneParam: t.timeZoneParam
    } : null;
  },
  fetch(t, e, n) {
    const { meta: r } = t.eventSource, i = Xc(r, t.range, t.context);
    Co(r.method, r.url, i).then(([s, l]) => {
      e({ rawEvents: s, response: l });
    }, n);
  }
};
const Kc = se({
  name: "json-event-source",
  eventSourceRefiners: $c,
  eventSourceDefs: [Jc]
});
function Xc(t, e, n) {
  let { dateEnv: r, options: i } = n, s, l, a, o, d = {};
  return s = t.startParam, s == null && (s = i.startParam), l = t.endParam, l == null && (l = i.endParam), a = t.timeZoneParam, a == null && (a = i.timeZoneParam), typeof t.extraParams == "function" ? o = t.extraParams() : o = t.extraParams || {}, Object.assign(d, o), d[s] = r.formatIso(e.start), d[l] = r.formatIso(e.end), r.timeZone !== "local" && (d[a] = r.timeZone), d;
}
const ed = {
  daysOfWeek: p,
  startTime: R,
  endTime: R,
  duration: R,
  startRecur: p,
  endRecur: p
};
let td = {
  parse(t, e) {
    if (t.daysOfWeek || t.startTime || t.endTime || t.startRecur || t.endRecur) {
      let n = {
        daysOfWeek: t.daysOfWeek || null,
        startTime: t.startTime || null,
        endTime: t.endTime || null,
        startRecur: t.startRecur ? e.createMarker(t.startRecur) : null,
        endRecur: t.endRecur ? e.createMarker(t.endRecur) : null,
        dateEnv: e
      }, r;
      return t.duration && (r = t.duration), !r && t.startTime && t.endTime && (r = xl(t.endTime, t.startTime)), {
        allDayGuess: !t.startTime && !t.endTime,
        duration: r,
        typeData: n
        // doesn't need endTime anymore but oh well
      };
    }
    return null;
  },
  expand(t, e, n) {
    let r = he(e, { start: t.startRecur, end: t.endRecur });
    return r ? rd(t.daysOfWeek, t.startTime, t.dateEnv, n, r) : [];
  }
};
const nd = se({
  name: "simple-recurring-event",
  recurringTypes: [td],
  eventRefiners: ed
});
function rd(t, e, n, r, i) {
  let s = t ? Ai(t) : null, l = I(i.start), a = i.end, o = [];
  for (e && (e.milliseconds < 0 ? a = B(a, 1) : e.milliseconds >= 1e3 * 60 * 60 * 24 && (l = B(l, -1))); l < a; ) {
    let d;
    (!s || s[l.getUTCDay()]) && (e ? d = r.add(l, e) : d = l, o.push(r.createMarker(n.toDate(d)))), l = B(l, 1);
  }
  return o;
}
const id = se({
  name: "change-handler",
  optionChangeHandlers: {
    events(t, e) {
      Tr([t], e);
    },
    eventSources: Tr
  }
});
function Tr(t, e) {
  let n = gn(e.getCurrentData().eventSources);
  if (n.length === 1 && t.length === 1 && Array.isArray(n[0]._raw) && Array.isArray(t[0])) {
    e.dispatch({
      type: "RESET_RAW_EVENTS",
      sourceId: n[0].sourceId,
      rawEvents: t[0]
    });
    return;
  }
  let r = [];
  for (let i of t) {
    let s = !1;
    for (let l = 0; l < n.length; l += 1)
      if (n[l]._raw === i) {
        n.splice(l, 1), s = !0;
        break;
      }
    s || r.push(i);
  }
  for (let i of n)
    e.dispatch({
      type: "REMOVE_EVENT_SOURCE",
      sourceId: i.sourceId
    });
  for (let i of r)
    e.calendarApi.addEventSource(i);
}
function sd(t, e) {
  e.emitter.trigger("datesSet", Object.assign(Object.assign({}, Ui(t.activeRange, e.dateEnv)), { view: e.viewApi }));
}
function ld(t, e) {
  let { emitter: n } = e;
  n.hasHandlers("eventsSet") && n.trigger("eventsSet", En(t, e));
}
const ad = [
  qc,
  Zc,
  Kc,
  nd,
  id,
  se({
    name: "misc",
    isLoadingFuncs: [
      (t) => cs(t.eventSources)
    ],
    propSetHandlers: {
      dateProfile: sd,
      eventStore: ld
    }
  })
];
class od {
  constructor(e, n) {
    this.runTaskOption = e, this.drainedOption = n, this.queue = [], this.delayedRunner = new cn(this.drain.bind(this));
  }
  request(e, n) {
    this.queue.push(e), this.delayedRunner.request(n);
  }
  pause(e) {
    this.delayedRunner.pause(e);
  }
  resume(e, n) {
    this.delayedRunner.resume(e, n);
  }
  drain() {
    let { queue: e } = this;
    for (; e.length; ) {
      let n = [], r;
      for (; r = e.shift(); )
        this.runTask(r), n.push(r);
      this.drained(n);
    }
  }
  runTask(e) {
    this.runTaskOption && this.runTaskOption(e);
  }
  drained(e) {
    this.drainedOption && this.drainedOption(e);
  }
}
function cd(t, e, n) {
  let r;
  return /^(year|month)$/.test(t.currentRangeUnit) ? r = t.currentRange : r = t.activeRange, n.formatRange(r.start, r.end, O(e.titleFormat || dd(t)), {
    isEndExclusive: t.isRangeAllDay,
    defaultSeparator: e.titleRangeSeparator
  });
}
function dd(t) {
  let { currentRangeUnit: e } = t;
  if (e === "year")
    return { year: "numeric" };
  if (e === "month")
    return { year: "numeric", month: "long" };
  let n = yt(t.currentRange.start, t.currentRange.end);
  return n !== null && n > 1 ? { year: "numeric", month: "short", day: "numeric" } : { year: "numeric", month: "long", day: "numeric" };
}
class xr {
  constructor() {
    this.resetListeners = /* @__PURE__ */ new Set();
  }
  handleInput(e, n) {
    const r = this.dateEnv;
    if (e !== r && (typeof n == "function" ? this.nowFn = n : r || (this.nowAnchorDate = e.toDate(n ? e.createMarker(n) : e.createNowMarker()), this.nowAnchorQueried = Date.now()), this.dateEnv = e, r))
      for (const i of this.resetListeners.values())
        i();
  }
  getDateMarker() {
    return this.nowAnchorDate ? this.dateEnv.timestampToMarker(this.nowAnchorDate.valueOf() + (Date.now() - this.nowAnchorQueried)) : this.dateEnv.createMarker(this.nowFn());
  }
  addResetListener(e) {
    this.resetListeners.add(e);
  }
  removeResetListener(e) {
    this.resetListeners.delete(e);
  }
}
class ud {
  constructor(e) {
    this.computeCurrentViewData = C(this._computeCurrentViewData), this.organizeRawLocales = C(hc), this.buildLocale = C(as), this.buildPluginHooks = vc(), this.buildDateEnv = C(fd), this.buildTheme = C(hd), this.parseToolbars = C(jc), this.buildViewSpecs = C(Sc), this.buildDateProfileGenerator = ut(gd), this.buildViewApi = C(pd), this.buildViewUiProps = ut(yd), this.buildEventUiBySource = C(md, Y), this.buildEventUiBases = C(vd), this.parseContextBusinessHours = ut(bd), this.buildTitle = C(cd), this.nowManager = new xr(), this.emitter = new Ja(), this.actionRunner = new od(this._handleAction.bind(this), this.updateData.bind(this)), this.currentCalendarOptionsInput = {}, this.currentCalendarOptionsRefined = {}, this.currentViewOptionsInput = {}, this.currentViewOptionsRefined = {}, this.currentCalendarOptionsRefiners = {}, this.optionsForRefining = [], this.optionsForHandling = [], this.getCurrentData = () => this.data, this.dispatch = (h) => {
      this.actionRunner.request(h);
    }, this.props = e, this.actionRunner.pause(), this.nowManager = new xr();
    let n = {}, r = this.computeOptionsData(e.optionOverrides, n, e.calendarApi), i = r.calendarOptions.initialView || r.pluginHooks.initialView, s = this.computeCurrentViewData(i, r, e.optionOverrides, n);
    e.calendarApi.currentDataManager = this, this.emitter.setThisContext(e.calendarApi), this.emitter.setOptions(s.options);
    let l = {
      nowManager: this.nowManager,
      dateEnv: r.dateEnv,
      options: r.calendarOptions,
      pluginHooks: r.pluginHooks,
      calendarApi: e.calendarApi,
      dispatch: this.dispatch,
      emitter: this.emitter,
      getCurrentData: this.getCurrentData
    }, a = Tc(r.calendarOptions, r.dateEnv, this.nowManager), o = s.dateProfileGenerator.build(a);
    te(o.activeRange, a) || (a = o.currentRange.start);
    for (let h of r.pluginHooks.contextInit)
      h(l);
    let d = Mc(r.calendarOptions, o, l), c = {
      dynamicOptionOverrides: n,
      currentViewType: i,
      currentDate: a,
      dateProfile: o,
      businessHours: this.parseContextBusinessHours(l),
      eventSources: d,
      eventUiBases: {},
      eventStore: re(),
      renderableEventStore: re(),
      dateSelection: null,
      eventSelection: "",
      eventDrag: null,
      eventResize: null,
      selectionConfig: this.buildViewUiProps(l).selectionConfig
    }, g = Object.assign(Object.assign({}, l), c);
    for (let h of r.pluginHooks.reducers)
      Object.assign(c, h(null, null, g));
    Vt(c, l) && this.emitter.trigger("loading", !0), this.state = c, this.updateData(), this.actionRunner.resume();
  }
  resetOptions(e, n) {
    let { props: r } = this;
    n === void 0 ? r.optionOverrides = e : (r.optionOverrides = Object.assign(Object.assign({}, r.optionOverrides || {}), e), this.optionsForRefining.push(...n)), (n === void 0 || n.length) && this.actionRunner.request({
      type: "NOTHING"
    });
  }
  _handleAction(e) {
    let { props: n, state: r, emitter: i } = this, s = xc(r.dynamicOptionOverrides, e), l = this.computeOptionsData(n.optionOverrides, s, n.calendarApi), a = _c(r.currentViewType, e), o = this.computeCurrentViewData(a, l, n.optionOverrides, s);
    n.calendarApi.currentDataManager = this, i.setThisContext(n.calendarApi), i.setOptions(o.options);
    let d = {
      nowManager: this.nowManager,
      dateEnv: l.dateEnv,
      options: l.calendarOptions,
      pluginHooks: l.pluginHooks,
      calendarApi: n.calendarApi,
      dispatch: this.dispatch,
      emitter: i,
      getCurrentData: this.getCurrentData
    }, { currentDate: c, dateProfile: g } = r;
    this.data && this.data.dateProfileGenerator !== o.dateProfileGenerator && (g = o.dateProfileGenerator.build(c)), c = Rc(c, e), g = kc(g, e, c, o.dateProfileGenerator), (e.type === "PREV" || // TODO: move this logic into DateProfileGenerator
    e.type === "NEXT" || // "
    !te(g.currentRange, c)) && (c = g.currentRange.start);
    let h = Ic(r.eventSources, e, g, d), f = Qa(r.eventStore, e, h, g, d), y = cs(h) && !o.options.progressiveEventRendering && r.renderableEventStore || f, { eventUiSingleBase: v, selectionConfig: b } = this.buildViewUiProps(d), A = this.buildEventUiBySource(h), w = this.buildEventUiBases(y.defs, v, A), D = {
      dynamicOptionOverrides: s,
      currentViewType: a,
      currentDate: c,
      dateProfile: g,
      eventSources: h,
      eventStore: f,
      renderableEventStore: y,
      selectionConfig: b,
      eventUiBases: w,
      businessHours: this.parseContextBusinessHours(d),
      dateSelection: zc(r.dateSelection, e),
      eventSelection: Uc(r.eventSelection, e),
      eventDrag: Wc(r.eventDrag, e),
      eventResize: Lc(r.eventResize, e)
    }, F = Object.assign(Object.assign({}, d), D);
    for (let _ of l.pluginHooks.reducers)
      Object.assign(D, _(r, e, F));
    let x = Vt(r, d), P = Vt(D, d);
    !x && P ? i.trigger("loading", !0) : x && !P && i.trigger("loading", !1), this.state = D, n.onAction && n.onAction(e);
  }
  updateData() {
    let { props: e, state: n } = this, r = this.data, i = this.computeOptionsData(e.optionOverrides, n.dynamicOptionOverrides, e.calendarApi), s = this.computeCurrentViewData(n.currentViewType, i, e.optionOverrides, n.dynamicOptionOverrides), l = this.data = Object.assign(Object.assign(Object.assign({ nowManager: this.nowManager, viewTitle: this.buildTitle(n.dateProfile, s.options, i.dateEnv), calendarApi: e.calendarApi, dispatch: this.dispatch, emitter: this.emitter, getCurrentData: this.getCurrentData }, i), s), n), a = i.pluginHooks.optionChangeHandlers, o = r && r.calendarOptions, d = i.calendarOptions;
    if (o && o !== d) {
      o.timeZone !== d.timeZone && (n.eventSources = l.eventSources = Nc(l.eventSources, n.dateProfile, l), n.eventStore = l.eventStore = yr(l.eventStore, r.dateEnv, l.dateEnv), n.renderableEventStore = l.renderableEventStore = yr(l.renderableEventStore, r.dateEnv, l.dateEnv));
      for (let c in a)
        (this.optionsForHandling.indexOf(c) !== -1 || o[c] !== d[c]) && a[c](d[c], l);
    }
    this.optionsForHandling = [], e.onData && e.onData(l);
  }
  computeOptionsData(e, n, r) {
    if (!this.optionsForRefining.length && e === this.stableOptionOverrides && n === this.stableDynamicOptionOverrides)
      return this.stableCalendarOptionsData;
    let { refinedOptions: i, pluginHooks: s, localeDefaults: l, availableLocaleData: a, extra: o } = this.processRawCalendarOptions(e, n);
    kr(o);
    let d = this.buildDateEnv(i.timeZone, i.locale, i.weekNumberCalculation, i.firstDay, i.weekText, s, a, i.defaultRangeSeparator), c = this.buildViewSpecs(s.views, this.stableOptionOverrides, this.stableDynamicOptionOverrides, l), g = this.buildTheme(i, s), h = this.parseToolbars(i, this.stableOptionOverrides, g, c, r);
    return this.stableCalendarOptionsData = {
      calendarOptions: i,
      pluginHooks: s,
      dateEnv: d,
      viewSpecs: c,
      theme: g,
      toolbarConfig: h,
      localeDefaults: l,
      availableRawLocales: a.map
    };
  }
  // always called from behind a memoizer
  processRawCalendarOptions(e, n) {
    let { locales: r, locale: i } = Bt([
      Ue,
      e,
      n
    ]), s = this.organizeRawLocales(r), l = s.map, a = this.buildLocale(i || s.defaultCode, l).options, o = this.buildPluginHooks(e.plugins || [], ad), d = this.currentCalendarOptionsRefiners = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, fr), hr), gr), o.listenerRefiners), o.optionRefiners), c = {}, g = Bt([
      Ue,
      a,
      e,
      n
    ]), h = {}, f = this.currentCalendarOptionsInput, m = this.currentCalendarOptionsRefined, y = !1;
    for (let v in g)
      this.optionsForRefining.indexOf(v) === -1 && (g[v] === f[v] || be[v] && v in f && be[v](f[v], g[v])) ? h[v] = m[v] : d[v] ? (h[v] = d[v](g[v]), y = !0) : c[v] = f[v];
    return y && (this.currentCalendarOptionsInput = g, this.currentCalendarOptionsRefined = h, this.stableOptionOverrides = e, this.stableDynamicOptionOverrides = n), this.optionsForHandling.push(...this.optionsForRefining), this.optionsForRefining = [], {
      rawOptions: this.currentCalendarOptionsInput,
      refinedOptions: this.currentCalendarOptionsRefined,
      pluginHooks: o,
      availableLocaleData: s,
      localeDefaults: a,
      extra: c
    };
  }
  _computeCurrentViewData(e, n, r, i) {
    let s = n.viewSpecs[e];
    if (!s)
      throw new Error(`viewType "${e}" is not available. Please make sure you've loaded all neccessary plugins`);
    let { refinedOptions: l, extra: a } = this.processRawViewOptions(s, n.pluginHooks, n.localeDefaults, r, i);
    kr(a), this.nowManager.handleInput(n.dateEnv, l.now);
    let o = this.buildDateProfileGenerator({
      dateProfileGeneratorClass: s.optionDefaults.dateProfileGeneratorClass,
      nowManager: this.nowManager,
      duration: s.duration,
      durationUnit: s.durationUnit,
      usesMinMaxTime: s.optionDefaults.usesMinMaxTime,
      dateEnv: n.dateEnv,
      calendarApi: this.props.calendarApi,
      slotMinTime: l.slotMinTime,
      slotMaxTime: l.slotMaxTime,
      showNonCurrentDates: l.showNonCurrentDates,
      dayCount: l.dayCount,
      dateAlignment: l.dateAlignment,
      dateIncrement: l.dateIncrement,
      hiddenDays: l.hiddenDays,
      weekends: l.weekends,
      validRangeInput: l.validRange,
      visibleRangeInput: l.visibleRange,
      fixedWeekCount: l.fixedWeekCount
    }), d = this.buildViewApi(e, this.getCurrentData, n.dateEnv);
    return { viewSpec: s, options: l, dateProfileGenerator: o, viewApi: d };
  }
  processRawViewOptions(e, n, r, i, s) {
    let l = Bt([
      Ue,
      e.optionDefaults,
      r,
      i,
      e.optionOverrides,
      s
    ]), a = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, fr), hr), gr), oa), n.listenerRefiners), n.optionRefiners), o = {}, d = this.currentViewOptionsInput, c = this.currentViewOptionsRefined, g = !1, h = {};
    for (let f in l)
      l[f] === d[f] || be[f] && be[f](l[f], d[f]) ? o[f] = c[f] : (l[f] === this.currentCalendarOptionsInput[f] || be[f] && be[f](l[f], this.currentCalendarOptionsInput[f]) ? f in this.currentCalendarOptionsRefined && (o[f] = this.currentCalendarOptionsRefined[f]) : a[f] ? o[f] = a[f](l[f]) : h[f] = l[f], g = !0);
    return g && (this.currentViewOptionsInput = l, this.currentViewOptionsRefined = o), {
      rawOptions: this.currentViewOptionsInput,
      refinedOptions: this.currentViewOptionsRefined,
      extra: h
    };
  }
}
function fd(t, e, n, r, i, s, l, a) {
  let o = as(e || l.defaultCode, l.map);
  return new ba({
    calendarSystem: "gregory",
    timeZone: t,
    namedTimeZoneImpl: s.namedTimeZonedImpl,
    locale: o,
    weekNumberCalculation: n,
    firstDay: r,
    weekText: i,
    cmdFormatter: s.cmdFormatter,
    defaultSeparator: a
  });
}
function hd(t, e) {
  let n = e.themeClasses[t.themeSystem] || pe;
  return new n(t);
}
function gd(t) {
  let e = t.dateProfileGeneratorClass || Ri;
  return new e(t);
}
function pd(t, e, n) {
  return new Gc(t, e, n);
}
function md(t) {
  return Se(t, (e) => e.ui);
}
function vd(t, e, n) {
  let r = { "": e };
  for (let i in t) {
    let s = t[i];
    s.sourceId && n[s.sourceId] && (r[i] = n[s.sourceId]);
  }
  return r;
}
function yd(t) {
  let { options: e } = t;
  return {
    eventUiSingleBase: Dt({
      display: e.eventDisplay,
      editable: e.editable,
      startEditable: e.eventStartEditable,
      durationEditable: e.eventDurationEditable,
      constraint: e.eventConstraint,
      overlap: typeof e.eventOverlap == "boolean" ? e.eventOverlap : void 0,
      allow: e.eventAllow,
      backgroundColor: e.eventBackgroundColor,
      borderColor: e.eventBorderColor,
      textColor: e.eventTextColor,
      color: e.eventColor
      // classNames: options.eventClassNames // render hook will handle this
    }, t),
    selectionConfig: Dt({
      constraint: e.selectConstraint,
      overlap: typeof e.selectOverlap == "boolean" ? e.selectOverlap : void 0,
      allow: e.selectAllow
    }, t)
  };
}
function Vt(t, e) {
  for (let n of e.pluginHooks.isLoadingFuncs)
    if (n(t))
      return !0;
  return !1;
}
function bd(t) {
  return to(t.options.businessHours, t);
}
function kr(t, e) {
  for (let n in t)
    console.warn(`Unknown option '${n}'`);
}
class Ad extends T {
  render() {
    let e = this.props.widgetGroups.map((n) => this.renderWidgetGroup(n));
    return u("div", { className: "fc-toolbar-chunk" }, ...e);
  }
  renderWidgetGroup(e) {
    let { props: n } = this, { theme: r } = this.context, i = [], s = !0;
    for (let l of e) {
      let { buttonName: a, buttonClick: o, buttonText: d, buttonIcon: c, buttonHint: g } = l;
      if (a === "title")
        s = !1, i.push(u("h2", { className: "fc-toolbar-title", id: n.titleId }, n.title));
      else {
        let h = a === n.activeButton, f = !n.isTodayEnabled && a === "today" || !n.isPrevEnabled && a === "prev" || !n.isNextEnabled && a === "next", m = [`fc-${a}-button`, r.getClass("button")];
        h && m.push(r.getClass("buttonActive")), i.push(u("button", { type: "button", title: typeof g == "function" ? g(n.navUnit) : g, disabled: f, "aria-pressed": h, className: m.join(" "), onClick: o }, d || (c ? u("span", { className: c, role: "img" }) : "")));
      }
    }
    if (i.length > 1) {
      let l = s && r.getClass("buttonGroup") || "";
      return u("div", { className: l }, ...i);
    }
    return i[0];
  }
}
class Mr extends T {
  render() {
    let { model: e, extraClassName: n } = this.props, r = !1, i, s, l = e.sectionWidgets, a = l.center;
    return l.left ? (r = !0, i = l.left) : i = l.start, l.right ? (r = !0, s = l.right) : s = l.end, u(
      "div",
      { className: [
        n || "",
        "fc-toolbar",
        r ? "fc-toolbar-ltr" : ""
      ].join(" ") },
      this.renderSection("start", i || []),
      this.renderSection("center", a || []),
      this.renderSection("end", s || [])
    );
  }
  renderSection(e, n) {
    let { props: r } = this;
    return u(Ad, { key: e, widgetGroups: n, title: r.title, navUnit: r.navUnit, activeButton: r.activeButton, isTodayEnabled: r.isTodayEnabled, isPrevEnabled: r.isPrevEnabled, isNextEnabled: r.isNextEnabled, titleId: r.titleId });
  }
}
class Ed extends T {
  constructor() {
    super(...arguments), this.state = {
      availableWidth: null
    }, this.handleEl = (e) => {
      this.el = e, J(this.props.elRef, e), this.updateAvailableWidth();
    }, this.handleResize = () => {
      this.updateAvailableWidth();
    };
  }
  render() {
    let { props: e, state: n } = this, { aspectRatio: r } = e, i = [
      "fc-view-harness",
      r || e.liquid || e.height ? "fc-view-harness-active" : "fc-view-harness-passive"
      // let the view do the height
    ], s = "", l = "";
    return r ? n.availableWidth !== null ? s = n.availableWidth / r : l = `${1 / r * 100}%` : s = e.height || "", u("div", { "aria-labelledby": e.labeledById, ref: this.handleEl, className: i.join(" "), style: { height: s, paddingBottom: l } }, e.children);
  }
  componentDidMount() {
    this.context.addResizeHandler(this.handleResize);
  }
  componentWillUnmount() {
    this.context.removeResizeHandler(this.handleResize);
  }
  updateAvailableWidth() {
    this.el && // needed. but why?
    this.props.aspectRatio && this.setState({ availableWidth: this.el.offsetWidth });
  }
}
class Cd extends ji {
  constructor(e) {
    super(e), this.handleSegClick = (n, r) => {
      let { component: i } = this, { context: s } = i, l = nn(r);
      if (l && // might be the <div> surrounding the more link
      i.isValidSegDownEl(n.target)) {
        let a = X(n.target, ".fc-event-forced-url"), o = a ? a.querySelector("a[href]").href : "";
        s.emitter.trigger("eventClick", {
          el: r,
          event: new Q(i.context, l.eventRange.def, l.eventRange.instance),
          jsEvent: n,
          view: s.viewApi
        }), o && !n.defaultPrevented && (window.location.href = o);
      }
    }, this.destroy = pi(
      e.el,
      "click",
      ".fc-event",
      // on both fg and bg events
      this.handleSegClick
    );
  }
}
class Sd extends ji {
  constructor(e) {
    super(e), this.handleEventElRemove = (n) => {
      n === this.currentSegEl && this.handleSegLeave(null, this.currentSegEl);
    }, this.handleSegEnter = (n, r) => {
      nn(r) && (this.currentSegEl = r, this.triggerEvent("eventMouseEnter", n, r));
    }, this.handleSegLeave = (n, r) => {
      this.currentSegEl && (this.currentSegEl = null, this.triggerEvent("eventMouseLeave", n, r));
    }, this.removeHoverListeners = Al(
      e.el,
      ".fc-event",
      // on both fg and bg events
      this.handleSegEnter,
      this.handleSegLeave
    );
  }
  destroy() {
    this.removeHoverListeners();
  }
  triggerEvent(e, n, r) {
    let { component: i } = this, { context: s } = i, l = nn(r);
    (!n || i.isValidSegDownEl(n.target)) && s.emitter.trigger(e, {
      el: r,
      event: new Q(s, l.eventRange.def, l.eventRange.instance),
      jsEvent: n,
      view: s.viewApi
    });
  }
}
class Dd extends we {
  constructor() {
    super(...arguments), this.buildViewContext = C(Ca), this.buildViewPropTransformers = C(_d), this.buildToolbarProps = C(wd), this.headerRef = L(), this.footerRef = L(), this.interactionsStore = {}, this.state = {
      viewLabelId: de()
    }, this.registerInteractiveComponent = (e, n) => {
      let r = wo(e, n), l = [
        Cd,
        Sd
      ].concat(this.props.pluginHooks.componentInteractions).map((a) => new a(r));
      this.interactionsStore[e.uid] = l, Cr[e.uid] = r;
    }, this.unregisterInteractiveComponent = (e) => {
      let n = this.interactionsStore[e.uid];
      if (n) {
        for (let r of n)
          r.destroy();
        delete this.interactionsStore[e.uid];
      }
      delete Cr[e.uid];
    }, this.resizeRunner = new cn(() => {
      this.props.emitter.trigger("_resize", !0), this.props.emitter.trigger("windowResize", { view: this.props.viewApi });
    }), this.handleWindowResize = (e) => {
      let { options: n } = this.props;
      n.handleWindowResize && e.target === window && this.resizeRunner.request(n.windowResizeDelay);
    };
  }
  /*
  renders INSIDE of an outer div
  */
  render() {
    let { props: e } = this, { toolbarConfig: n, options: r } = e, i = !1, s = "", l;
    e.isHeightAuto || e.forPrint ? s = "" : r.height != null ? i = !0 : r.contentHeight != null ? s = r.contentHeight : l = Math.max(r.aspectRatio, 0.5);
    let a = this.buildViewContext(e.viewSpec, e.viewApi, e.options, e.dateProfileGenerator, e.dateEnv, e.nowManager, e.theme, e.pluginHooks, e.dispatch, e.getCurrentData, e.emitter, e.calendarApi, this.registerInteractiveComponent, this.unregisterInteractiveComponent), o = n.header && n.header.hasTitle ? this.state.viewLabelId : void 0;
    return u(
      ie.Provider,
      { value: a },
      u(_e, { unit: "day" }, (d) => {
        let c = this.buildToolbarProps(e.viewSpec, e.dateProfile, e.dateProfileGenerator, e.currentDate, d, e.viewTitle);
        return u(
          k,
          null,
          n.header && u(Mr, Object.assign({ ref: this.headerRef, extraClassName: "fc-header-toolbar", model: n.header, titleId: o }, c)),
          u(
            Ed,
            { liquid: i, height: s, aspectRatio: l, labeledById: o },
            this.renderView(e),
            this.buildAppendContent()
          ),
          n.footer && u(Mr, Object.assign({ ref: this.footerRef, extraClassName: "fc-footer-toolbar", model: n.footer, titleId: "" }, c))
        );
      })
    );
  }
  componentDidMount() {
    let { props: e } = this;
    this.calendarInteractions = e.pluginHooks.calendarInteractions.map((r) => new r(e)), window.addEventListener("resize", this.handleWindowResize);
    let { propSetHandlers: n } = e.pluginHooks;
    for (let r in n)
      n[r](e[r], e);
  }
  componentDidUpdate(e) {
    let { props: n } = this, { propSetHandlers: r } = n.pluginHooks;
    for (let i in r)
      n[i] !== e[i] && r[i](n[i], n);
  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.handleWindowResize), this.resizeRunner.clear();
    for (let e of this.calendarInteractions)
      e.destroy();
    this.props.emitter.trigger("_unmount");
  }
  buildAppendContent() {
    let { props: e } = this, n = e.pluginHooks.viewContainerAppends.map((r) => r(e));
    return u(k, {}, ...n);
  }
  renderView(e) {
    let { pluginHooks: n } = e, { viewSpec: r } = e, i = {
      dateProfile: e.dateProfile,
      businessHours: e.businessHours,
      eventStore: e.renderableEventStore,
      eventUiBases: e.eventUiBases,
      dateSelection: e.dateSelection,
      eventSelection: e.eventSelection,
      eventDrag: e.eventDrag,
      eventResize: e.eventResize,
      isHeightAuto: e.isHeightAuto,
      forPrint: e.forPrint
    }, s = this.buildViewPropTransformers(n.viewPropsTransformers);
    for (let a of s)
      Object.assign(i, a.transform(i, e));
    let l = r.component;
    return u(l, Object.assign({}, i));
  }
}
function wd(t, e, n, r, i, s) {
  let l = n.build(i, void 0, !1), a = n.buildPrev(e, r, !1), o = n.buildNext(e, r, !1);
  return {
    title: s,
    activeButton: t.type,
    navUnit: t.singleUnit,
    isTodayEnabled: l.isValid && !te(e.currentRange, i),
    isPrevEnabled: a.isValid,
    isNextEnabled: o.isValid
  };
}
function _d(t) {
  return t.map((e) => new e());
}
let Rd = class extends Ro {
  constructor(e, n = {}) {
    super(), this.isRendering = !1, this.isRendered = !1, this.currentClassNames = [], this.customContentRenderId = 0, this.handleAction = (r) => {
      switch (r.type) {
        case "SET_EVENT_DRAG":
        case "SET_EVENT_RESIZE":
          this.renderRunner.tryDrain();
      }
    }, this.handleData = (r) => {
      this.currentData = r, this.renderRunner.request(r.calendarOptions.rerenderDelay);
    }, this.handleRenderRequest = () => {
      if (this.isRendering) {
        this.isRendered = !0;
        let { currentData: r } = this;
        Ct(() => {
          je(u(Do, { options: r.calendarOptions, theme: r.theme, emitter: r.emitter }, (i, s, l, a) => (this.setClassNames(i), this.setHeight(s), u(
            Di.Provider,
            { value: this.customContentRenderId },
            u(Dd, Object.assign({ isHeightAuto: l, forPrint: a }, r))
          ))), this.el);
        });
      } else this.isRendered && (this.isRendered = !1, je(null, this.el), this.setClassNames([]), this.setHeight(""));
    }, ol(e), this.el = e, this.renderRunner = new cn(this.handleRenderRequest), new ud({
      optionOverrides: n,
      calendarApi: this,
      onAction: this.handleAction,
      onData: this.handleData
    });
  }
  render() {
    let e = this.isRendering;
    e ? this.customContentRenderId += 1 : this.isRendering = !0, this.renderRunner.request(), e && this.updateSize();
  }
  destroy() {
    this.isRendering && (this.isRendering = !1, this.renderRunner.request());
  }
  updateSize() {
    Ct(() => {
      super.updateSize();
    });
  }
  batchRendering(e) {
    this.renderRunner.pause("batchRendering"), e(), this.renderRunner.resume("batchRendering");
  }
  pauseRendering() {
    this.renderRunner.pause("pauseRendering");
  }
  resumeRendering() {
    this.renderRunner.resume("pauseRendering", !0);
  }
  resetOptions(e, n) {
    this.currentDataManager.resetOptions(e, n);
  }
  setClassNames(e) {
    if (!ue(e, this.currentClassNames)) {
      let { classList: n } = this.el;
      for (let r of this.currentClassNames)
        n.remove(r);
      for (let r of e)
        n.add(r);
      this.currentClassNames = e;
    }
  }
  setHeight(e) {
    gi(this.el, "height", e);
  }
};
var Td = Gr("<div></div>");
function xd(t, e) {
  Fr(e, !1);
  const n = W();
  let r = N(e, "class", 8, null), i = N(e, "style", 8, null), s = N(e, "options", 8);
  function l() {
    return E(o);
  }
  let a = W(), o = W();
  zr(async () => (d(), () => {
    E(o) && E(o).destroy();
  }));
  function d() {
    z(o, new Rd(E(a), s())), E(o).render();
  }
  function c() {
    E(o).pauseRendering(), E(o).resetOptions(s()), E(o).resumeRendering();
  }
  V(
    () => (M(s()), E(a), E(o)),
    () => {
      z(n, s() && s().plugins && s().plugins.length && E(a) && !E(o));
    }
  ), V(
    () => (E(o), M(s()), E(n)),
    () => {
      E(o) && s() && s().plugins && s().plugins.length && c(), E(n) && d();
    }
  ), Ur();
  var g = { getAPI: l };
  Wr();
  var h = Td();
  return Qt(h, (f) => z(a, f), () => E(a)), Lr(() => {
    Qr(h, 1, Os(r())), Hs(h, i());
  }), jr(t, h), Ns(e, "getAPI", l), Vr(g);
}
class kd extends Z {
  constructor() {
    super(...arguments), this.headerElRef = L();
  }
  renderSimpleLayout(e, n) {
    let { props: r, context: i } = this, s = [], l = wt(i.options);
    return e && s.push({
      type: "header",
      key: "header",
      isSticky: l,
      chunk: {
        elRef: this.headerElRef,
        tableClassName: "fc-col-header",
        rowContent: e
      }
    }), s.push({
      type: "body",
      key: "body",
      liquid: !0,
      chunk: { content: n }
    }), u(
      Ve,
      { elClasses: ["fc-daygrid"], viewSpec: i.viewSpec },
      u(_n, { liquid: !r.isHeightAuto && !r.forPrint, collapsibleWidth: r.forPrint, cols: [], sections: s })
    );
  }
  renderHScrollLayout(e, n, r, i) {
    let s = this.context.pluginHooks.scrollGridImpl;
    if (!s)
      throw new Error("No ScrollGrid implementation");
    let { props: l, context: a } = this, o = !l.forPrint && wt(a.options), d = !l.forPrint && Xi(a.options), c = [];
    return e && c.push({
      type: "header",
      key: "header",
      isSticky: o,
      chunks: [{
        key: "main",
        elRef: this.headerElRef,
        tableClassName: "fc-col-header",
        rowContent: e
      }]
    }), c.push({
      type: "body",
      key: "body",
      liquid: !0,
      chunks: [{
        key: "main",
        content: n
      }]
    }), d && c.push({
      type: "footer",
      key: "footer",
      isSticky: !0,
      chunks: [{
        key: "main",
        content: ln
      }]
    }), u(
      Ve,
      { elClasses: ["fc-daygrid"], viewSpec: a.viewSpec },
      u(s, { liquid: !l.isHeightAuto && !l.forPrint, forPrint: l.forPrint, collapsibleWidth: l.forPrint, colGroups: [{ cols: [{ span: r, minWidth: i }] }], sections: c })
    );
  }
}
function ht(t, e) {
  let n = [];
  for (let r = 0; r < e; r += 1)
    n[r] = [];
  for (let r of t)
    n[r.row].push(r);
  return n;
}
function at(t, e) {
  let n = [];
  for (let r = 0; r < e; r += 1)
    n[r] = [];
  for (let r of t)
    n[r.firstCol].push(r);
  return n;
}
function Ir(t, e) {
  let n = [];
  if (t) {
    for (let r = 0; r < e; r += 1)
      n[r] = {
        affectedInstances: t.affectedInstances,
        isEvent: t.isEvent,
        segs: []
      };
    for (let r of t.segs)
      n[r.row].segs.push(r);
  } else
    for (let r = 0; r < e; r += 1)
      n[r] = null;
  return n;
}
const gs = O({
  hour: "numeric",
  minute: "2-digit",
  omitZeroMinute: !0,
  meridiem: "narrow"
});
function ps(t) {
  let { display: e } = t.eventRange.ui;
  return e === "list-item" || e === "auto" && !t.eventRange.def.allDay && t.firstCol === t.lastCol && // can't be multi-day
  t.isStart && // "
  t.isEnd;
}
class ms extends T {
  render() {
    let { props: e } = this;
    return u(Rn, Object.assign({}, e, { elClasses: ["fc-daygrid-event", "fc-daygrid-block-event", "fc-h-event"], defaultTimeFormat: gs, defaultDisplayEventEnd: e.defaultDisplayEventEnd, disableResizing: !e.seg.eventRange.def.allDay }));
  }
}
class vs extends T {
  render() {
    let { props: e, context: n } = this, { options: r } = n, { seg: i } = e, s = r.eventTimeFormat || gs, l = We(i, s, n, !0, e.defaultDisplayEventEnd);
    return u(xt, Object.assign({}, e, { elTag: "a", elClasses: ["fc-daygrid-event", "fc-daygrid-dot-event"], elAttrs: Sn(e.seg, n), defaultGenerator: Md, timeText: l, isResizing: !1, isDateSelecting: !1 }));
  }
}
function Md(t) {
  return u(
    k,
    null,
    u("div", { className: "fc-daygrid-event-dot", style: { borderColor: t.borderColor || t.backgroundColor } }),
    t.timeText && u("div", { className: "fc-event-time" }, t.timeText),
    u("div", { className: "fc-event-title" }, t.event.title || u(k, null, " "))
  );
}
class Id extends T {
  constructor() {
    super(...arguments), this.compileSegs = C(Nd);
  }
  render() {
    let { props: e } = this, { allSegs: n, invisibleSegs: r } = this.compileSegs(e.singlePlacements);
    return u(rs, { elClasses: ["fc-daygrid-more-link"], dateProfile: e.dateProfile, todayRange: e.todayRange, allDayDate: e.allDayDate, moreCnt: e.moreCnt, allSegs: n, hiddenSegs: r, alignmentElRef: e.alignmentElRef, alignGridTop: e.alignGridTop, extraDateSpan: e.extraDateSpan, popoverContent: () => {
      let i = (e.eventDrag ? e.eventDrag.affectedInstances : null) || (e.eventResize ? e.eventResize.affectedInstances : null) || {};
      return u(k, null, n.map((s) => {
        let l = s.eventRange.instance.instanceId;
        return u("div", { className: "fc-daygrid-event-harness", key: l, style: {
          visibility: i[l] ? "hidden" : ""
        } }, ps(s) ? u(vs, Object.assign({ seg: s, isDragging: !1, isSelected: l === e.eventSelection, defaultDisplayEventEnd: !1 }, ne(s, e.todayRange))) : u(ms, Object.assign({ seg: s, isDragging: !1, isResizing: !1, isDateSelecting: !1, isSelected: l === e.eventSelection, defaultDisplayEventEnd: !1 }, ne(s, e.todayRange))));
      }));
    } });
  }
}
function Nd(t) {
  let e = [], n = [];
  for (let r of t)
    e.push(r.seg), r.isVisible || n.push(r.seg);
  return { allSegs: e, invisibleSegs: n };
}
const Od = O({ week: "narrow" });
class Hd extends Z {
  constructor() {
    super(...arguments), this.rootElRef = L(), this.state = {
      dayNumberId: de()
    }, this.handleRootEl = (e) => {
      J(this.rootElRef, e), J(this.props.elRef, e);
    };
  }
  render() {
    let { context: e, props: n, state: r, rootElRef: i } = this, { options: s, dateEnv: l } = e, { date: a, dateProfile: o } = n;
    const d = n.showDayNumber && Bd(a, o.currentRange, l);
    return u(xn, { elTag: "td", elRef: this.handleRootEl, elClasses: [
      "fc-daygrid-day",
      ...n.extraClassNames || []
    ], elAttrs: Object.assign(Object.assign(Object.assign({}, n.extraDataAttrs), n.showDayNumber ? { "aria-labelledby": r.dayNumberId } : {}), { role: "gridcell" }), defaultGenerator: Pd, date: a, dateProfile: o, todayRange: n.todayRange, showDayNumber: n.showDayNumber, isMonthStart: d, extraRenderProps: n.extraRenderProps }, (c, g) => u(
      "div",
      { ref: n.innerElRef, className: "fc-daygrid-day-frame fc-scrollgrid-sync-inner", style: { minHeight: n.minHeight } },
      n.showWeekNumber && u(ns, { elTag: "a", elClasses: ["fc-daygrid-week-number"], elAttrs: He(e, a, "week"), date: a, defaultFormat: Od }),
      !g.isDisabled && (n.showDayNumber || kn(s) || n.forceDayTop) ? u(
        "div",
        { className: "fc-daygrid-day-top" },
        u(c, { elTag: "a", elClasses: [
          "fc-daygrid-day-number",
          d && "fc-daygrid-month-start"
        ], elAttrs: Object.assign(Object.assign({}, He(e, a)), { id: r.dayNumberId }) })
      ) : n.showDayNumber ? (
        // for creating correct amount of space (see issue #7162)
        u(
          "div",
          { className: "fc-daygrid-day-top", style: { visibility: "hidden" } },
          u("a", { className: "fc-daygrid-day-number" }, " ")
        )
      ) : void 0,
      u(
        "div",
        { className: "fc-daygrid-day-events", ref: n.fgContentElRef },
        n.fgContent,
        u(
          "div",
          { className: "fc-daygrid-day-bottom", style: { marginTop: n.moreMarginTop } },
          u(Id, { allDayDate: a, singlePlacements: n.singlePlacements, moreCnt: n.moreCnt, alignmentElRef: i, alignGridTop: !n.showDayNumber, extraDateSpan: n.extraDateSpan, dateProfile: n.dateProfile, eventSelection: n.eventSelection, eventDrag: n.eventDrag, eventResize: n.eventResize, todayRange: n.todayRange })
        )
      ),
      u("div", { className: "fc-daygrid-day-bg" }, n.bgContent)
    ));
  }
}
function Pd(t) {
  return t.dayNumberText || u(k, null, " ");
}
function Bd(t, e, n) {
  const { start: r, end: i } = e, s = fe(i, -1), l = n.getYear(r), a = n.getMonth(r), o = n.getYear(s), d = n.getMonth(s);
  return !(l === o && a === d) && // first date in current view?
  (t.valueOf() === r.valueOf() || // a month-start that's within the current range?
  n.getDay(t) === 1 && t.valueOf() < i.valueOf());
}
function ys(t) {
  return t.eventRange.instance.instanceId + ":" + t.firstCol;
}
function bs(t) {
  return ys(t) + ":" + t.lastCol;
}
function Fd(t, e, n, r, i, s, l) {
  let a = new Wd((b) => {
    let A = t[b.index].eventRange.instance.instanceId + ":" + b.span.start + ":" + (b.span.end - 1);
    return i[A] || 1;
  });
  a.allowReslicing = !0, a.strictOrder = r, e === !0 || n === !0 ? (a.maxCoord = s, a.hiddenConsumes = !0) : typeof e == "number" ? a.maxStackCnt = e : typeof n == "number" && (a.maxStackCnt = n, a.hiddenConsumes = !0);
  let o = [], d = [];
  for (let b = 0; b < t.length; b += 1) {
    let A = t[b], w = bs(A);
    i[w] != null ? o.push({
      index: b,
      span: {
        start: A.firstCol,
        end: A.lastCol + 1
      }
    }) : d.push(A);
  }
  let c = a.addSegs(o), g = a.toRects(), { singleColPlacements: h, multiColPlacements: f, leftoverMargins: m } = zd(g, t, l), y = [], v = [];
  for (let b of d) {
    f[b.firstCol].push({
      seg: b,
      isVisible: !1,
      isAbsolute: !0,
      absoluteTop: 0,
      marginTop: 0
    });
    for (let A = b.firstCol; A <= b.lastCol; A += 1)
      h[A].push({
        seg: Ie(b, A, A + 1, l),
        isVisible: !1,
        isAbsolute: !1,
        absoluteTop: 0,
        marginTop: 0
      });
  }
  for (let b = 0; b < l.length; b += 1)
    y.push(0);
  for (let b of c) {
    let A = t[b.index], w = b.span;
    f[w.start].push({
      seg: Ie(A, w.start, w.end, l),
      isVisible: !1,
      isAbsolute: !0,
      absoluteTop: 0,
      marginTop: 0
    });
    for (let D = w.start; D < w.end; D += 1)
      y[D] += 1, h[D].push({
        seg: Ie(A, D, D + 1, l),
        isVisible: !1,
        isAbsolute: !1,
        absoluteTop: 0,
        marginTop: 0
      });
  }
  for (let b = 0; b < l.length; b += 1)
    v.push(m[b]);
  return { singleColPlacements: h, multiColPlacements: f, moreCnts: y, moreMarginTops: v };
}
function zd(t, e, n) {
  let r = Ud(t, n.length), i = [], s = [], l = [];
  for (let a = 0; a < n.length; a += 1) {
    let o = r[a], d = [], c = 0, g = 0;
    for (let f of o) {
      let m = e[f.index];
      d.push({
        seg: Ie(m, a, a + 1, n),
        isVisible: !0,
        isAbsolute: !1,
        absoluteTop: f.levelCoord,
        marginTop: f.levelCoord - c
      }), c = f.levelCoord + f.thickness;
    }
    let h = [];
    c = 0, g = 0;
    for (let f of o) {
      let m = e[f.index], y = f.span.end - f.span.start > 1, v = f.span.start === a;
      g += f.levelCoord - c, c = f.levelCoord + f.thickness, y ? (g += f.thickness, v && h.push({
        seg: Ie(m, f.span.start, f.span.end, n),
        isVisible: !0,
        isAbsolute: !0,
        absoluteTop: f.levelCoord,
        marginTop: 0
      })) : v && (h.push({
        seg: Ie(m, f.span.start, f.span.end, n),
        isVisible: !0,
        isAbsolute: !1,
        absoluteTop: f.levelCoord,
        marginTop: g
        // claim the margin
      }), g = 0);
    }
    i.push(d), s.push(h), l.push(g);
  }
  return { singleColPlacements: i, multiColPlacements: s, leftoverMargins: l };
}
function Ud(t, e) {
  let n = [];
  for (let r = 0; r < e; r += 1)
    n.push([]);
  for (let r of t)
    for (let i = r.span.start; i < r.span.end; i += 1)
      n[i].push(r);
  return n;
}
function Ie(t, e, n, r) {
  if (t.firstCol === e && t.lastCol === n - 1)
    return t;
  let i = t.eventRange, s = i.range, l = he(s, {
    start: r[e].date,
    end: B(r[n - 1].date, 1)
  });
  return Object.assign(Object.assign({}, t), { firstCol: e, lastCol: n - 1, eventRange: {
    def: i.def,
    ui: Object.assign(Object.assign({}, i.ui), { durationEditable: !1 }),
    instance: i.instance,
    range: l
  }, isStart: t.isStart && l.start.valueOf() === s.start.valueOf(), isEnd: t.isEnd && l.end.valueOf() === s.end.valueOf() });
}
class Wd extends Vi {
  constructor() {
    super(...arguments), this.hiddenConsumes = !1, this.forceHidden = {};
  }
  addSegs(e) {
    const n = super.addSegs(e), { entriesByLevel: r } = this, i = (s) => !this.forceHidden[Ce(s)];
    for (let s = 0; s < r.length; s += 1)
      r[s] = r[s].filter(i);
    return n;
  }
  handleInvalidInsertion(e, n, r) {
    const { entriesByLevel: i, forceHidden: s } = this, { touchingEntry: l, touchingLevel: a, touchingLateral: o } = e;
    if (this.hiddenConsumes && l) {
      const d = Ce(l);
      if (!s[d])
        if (this.allowReslicing) {
          const c = Object.assign(Object.assign({}, l), { span: wn(l.span, n.span) }), g = Ce(c);
          s[g] = !0, i[a][o] = c, r.push(c), this.splitEntry(l, n, r);
        } else
          s[d] = !0, r.push(l);
    }
    super.handleInvalidInsertion(e, n, r);
  }
}
class As extends Z {
  constructor() {
    super(...arguments), this.cellElRefs = new ee(), this.frameElRefs = new ee(), this.fgElRefs = new ee(), this.segHarnessRefs = new ee(), this.rootElRef = L(), this.state = {
      framePositions: null,
      maxContentHeight: null,
      segHeights: {}
    }, this.handleResize = (e) => {
      e && this.updateSizing(!0);
    };
  }
  render() {
    let { props: e, state: n, context: r } = this, { options: i } = r, s = e.cells.length, l = at(e.businessHourSegs, s), a = at(e.bgEventSegs, s), o = at(this.getHighlightSegs(), s), d = at(this.getMirrorSegs(), s), { singleColPlacements: c, multiColPlacements: g, moreCnts: h, moreMarginTops: f } = Fd(Cn(e.fgEventSegs, i.eventOrder), e.dayMaxEvents, e.dayMaxEventRows, i.eventOrderStrict, n.segHeights, n.maxContentHeight, e.cells), m = (
      // TODO: messy way to compute this
      e.eventDrag && e.eventDrag.affectedInstances || e.eventResize && e.eventResize.affectedInstances || {}
    );
    return u(
      "tr",
      { ref: this.rootElRef, role: "row" },
      e.renderIntro && e.renderIntro(),
      e.cells.map((y, v) => {
        let b = this.renderFgSegs(v, e.forPrint ? c[v] : g[v], e.todayRange, m), A = this.renderFgSegs(v, Ld(d[v], g), e.todayRange, {}, !!e.eventDrag, !!e.eventResize, !1);
        return u(Hd, { key: y.key, elRef: this.cellElRefs.createRef(y.key), innerElRef: this.frameElRefs.createRef(y.key), dateProfile: e.dateProfile, date: y.date, showDayNumber: e.showDayNumbers, showWeekNumber: e.showWeekNumbers && v === 0, forceDayTop: e.showWeekNumbers, todayRange: e.todayRange, eventSelection: e.eventSelection, eventDrag: e.eventDrag, eventResize: e.eventResize, extraRenderProps: y.extraRenderProps, extraDataAttrs: y.extraDataAttrs, extraClassNames: y.extraClassNames, extraDateSpan: y.extraDateSpan, moreCnt: h[v], moreMarginTop: f[v], singlePlacements: c[v], fgContentElRef: this.fgElRefs.createRef(y.key), fgContent: (
          // Fragment scopes the keys
          u(
            k,
            null,
            u(k, null, b),
            u(k, null, A)
          )
        ), bgContent: (
          // Fragment scopes the keys
          u(
            k,
            null,
            this.renderFillSegs(o[v], "highlight"),
            this.renderFillSegs(l[v], "non-business"),
            this.renderFillSegs(a[v], "bg-event")
          )
        ), minHeight: e.cellMinHeight });
      })
    );
  }
  componentDidMount() {
    this.updateSizing(!0), this.context.addResizeHandler(this.handleResize);
  }
  componentDidUpdate(e, n) {
    let r = this.props;
    this.updateSizing(!Y(e, r));
  }
  componentWillUnmount() {
    this.context.removeResizeHandler(this.handleResize);
  }
  getHighlightSegs() {
    let { props: e } = this;
    return e.eventDrag && e.eventDrag.segs.length ? e.eventDrag.segs : e.eventResize && e.eventResize.segs.length ? e.eventResize.segs : e.dateSelectionSegs;
  }
  getMirrorSegs() {
    let { props: e } = this;
    return e.eventResize && e.eventResize.segs.length ? e.eventResize.segs : [];
  }
  renderFgSegs(e, n, r, i, s, l, a) {
    let { context: o } = this, { eventSelection: d } = this.props, { framePositions: c } = this.state, g = this.props.cells.length === 1, h = s || l || a, f = [];
    if (c)
      for (let m of n) {
        let { seg: y } = m, { instanceId: v } = y.eventRange.instance, b = m.isVisible && !i[v], A = m.isAbsolute, w = "", D = "";
        A && (o.isRtl ? (D = 0, w = c.lefts[y.lastCol] - c.lefts[y.firstCol]) : (w = 0, D = c.rights[y.firstCol] - c.rights[y.lastCol])), f.push(u("div", { className: "fc-daygrid-event-harness" + (A ? " fc-daygrid-event-harness-abs" : ""), key: ys(y), ref: h ? null : this.segHarnessRefs.createRef(bs(y)), style: {
          visibility: b ? "" : "hidden",
          marginTop: A ? "" : m.marginTop,
          top: A ? m.absoluteTop : "",
          left: w,
          right: D
        } }, ps(y) ? u(vs, Object.assign({ seg: y, isDragging: s, isSelected: v === d, defaultDisplayEventEnd: g }, ne(y, r))) : u(ms, Object.assign({ seg: y, isDragging: s, isResizing: l, isDateSelecting: a, isSelected: v === d, defaultDisplayEventEnd: g }, ne(y, r)))));
      }
    return f;
  }
  renderFillSegs(e, n) {
    let { isRtl: r } = this.context, { todayRange: i } = this.props, { framePositions: s } = this.state, l = [];
    if (s)
      for (let a of e) {
        let o = r ? {
          right: 0,
          left: s.lefts[a.lastCol] - s.lefts[a.firstCol]
        } : {
          left: 0,
          right: s.rights[a.firstCol] - s.rights[a.lastCol]
        };
        l.push(u("div", { key: zi(a.eventRange), className: "fc-daygrid-bg-harness", style: o }, n === "bg-event" ? u(es, Object.assign({ seg: a }, ne(a, i))) : ts(n)));
      }
    return u(k, {}, ...l);
  }
  updateSizing(e) {
    let { props: n, state: r, frameElRefs: i } = this;
    if (!n.forPrint && n.clientWidth !== null) {
      if (e) {
        let o = n.cells.map((d) => i.currentMap[d.key]);
        if (o.length) {
          let d = this.rootElRef.current, c = new Pe(
            d,
            o,
            !0,
            // isHorizontal
            !1
          );
          (!r.framePositions || !r.framePositions.similarTo(c)) && this.setState({
            framePositions: new Pe(
              d,
              o,
              !0,
              // isHorizontal
              !1
            )
          });
        }
      }
      const s = this.state.segHeights, l = this.querySegHeights(), a = n.dayMaxEvents === !0 || n.dayMaxEventRows === !0;
      this.safeSetState({
        // HACK to prevent oscillations of events being shown/hidden from max-event-rows
        // Essentially, once you compute an element's height, never null-out.
        // TODO: always display all events, as visibility:hidden?
        segHeights: Object.assign(Object.assign({}, s), l),
        maxContentHeight: a ? this.computeMaxContentHeight() : null
      });
    }
  }
  querySegHeights() {
    let e = this.segHarnessRefs.currentMap, n = {};
    for (let r in e) {
      let i = Math.round(e[r].getBoundingClientRect().height);
      n[r] = Math.max(n[r] || 0, i);
    }
    return n;
  }
  computeMaxContentHeight() {
    let e = this.props.cells[0].key, n = this.cellElRefs.currentMap[e], r = this.fgElRefs.currentMap[e];
    return n.getBoundingClientRect().bottom - r.getBoundingClientRect().top;
  }
  getCellEls() {
    let e = this.cellElRefs.currentMap;
    return this.props.cells.map((n) => e[n.key]);
  }
}
As.addStateEquality({
  segHeights: Y
});
function Ld(t, e) {
  if (!t.length)
    return [];
  let n = jd(e);
  return t.map((r) => ({
    seg: r,
    isVisible: !0,
    isAbsolute: !0,
    absoluteTop: n[r.eventRange.instance.instanceId],
    marginTop: 0
  }));
}
function jd(t) {
  let e = {};
  for (let n of t)
    for (let r of n)
      e[r.seg.eventRange.instance.instanceId] = r.absoluteTop;
  return e;
}
class Vd extends Z {
  constructor() {
    super(...arguments), this.splitBusinessHourSegs = C(ht), this.splitBgEventSegs = C(Gd), this.splitFgEventSegs = C(ht), this.splitDateSelectionSegs = C(ht), this.splitEventDrag = C(Ir), this.splitEventResize = C(Ir), this.rowRefs = new ee();
  }
  render() {
    let { props: e, context: n } = this, r = e.cells.length, i = this.splitBusinessHourSegs(e.businessHourSegs, r), s = this.splitBgEventSegs(e.bgEventSegs, r), l = this.splitFgEventSegs(e.fgEventSegs, r), a = this.splitDateSelectionSegs(e.dateSelectionSegs, r), o = this.splitEventDrag(e.eventDrag, r), d = this.splitEventResize(e.eventResize, r), c = r >= 7 && e.clientWidth ? e.clientWidth / n.options.aspectRatio / 6 : null;
    return u(_e, { unit: "day" }, (g, h) => u(k, null, e.cells.map((f, m) => u(As, {
      ref: this.rowRefs.createRef(m),
      key: f.length ? f[0].date.toISOString() : m,
      showDayNumbers: r > 1,
      showWeekNumbers: e.showWeekNumbers,
      todayRange: h,
      dateProfile: e.dateProfile,
      cells: f,
      renderIntro: e.renderRowIntro,
      businessHourSegs: i[m],
      eventSelection: e.eventSelection,
      bgEventSegs: s[m],
      fgEventSegs: l[m],
      dateSelectionSegs: a[m],
      eventDrag: o[m],
      eventResize: d[m],
      dayMaxEvents: e.dayMaxEvents,
      dayMaxEventRows: e.dayMaxEventRows,
      clientWidth: e.clientWidth,
      clientHeight: e.clientHeight,
      cellMinHeight: c,
      forPrint: e.forPrint
    }))));
  }
  componentDidMount() {
    this.registerInteractiveComponent();
  }
  componentDidUpdate() {
    this.registerInteractiveComponent();
  }
  registerInteractiveComponent() {
    if (!this.rootEl) {
      const e = this.rowRefs.currentMap[0].getCellEls()[0], n = e ? e.closest(".fc-daygrid-body") : null;
      n && (this.rootEl = n, this.context.registerInteractiveComponent(this, {
        el: n,
        isHitComboAllowed: this.props.isHitComboAllowed
      }));
    }
  }
  componentWillUnmount() {
    this.rootEl && (this.context.unregisterInteractiveComponent(this), this.rootEl = null);
  }
  // Hit System
  // ----------------------------------------------------------------------------------------------------
  prepareHits() {
    this.rowPositions = new Pe(
      this.rootEl,
      this.rowRefs.collect().map((e) => e.getCellEls()[0]),
      // first cell el in each row. TODO: not optimal
      !1,
      !0
    ), this.colPositions = new Pe(
      this.rootEl,
      this.rowRefs.currentMap[0].getCellEls(),
      // cell els in first row
      !0,
      // horizontal
      !1
    );
  }
  queryHit(e, n) {
    let { colPositions: r, rowPositions: i } = this, s = r.leftToIndex(e), l = i.topToIndex(n);
    if (l != null && s != null) {
      let a = this.props.cells[l][s];
      return {
        dateProfile: this.props.dateProfile,
        dateSpan: Object.assign({ range: this.getCellRange(l, s), allDay: !0 }, a.extraDateSpan),
        dayEl: this.getCellEl(l, s),
        rect: {
          left: r.lefts[s],
          right: r.rights[s],
          top: i.tops[l],
          bottom: i.bottoms[l]
        },
        layer: 0
      };
    }
    return null;
  }
  getCellEl(e, n) {
    return this.rowRefs.currentMap[e].getCellEls()[n];
  }
  getCellRange(e, n) {
    let r = this.props.cells[e][n].date, i = B(r, 1);
    return { start: r, end: i };
  }
}
function Gd(t, e) {
  return ht(t.filter(Qd), e);
}
function Qd(t) {
  return t.eventRange.def.allDay;
}
class qd extends Z {
  constructor() {
    super(...arguments), this.elRef = L(), this.needsScrollReset = !1;
  }
  render() {
    let { props: e } = this, { dayMaxEventRows: n, dayMaxEvents: r, expandRows: i } = e, s = r === !0 || n === !0;
    s && !i && (s = !1, n = null, r = null);
    let l = [
      "fc-daygrid-body",
      s ? "fc-daygrid-body-balanced" : "fc-daygrid-body-unbalanced",
      i ? "" : "fc-daygrid-body-natural"
      // will height of one row depend on the others?
    ];
    return u(
      "div",
      { ref: this.elRef, className: l.join(" "), style: {
        // these props are important to give this wrapper correct dimensions for interactions
        // TODO: if we set it here, can we avoid giving to inner tables?
        width: e.clientWidth,
        minWidth: e.tableMinWidth
      } },
      u(
        "table",
        { role: "presentation", className: "fc-scrollgrid-sync-table", style: {
          width: e.clientWidth,
          minWidth: e.tableMinWidth,
          height: i ? e.clientHeight : ""
        } },
        e.colGroupNode,
        u(
          "tbody",
          { role: "presentation" },
          u(Vd, { dateProfile: e.dateProfile, cells: e.cells, renderRowIntro: e.renderRowIntro, showWeekNumbers: e.showWeekNumbers, clientWidth: e.clientWidth, clientHeight: e.clientHeight, businessHourSegs: e.businessHourSegs, bgEventSegs: e.bgEventSegs, fgEventSegs: e.fgEventSegs, dateSelectionSegs: e.dateSelectionSegs, eventSelection: e.eventSelection, eventDrag: e.eventDrag, eventResize: e.eventResize, dayMaxEvents: r, dayMaxEventRows: n, forPrint: e.forPrint, isHitComboAllowed: e.isHitComboAllowed })
        )
      )
    );
  }
  componentDidMount() {
    this.requestScrollReset();
  }
  componentDidUpdate(e) {
    e.dateProfile !== this.props.dateProfile ? this.requestScrollReset() : this.flushScrollReset();
  }
  requestScrollReset() {
    this.needsScrollReset = !0, this.flushScrollReset();
  }
  flushScrollReset() {
    if (this.needsScrollReset && this.props.clientWidth) {
      const e = Yd(this.elRef.current, this.props.dateProfile);
      if (e) {
        const n = e.closest(".fc-daygrid-body"), r = n.closest(".fc-scroller"), i = e.getBoundingClientRect().top - n.getBoundingClientRect().top;
        r.scrollTop = i ? i + 1 : 0;
      }
      this.needsScrollReset = !1;
    }
  }
}
function Yd(t, e) {
  let n;
  return e.currentRangeUnit.match(/year|month/) && (n = t.querySelector(`[data-date="${Gl(e.currentDate)}-01"]`)), n || (n = t.querySelector(`[data-date="${Qe(e.currentDate)}"]`)), n;
}
class Zd extends $i {
  constructor() {
    super(...arguments), this.forceDayIfListItem = !0;
  }
  sliceRange(e, n) {
    return n.sliceRange(e);
  }
}
class Es extends Z {
  constructor() {
    super(...arguments), this.slicer = new Zd(), this.tableRef = L();
  }
  render() {
    let { props: e, context: n } = this;
    return u(qd, Object.assign({ ref: this.tableRef }, this.slicer.sliceProps(e, e.dateProfile, e.nextDayThreshold, n, e.dayTableModel), { dateProfile: e.dateProfile, cells: e.dayTableModel.cells, colGroupNode: e.colGroupNode, tableMinWidth: e.tableMinWidth, renderRowIntro: e.renderRowIntro, dayMaxEvents: e.dayMaxEvents, dayMaxEventRows: e.dayMaxEventRows, showWeekNumbers: e.showWeekNumbers, expandRows: e.expandRows, headerAlignElRef: e.headerAlignElRef, clientWidth: e.clientWidth, clientHeight: e.clientHeight, forPrint: e.forPrint }));
  }
}
class $d extends kd {
  constructor() {
    super(...arguments), this.buildDayTableModel = C(Jd), this.headerRef = L(), this.tableRef = L();
  }
  render() {
    let { options: e, dateProfileGenerator: n } = this.context, { props: r } = this, i = this.buildDayTableModel(r.dateProfile, n), s = e.dayHeaders && u(qi, { ref: this.headerRef, dateProfile: r.dateProfile, dates: i.headerDates, datesRepDistinctDays: i.rowCnt === 1 }), l = (a) => u(Es, { ref: this.tableRef, dateProfile: r.dateProfile, dayTableModel: i, businessHours: r.businessHours, dateSelection: r.dateSelection, eventStore: r.eventStore, eventUiBases: r.eventUiBases, eventSelection: r.eventSelection, eventDrag: r.eventDrag, eventResize: r.eventResize, nextDayThreshold: e.nextDayThreshold, colGroupNode: a.tableColGroupNode, tableMinWidth: a.tableMinWidth, dayMaxEvents: e.dayMaxEvents, dayMaxEventRows: e.dayMaxEventRows, showWeekNumbers: e.weekNumbers, expandRows: !r.isHeightAuto, headerAlignElRef: this.headerElRef, clientWidth: a.clientWidth, clientHeight: a.clientHeight, forPrint: r.forPrint });
    return e.dayMinWidth ? this.renderHScrollLayout(s, l, i.colCnt, e.dayMinWidth) : this.renderSimpleLayout(s, l);
  }
}
function Jd(t, e) {
  let n = new Yi(t.renderRange, e);
  return new Zi(n, /year|month|week/.test(t.currentRangeUnit));
}
class Kd extends Ri {
  // Computes the date range that will be rendered
  buildRenderRange(e, n, r) {
    let i = super.buildRenderRange(e, n, r), { props: s } = this;
    return Xd({
      currentRange: i,
      snapToWeek: /^(year|month)$/.test(n),
      fixedWeekCount: s.fixedWeekCount,
      dateEnv: s.dateEnv
    });
  }
}
function Xd(t) {
  let { dateEnv: e, currentRange: n } = t, { start: r, end: i } = n, s;
  if (t.snapToWeek && (r = e.startOfWeek(r), s = e.startOfWeek(i), s.valueOf() !== i.valueOf() && (i = ar(s, 1))), t.fixedWeekCount) {
    let l = e.startOfWeek(e.startOfMonth(B(n.end, -1))), a = Math.ceil(
      // could be partial weeks due to hiddenDays
      Ol(l, i)
    );
    i = ar(i, 6 - a);
  }
  return { start: r, end: i };
}
var eu = ':root{--fc-daygrid-event-dot-width:8px}.fc-daygrid-day-events:after,.fc-daygrid-day-events:before,.fc-daygrid-day-frame:after,.fc-daygrid-day-frame:before,.fc-daygrid-event-harness:after,.fc-daygrid-event-harness:before{clear:both;content:"";display:table}.fc .fc-daygrid-body{position:relative;z-index:1}.fc .fc-daygrid-day.fc-day-today{background-color:var(--fc-today-bg-color)}.fc .fc-daygrid-day-frame{min-height:100%;position:relative}.fc .fc-daygrid-day-top{display:flex;flex-direction:row-reverse}.fc .fc-day-other .fc-daygrid-day-top{opacity:.3}.fc .fc-daygrid-day-number{padding:4px;position:relative;z-index:4}.fc .fc-daygrid-month-start{font-size:1.1em;font-weight:700}.fc .fc-daygrid-day-events{margin-top:1px}.fc .fc-daygrid-body-balanced .fc-daygrid-day-events{left:0;position:absolute;right:0}.fc .fc-daygrid-body-unbalanced .fc-daygrid-day-events{min-height:2em;position:relative}.fc .fc-daygrid-body-natural .fc-daygrid-day-events{margin-bottom:1em}.fc .fc-daygrid-event-harness{position:relative}.fc .fc-daygrid-event-harness-abs{left:0;position:absolute;right:0;top:0}.fc .fc-daygrid-bg-harness{bottom:0;position:absolute;top:0}.fc .fc-daygrid-day-bg .fc-non-business{z-index:1}.fc .fc-daygrid-day-bg .fc-bg-event{z-index:2}.fc .fc-daygrid-day-bg .fc-highlight{z-index:3}.fc .fc-daygrid-event{margin-top:1px;z-index:6}.fc .fc-daygrid-event.fc-event-mirror{z-index:7}.fc .fc-daygrid-day-bottom{font-size:.85em;margin:0 2px}.fc .fc-daygrid-day-bottom:after,.fc .fc-daygrid-day-bottom:before{clear:both;content:"";display:table}.fc .fc-daygrid-more-link{border-radius:3px;cursor:pointer;line-height:1;margin-top:1px;max-width:100%;overflow:hidden;padding:2px;position:relative;white-space:nowrap;z-index:4}.fc .fc-daygrid-more-link:hover{background-color:rgba(0,0,0,.1)}.fc .fc-daygrid-week-number{background-color:var(--fc-neutral-bg-color);color:var(--fc-neutral-text-color);min-width:1.5em;padding:2px;position:absolute;text-align:center;top:0;z-index:5}.fc .fc-more-popover .fc-popover-body{min-width:220px;padding:10px}.fc-direction-ltr .fc-daygrid-event.fc-event-start,.fc-direction-rtl .fc-daygrid-event.fc-event-end{margin-left:2px}.fc-direction-ltr .fc-daygrid-event.fc-event-end,.fc-direction-rtl .fc-daygrid-event.fc-event-start{margin-right:2px}.fc-direction-ltr .fc-daygrid-more-link{float:left}.fc-direction-ltr .fc-daygrid-week-number{border-radius:0 0 3px 0;left:0}.fc-direction-rtl .fc-daygrid-more-link{float:right}.fc-direction-rtl .fc-daygrid-week-number{border-radius:0 0 0 3px;right:0}.fc-liquid-hack .fc-daygrid-day-frame{position:static}.fc-daygrid-event{border-radius:3px;font-size:var(--fc-small-font-size);position:relative;white-space:nowrap}.fc-daygrid-block-event .fc-event-time{font-weight:700}.fc-daygrid-block-event .fc-event-time,.fc-daygrid-block-event .fc-event-title{padding:1px}.fc-daygrid-dot-event{align-items:center;display:flex;padding:2px 0}.fc-daygrid-dot-event .fc-event-title{flex-grow:1;flex-shrink:1;font-weight:700;min-width:0;overflow:hidden}.fc-daygrid-dot-event.fc-event-mirror,.fc-daygrid-dot-event:hover{background:rgba(0,0,0,.1)}.fc-daygrid-dot-event.fc-event-selected:before{bottom:-10px;top:-10px}.fc-daygrid-event-dot{border:calc(var(--fc-daygrid-event-dot-width)/2) solid var(--fc-event-border-color);border-radius:calc(var(--fc-daygrid-event-dot-width)/2);box-sizing:content-box;height:0;margin:0 4px;width:0}.fc-direction-ltr .fc-daygrid-event .fc-event-time{margin-right:3px}.fc-direction-rtl .fc-daygrid-event .fc-event-time{margin-left:3px}';
Rt(eu);
var tu = se({
  name: "@fullcalendar/daygrid",
  initialView: "dayGridMonth",
  views: {
    dayGrid: {
      component: $d,
      dateProfileGeneratorClass: Kd
    },
    dayGridDay: {
      type: "dayGrid",
      duration: { days: 1 }
    },
    dayGridWeek: {
      type: "dayGrid",
      duration: { weeks: 1 }
    },
    dayGridMonth: {
      type: "dayGrid",
      duration: { months: 1 },
      fixedWeekCount: !0
    },
    dayGridYear: {
      type: "dayGrid",
      duration: { years: 1 }
    }
  }
});
class nu extends xo {
  getKeyInfo() {
    return {
      allDay: {},
      timed: {}
    };
  }
  getKeysForDateSpan(e) {
    return e.allDay ? ["allDay"] : ["timed"];
  }
  getKeysForEventDef(e) {
    return e.allDay ? co(e) ? ["timed", "allDay"] : ["allDay"] : ["timed"];
  }
}
const ru = O({
  hour: "numeric",
  minute: "2-digit",
  omitZeroMinute: !0,
  meridiem: "short"
});
function Cs(t) {
  let e = [
    "fc-timegrid-slot",
    "fc-timegrid-slot-label",
    t.isLabeled ? "fc-scrollgrid-shrink" : "fc-timegrid-slot-minor"
  ];
  return u(ie.Consumer, null, (n) => {
    if (!t.isLabeled)
      return u("td", { className: e.join(" "), "data-time": t.isoTimeStr });
    let { dateEnv: r, options: i, viewApi: s } = n, l = (
      // TODO: fully pre-parse
      i.slotLabelFormat == null ? ru : Array.isArray(i.slotLabelFormat) ? O(i.slotLabelFormat[0]) : O(i.slotLabelFormat)
    ), a = {
      level: 0,
      time: t.time,
      date: r.toDate(t.date),
      view: s,
      text: r.format(t.date, l)
    };
    return u(U, { elTag: "td", elClasses: e, elAttrs: {
      "data-time": t.isoTimeStr
    }, renderProps: a, generatorName: "slotLabelContent", customGenerator: i.slotLabelContent, defaultGenerator: iu, classNameGenerator: i.slotLabelClassNames, didMount: i.slotLabelDidMount, willUnmount: i.slotLabelWillUnmount }, (o) => u(
      "div",
      { className: "fc-timegrid-slot-label-frame fc-scrollgrid-shrink-frame" },
      u(o, { elTag: "div", elClasses: [
        "fc-timegrid-slot-label-cushion",
        "fc-scrollgrid-shrink-cushion"
      ] })
    ));
  });
}
function iu(t) {
  return t.text;
}
class su extends T {
  render() {
    return this.props.slatMetas.map((e) => u(
      "tr",
      { key: e.key },
      u(Cs, Object.assign({}, e))
    ));
  }
}
const lu = O({ week: "short" }), au = 5;
class ou extends Z {
  constructor() {
    super(...arguments), this.allDaySplitter = new nu(), this.headerElRef = L(), this.rootElRef = L(), this.scrollerElRef = L(), this.state = {
      slatCoords: null
    }, this.handleScrollTopRequest = (e) => {
      let n = this.scrollerElRef.current;
      n && (n.scrollTop = e);
    }, this.renderHeadAxis = (e, n = "") => {
      let { options: r } = this.context, { dateProfile: i } = this.props, s = i.renderRange, a = ge(s.start, s.end) === 1 ? He(this.context, s.start, "week") : {};
      return r.weekNumbers && e === "day" ? u(ns, { elTag: "th", elClasses: [
        "fc-timegrid-axis",
        "fc-scrollgrid-shrink"
      ], elAttrs: {
        "aria-hidden": !0
      }, date: s.start, defaultFormat: lu }, (o) => u(
        "div",
        { className: [
          "fc-timegrid-axis-frame",
          "fc-scrollgrid-shrink-frame",
          "fc-timegrid-axis-frame-liquid"
        ].join(" "), style: { height: n } },
        u(o, { elTag: "a", elClasses: [
          "fc-timegrid-axis-cushion",
          "fc-scrollgrid-shrink-cushion",
          "fc-scrollgrid-sync-inner"
        ], elAttrs: a })
      )) : u(
        "th",
        { "aria-hidden": !0, className: "fc-timegrid-axis" },
        u("div", { className: "fc-timegrid-axis-frame", style: { height: n } })
      );
    }, this.renderTableRowAxis = (e) => {
      let { options: n, viewApi: r } = this.context, i = {
        text: n.allDayText,
        view: r
      };
      return (
        // TODO: make reusable hook. used in list view too
        u(U, { elTag: "td", elClasses: [
          "fc-timegrid-axis",
          "fc-scrollgrid-shrink"
        ], elAttrs: {
          "aria-hidden": !0
        }, renderProps: i, generatorName: "allDayContent", customGenerator: n.allDayContent, defaultGenerator: cu, classNameGenerator: n.allDayClassNames, didMount: n.allDayDidMount, willUnmount: n.allDayWillUnmount }, (s) => u(
          "div",
          { className: [
            "fc-timegrid-axis-frame",
            "fc-scrollgrid-shrink-frame",
            e == null ? " fc-timegrid-axis-frame-liquid" : ""
          ].join(" "), style: { height: e } },
          u(s, { elTag: "span", elClasses: [
            "fc-timegrid-axis-cushion",
            "fc-scrollgrid-shrink-cushion",
            "fc-scrollgrid-sync-inner"
          ] })
        ))
      );
    }, this.handleSlatCoords = (e) => {
      this.setState({ slatCoords: e });
    };
  }
  // rendering
  // ----------------------------------------------------------------------------------------------------
  renderSimpleLayout(e, n, r) {
    let { context: i, props: s } = this, l = [], a = wt(i.options);
    return e && l.push({
      type: "header",
      key: "header",
      isSticky: a,
      chunk: {
        elRef: this.headerElRef,
        tableClassName: "fc-col-header",
        rowContent: e
      }
    }), n && (l.push({
      type: "body",
      key: "all-day",
      chunk: { content: n }
    }), l.push({
      type: "body",
      key: "all-day-divider",
      outerContent: (
        // TODO: rename to cellContent so don't need to define <tr>?
        u(
          "tr",
          { role: "presentation", className: "fc-scrollgrid-section" },
          u("td", { className: "fc-timegrid-divider " + i.theme.getClass("tableCellShaded") })
        )
      )
    })), l.push({
      type: "body",
      key: "body",
      liquid: !0,
      expandRows: !!i.options.expandRows,
      chunk: {
        scrollerElRef: this.scrollerElRef,
        content: r
      }
    }), u(
      Ve,
      { elRef: this.rootElRef, elClasses: ["fc-timegrid"], viewSpec: i.viewSpec },
      u(_n, { liquid: !s.isHeightAuto && !s.forPrint, collapsibleWidth: s.forPrint, cols: [{ width: "shrink" }], sections: l })
    );
  }
  renderHScrollLayout(e, n, r, i, s, l, a) {
    let o = this.context.pluginHooks.scrollGridImpl;
    if (!o)
      throw new Error("No ScrollGrid implementation");
    let { context: d, props: c } = this, g = !c.forPrint && wt(d.options), h = !c.forPrint && Xi(d.options), f = [];
    e && f.push({
      type: "header",
      key: "header",
      isSticky: g,
      syncRowHeights: !0,
      chunks: [
        {
          key: "axis",
          rowContent: (y) => u("tr", { role: "presentation" }, this.renderHeadAxis("day", y.rowSyncHeights[0]))
        },
        {
          key: "cols",
          elRef: this.headerElRef,
          tableClassName: "fc-col-header",
          rowContent: e
        }
      ]
    }), n && (f.push({
      type: "body",
      key: "all-day",
      syncRowHeights: !0,
      chunks: [
        {
          key: "axis",
          rowContent: (y) => u("tr", { role: "presentation" }, this.renderTableRowAxis(y.rowSyncHeights[0]))
        },
        {
          key: "cols",
          content: n
        }
      ]
    }), f.push({
      key: "all-day-divider",
      type: "body",
      outerContent: (
        // TODO: rename to cellContent so don't need to define <tr>?
        u(
          "tr",
          { role: "presentation", className: "fc-scrollgrid-section" },
          u("td", { colSpan: 2, className: "fc-timegrid-divider " + d.theme.getClass("tableCellShaded") })
        )
      )
    }));
    let m = d.options.nowIndicator;
    return f.push({
      type: "body",
      key: "body",
      liquid: !0,
      expandRows: !!d.options.expandRows,
      chunks: [
        {
          key: "axis",
          content: (y) => (
            // TODO: make this now-indicator arrow more DRY with TimeColsContent
            u(
              "div",
              { className: "fc-timegrid-axis-chunk" },
              u(
                "table",
                { "aria-hidden": !0, style: { height: y.expandRows ? y.clientHeight : "" } },
                y.tableColGroupNode,
                u(
                  "tbody",
                  null,
                  u(su, { slatMetas: l })
                )
              ),
              u(
                "div",
                { className: "fc-timegrid-now-indicator-container" },
                u(_e, {
                  unit: m ? "minute" : "day"
                  /* hacky */
                }, (v) => {
                  let b = m && a && a.safeComputeTop(v);
                  return typeof b == "number" ? u(Tn, { elClasses: ["fc-timegrid-now-indicator-arrow"], elStyle: { top: b }, isAxis: !0, date: v }) : null;
                })
              )
            )
          )
        },
        {
          key: "cols",
          scrollerElRef: this.scrollerElRef,
          content: r
        }
      ]
    }), h && f.push({
      key: "footer",
      type: "footer",
      isSticky: !0,
      chunks: [
        {
          key: "axis",
          content: ln
        },
        {
          key: "cols",
          content: ln
        }
      ]
    }), u(
      Ve,
      { elRef: this.rootElRef, elClasses: ["fc-timegrid"], viewSpec: d.viewSpec },
      u(o, { liquid: !c.isHeightAuto && !c.forPrint, forPrint: c.forPrint, collapsibleWidth: !1, colGroups: [
        { width: "shrink", cols: [{ width: "shrink" }] },
        { cols: [{ span: i, minWidth: s }] }
      ], sections: f })
    );
  }
  /* Dimensions
  ------------------------------------------------------------------------------------------------------------------*/
  getAllDayMaxEventProps() {
    let { dayMaxEvents: e, dayMaxEventRows: n } = this.context.options;
    return (e === !0 || n === !0) && (e = void 0, n = au), { dayMaxEvents: e, dayMaxEventRows: n };
  }
}
function cu(t) {
  return t.text;
}
class du {
  constructor(e, n, r) {
    this.positions = e, this.dateProfile = n, this.slotDuration = r;
  }
  safeComputeTop(e) {
    let { dateProfile: n } = this;
    if (te(n.currentRange, e)) {
      let r = I(e), i = e.valueOf() - r.valueOf();
      if (i >= q(n.slotMinTime) && i < q(n.slotMaxTime))
        return this.computeTimeTop(R(i));
    }
    return null;
  }
  // Computes the top coordinate, relative to the bounds of the grid, of the given date.
  // A `startOfDayDate` must be given for avoiding ambiguity over how to treat midnight.
  computeDateTop(e, n) {
    return n || (n = I(e)), this.computeTimeTop(R(e.valueOf() - n.valueOf()));
  }
  // Computes the top coordinate, relative to the bounds of the grid, of the given time (a Duration).
  // This is a makeshify way to compute the time-top. Assumes all slatMetas dates are uniform.
  // Eventually allow computation with arbirary slat dates.
  computeTimeTop(e) {
    let { positions: n, dateProfile: r } = this, i = n.els.length, s = (e.milliseconds - q(r.slotMinTime)) / q(this.slotDuration), l, a;
    return s = Math.max(0, s), s = Math.min(i, s), l = Math.floor(s), l = Math.min(l, i - 1), a = s - l, n.tops[l] + n.getHeight(l) * a;
  }
}
class uu extends T {
  render() {
    let { props: e, context: n } = this, { options: r } = n, { slatElRefs: i } = e;
    return u("tbody", null, e.slatMetas.map((s, l) => {
      let a = {
        time: s.time,
        date: n.dateEnv.toDate(s.date),
        view: n.viewApi
      };
      return u(
        "tr",
        { key: s.key, ref: i.createRef(s.key) },
        e.axis && u(Cs, Object.assign({}, s)),
        u(U, { elTag: "td", elClasses: [
          "fc-timegrid-slot",
          "fc-timegrid-slot-lane",
          !s.isLabeled && "fc-timegrid-slot-minor"
        ], elAttrs: {
          "data-time": s.isoTimeStr
        }, renderProps: a, generatorName: "slotLaneContent", customGenerator: r.slotLaneContent, classNameGenerator: r.slotLaneClassNames, didMount: r.slotLaneDidMount, willUnmount: r.slotLaneWillUnmount })
      );
    }));
  }
}
class fu extends T {
  constructor() {
    super(...arguments), this.rootElRef = L(), this.slatElRefs = new ee();
  }
  render() {
    let { props: e, context: n } = this;
    return u(
      "div",
      { ref: this.rootElRef, className: "fc-timegrid-slots" },
      u(
        "table",
        { "aria-hidden": !0, className: n.theme.getClass("table"), style: {
          minWidth: e.tableMinWidth,
          width: e.clientWidth,
          height: e.minHeight
        } },
        e.tableColGroupNode,
        u(uu, { slatElRefs: this.slatElRefs, axis: e.axis, slatMetas: e.slatMetas })
      )
    );
  }
  componentDidMount() {
    this.updateSizing();
  }
  componentDidUpdate() {
    this.updateSizing();
  }
  componentWillUnmount() {
    this.props.onCoords && this.props.onCoords(null);
  }
  updateSizing() {
    let { context: e, props: n } = this;
    n.onCoords && n.clientWidth !== null && this.rootElRef.current.offsetHeight && n.onCoords(new du(new Pe(this.rootElRef.current, hu(this.slatElRefs.currentMap, n.slatMetas), !1, !0), this.props.dateProfile, e.options.slotDuration));
  }
}
function hu(t, e) {
  return e.map((n) => t[n.key]);
}
function Fe(t, e) {
  let n = [], r;
  for (r = 0; r < e; r += 1)
    n.push([]);
  if (t)
    for (r = 0; r < t.length; r += 1)
      n[t[r].col].push(t[r]);
  return n;
}
function Nr(t, e) {
  let n = [];
  if (t) {
    for (let r = 0; r < e; r += 1)
      n[r] = {
        affectedInstances: t.affectedInstances,
        isEvent: t.isEvent,
        segs: []
      };
    for (let r of t.segs)
      n[r.col].segs.push(r);
  } else
    for (let r = 0; r < e; r += 1)
      n[r] = null;
  return n;
}
class gu extends T {
  render() {
    let { props: e } = this;
    return u(rs, { elClasses: ["fc-timegrid-more-link"], elStyle: {
      top: e.top,
      bottom: e.bottom
    }, allDayDate: null, moreCnt: e.hiddenSegs.length, allSegs: e.hiddenSegs, hiddenSegs: e.hiddenSegs, extraDateSpan: e.extraDateSpan, dateProfile: e.dateProfile, todayRange: e.todayRange, popoverContent: () => Ds(e.hiddenSegs, e), defaultGenerator: pu, forceTimed: !0 }, (n) => u(n, { elTag: "div", elClasses: ["fc-timegrid-more-link-inner", "fc-sticky"] }));
  }
}
function pu(t) {
  return t.shortText;
}
function mu(t, e, n) {
  let r = new Vi();
  e != null && (r.strictOrder = e), n != null && (r.maxStackCnt = n);
  let i = r.addSegs(t), s = Fo(i), l = vu(r);
  return l = Eu(l, 1), { segRects: Cu(l), hiddenGroups: s };
}
function vu(t) {
  const { entriesByLevel: e } = t, n = In((r, i) => r + ":" + i, (r, i) => {
    let s = Au(t, r, i), l = Or(s, n), a = e[r][i];
    return [
      Object.assign(Object.assign({}, a), { nextLevelNodes: l[0] }),
      a.thickness + l[1]
      // the pressure builds
    ];
  });
  return Or(e.length ? { level: 0, lateralStart: 0, lateralEnd: e[0].length } : null, n)[0];
}
function Or(t, e) {
  if (!t)
    return [[], 0];
  let { level: n, lateralStart: r, lateralEnd: i } = t, s = r, l = [];
  for (; s < i; )
    l.push(e(n, s)), s += 1;
  return l.sort(yu), [
    l.map(bu),
    l[0][1]
    // first item's pressure
  ];
}
function yu(t, e) {
  return e[1] - t[1];
}
function bu(t) {
  return t[0];
}
function Au(t, e, n) {
  let { levelCoords: r, entriesByLevel: i } = t, s = i[e][n], l = r[e] + s.thickness, a = r.length, o = e;
  for (; o < a && r[o] < l; o += 1)
    ;
  for (; o < a; o += 1) {
    let d = i[o], c, g = sn(d, s.span.start, rn), h = g[0] + g[1], f = h;
    for (
      ;
      // loop through entries that horizontally intersect
      (c = d[f]) && // but not past the whole seg list
      c.span.start < s.span.end;
    )
      f += 1;
    if (h < f)
      return { level: o, lateralStart: h, lateralEnd: f };
  }
  return null;
}
function Eu(t, e) {
  const n = In((r, i, s) => Ce(r), (r, i, s) => {
    let { nextLevelNodes: l, thickness: a } = r, o = a + s, d = a / o, c, g = [];
    if (!l.length)
      c = e;
    else
      for (let f of l)
        if (c === void 0) {
          let m = n(f, i, o);
          c = m[0], g.push(m[1]);
        } else {
          let m = n(f, c, 0);
          g.push(m[1]);
        }
    let h = (c - i) * d;
    return [c - h, Object.assign(Object.assign({}, r), { thickness: h, nextLevelNodes: g })];
  });
  return t.map((r) => n(r, 0, 0)[1]);
}
function Cu(t) {
  let e = [];
  const n = In((i, s, l) => Ce(i), (i, s, l) => {
    let a = Object.assign(Object.assign({}, i), {
      levelCoord: s,
      stackDepth: l,
      stackForward: 0
    });
    return e.push(a), a.stackForward = r(i.nextLevelNodes, s + i.thickness, l + 1) + 1;
  });
  function r(i, s, l) {
    let a = 0;
    for (let o of i)
      a = Math.max(n(o, s, l), a);
    return a;
  }
  return r(t, 0, 0), e;
}
function In(t, e) {
  const n = {};
  return (...r) => {
    let i = t(...r);
    return i in n ? n[i] : n[i] = e(...r);
  };
}
function Hr(t, e, n = null, r = 0) {
  let i = [];
  if (n)
    for (let s = 0; s < t.length; s += 1) {
      let l = t[s], a = n.computeDateTop(l.start, e), o = Math.max(
        a + (r || 0),
        // :(
        n.computeDateTop(l.end, e)
      );
      i.push({
        start: Math.round(a),
        end: Math.round(o)
        //
      });
    }
  return i;
}
function Su(t, e, n, r) {
  let i = [], s = [];
  for (let d = 0; d < t.length; d += 1) {
    let c = e[d];
    c ? i.push({
      index: d,
      thickness: 1,
      span: c
    }) : s.push(t[d]);
  }
  let { segRects: l, hiddenGroups: a } = mu(i, n, r), o = [];
  for (let d of l)
    o.push({
      seg: t[d.index],
      rect: d
    });
  for (let d of s)
    o.push({ seg: d, rect: null });
  return { segPlacements: o, hiddenGroups: a };
}
const Du = O({
  hour: "numeric",
  minute: "2-digit",
  meridiem: !1
});
class Ss extends T {
  render() {
    return u(Rn, Object.assign({}, this.props, { elClasses: [
      "fc-timegrid-event",
      "fc-v-event",
      this.props.isShort && "fc-timegrid-event-short"
    ], defaultTimeFormat: Du }));
  }
}
class wu extends T {
  constructor() {
    super(...arguments), this.sortEventSegs = C(Cn);
  }
  // TODO: memoize event-placement?
  render() {
    let { props: e, context: n } = this, { options: r } = n, i = r.selectMirror, s = (
      // yuck
      e.eventDrag && e.eventDrag.segs || e.eventResize && e.eventResize.segs || i && e.dateSelectionSegs || []
    ), l = (
      // TODO: messy way to compute this
      e.eventDrag && e.eventDrag.affectedInstances || e.eventResize && e.eventResize.affectedInstances || {}
    ), a = this.sortEventSegs(e.fgEventSegs, r.eventOrder);
    return u(xn, { elTag: "td", elRef: e.elRef, elClasses: [
      "fc-timegrid-col",
      ...e.extraClassNames || []
    ], elAttrs: Object.assign({ role: "gridcell" }, e.extraDataAttrs), date: e.date, dateProfile: e.dateProfile, todayRange: e.todayRange, extraRenderProps: e.extraRenderProps }, (o) => u(
      "div",
      { className: "fc-timegrid-col-frame" },
      u(
        "div",
        { className: "fc-timegrid-col-bg" },
        this.renderFillSegs(e.businessHourSegs, "non-business"),
        this.renderFillSegs(e.bgEventSegs, "bg-event"),
        this.renderFillSegs(e.dateSelectionSegs, "highlight")
      ),
      u("div", { className: "fc-timegrid-col-events" }, this.renderFgSegs(a, l, !1, !1, !1)),
      u("div", { className: "fc-timegrid-col-events" }, this.renderFgSegs(s, {}, !!e.eventDrag, !!e.eventResize, !!i, "mirror")),
      u("div", { className: "fc-timegrid-now-indicator-container" }, this.renderNowIndicator(e.nowIndicatorSegs)),
      kn(r) && u(o, { elTag: "div", elClasses: ["fc-timegrid-col-misc"] })
    ));
  }
  renderFgSegs(e, n, r, i, s, l) {
    let { props: a } = this;
    return a.forPrint ? Ds(e, a) : this.renderPositionedFgSegs(e, n, r, i, s, l);
  }
  renderPositionedFgSegs(e, n, r, i, s, l) {
    let { eventMaxStack: a, eventShortHeight: o, eventOrderStrict: d, eventMinHeight: c } = this.context.options, { date: g, slatCoords: h, eventSelection: f, todayRange: m, nowDate: y } = this.props, v = r || i || s, b = Hr(e, g, h, c), { segPlacements: A, hiddenGroups: w } = Su(e, b, d, a);
    return u(
      k,
      null,
      this.renderHiddenGroups(w, e),
      A.map((D) => {
        let { seg: F, rect: x } = D, P = F.eventRange.instance.instanceId, _ = v || !!(!n[P] && x), K = Gt(x && x.span), Ze = !v && x ? this.computeSegHStyle(x) : { left: 0, right: 0 }, $e = !!x && x.stackForward > 0, Re = !!x && x.span.end - x.span.start < o;
        return u(
          "div",
          { className: "fc-timegrid-event-harness" + ($e ? " fc-timegrid-event-harness-inset" : ""), key: l || P, style: Object.assign(Object.assign({ visibility: _ ? "" : "hidden" }, K), Ze) },
          u(Ss, Object.assign({ seg: F, isDragging: r, isResizing: i, isDateSelecting: s, isSelected: P === f, isShort: Re }, ne(F, m, y)))
        );
      })
    );
  }
  // will already have eventMinHeight applied because segInputs already had it
  renderHiddenGroups(e, n) {
    let { extraDateSpan: r, dateProfile: i, todayRange: s, nowDate: l, eventSelection: a, eventDrag: o, eventResize: d } = this.props;
    return u(k, null, e.map((c) => {
      let g = Gt(c.span), h = _u(c.entries, n);
      return u(gu, { key: bi(is(h)), hiddenSegs: h, top: g.top, bottom: g.bottom, extraDateSpan: r, dateProfile: i, todayRange: s, nowDate: l, eventSelection: a, eventDrag: o, eventResize: d });
    }));
  }
  renderFillSegs(e, n) {
    let { props: r, context: i } = this, l = Hr(e, r.date, r.slatCoords, i.options.eventMinHeight).map((a, o) => {
      let d = e[o];
      return u("div", { key: zi(d.eventRange), className: "fc-timegrid-bg-harness", style: Gt(a) }, n === "bg-event" ? u(es, Object.assign({ seg: d }, ne(d, r.todayRange, r.nowDate))) : ts(n));
    });
    return u(k, null, l);
  }
  renderNowIndicator(e) {
    let { slatCoords: n, date: r } = this.props;
    return n ? e.map((i, s) => u(
      Tn,
      {
        // key doesn't matter. will only ever be one
        key: s,
        elClasses: ["fc-timegrid-now-indicator-line"],
        elStyle: {
          top: n.computeDateTop(i.start, r)
        },
        isAxis: !1,
        date: r
      }
    )) : null;
  }
  computeSegHStyle(e) {
    let { isRtl: n, options: r } = this.context, i = r.slotEventOverlap, s = e.levelCoord, l = e.levelCoord + e.thickness, a, o;
    i && (l = Math.min(1, s + (l - s) * 2)), n ? (a = 1 - l, o = s) : (a = s, o = 1 - l);
    let d = {
      zIndex: e.stackDepth + 1,
      left: a * 100 + "%",
      right: o * 100 + "%"
    };
    return i && !e.stackForward && (d[n ? "marginLeft" : "marginRight"] = 20), d;
  }
}
function Ds(t, { todayRange: e, nowDate: n, eventSelection: r, eventDrag: i, eventResize: s }) {
  let l = (i ? i.affectedInstances : null) || (s ? s.affectedInstances : null) || {};
  return u(k, null, t.map((a) => {
    let o = a.eventRange.instance.instanceId;
    return u(
      "div",
      { key: o, style: { visibility: l[o] ? "hidden" : "" } },
      u(Ss, Object.assign({ seg: a, isDragging: !1, isResizing: !1, isDateSelecting: !1, isSelected: o === r, isShort: !1 }, ne(a, e, n)))
    );
  }));
}
function Gt(t) {
  return t ? {
    top: t.start,
    bottom: -t.end
  } : { top: "", bottom: "" };
}
function _u(t, e) {
  return t.map((n) => e[n.index]);
}
class Ru extends T {
  constructor() {
    super(...arguments), this.splitFgEventSegs = C(Fe), this.splitBgEventSegs = C(Fe), this.splitBusinessHourSegs = C(Fe), this.splitNowIndicatorSegs = C(Fe), this.splitDateSelectionSegs = C(Fe), this.splitEventDrag = C(Nr), this.splitEventResize = C(Nr), this.rootElRef = L(), this.cellElRefs = new ee();
  }
  render() {
    let { props: e, context: n } = this, r = n.options.nowIndicator && e.slatCoords && e.slatCoords.safeComputeTop(e.nowDate), i = e.cells.length, s = this.splitFgEventSegs(e.fgEventSegs, i), l = this.splitBgEventSegs(e.bgEventSegs, i), a = this.splitBusinessHourSegs(e.businessHourSegs, i), o = this.splitNowIndicatorSegs(e.nowIndicatorSegs, i), d = this.splitDateSelectionSegs(e.dateSelectionSegs, i), c = this.splitEventDrag(e.eventDrag, i), g = this.splitEventResize(e.eventResize, i);
    return u(
      "div",
      { className: "fc-timegrid-cols", ref: this.rootElRef },
      u(
        "table",
        { role: "presentation", style: {
          minWidth: e.tableMinWidth,
          width: e.clientWidth
        } },
        e.tableColGroupNode,
        u(
          "tbody",
          { role: "presentation" },
          u(
            "tr",
            { role: "row" },
            e.axis && u(
              "td",
              { "aria-hidden": !0, className: "fc-timegrid-col fc-timegrid-axis" },
              u(
                "div",
                { className: "fc-timegrid-col-frame" },
                u("div", { className: "fc-timegrid-now-indicator-container" }, typeof r == "number" && u(Tn, { elClasses: ["fc-timegrid-now-indicator-arrow"], elStyle: { top: r }, isAxis: !0, date: e.nowDate }))
              )
            ),
            e.cells.map((h, f) => u(wu, { key: h.key, elRef: this.cellElRefs.createRef(h.key), dateProfile: e.dateProfile, date: h.date, nowDate: e.nowDate, todayRange: e.todayRange, extraRenderProps: h.extraRenderProps, extraDataAttrs: h.extraDataAttrs, extraClassNames: h.extraClassNames, extraDateSpan: h.extraDateSpan, fgEventSegs: s[f], bgEventSegs: l[f], businessHourSegs: a[f], nowIndicatorSegs: o[f], dateSelectionSegs: d[f], eventDrag: c[f], eventResize: g[f], slatCoords: e.slatCoords, eventSelection: e.eventSelection, forPrint: e.forPrint }))
          )
        )
      )
    );
  }
  componentDidMount() {
    this.updateCoords();
  }
  componentDidUpdate() {
    this.updateCoords();
  }
  updateCoords() {
    let { props: e } = this;
    e.onColCoords && e.clientWidth !== null && e.onColCoords(new Pe(
      this.rootElRef.current,
      Tu(this.cellElRefs.currentMap, e.cells),
      !0,
      // horizontal
      !1
    ));
  }
}
function Tu(t, e) {
  return e.map((n) => t[n.key]);
}
class xu extends Z {
  constructor() {
    super(...arguments), this.processSlotOptions = C(ku), this.state = {
      slatCoords: null
    }, this.handleRootEl = (e) => {
      e ? this.context.registerInteractiveComponent(this, {
        el: e,
        isHitComboAllowed: this.props.isHitComboAllowed
      }) : this.context.unregisterInteractiveComponent(this);
    }, this.handleScrollRequest = (e) => {
      let { onScrollTopRequest: n } = this.props, { slatCoords: r } = this.state;
      if (n && r) {
        if (e.time) {
          let i = r.computeTimeTop(e.time);
          i = Math.ceil(i), i && (i += 1), n(i);
        }
        return !0;
      }
      return !1;
    }, this.handleColCoords = (e) => {
      this.colCoords = e;
    }, this.handleSlatCoords = (e) => {
      this.setState({ slatCoords: e }), this.props.onSlatCoords && this.props.onSlatCoords(e);
    };
  }
  render() {
    let { props: e, state: n } = this;
    return u(
      "div",
      { className: "fc-timegrid-body", ref: this.handleRootEl, style: {
        // these props are important to give this wrapper correct dimensions for interactions
        // TODO: if we set it here, can we avoid giving to inner tables?
        width: e.clientWidth,
        minWidth: e.tableMinWidth
      } },
      u(fu, { axis: e.axis, dateProfile: e.dateProfile, slatMetas: e.slatMetas, clientWidth: e.clientWidth, minHeight: e.expandRows ? e.clientHeight : "", tableMinWidth: e.tableMinWidth, tableColGroupNode: e.axis ? e.tableColGroupNode : null, onCoords: this.handleSlatCoords }),
      u(Ru, { cells: e.cells, axis: e.axis, dateProfile: e.dateProfile, businessHourSegs: e.businessHourSegs, bgEventSegs: e.bgEventSegs, fgEventSegs: e.fgEventSegs, dateSelectionSegs: e.dateSelectionSegs, eventSelection: e.eventSelection, eventDrag: e.eventDrag, eventResize: e.eventResize, todayRange: e.todayRange, nowDate: e.nowDate, nowIndicatorSegs: e.nowIndicatorSegs, clientWidth: e.clientWidth, tableMinWidth: e.tableMinWidth, tableColGroupNode: e.tableColGroupNode, slatCoords: n.slatCoords, onColCoords: this.handleColCoords, forPrint: e.forPrint })
    );
  }
  componentDidMount() {
    this.scrollResponder = this.context.createScrollResponder(this.handleScrollRequest);
  }
  componentDidUpdate(e) {
    this.scrollResponder.update(e.dateProfile !== this.props.dateProfile);
  }
  componentWillUnmount() {
    this.scrollResponder.detach();
  }
  queryHit(e, n) {
    let { dateEnv: r, options: i } = this.context, { colCoords: s } = this, { dateProfile: l } = this.props, { slatCoords: a } = this.state, { snapDuration: o, snapsPerSlot: d } = this.processSlotOptions(this.props.slotDuration, i.snapDuration), c = s.leftToIndex(e), g = a.positions.topToIndex(n);
    if (c != null && g != null) {
      let h = this.props.cells[c], f = a.positions.tops[g], m = a.positions.getHeight(g), y = (n - f) / m, v = Math.floor(y * d), b = g * d + v, A = this.props.cells[c].date, w = $t(l.slotMinTime, kl(o, b)), D = r.add(A, w), F = r.add(D, o);
      return {
        dateProfile: l,
        dateSpan: Object.assign({ range: { start: D, end: F }, allDay: !1 }, h.extraDateSpan),
        dayEl: s.els[c],
        rect: {
          left: s.lefts[c],
          right: s.rights[c],
          top: f,
          bottom: f + m
        },
        layer: 0
      };
    }
    return null;
  }
}
function ku(t, e) {
  let n = e || t, r = dn(t, n);
  return r === null && (n = t, r = 1), { snapDuration: n, snapsPerSlot: r };
}
class Mu extends $i {
  sliceRange(e, n) {
    let r = [];
    for (let i = 0; i < n.length; i += 1) {
      let s = he(e, n[i]);
      s && r.push({
        start: s.start,
        end: s.end,
        isStart: s.start.valueOf() === e.start.valueOf(),
        isEnd: s.end.valueOf() === e.end.valueOf(),
        col: i
      });
    }
    return r;
  }
}
class Iu extends Z {
  constructor() {
    super(...arguments), this.buildDayRanges = C(Nu), this.slicer = new Mu(), this.timeColsRef = L();
  }
  render() {
    let { props: e, context: n } = this, { dateProfile: r, dayTableModel: i } = e, { nowIndicator: s, nextDayThreshold: l } = n.options, a = this.buildDayRanges(i, r, n.dateEnv);
    return u(_e, { unit: s ? "minute" : "day" }, (o, d) => u(xu, Object.assign({ ref: this.timeColsRef }, this.slicer.sliceProps(e, r, null, n, a), { forPrint: e.forPrint, axis: e.axis, dateProfile: r, slatMetas: e.slatMetas, slotDuration: e.slotDuration, cells: i.cells[0], tableColGroupNode: e.tableColGroupNode, tableMinWidth: e.tableMinWidth, clientWidth: e.clientWidth, clientHeight: e.clientHeight, expandRows: e.expandRows, nowDate: o, nowIndicatorSegs: s && this.slicer.sliceNowDate(o, r, l, n, a), todayRange: d, onScrollTopRequest: e.onScrollTopRequest, onSlatCoords: e.onSlatCoords })));
  }
}
function Nu(t, e, n) {
  let r = [];
  for (let i of t.headerDates)
    r.push({
      start: n.add(i, e.slotMinTime),
      end: n.add(i, e.slotMaxTime)
    });
  return r;
}
const Pr = [
  { hours: 1 },
  { minutes: 30 },
  { minutes: 15 },
  { seconds: 30 },
  { seconds: 15 }
];
function Ou(t, e, n, r, i) {
  let s = /* @__PURE__ */ new Date(0), l = t, a = R(0), o = n || Hu(r), d = [];
  for (; q(l) < q(e); ) {
    let c = i.add(s, l), g = dn(a, o) !== null;
    d.push({
      date: c,
      time: l,
      key: c.toISOString(),
      isoTimeStr: Ql(c),
      isLabeled: g
    }), l = $t(l, r), a = $t(a, r);
  }
  return d;
}
function Hu(t) {
  let e, n, r;
  for (e = Pr.length - 1; e >= 0; e -= 1)
    if (n = R(Pr[e]), r = dn(n, t), r !== null && r > 1)
      return n;
  return t;
}
class Pu extends ou {
  constructor() {
    super(...arguments), this.buildTimeColsModel = C(Bu), this.buildSlatMetas = C(Ou);
  }
  render() {
    let { options: e, dateEnv: n, dateProfileGenerator: r } = this.context, { props: i } = this, { dateProfile: s } = i, l = this.buildTimeColsModel(s, r), a = this.allDaySplitter.splitProps(i), o = this.buildSlatMetas(s.slotMinTime, s.slotMaxTime, e.slotLabelInterval, e.slotDuration, n), { dayMinWidth: d } = e, c = !d, g = d, h = e.dayHeaders && u(qi, { dates: l.headerDates, dateProfile: s, datesRepDistinctDays: !0, renderIntro: c ? this.renderHeadAxis : null }), f = e.allDaySlot !== !1 && ((y) => u(Es, Object.assign({}, a.allDay, { dateProfile: s, dayTableModel: l, nextDayThreshold: e.nextDayThreshold, tableMinWidth: y.tableMinWidth, colGroupNode: y.tableColGroupNode, renderRowIntro: c ? this.renderTableRowAxis : null, showWeekNumbers: !1, expandRows: !1, headerAlignElRef: this.headerElRef, clientWidth: y.clientWidth, clientHeight: y.clientHeight, forPrint: i.forPrint }, this.getAllDayMaxEventProps()))), m = (y) => u(Iu, Object.assign({}, a.timed, { dayTableModel: l, dateProfile: s, axis: c, slotDuration: e.slotDuration, slatMetas: o, forPrint: i.forPrint, tableColGroupNode: y.tableColGroupNode, tableMinWidth: y.tableMinWidth, clientWidth: y.clientWidth, clientHeight: y.clientHeight, onSlatCoords: this.handleSlatCoords, expandRows: y.expandRows, onScrollTopRequest: this.handleScrollTopRequest }));
    return g ? this.renderHScrollLayout(h, f, m, l.colCnt, d, o, this.state.slatCoords) : this.renderSimpleLayout(h, f, m);
  }
}
function Bu(t, e) {
  let n = new Yi(t.renderRange, e);
  return new Zi(n, !1);
}
var Fu = '.fc-v-event{background-color:var(--fc-event-bg-color);border:1px solid var(--fc-event-border-color);display:block}.fc-v-event .fc-event-main{color:var(--fc-event-text-color);height:100%}.fc-v-event .fc-event-main-frame{display:flex;flex-direction:column;height:100%}.fc-v-event .fc-event-time{flex-grow:0;flex-shrink:0;max-height:100%;overflow:hidden}.fc-v-event .fc-event-title-container{flex-grow:1;flex-shrink:1;min-height:0}.fc-v-event .fc-event-title{bottom:0;max-height:100%;overflow:hidden;top:0}.fc-v-event:not(.fc-event-start){border-top-left-radius:0;border-top-right-radius:0;border-top-width:0}.fc-v-event:not(.fc-event-end){border-bottom-left-radius:0;border-bottom-right-radius:0;border-bottom-width:0}.fc-v-event.fc-event-selected:before{left:-10px;right:-10px}.fc-v-event .fc-event-resizer-start{cursor:n-resize}.fc-v-event .fc-event-resizer-end{cursor:s-resize}.fc-v-event:not(.fc-event-selected) .fc-event-resizer{height:var(--fc-event-resizer-thickness);left:0;right:0}.fc-v-event:not(.fc-event-selected) .fc-event-resizer-start{top:calc(var(--fc-event-resizer-thickness)/-2)}.fc-v-event:not(.fc-event-selected) .fc-event-resizer-end{bottom:calc(var(--fc-event-resizer-thickness)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer{left:50%;margin-left:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer-start{top:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc-v-event.fc-event-selected .fc-event-resizer-end{bottom:calc(var(--fc-event-resizer-dot-total-width)/-2)}.fc .fc-timegrid .fc-daygrid-body{z-index:2}.fc .fc-timegrid-divider{padding:0 0 2px}.fc .fc-timegrid-body{min-height:100%;position:relative;z-index:1}.fc .fc-timegrid-axis-chunk{position:relative}.fc .fc-timegrid-axis-chunk>table,.fc .fc-timegrid-slots{position:relative;z-index:1}.fc .fc-timegrid-slot{border-bottom:0;height:1.5em}.fc .fc-timegrid-slot:empty:before{content:"\\00a0"}.fc .fc-timegrid-slot-minor{border-top-style:dotted}.fc .fc-timegrid-slot-label-cushion{display:inline-block;white-space:nowrap}.fc .fc-timegrid-slot-label{vertical-align:middle}.fc .fc-timegrid-axis-cushion,.fc .fc-timegrid-slot-label-cushion{padding:0 4px}.fc .fc-timegrid-axis-frame-liquid{height:100%}.fc .fc-timegrid-axis-frame{align-items:center;display:flex;justify-content:flex-end;overflow:hidden}.fc .fc-timegrid-axis-cushion{flex-shrink:0;max-width:60px}.fc-direction-ltr .fc-timegrid-slot-label-frame{text-align:right}.fc-direction-rtl .fc-timegrid-slot-label-frame{text-align:left}.fc-liquid-hack .fc-timegrid-axis-frame-liquid{bottom:0;height:auto;left:0;position:absolute;right:0;top:0}.fc .fc-timegrid-col.fc-day-today{background-color:var(--fc-today-bg-color)}.fc .fc-timegrid-col-frame{min-height:100%;position:relative}.fc-media-screen.fc-liquid-hack .fc-timegrid-col-frame{bottom:0;height:auto;left:0;position:absolute;right:0;top:0}.fc-media-screen .fc-timegrid-cols{bottom:0;left:0;position:absolute;right:0;top:0}.fc-media-screen .fc-timegrid-cols>table{height:100%}.fc-media-screen .fc-timegrid-col-bg,.fc-media-screen .fc-timegrid-col-events,.fc-media-screen .fc-timegrid-now-indicator-container{left:0;position:absolute;right:0;top:0}.fc .fc-timegrid-col-bg{z-index:2}.fc .fc-timegrid-col-bg .fc-non-business{z-index:1}.fc .fc-timegrid-col-bg .fc-bg-event{z-index:2}.fc .fc-timegrid-col-bg .fc-highlight{z-index:3}.fc .fc-timegrid-bg-harness{left:0;position:absolute;right:0}.fc .fc-timegrid-col-events{z-index:3}.fc .fc-timegrid-now-indicator-container{bottom:0;overflow:hidden}.fc-direction-ltr .fc-timegrid-col-events{margin:0 2.5% 0 2px}.fc-direction-rtl .fc-timegrid-col-events{margin:0 2px 0 2.5%}.fc-timegrid-event-harness{position:absolute}.fc-timegrid-event-harness>.fc-timegrid-event{bottom:0;left:0;position:absolute;right:0;top:0}.fc-timegrid-event-harness-inset .fc-timegrid-event,.fc-timegrid-event.fc-event-mirror,.fc-timegrid-more-link{box-shadow:0 0 0 1px var(--fc-page-bg-color)}.fc-timegrid-event,.fc-timegrid-more-link{border-radius:3px;font-size:var(--fc-small-font-size)}.fc-timegrid-event{margin-bottom:1px}.fc-timegrid-event .fc-event-main{padding:1px 1px 0}.fc-timegrid-event .fc-event-time{font-size:var(--fc-small-font-size);margin-bottom:1px;white-space:nowrap}.fc-timegrid-event-short .fc-event-main-frame{flex-direction:row;overflow:hidden}.fc-timegrid-event-short .fc-event-time:after{content:"\\00a0-\\00a0"}.fc-timegrid-event-short .fc-event-title{font-size:var(--fc-small-font-size)}.fc-timegrid-more-link{background:var(--fc-more-link-bg-color);color:var(--fc-more-link-text-color);cursor:pointer;margin-bottom:1px;position:absolute;z-index:9999}.fc-timegrid-more-link-inner{padding:3px 2px;top:0}.fc-direction-ltr .fc-timegrid-more-link{right:0}.fc-direction-rtl .fc-timegrid-more-link{left:0}.fc .fc-timegrid-now-indicator-arrow,.fc .fc-timegrid-now-indicator-line{pointer-events:none}.fc .fc-timegrid-now-indicator-line{border-color:var(--fc-now-indicator-color);border-style:solid;border-width:1px 0 0;left:0;position:absolute;right:0;z-index:4}.fc .fc-timegrid-now-indicator-arrow{border-color:var(--fc-now-indicator-color);border-style:solid;margin-top:-5px;position:absolute;z-index:4}.fc-direction-ltr .fc-timegrid-now-indicator-arrow{border-bottom-color:transparent;border-top-color:transparent;border-width:5px 0 5px 6px;left:0}.fc-direction-rtl .fc-timegrid-now-indicator-arrow{border-bottom-color:transparent;border-top-color:transparent;border-width:5px 6px 5px 0;right:0}';
Rt(Fu);
const zu = {
  allDaySlot: Boolean
};
var Uu = se({
  name: "@fullcalendar/timegrid",
  initialView: "timeGridWeek",
  optionRefiners: zu,
  views: {
    timeGrid: {
      component: Pu,
      usesMinMaxTime: !0,
      allDaySlot: !0,
      slotDuration: "00:30:00",
      slotEventOverlap: !0
      // a bad name. confused with overlap/constraint system
    },
    timeGridDay: {
      type: "timeGrid",
      duration: { days: 1 }
    },
    timeGridWeek: {
      type: "timeGrid",
      duration: { weeks: 1 }
    }
  }
});
class Wu extends T {
  constructor() {
    super(...arguments), this.state = {
      textId: de()
    };
  }
  render() {
    let { theme: e, dateEnv: n, options: r, viewApi: i } = this.context, { cellId: s, dayDate: l, todayRange: a } = this.props, { textId: o } = this.state, d = Dn(l, a), c = r.listDayFormat ? n.format(l, r.listDayFormat) : "", g = r.listDaySideFormat ? n.format(l, r.listDaySideFormat) : "", h = Object.assign({
      date: n.toDate(l),
      view: i,
      textId: o,
      text: c,
      sideText: g,
      navLinkAttrs: He(this.context, l),
      sideNavLinkAttrs: He(this.context, l, "day", !1)
    }, d);
    return u(U, { elTag: "tr", elClasses: [
      "fc-list-day",
      ...Tt(d, e)
    ], elAttrs: {
      "data-date": Qe(l)
    }, renderProps: h, generatorName: "dayHeaderContent", customGenerator: r.dayHeaderContent, defaultGenerator: Lu, classNameGenerator: r.dayHeaderClassNames, didMount: r.dayHeaderDidMount, willUnmount: r.dayHeaderWillUnmount }, (f) => (
      // TODO: force-hide top border based on :first-child
      u(
        "th",
        { scope: "colgroup", colSpan: 3, id: s, "aria-labelledby": o },
        u(f, { elTag: "div", elClasses: [
          "fc-list-day-cushion",
          e.getClass("tableCellShaded")
        ] })
      )
    ));
  }
}
function Lu(t) {
  return u(
    k,
    null,
    t.text && u("a", Object.assign({ id: t.textId, className: "fc-list-day-text" }, t.navLinkAttrs), t.text),
    t.sideText && /* not keyboard tabbable */
    u("a", Object.assign({ "aria-hidden": !0, className: "fc-list-day-side-text" }, t.sideNavLinkAttrs), t.sideText)
  );
}
const ju = O({
  hour: "numeric",
  minute: "2-digit",
  meridiem: "short"
});
class Vu extends T {
  render() {
    let { props: e, context: n } = this, { options: r } = n, { seg: i, timeHeaderId: s, eventHeaderId: l, dateHeaderId: a } = e, o = r.eventTimeFormat || ju;
    return u(xt, Object.assign({}, e, { elTag: "tr", elClasses: [
      "fc-list-event",
      i.eventRange.def.url && "fc-event-forced-url"
    ], defaultGenerator: () => Gu(i, n), seg: i, timeText: "", disableDragging: !0, disableResizing: !0 }), (d, c) => u(
      k,
      null,
      Qu(i, o, n, s, a),
      u(
        "td",
        { "aria-hidden": !0, className: "fc-list-event-graphic" },
        u("span", { className: "fc-list-event-dot", style: {
          borderColor: c.borderColor || c.backgroundColor
        } })
      ),
      u(d, { elTag: "td", elClasses: ["fc-list-event-title"], elAttrs: { headers: `${l} ${a}` } })
    ));
  }
}
function Gu(t, e) {
  let n = Sn(t, e);
  return u("a", Object.assign({}, n), t.eventRange.def.title);
}
function Qu(t, e, n, r, i) {
  let { options: s } = n;
  if (s.displayEventTime !== !1) {
    let l = t.eventRange.def, a = t.eventRange.instance, o = !1, d;
    if (l.allDay ? o = !0 : Ia(t.eventRange.range) ? t.isStart ? d = We(t, e, n, null, null, a.range.start, t.end) : t.isEnd ? d = We(t, e, n, null, null, t.start, a.range.end) : o = !0 : d = We(t, e, n), o) {
      let c = {
        text: n.options.allDayText,
        view: n.viewApi
      };
      return u(U, { elTag: "td", elClasses: ["fc-list-event-time"], elAttrs: {
        headers: `${r} ${i}`
      }, renderProps: c, generatorName: "allDayContent", customGenerator: s.allDayContent, defaultGenerator: qu, classNameGenerator: s.allDayClassNames, didMount: s.allDayDidMount, willUnmount: s.allDayWillUnmount });
    }
    return u("td", { className: "fc-list-event-time" }, d);
  }
  return null;
}
function qu(t) {
  return t.text;
}
class Yu extends Z {
  constructor() {
    super(...arguments), this.computeDateVars = C($u), this.eventStoreToSegs = C(this._eventStoreToSegs), this.state = {
      timeHeaderId: de(),
      eventHeaderId: de(),
      dateHeaderIdRoot: de()
    }, this.setRootEl = (e) => {
      e ? this.context.registerInteractiveComponent(this, {
        el: e
      }) : this.context.unregisterInteractiveComponent(this);
    };
  }
  render() {
    let { props: e, context: n } = this, { dayDates: r, dayRanges: i } = this.computeDateVars(e.dateProfile), s = this.eventStoreToSegs(e.eventStore, e.eventUiBases, i);
    return u(
      Ve,
      { elRef: this.setRootEl, elClasses: [
        "fc-list",
        n.theme.getClass("table"),
        n.options.stickyHeaderDates !== !1 ? "fc-list-sticky" : ""
      ], viewSpec: n.viewSpec },
      u(Ji, { liquid: !e.isHeightAuto, overflowX: e.isHeightAuto ? "visible" : "hidden", overflowY: e.isHeightAuto ? "visible" : "auto" }, s.length > 0 ? this.renderSegList(s, r) : this.renderEmptyMessage())
    );
  }
  renderEmptyMessage() {
    let { options: e, viewApi: n } = this.context, r = {
      text: e.noEventsText,
      view: n
    };
    return u(U, { elTag: "div", elClasses: ["fc-list-empty"], renderProps: r, generatorName: "noEventsContent", customGenerator: e.noEventsContent, defaultGenerator: Zu, classNameGenerator: e.noEventsClassNames, didMount: e.noEventsDidMount, willUnmount: e.noEventsWillUnmount }, (i) => u(i, { elTag: "div", elClasses: ["fc-list-empty-cushion"] }));
  }
  renderSegList(e, n) {
    let { theme: r, options: i } = this.context, { timeHeaderId: s, eventHeaderId: l, dateHeaderIdRoot: a } = this.state, o = Ju(e);
    return u(_e, { unit: "day" }, (d, c) => {
      let g = [];
      for (let h = 0; h < o.length; h += 1) {
        let f = o[h];
        if (f) {
          let m = Qe(n[h]), y = a + "-" + m;
          g.push(u(Wu, { key: m, cellId: y, dayDate: n[h], todayRange: c })), f = Cn(f, i.eventOrder);
          for (let v of f)
            g.push(u(Vu, Object.assign({ key: m + ":" + v.eventRange.instance.instanceId, seg: v, isDragging: !1, isResizing: !1, isDateSelecting: !1, isSelected: !1, timeHeaderId: s, eventHeaderId: l, dateHeaderId: y }, ne(v, c, d))));
        }
      }
      return u(
        "table",
        { className: "fc-list-table " + r.getClass("table") },
        u(
          "thead",
          null,
          u(
            "tr",
            null,
            u("th", { scope: "col", id: s }, i.timeHint),
            u("th", { scope: "col", "aria-hidden": !0 }),
            u("th", { scope: "col", id: l }, i.eventHint)
          )
        ),
        u("tbody", null, g)
      );
    });
  }
  _eventStoreToSegs(e, n, r) {
    return this.eventRangesToSegs(tn(e, n, this.props.dateProfile.activeRange, this.context.options.nextDayThreshold).fg, r);
  }
  eventRangesToSegs(e, n) {
    let r = [];
    for (let i of e)
      r.push(...this.eventRangeToSegs(i, n));
    return r;
  }
  eventRangeToSegs(e, n) {
    let { dateEnv: r } = this.context, { nextDayThreshold: i } = this.context.options, s = e.range, l = e.def.allDay, a, o, d, c = [];
    for (a = 0; a < n.length; a += 1)
      if (o = he(s, n[a]), o && (d = {
        component: this,
        eventRange: e,
        start: o.start,
        end: o.end,
        isStart: e.isStart && o.start.valueOf() === s.start.valueOf(),
        isEnd: e.isEnd && o.end.valueOf() === s.end.valueOf(),
        dayIndex: a
      }, c.push(d), !d.isEnd && !l && a + 1 < n.length && s.end < r.add(n[a + 1].start, i))) {
        d.end = s.end, d.isEnd = !0;
        break;
      }
    return c;
  }
}
function Zu(t) {
  return t.text;
}
function $u(t) {
  let e = I(t.renderRange.start), n = t.renderRange.end, r = [], i = [];
  for (; e < n; )
    r.push(e), i.push({
      start: e,
      end: B(e, 1)
    }), e = B(e, 1);
  return { dayDates: r, dayRanges: i };
}
function Ju(t) {
  let e = [], n, r;
  for (n = 0; n < t.length; n += 1)
    r = t[n], (e[r.dayIndex] || (e[r.dayIndex] = [])).push(r);
  return e;
}
var Ku = ':root{--fc-list-event-dot-width:10px;--fc-list-event-hover-bg-color:#f5f5f5}.fc-theme-standard .fc-list{border:1px solid var(--fc-border-color)}.fc .fc-list-empty{align-items:center;background-color:var(--fc-neutral-bg-color);display:flex;height:100%;justify-content:center}.fc .fc-list-empty-cushion{margin:5em 0}.fc .fc-list-table{border-style:hidden;width:100%}.fc .fc-list-table tr>*{border-left:0;border-right:0}.fc .fc-list-sticky .fc-list-day>*{background:var(--fc-page-bg-color);position:sticky;top:0}.fc .fc-list-table thead{left:-10000px;position:absolute}.fc .fc-list-table tbody>tr:first-child th{border-top:0}.fc .fc-list-table th{padding:0}.fc .fc-list-day-cushion,.fc .fc-list-table td{padding:8px 14px}.fc .fc-list-day-cushion:after{clear:both;content:"";display:table}.fc-theme-standard .fc-list-day-cushion{background-color:var(--fc-neutral-bg-color)}.fc-direction-ltr .fc-list-day-text,.fc-direction-rtl .fc-list-day-side-text{float:left}.fc-direction-ltr .fc-list-day-side-text,.fc-direction-rtl .fc-list-day-text{float:right}.fc-direction-ltr .fc-list-table .fc-list-event-graphic{padding-right:0}.fc-direction-rtl .fc-list-table .fc-list-event-graphic{padding-left:0}.fc .fc-list-event.fc-event-forced-url{cursor:pointer}.fc .fc-list-event:hover td{background-color:var(--fc-list-event-hover-bg-color)}.fc .fc-list-event-graphic,.fc .fc-list-event-time{white-space:nowrap;width:1px}.fc .fc-list-event-dot{border:calc(var(--fc-list-event-dot-width)/2) solid var(--fc-event-border-color);border-radius:calc(var(--fc-list-event-dot-width)/2);box-sizing:content-box;display:inline-block;height:0;width:0}.fc .fc-list-event-title a{color:inherit;text-decoration:none}.fc .fc-list-event.fc-event-forced-url:hover a{text-decoration:underline}';
Rt(Ku);
const Xu = {
  listDayFormat: Br,
  listDaySideFormat: Br,
  noEventsClassNames: p,
  noEventsContent: p,
  noEventsDidMount: p,
  noEventsWillUnmount: p
  // noEventsText is defined in base options
};
function Br(t) {
  return t === !1 ? null : O(t);
}
var ef = se({
  name: "@fullcalendar/list",
  optionRefiners: Xu,
  views: {
    list: {
      component: Yu,
      buttonTextKey: "list",
      listDayFormat: { month: "long", day: "numeric", year: "numeric" }
      // like "January 1, 2016"
    },
    listDay: {
      type: "list",
      duration: { days: 1 },
      listDayFormat: { weekday: "long" }
      // day-of-week is all we need. full date is probably in headerToolbar
    },
    listWeek: {
      type: "list",
      duration: { weeks: 1 },
      listDayFormat: { weekday: "long" },
      listDaySideFormat: { month: "long", day: "numeric", year: "numeric" }
    },
    listMonth: {
      type: "list",
      duration: { month: 1 },
      listDaySideFormat: { weekday: "long" }
      // day-of-week is nice-to-have
    },
    listYear: {
      type: "list",
      duration: { year: 1 },
      listDaySideFormat: { weekday: "long" }
      // day-of-week is nice-to-have
    }
  }
}), tf = Gr("<div><!></div>");
function sf(t, e) {
  Fr(e, !1);
  const n = () => Ws(_s, "$component", r), [r, i] = Fs(), s = W(), l = W(), a = W(), o = W(), d = W(), c = W(), g = W(), h = W(), f = W();
  let m = N(e, "todayText", 8, "Today"), y = N(e, "dataProvider", 8), v = N(e, "eventStart", 8), b = N(e, "eventEnd", 8), A = N(e, "eventTitle", 8), w = N(e, "onClick", 8), D = N(e, "showButtons", 8), F = N(e, "buttonType", 8, "action"), x = N(e, "monthText", 8, "Month"), P = N(e, "weekText", 8, "Week"), _ = N(e, "dayText", 8, "Day"), K = N(e, "agendaText", 8, "Agenda"), Ze = N(e, "showTitleDate", 8, !0), $e = N(e, "locale", 8, "en-gb"), Re = N(e, "yearTitleFormat", 8), Je = N(e, "monthTitleFormat", 8), Ke = N(e, "dayTitleFormat", 8), Xe = N(e, "weekdayTitleFormat", 8), Nn = N(e, "emptyAgendaText", 8, "No events found"), On = N(e, "openOnDate", 8, "{{ now }}"), le = N(e, "calendarType", 8, "dayGridMonth"), Be = N(e, "showDayNames", 8, !0);
  const { styleable: ws } = Pn("sdk"), _s = Pn("component");
  let Te = W(null), me = W(null), ve = W(null);
  const Rs = () => {
    E(Te)?.getAPI?.()?.updateSize();
  };
  zr(() => (typeof ResizeObserver < "u" && (z(ve, new ResizeObserver(() => Rs())), E(me) && E(ve).observe(E(me))), () => {
    E(ve)?.disconnect(), z(ve, null);
  }));
  function Ts(H) {
    const kt = H.event.title, ks = H.event.start, Ms = H.event.end, Is = H.event.extendedProps?.row_id || H.event.id;
    w()?.({ title: kt, start: ks, end: Ms, row_id: Is });
  }
  V(() => M(le()), () => {
    z(s, le() === "timeGridDay");
  }), V(() => M(F()), () => {
    z(l, F() === "primary" ? "primary" : "action");
  }), V(() => M(w()), () => {
    z(a, typeof w() == "function");
  }), V(() => M(Re()), () => {
    z(o, Re() && Re() !== "hidden" ? { year: Re() } : {});
  }), V(() => M(Je()), () => {
    z(d, Je() && Je() !== "hidden" ? { month: Je() } : {});
  }), V(() => M(Ke()), () => {
    z(c, Ke() && Ke() !== "hidden" ? { day: Ke() } : {});
  }), V(() => M(Xe()), () => {
    z(g, Xe() && Xe() !== "hidden" ? { weekday: Xe() } : {});
  }), V(
    () => (M(y()), M(A()), M(v()), M(b())),
    () => {
      z(h, y()?.rows?.map((H) => ({
        title: H[A()],
        start: H[v()],
        end: H[b()],
        row_id: H._id
      })) ?? []);
    }
  ), V(() => (E(ve), E(me)), () => {
    E(ve) && E(me) && E(ve).observe(E(me));
  }), V(
    () => (M(D()), M(Ze()), M($e()), M(m()), M(x()), M(P()), M(_()), M(K()), M(le()), E(o), E(d), M(Be()), E(c), E(g), M(Nn()), M(On()), E(h)),
    () => {
      z(f, {
        headerToolbar: {
          left: D() ? "dayGridMonth,dayGridWeek,timeGridDay,listWeek" : "",
          center: Ze() ? "title" : "",
          right: D() ? "prevYear,prev,today,next,nextYear" : ""
        },
        footerToolbar: "",
        locale: $e(),
        buttonText: {
          today: m(),
          dayGridMonth: x(),
          dayGridWeek: P(),
          timeGridDay: _(),
          listWeek: K()
        },
        plugins: [tu, Uu, ef],
        initialView: le() || "dayGridMonth",
        views: {
          dayGridMonth: {
            titleFormat: {
              ...E(o),
              ...E(d)
            },
            dayHeaders: Be()
          },
          dayGridWeek: {
            titleFormat: {
              ...E(o),
              ...E(c),
              ...E(d)
            },
            dayHeaderFormat: Be() ? { weekday: "short", day: "numeric", month: "numeric" } : { day: "numeric", month: "numeric" }
          },
          timeGridDay: {
            titleFormat: {
              ...E(o),
              ...E(c),
              ...E(d),
              ...E(g),
              omitCommas: !0
            },
            dayHeaderFormat: Be() ? { weekday: "short", day: "numeric", month: "numeric" } : { day: "numeric", month: "numeric" }
          },
          listWeek: {
            titleFormat: {
              ...E(o),
              ...E(c),
              ...E(d)
            },
            listDayFormat: Be() ? { weekday: "long" } : !1,
            noEventsContent: Nn()
          }
        },
        initialDate: On(),
        events: E(h),
        eventClick: Ts,
        eventTimeFormat: { hour: "numeric", minute: "2-digit", meridiem: "short" },
        height: "100%"
      });
    }
  ), V(() => (E(Te), M(le())), () => {
    if (E(Te) && le()) {
      const H = E(Te).getAPI?.();
      H && H.view.type !== le() && H.changeView(le());
    }
  }), Ur(), Wr();
  var ye = tf();
  let Hn;
  var xs = zs(ye);
  Qt(
    xd(xs, {
      get options() {
        return E(f);
      },
      $$legacy: !0
    }),
    (H) => z(Te, H),
    () => E(Te)
  ), Us(ye), Qt(ye, (H) => z(me, H), () => E(me)), Ps(ye, (H, kt) => ws?.(H, kt), () => n().styles), Lr(
    (H) => {
      Hn = Qr(ye, 1, "calendar svelte-a7w3h2", null, Hn, H), Bs(ye, "data-button-type", E(l));
    },
    [
      () => ({
        timeGridDay: E(s),
        hasClickAction: E(a)
      })
    ]
  ), jr(t, ye), Vr(), i();
}
export {
  sf as default
};
