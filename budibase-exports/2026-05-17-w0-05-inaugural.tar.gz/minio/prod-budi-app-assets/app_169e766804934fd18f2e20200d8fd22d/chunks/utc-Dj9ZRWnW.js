import { aL as M } from "./index-CMyk0zjR.js";
var f = { exports: {} }, Y = f.exports, m;
function H() {
  return m || (m = 1, (function(D, L) {
    (function(n, a) {
      D.exports = a();
    })(Y, (function() {
      var n = "minute", a = /[+-]\d\d(?::?\d\d)?/g, p = /([+-]|\d\d)/g;
      return function(q, $, u) {
        var i = $.prototype;
        u.utc = function(t) {
          var e = { date: t, utc: !0, args: arguments };
          return new $(e);
        }, i.utc = function(t) {
          var e = u(this.toDate(), { locale: this.$L, utc: !0 });
          return t ? e.add(this.utcOffset(), n) : e;
        }, i.local = function() {
          return u(this.toDate(), { locale: this.$L, utc: !1 });
        };
        var T = i.parse;
        i.parse = function(t) {
          t.utc && (this.$u = !0), this.$utils().u(t.$offset) || (this.$offset = t.$offset), T.call(this, t);
        };
        var O = i.init;
        i.init = function() {
          if (this.$u) {
            var t = this.$d;
            this.$y = t.getUTCFullYear(), this.$M = t.getUTCMonth(), this.$D = t.getUTCDate(), this.$W = t.getUTCDay(), this.$H = t.getUTCHours(), this.$m = t.getUTCMinutes(), this.$s = t.getUTCSeconds(), this.$ms = t.getUTCMilliseconds();
          } else O.call(this);
        };
        var U = i.utcOffset;
        i.utcOffset = function(t, e) {
          var o = this.$utils().u;
          if (o(t)) return this.$u ? 0 : o(this.$offset) ? U.call(this) : this.$offset;
          if (typeof t == "string" && (t = (function(c) {
            c === void 0 && (c = "");
            var g = c.match(a);
            if (!g) return null;
            var h = ("" + g[0]).match(p) || ["-", 0, 0], S = h[0], l = 60 * +h[1] + +h[2];
            return l === 0 ? 0 : S === "+" ? l : -l;
          })(t), t === null)) return this;
          var s = Math.abs(t) <= 16 ? 60 * t : t;
          if (s === 0) return this.utc(e);
          var r = this.clone();
          if (e) return r.$offset = s, r.$u = !1, r;
          var d = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
          return (r = this.local().add(s + d, n)).$offset = s, r.$x.$localOffset = d, r;
        };
        var x = i.format;
        i.format = function(t) {
          var e = t || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
          return x.call(this, e);
        }, i.valueOf = function() {
          var t = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
          return this.$d.valueOf() - 6e4 * t;
        }, i.isUTC = function() {
          return !!this.$u;
        }, i.toISOString = function() {
          return this.toDate().toISOString();
        }, i.toString = function() {
          return this.toDate().toUTCString();
        };
        var C = i.toDate;
        i.toDate = function(t) {
          return t === "s" && this.$offset ? u(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : C.call(this);
        };
        var v = i.diff;
        i.diff = function(t, e, o) {
          if (t && this.$u === t.$u) return v.call(this, t, e, o);
          var s = this.local(), r = u(t).local();
          return v.call(s, r, e, o);
        };
      };
    }));
  })(f)), f.exports;
}
var y = H();
const E = /* @__PURE__ */ M(y);
export {
  E as u
};
