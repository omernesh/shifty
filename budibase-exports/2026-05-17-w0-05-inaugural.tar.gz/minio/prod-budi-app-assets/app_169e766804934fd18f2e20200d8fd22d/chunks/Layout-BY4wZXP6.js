import { p as a, c as u, r as d, t as $, b as ie, U as ia, V as ja, d as n, f as S, g as Ee, h as gt, W as ca, m as ze, E as bt, s as T, u as L, X as lt, a as ge, e as Le, Y as Da, w as Oe, I as Ae, Z as va, _ as Xa, $ as xt, B as f, j as e, l as C, i as g, k as De, q as ce, a0 as Ya, a1 as Ka, a2 as we, a3 as Be, a4 as Ne, a5 as Ga, z as b, a6 as jt, a7 as ht, y as nt, a8 as Dt, a9 as Xt, H as Me, A as o, x as de, aa as _t, ab as rt, ac as Qa, ad as da, ae as ua, af as Lt, ag as Yt, ah as Za, ai as Ja, n as Ue, aj as er, ak as tr, al as ar, S as fa, am as Kt, v as mt, T as ga, an as pt, ao as Ge, ap as at, aq as rr, ar as lr, as as ut, at as Gt, au as Qt, av as nr, aw as sr, ax as or, ay as ir, az as cr, aA as Zt, aB as vr, aC as Jt, aD as dr, aE as ur, N as fr, O as gr } from "./index-CMyk0zjR.js";
import { U as hr, h as _r } from "./UserAvatar-Bi38c0Um.js";
import { h as mr } from "./users-DI_wYCOX.js";
function ea(v) {
  return !!v.providerType;
}
var br = S('<div class="error-message svelte-x1z8mp"> </div>');
function xr(v, t) {
  let r = a(t, "error", 8, null);
  var l = br(), h = u(l, !0);
  d(l), $(() => ie(h, r())), ia(3, l, () => ja, () => ({ duration: 130 })), n(v, l);
}
var kr = S('<div class="error-icon svelte-ct7phr"><!></div>'), yr = S('<div><div class="content svelte-ct7phr"><div class="field svelte-ct7phr"><!></div> <!></div> <!></div>');
function Sr(v, t) {
  Ee(t, !1);
  let r = a(t, "disabled", 8, !1), l = a(t, "error", 12, null), h = a(t, "focused", 8, !1), i = a(t, "clickable", 8, !1), P = a(t, "validate", 8), c = a(t, "value", 8), A = a(t, "ref", 28, () => {
  }), ae = a(t, "autoHeight", 24, () => {
  }), N = a(t, "compact", 8, !1);
  const B = gt("fancy-form"), W = Math.random().toString(), _ = {
    validate: () => (P() && l(P()(c())), !l())
  };
  ca(() => (B && B.registerField(W, _), () => {
    B && B.unregisterField(W);
  })), ze();
  var x = yr();
  let M;
  var O = u(x), E = u(O), m = u(E);
  bt(m, t, "default", {}, null), d(E);
  var H = T(E, 2);
  {
    var K = (w) => {
      var I = kr(), he = u(I);
      Ae(he, { name: "warning" }), d(I), n(w, I);
    };
    L(H, (w) => {
      l() && w(K);
    });
  }
  d(O);
  var ee = T(O, 2);
  {
    var k = (w) => {
      xr(w, {
        get error() {
          return l();
        }
      });
    };
    L(ee, (w) => {
      l() && w(k);
    });
  }
  d(x), lt(x, (w) => A(w), () => A()), $((w) => M = ge(x, 1, "fancy-field svelte-ct7phr", null, M, w), [
    () => ({
      error: l(),
      disabled: r(),
      focused: h(),
      clickable: i(),
      compact: N(),
      "auto-height": ae()
    })
  ]), Le("click", O, function(w) {
    Da.call(this, t, w);
  }), n(v, x), Oe();
}
var wr = S("<div><!></div>");
function Lr(v, t) {
  let r = a(t, "placeholder", 8, !0);
  var l = wr();
  let h;
  var i = u(l);
  bt(i, t, "default", {}, null), d(l), $((P) => h = ge(l, 1, "svelte-m3thcp", null, h, P), [() => ({ placeholder: r() })]), n(v, l);
}
var pr = S('<div class="fancy-form svelte-7xsnp"><!></div>');
function Pr(v, t) {
  Ee(t, !1);
  let r = {};
  va("fancy-form", {
    registerField: (c, A) => {
      r = { ...r, [c]: A };
    },
    unregisterField: (c) => {
      delete r[c], r = r;
    }
  });
  const l = () => {
    let c = !0;
    return Object.values(r).forEach((A) => {
      A.validate() || (c = !1);
    }), c;
  };
  var h = { validate: l };
  ze();
  var i = pr(), P = u(i);
  return bt(P, t, "default", {}, null), d(i), n(v, i), Xa(t, "validate", l), Oe(h);
}
var Tr = S('<div class="suffix svelte-w1fx0n"> </div>'), Cr = S("<!> <input/> <!>", 1);
function ta(v, t) {
  Ee(t, !1);
  const r = b();
  let l = a(t, "label", 8), h = a(t, "value", 12), i = a(t, "type", 8, "text"), P = a(t, "disabled", 8, !1), c = a(t, "error", 12, null), A = a(t, "validate", 8, null), ae = a(t, "suffix", 8, null), N = a(t, "validateOn", 8, "change");
  const B = xt();
  let W = b(), _ = b(!1), x = b(!1);
  const M = (E) => {
    const m = E.target.value;
    B("change", m), h(m), A() && (c() || N() === "change") && c(A()(m));
  }, O = (E) => {
    f(_, !1);
    const m = E.target.value;
    B("blur", m), A() && N() === "blur" && c(A()(m));
  };
  ca(() => {
    const E = setInterval(
      () => {
        f(x, e(W)?.matches(":-webkit-autofill")), e(x) && clearInterval(E);
      },
      100
    ), m = setTimeout(
      () => {
        clearInterval(E);
      },
      2e3
    );
    return () => {
      clearInterval(E), clearTimeout(m);
    };
  }), C(
    () => (e(x), e(_), g(h())),
    () => {
      f(r, !e(x) && !e(_) && !h());
    }
  ), De(), ze(), Sr(v, {
    get error() {
      return c();
    },
    get value() {
      return h();
    },
    get validate() {
      return A();
    },
    get disabled() {
      return P();
    },
    get focused() {
      return e(_);
    },
    children: (E, m) => {
      var H = Cr(), K = ce(H);
      {
        var ee = (re) => {
          Lr(re, {
            get placeholder() {
              return e(r);
            },
            children: (_e, me) => {
              Be();
              var Pe = Ne();
              $(() => ie(Pe, l())), n(_e, Pe);
            },
            $$slots: { default: !0 }
          });
        };
        L(K, (re) => {
          l() && re(ee);
        });
      }
      var k = T(K, 2);
      Ya(k);
      let w;
      lt(k, (re) => f(W, re), () => e(W));
      var I = T(k, 2);
      {
        var he = (re) => {
          var _e = Tr(), me = u(_e, !0);
          d(_e), $(() => ie(me, ae())), ia(1, _e, () => Ga, () => ({ duration: 130 })), n(re, _e);
        };
        L(I, (re) => {
          ae() && !e(r) && re(he);
        });
      }
      $(
        (re) => {
          k.disabled = P(), Ka(k, h() || ""), we(k, "type", i() || "text"), w = ge(k, 1, "svelte-w1fx0n", null, w, re);
        },
        [() => ({ placeholder: e(r) })]
      ), Le("input", k, M), Le("focus", k, () => f(_, !0)), Le("blur", k, O), n(E, H);
    },
    $$slots: { default: !0 }
  }), Oe();
}
function aa(v) {
  return v != null && v !== "" || "This field is required";
}
function ra(v, ...t) {
  let r = !1;
  const l = ht(""), h = jt(l, () => r || (r = !0, !1)), i = jt(
    [l, h],
    ([P, c]) => c && $r(P, t)
  );
  return [l, i, h];
}
function $r(v, t) {
  const r = t.find((l) => l(v) !== !0);
  return r && r(v);
}
var Ar = S("<!> <!>", 1);
function Nr(v, t) {
  Ee(t, !1);
  const r = () => de(O, "$firstPassword", c), l = () => de(m, "$firstTouched", c), h = () => de(E, "$passwordError", c), i = () => de(ee, "$repeatTouched", c), P = () => de(H, "$repeatPassword", c), [c, A] = nt(), ae = b();
  let N = a(t, "passwordForm", 28, () => {
  }), B = a(t, "password", 12), W = a(t, "error", 12), _ = a(t, "minLength", 8, "12"), x = a(t, "labels", 24, () => ({}));
  const M = (k) => !k || k.length < parseInt(_()) ? x()?.minLengthText?.replace("{minLength}", _()) || `Please enter at least ${_()} characters. We recommend using machine generated or random passwords.` : null, [O, E, m] = ra("", aa), [H, K, ee] = ra("", aa, M);
  C(() => r(), () => {
    B(r());
  }), C(
    () => (l(), h(), i(), g(B())),
    () => {
      f(ae, l() && h() || i() && M(B()));
    }
  ), C(
    () => (r(), l(), i(), P(), e(ae)),
    () => {
      W(!r() || !l() || !i() || r() !== P() || e(ae));
    }
  ), De(), ze(), lt(
    Pr(v, {
      children: (k, w) => {
        var I = Ar(), he = ce(I);
        {
          let _e = Me(() => (g(x()), o(() => x()?.passwordLabel ?? "Password")));
          ta(he, {
            get label() {
              return e(_e);
            },
            type: "password",
            get error() {
              return e(ae);
            },
            get value() {
              return Xt(), r();
            },
            set value(me) {
              Dt(O, me);
            },
            $$legacy: !0
          });
        }
        var re = T(he, 2);
        {
          let _e = Me(() => (g(x()), o(() => x()?.repeatLabel ?? "Repeat password"))), me = Me(() => (i(), r(), P(), g(x()), o(() => i() && r() !== P() && (x()?.mismatchText ?? "Passwords must match"))));
          ta(re, {
            get label() {
              return e(_e);
            },
            type: "password",
            get error() {
              return e(me);
            },
            get value() {
              return Xt(), P();
            },
            set value(Pe) {
              Dt(H, Pe);
            },
            $$legacy: !0
          });
        }
        n(k, I);
      },
      $$slots: { default: !0 },
      $$legacy: !0
    }),
    (k) => N(k),
    () => N()
  ), Oe(), A();
}
var Br = S("<!> <!>", 1);
function Ur(v, t) {
  Ee(t, !1);
  const r = b();
  let l = a(t, "API", 8), h = a(t, "passwordMinLength", 24, () => {
  }), i = a(t, "notifySuccess", 24, () => _t.success), P = a(t, "notifyError", 24, () => _t.error);
  const c = rt("passwordModal");
  let A = a(t, "labels", 24, () => ({}));
  const ae = xt();
  let N = b(""), B = b("");
  const W = async () => {
    try {
      await l().updateSelf({ password: e(N) }), i()(e(r).successText), ae("save");
    } catch {
      P()(e(r).errorText);
    }
  }, _ = (x) => {
    x.key === "Enter" && !e(B) && e(N) && W();
  };
  C(() => g(A()), () => {
    f(r, { ...c, ...A() });
  }), De(), ze(), Le("keydown", Qa, _);
  {
    let x = Me(() => !!e(B) || !e(N));
    da(v, {
      get title() {
        return e(r), o(() => e(r).title);
      },
      get confirmText() {
        return e(r), o(() => e(r).saveText);
      },
      get cancelText() {
        return e(r), o(() => e(r).cancelText);
      },
      onConfirm: W,
      get disabled() {
        return e(x);
      },
      children: (M, O) => {
        var E = Br(), m = ce(E);
        ua(m, {
          size: "S",
          children: (K, ee) => {
            Be();
            var k = Ne();
            $(() => ie(k, (e(r), o(() => e(r).body)))), n(K, k);
          },
          $$slots: { default: !0 }
        });
        var H = T(m, 2);
        Nr(H, {
          get minLength() {
            return h();
          },
          get labels() {
            return e(r);
          },
          get password() {
            return e(N);
          },
          set password(K) {
            f(N, K);
          },
          get error() {
            return e(B);
          },
          set error(K) {
            f(B, K);
          },
          $$legacy: !0
        }), n(M, E);
      },
      $$slots: { default: !0 }
    });
  }
  Oe();
}
var qr = S("<!> <!> <!> <!>", 1);
function Mr(v, t) {
  Ee(t, !1);
  const r = () => de(_, "$values", l), [l, h] = nt(), i = b();
  let P = a(t, "user", 24, () => {
  }), c = a(t, "API", 8), A = a(t, "notifySuccess", 24, () => _t.success), ae = a(t, "notifyError", 24, () => _t.error);
  const N = rt("profileModal");
  let B = a(t, "labels", 24, () => ({}));
  const W = xt(), _ = ht({ firstName: P()?.firstName, lastName: P()?.lastName }), x = async () => {
    try {
      await c().updateSelf(r()), A()(e(i).successText), W("save");
    } catch (M) {
      console.error(M), ae()(e(i).errorText);
    }
  };
  C(() => g(B()), () => {
    f(i, { ...N, ...B() });
  }), De(), ze(), da(v, {
    get title() {
      return e(i), o(() => e(i).title);
    },
    get confirmText() {
      return e(i), o(() => e(i).saveText);
    },
    get cancelText() {
      return e(i), o(() => e(i).cancelText);
    },
    onConfirm: x,
    children: (M, O) => {
      var E = qr(), m = ce(E);
      ua(m, {
        size: "S",
        children: (k, w) => {
          Be();
          var I = Ne();
          $(() => ie(I, (e(i), o(() => e(i).body)))), n(k, I);
        },
        $$slots: { default: !0 }
      });
      var H = T(m, 2);
      {
        let k = Me(() => (g(P()), o(() => P()?.email || "")));
        Lt(H, {
          disabled: !0,
          get value() {
            return e(k);
          },
          get label() {
            return e(i), o(() => e(i).emailLabel);
          }
        });
      }
      var K = T(H, 2);
      Lt(K, {
        get label() {
          return e(i), o(() => e(i).firstNameLabel);
        },
        get value() {
          return r().firstName;
        },
        set value(k) {
          Yt(_, o(r).firstName = k, o(r));
        },
        $$legacy: !0
      });
      var ee = T(K, 2);
      Lt(ee, {
        get label() {
          return e(i), o(() => e(i).lastNameLabel);
        },
        get value() {
          return r().lastName;
        },
        set value(k) {
          Yt(_, o(r).lastName = k, o(r));
        },
        $$legacy: !0
      }), n(M, E);
    },
    $$slots: { default: !0 }
  }), Oe(), h();
}
const ft = [];
let ha;
function _a(v) {
  const t = v.pattern.test(ha);
  la(v, v.className, t), la(v, v.inactiveClassName, !t);
}
function la(v, t, r) {
  (t || "").split(" ").forEach((l) => {
    l && (v.node.classList.remove(l), r && v.node.classList.add(l));
  });
}
Za.subscribe((v) => {
  ha = v.location + (v.querystring ? "?" + v.querystring : ""), ft.map(_a);
});
function na(v, t) {
  if (t && (typeof t == "string" || typeof t == "object" && t instanceof RegExp) ? t = {
    path: t
  } : t = t || {}, !t.path && v.hasAttribute("href") && (t.path = v.getAttribute("href"), t.path && t.path.length > 1 && t.path.charAt(0) == "#" && (t.path = t.path.substring(1))), t.className || (t.className = "active"), !t.path || typeof t.path == "string" && (t.path.length < 1 || t.path.charAt(0) != "/" && t.path.charAt(0) != "*"))
    throw Error('Invalid value for "path" argument');
  const { pattern: r } = typeof t.path == "string" ? Ja(t.path) : { pattern: t.path }, l = {
    node: v,
    className: t.className,
    inactiveClassName: t.inactiveClassName,
    pattern: r
  };
  return ft.push(l), _a(l), {
    // When the element is destroyed, remove it from the list
    destroy() {
      ft.splice(ft.indexOf(l), 1);
    }
  };
}
var Er = S('<span class="nav-item-letter svelte-e981re"><!></span>'), zr = S("<!> ", 1), Or = S("<a><!></a>"), Ir = S('<span class="nav-item-letter svelte-e981re"><!></span>'), Fr = S("<!> ", 1), Wr = S("<a><!></a>"), Rr = S('<div class="link"><!></div>'), Hr = S('<span class="nav-item-letter svelte-e981re"> </span>'), Vr = S('<!> <span class="svelte-e981re"> </span> <!>', 1), jr = S("<a> </a>"), Dr = S('<a class="svelte-e981re"> </a>'), Xr = S('<div><div><!></div> <div class="sublinks-wrapper svelte-e981re"><div class="sublinks svelte-e981re"></div></div></div>');
function Yr(v, t) {
  Ee(t, !1);
  const r = () => de(er, "$builderStore", i), l = () => de(tr, "$screenStore", i), h = () => de(w(), "$navStateStore", i), [i, P] = nt(), c = b(), A = b(), ae = b(), N = b(), B = b(), W = b(), _ = b();
  let x = a(t, "type", 8), M = a(t, "url", 8), O = a(t, "text", 8), E = a(t, "subLinks", 8), m = a(t, "icon", 8), H = a(t, "internalLink", 8), K = a(t, "customStyles", 8), ee = a(t, "leftNav", 8, !1), k = a(t, "mobile", 8, !1), w = a(t, "navStateStore", 8), I = a(t, "collapsed", 8, !1);
  const he = xt();
  let re = b();
  const _e = (le) => {
    if (!le)
      return "";
    const pe = le.trim().split(/\s+/);
    return pe.length === 1 ? pe[0].charAt(0).toUpperCase() : pe.slice(0, 2).map((qe) => qe.charAt(0).toUpperCase()).join("");
  }, me = () => {
    he("clickLink"), f(re, Math.random());
  }, Pe = () => {
    e(B) && w().update((le) => ({ ...le, [O()]: !le[O()] }));
  };
  C(() => (r(), l()), () => {
    f(c, (le) => r().inBuilder && le && le === l().activeScreen?.routing?.route);
  }), C(() => (e(c), g(M())), () => {
    f(A, e(c)(M()));
  }), C(() => (g(E()), e(c)), () => {
    f(ae, (E() || []).some((le) => e(c)(le.url)));
  }), C(
    () => (h(), g(O()), e(ae)),
    () => {
      f(N, !!h()[O()] || e(ae));
    }
  ), C(() => (g(ee()), g(k())), () => {
    f(B, ee() || k());
  }), C(() => (e(B), e(N)), () => {
    f(W, !e(B) || e(N) ? "caret-down" : "caret-right");
  }), C(() => g(O()), () => {
    f(_, _e(O()));
  }), De(), ze();
  var Xe = Ue(), Qe = ce(Xe);
  {
    var Re = (le) => {
      var pe = Rr(), qe = u(pe);
      {
        var oe = (ke) => {
          var V = Or();
          let ue;
          var ne = u(V);
          {
            var be = (U) => {
              pt(U, {
                get text() {
                  return O();
                },
                get position() {
                  return g(Ge), o(() => Ge.Right);
                },
                children: (j, Y) => {
                  var p = Er(), se = u(p);
                  {
                    var Q = (X) => {
                      Ae(X, {
                        get name() {
                          return m();
                        },
                        color: "var(--navTextColor)",
                        size: "XS"
                      });
                    }, D = (X) => {
                      var R = Ne();
                      $(() => ie(R, e(_))), n(X, R);
                    };
                    L(se, (X) => {
                      m() ? X(Q) : X(D, !1);
                    });
                  }
                  d(p), n(j, p);
                },
                $$slots: { default: !0 }
              });
            }, Ce = (U) => {
              var j = zr(), Y = ce(j);
              {
                var p = (Q) => {
                  Ae(Q, {
                    get name() {
                      return m();
                    },
                    color: "var(--navTextColor)",
                    size: "S"
                  });
                };
                L(Y, (Q) => {
                  m() && Q(p);
                });
              }
              var se = T(Y);
              $(() => ie(se, ` ${O() ?? ""}`)), n(U, j);
            };
            L(ne, (U) => {
              I() ? U(be) : U(Ce, !1);
            });
          }
          d(V), Kt(() => Le("click", V, me)), mt(V, (U, j) => na?.(U, j), M), $(
            (U) => {
              we(V, "href", `#${M() ?? ""}`), at(V, K()), ue = ge(V, 1, "svelte-e981re", null, ue, U);
            },
            [
              () => ({ builderActive: e(A), collapsed: I() })
            ]
          ), n(ke, V);
        }, te = (ke) => {
          var V = Wr();
          let ue;
          var ne = u(V);
          {
            var be = (U) => {
              pt(U, {
                get text() {
                  return O();
                },
                get position() {
                  return g(Ge), o(() => Ge.Right);
                },
                children: (j, Y) => {
                  var p = Ir(), se = u(p);
                  {
                    var Q = (X) => {
                      Ae(X, {
                        get name() {
                          return m();
                        },
                        color: "var(--navTextColor)",
                        size: "L"
                      });
                    }, D = (X) => {
                      var R = Ne();
                      $(() => ie(R, e(_))), n(X, R);
                    };
                    L(se, (X) => {
                      m() ? X(Q) : X(D, !1);
                    });
                  }
                  d(p), n(j, p);
                },
                $$slots: { default: !0 }
              });
            }, Ce = (U) => {
              var j = Fr(), Y = ce(j);
              {
                var p = (Q) => {
                  Ae(Q, {
                    get name() {
                      return m();
                    },
                    color: "var(--navTextColor)",
                    size: "S"
                  });
                };
                L(Y, (Q) => {
                  m() && Q(p);
                });
              }
              var se = T(Y);
              $(() => ie(se, ` ${O() ?? ""}`)), n(U, j);
            };
            L(ne, (U) => {
              I() ? U(be) : U(Ce, !1);
            });
          }
          d(V), $(
            (U) => {
              we(V, "href", M()), ue = ge(V, 1, "svelte-e981re", null, ue, U);
            },
            [() => ({ collapsed: I() })]
          ), Le("click", V, me), n(ke, V);
        };
        L(qe, (ke) => {
          H() ? ke(oe) : ke(te, !1);
        });
      }
      d(pe), n(le, pe);
    }, He = (le) => {
      var pe = Ue(), qe = ce(pe);
      ar(qe, () => e(re), (oe) => {
        var te = Xr();
        let ke;
        var V = u(te);
        let ue;
        var ne = u(V);
        {
          var be = (Y) => {
            pt(Y, {
              get text() {
                return O();
              },
              get position() {
                return g(Ge), o(() => Ge.Right);
              },
              children: (p, se) => {
                var Q = Ue(), D = ce(Q);
                {
                  var X = (q) => {
                    Ae(q, {
                      get name() {
                        return m();
                      },
                      color: "var(--navTextColor)",
                      size: "S"
                    });
                  }, R = (q) => {
                    var z = Hr(), Ie = u(z, !0);
                    d(z), $(() => ie(Ie, e(_))), n(q, z);
                  };
                  L(D, (q) => {
                    m() ? q(X) : q(R, !1);
                  });
                }
                n(p, Q);
              },
              $$slots: { default: !0 }
            });
          }, Ce = (Y) => {
            var p = Vr(), se = ce(p);
            {
              var Q = (q) => {
                Ae(q, {
                  get name() {
                    return m();
                  },
                  color: "var(--navTextColor)",
                  size: "S"
                });
              };
              L(se, (q) => {
                m() && q(Q);
              });
            }
            var D = T(se, 2), X = u(D, !0);
            d(D);
            var R = T(D, 2);
            Ae(R, {
              get name() {
                return e(W);
              },
              color: "var(--navTextColor)",
              size: "S"
            }), $(() => ie(X, O())), n(Y, p);
          };
          L(ne, (Y) => {
            I() ? Y(be) : Y(Ce, !1);
          });
        }
        d(V);
        var U = T(V, 2), j = u(U);
        fa(j, 5, () => E() || [], ga, (Y, p) => {
          var se = Ue(), Q = ce(se);
          {
            var D = (R) => {
              var q = jr();
              let z;
              var Ie = u(q, !0);
              d(q), Kt(() => Le("click", q, me)), mt(q, (Ve, st) => na?.(Ve, st), () => e(p).url), $(
                (Ve) => {
                  we(q, "href", `#${e(p), o(() => e(p).url) ?? ""}`), z = ge(q, 1, "sublink svelte-e981re", null, z, Ve), ie(Ie, (e(p), o(() => e(p).text)));
                },
                [
                  () => ({
                    active: !1,
                    builderActive: e(c)(e(p).url)
                  })
                ]
              ), n(R, q);
            }, X = (R) => {
              var q = Dr(), z = u(q, !0);
              d(q), $(() => {
                we(q, "href", (e(p), o(() => e(p).url))), ie(z, (e(p), o(() => e(p).text)));
              }), Le("click", q, me), n(R, q);
            };
            L(Q, (R) => {
              e(p), o(() => e(p).internalLink) ? R(D) : R(X, !1);
            });
          }
          n(Y, se);
        }), d(j), d(U), d(te), $(
          (Y, p) => {
            ke = ge(te, 1, "dropdown svelte-e981re", null, ke, Y), ue = ge(V, 1, "text svelte-e981re", null, ue, p);
          },
          [
            () => ({ left: e(B), expanded: e(N) }),
            () => ({ collapsed: I() })
          ]
        ), Le("click", V, Pe), n(oe, te);
      }), n(le, pe);
    };
    L(Qe, (le) => {
      !x() || x() === "link" ? le(Re) : le(He, !1);
    });
  }
  n(v, Xe), Oe(), P();
}
var Kr = S("<!> <!> <!> <!>", 1), Gr = S('<div class="text svelte-ynrlno"><div class="name svelte-ynrlno"> </div></div>'), Qr = S("<!> <!>", 1), Zr = S('<div class="container svelte-ynrlno"><!> <!></div>'), Jr = S("<!> <!> <!>", 1), el = S('<div class="text svelte-ynrlno"><div class="name svelte-ynrlno">Log in</div></div>'), tl = S('<button class="container login-button svelte-ynrlno"><!> <!></button>');
function sa(v, t) {
  Ee(t, !1);
  const r = () => de(ee, "$authStore", i), l = () => de(k, "$environmentStore", i), h = () => de(I, "$appStore", i), [i, P] = nt(), c = b(), A = b(), ae = b(), N = b(), B = b(), W = b(), _ = b(), x = b(), M = b(), O = b();
  let E = a(t, "compact", 8, !1), m = a(t, "collapsed", 8, !1), H = a(t, "showLoginButton", 8, !0), K = a(t, "isPublicPreview", 8, !1);
  const { authStore: ee, environmentStore: k, notificationStore: w, appStore: I } = gt("sdk");
  let he = b(), re = b();
  const {
    accountPortalAccountUrl: _e,
    builderWorkspacesUrl: me,
    builderAppsUrl: Pe
  } = _r, Xe = (oe) => {
    if (!oe)
      return "";
    if (oe.firstName) {
      let te = oe.firstName;
      return oe.lastName && (te += ` ${oe.lastName}`), te;
    } else
      return oe.email;
  }, Qe = () => {
    const oe = l().accountPortalUrl, te = e(A) ? me(oe) : Pe(oe);
    window.location.href = te;
  }, Re = () => {
    nr();
  };
  C(() => r(), () => {
    f(c, Xe(r()));
  }), C(() => r(), () => {
    f(A, mr(r()));
  }), C(() => (r(), ea), () => {
    f(ae, r() != null && ea(r()));
  }), C(() => (r(), l()), () => {
    f(N, r()?.accountPortalAccess && l().cloud);
  }), C(() => h(), () => {
    f(B, h().embedded || h().inIframe);
  }), C(() => h(), () => {
    f(W, rr(h().application?.translationOverrides));
  }), C(() => e(W), () => {
    f(_, rt("userMenu", e(W)));
  }), C(() => e(W), () => {
    f(x, rt("profileModal", e(W)));
  }), C(() => e(W), () => {
    f(M, rt("passwordModal", e(W)));
  }), C(() => r(), () => {
    f(O, r());
  }), De(), ze();
  var He = Ue(), le = ce(He);
  {
    var pe = (oe) => {
      var te = Jr(), ke = ce(te);
      {
        let ne = Me(() => E() ? "right" : "left");
        lr(ke, {
          get align() {
            return e(ne);
          },
          children: (be, Ce) => {
            var U = Kr(), j = ce(U);
            ut(j, {
              icon: "user-gear",
              $$events: { click: () => e(he)?.show() },
              children: (D, X) => {
                Be();
                var R = Ne();
                $(() => ie(R, (e(_), o(() => e(_).profile)))), n(D, R);
              },
              $$slots: { default: !0 }
            });
            var Y = T(j, 2);
            {
              var p = (D) => {
                ut(D, {
                  icon: "lock",
                  $$events: {
                    click: () => {
                      e(N) ? window.location.href = _e(l().accountPortalUrl) : e(re)?.show();
                    }
                  },
                  children: (X, R) => {
                    Be();
                    var q = Ne();
                    $(() => ie(q, (e(_), o(() => e(_).password)))), n(X, q);
                  },
                  $$slots: { default: !0 }
                });
              };
              L(Y, (D) => {
                e(ae) || D(p);
              });
            }
            var se = T(Y, 2);
            ut(se, {
              icon: "squares-four",
              get disabled() {
                return e(B);
              },
              $$events: { click: Qe },
              children: (D, X) => {
                Be();
                var R = Ne();
                $(() => ie(R, (e(_), o(() => e(_).portal)))), n(D, R);
              },
              $$slots: { default: !0 }
            });
            var Q = T(se, 2);
            ut(Q, {
              icon: "sign-out",
              get disabled() {
                return e(B);
              },
              $$events: {
                click(...D) {
                  ee.actions.logOut?.apply(this, D);
                }
              },
              children: (D, X) => {
                Be();
                var R = Ne();
                $(() => ie(R, (e(_), o(() => e(_).logout)))), n(D, R);
              },
              $$slots: { default: !0 }
            }), n(be, U);
          },
          $$slots: {
            default: !0,
            control: (be, Ce) => {
              var U = Zr(), j = u(U);
              hr(j, {
                get user() {
                  return e(O);
                },
                size: "M",
                showTooltip: !1
              });
              var Y = T(j, 2);
              {
                var p = (se) => {
                  var Q = Qr(), D = ce(Q);
                  {
                    var X = (q) => {
                      var z = Gr(), Ie = u(z), Ve = u(Ie, !0);
                      d(Ie), d(z), $(() => ie(Ve, e(c))), n(q, z);
                    };
                    L(D, (q) => {
                      E() || q(X);
                    });
                  }
                  var R = T(D, 2);
                  Ae(R, { size: "S", name: "caret-down", color: "var(--navTextColor)" }), n(se, Q);
                };
                L(Y, (se) => {
                  m() || se(p);
                });
              }
              d(U), n(be, U);
            }
          }
        });
      }
      var V = T(ke, 2);
      lt(
        Gt(V, {
          children: (ne, be) => {
            Mr(ne, {
              get API() {
                return Qt;
              },
              get user() {
                return r();
              },
              get notifySuccess() {
                return o(() => w.actions.success);
              },
              get notifyError() {
                return o(() => w.actions.error);
              },
              get labels() {
                return e(x);
              },
              $$events: { save: () => ee.actions.fetchUser() }
            });
          },
          $$slots: { default: !0 },
          $$legacy: !0
        }),
        (ne) => f(he, ne),
        () => e(he)
      );
      var ue = T(V, 2);
      lt(
        Gt(ue, {
          children: (ne, be) => {
            Ur(ne, {
              get API() {
                return Qt;
              },
              get passwordMinLength() {
                return l(), o(() => l().passwordMinLength);
              },
              get notifySuccess() {
                return o(() => w.actions.success);
              },
              get notifyError() {
                return o(() => w.actions.error);
              },
              get labels() {
                return e(M);
              },
              $$events: { save: () => ee.actions.logOut() }
            });
          },
          $$slots: { default: !0 },
          $$legacy: !0
        }),
        (ne) => f(re, ne),
        () => e(re)
      ), n(oe, te);
    }, qe = (oe) => {
      var te = Ue(), ke = ce(te);
      {
        var V = (ue) => {
          var ne = tl(), be = u(ne);
          {
            let j = Me(() => m() ? "M" : "S");
            Ae(be, {
              get size() {
                return e(j);
              },
              name: "sign-in",
              color: "var(--navTextColor)"
            });
          }
          var Ce = T(be, 2);
          {
            var U = (j) => {
              var Y = el();
              n(j, Y);
            };
            L(Ce, (j) => {
              m() || j(U);
            });
          }
          d(ne), $(() => ne.disabled = e(B)), Le("click", ne, Re), n(ue, ne);
        };
        L(
          ke,
          (ue) => {
            H() && ue(V);
          },
          !0
        );
      }
      n(oe, te);
    };
    L(le, (oe) => {
      r() && !K() ? oe(pe) : oe(qe, !1);
    });
  }
  n(v, He), Oe(), P();
}
var al = S('<a><img class="svelte-1yowvh9"/></a>'), rl = S('<a><img class="svelte-1yowvh9"/></a>'), ll = S('<img class="svelte-1yowvh9"/>');
function oa(v, t) {
  Ee(t, !1);
  let r = a(t, "logoUrl", 8), l = a(t, "logoLinkUrl", 8), h = a(t, "openLogoLinkInNewTab", 8), i = a(t, "hideLogo", 8, !1), P = a(t, "title", 8), c = a(t, "isInternal", 8), A = a(t, "getSanitizedUrl", 8), ae = a(t, "linkable", 8);
  ze();
  var N = Ue(), B = ce(N);
  {
    var W = (_) => {
      var x = Ue(), M = ce(x);
      {
        var O = (m) => {
          var H = al(), K = u(H);
          d(H), mt(H, (ee) => ae()?.(ee)), $(
            (ee) => {
              we(H, "href", ee), we(K, "src", r() || "/builder/bblogo.png"), we(K, "alt", P());
            },
            [
              () => (g(A()), g(l()), g(h()), o(() => A()(l(), h())))
            ]
          ), n(m, H);
        }, E = (m) => {
          var H = Ue(), K = ce(H);
          {
            var ee = (w) => {
              var I = rl(), he = u(I);
              d(I), $(
                (re) => {
                  we(I, "target", h() ? "_blank" : "_self"), we(I, "href", re), we(he, "src", r() || "/builder/bblogo.png"), we(he, "alt", P());
                },
                [
                  () => (g(A()), g(l()), g(h()), o(() => A()(l(), h())))
                ]
              ), n(w, I);
            }, k = (w) => {
              var I = ll();
              $(() => {
                we(I, "src", r() || "/builder/bblogo.png"), we(I, "alt", P());
              }), n(w, I);
            };
            L(
              K,
              (w) => {
                l() ? w(ee) : w(k, !1);
              },
              !0
            );
          }
          n(m, H);
        };
        L(M, (m) => {
          g(l()), g(c()), g(h()), o(() => l() && c()(l()) && !h()) ? m(O) : m(E, !1);
        });
      }
      n(_, x);
    };
    L(B, (_) => {
      i() || _(W);
    });
  }
  n(v, N), Oe();
}
var nl = S('<div class="banner svelte-qff93a"><div class="banner-content svelte-qff93a"> <!></div></div>'), sl = S('<div class="burger svelte-qff93a"><!></div>'), ol = S('<div class="nav-toggle svelte-qff93a"><i class="ph ph-sidebar-simple"></i></div>'), il = S('<div class="user top svelte-qff93a"><!></div>'), cl = S("<div><!></div>"), vl = S("<div><!> <!></div>"), dl = S('<div data-name="Navigation" data-icon="eye"><div><div><div class="nav-header svelte-qff93a"><!> <div><!> <!></div> <!> <!></div> <div></div> <div><!></div> <!></div></div></div>'), ul = S('<div class="banner svelte-qff93a"><div class="banner-content svelte-qff93a"> <!></div></div>'), fl = S('<div data-name="Screen" data-icon="browser"><div class="screen-wrapper layout-body svelte-qff93a"><!> <div class="layout-content svelte-qff93a"><!> <div class="main-wrapper svelte-qff93a"><div class="main-content-area svelte-qff93a"><!> <div><!></div></div></div></div></div> <div id="side-panel-container"><div class="side-panel-header svelte-qff93a"><!></div></div> <div class="modal-container"></div></div>');
function ml(v, t) {
  Ee(t, !1);
  const r = () => de(or, "$authStore", N), l = () => de(ir, "$currentRole", N), h = () => de(Qe, "$context", N), i = () => de(re, "$roleStore", N), P = () => de(he, "$routeStore", N), c = () => de(me, "$builderStore", N), A = () => de(Pe, "$sidePanelStore", N), ae = () => de(Re, "$navStateStore", N), [N, B] = nt(), W = b(), _ = b(), x = b(), M = b(), O = b(), E = b(), m = b(), H = b(), K = b(), ee = b(), k = b(), w = b(), I = gt("sdk"), {
    routeStore: he,
    roleStore: re,
    linkable: _e,
    builderStore: me,
    sidePanelStore: Pe,
    modalStore: Xe
  } = I, Qe = gt("context"), Re = ht({});
  let He = b({}), le = a(t, "title", 8), pe = a(t, "hideTitle", 8, !1), qe = a(t, "logoUrl", 8), oe = a(t, "hideLogo", 8, !1), te = a(t, "navigation", 8, "Top"), ke = a(t, "sticky", 8, !1), V = a(t, "links", 8), ue = a(t, "width", 8, "Large"), ne = a(t, "navBackground", 8), be = a(t, "navTextColor", 8), Ce = a(t, "navLinkHoverTextColor", 8), U = a(t, "navLinkHoverBackground", 8), j = a(t, "navLinkActiveTextColor", 8), Y = a(t, "navLinkActiveBackground", 8), p = a(t, "navWidth", 8), se = a(t, "pageWidth", 8), Q = a(t, "logoLinkUrl", 8), D = a(t, "logoHeight", 8), X = a(t, "openLogoLinkInNewTab", 8), R = a(t, "textAlign", 8), q = a(t, "embedded", 8, !1), z = a(t, "banner", 8), Ie = a(t, "showLoginButton", 8, !0), Ve = a(t, "collapsible", 8, !1);
  const st = { Top: "top", Left: "left", None: "none" }, ot = {
    Max: "max",
    Large: "l",
    Medium: "m",
    Small: "s",
    "Extra small": "xs"
  };
  let Pt = a(
    t,
    "logoPosition",
    8,
    "top"
    // "top" or "bottom"
  ), ma = a(t, "titleSize", 8, "S"), ba = a(t, "titleColor", 8), Ye = b(!1), $e = b(!1);
  const Tt = ht({ headerHeight: 0 });
  va("layout", Tt);
  const Ct = (s) => {
    const y = Ze(s.url);
    return {
      ...s,
      internalLink: y,
      url: y ? s.url : $t(s.url)
    };
  }, xa = (s) => {
    if (!s)
      return s;
    try {
      return new URL(s, "http://localhost").pathname;
    } catch {
      return s;
    }
  }, ka = (s, y) => {
    const G = s?.url;
    return G ? !Ze(G) || G.includes("{{") ? !0 : y.has(xa(G)) : !1;
  }, ya = (s, y, G = []) => {
    if (!s?.length)
      return [];
    const fe = new Set(G.map((Z) => Z.path));
    return s.filter((Z) => {
      if (!Z.text || Z.type !== "sublinks" && !Z.url)
        return !1;
      const ye = Z.roleId || Zt.BASIC;
      return y?.find((xe) => xe === ye);
    }).map((Z) => {
      const ye = Ct(Z);
      return Z.type === "sublinks" && Z.subLinks?.length && (ye.subLinks = Z.subLinks.filter((xe) => xe.text && ka(xe, fe)).map(Ct)), ye;
    }).filter((Z) => Z.type !== "sublinks" || Z.subLinks?.length > 0);
  };
  function Sa(s = []) {
    if (!s?.length) return !0;
    const y = fr(s), { visible: G } = gr(y);
    return G ?? !s.some((Z) => Z.action === "show");
  }
  const Ze = (s) => s?.startsWith("/"), $t = (s) => s?.length ? s.startsWith("http") ? s : `http://${s}` : s, wa = (s, y) => s !== "Left" ? 0 : y ? "0px" : "250px", La = (s, y) => y ? !s || s === "None" ? 0 : "61px" : s === "Top" ? "137px" : "0px", pa = (s, y, G, fe, Z, ye, xe, Fe, Ke) => {
    let Se = `--width:${Fe}px; --height:${Ke}px;`;
    return s && (Se += `--navBackground:${s};`), y && (Se += `--navTextColor:${y};`), G && (Se += `--navLinkHoverTextColor:${G};`), fe && (Se += `--navLinkHoverBackground:${fe};`), Z && (Se += `--navLinkActiveTextColor:${Z};`), ye && (Se += `--navLinkActiveBackground:${ye};`), Se += `--logoHeight:${xe || 24}px;`, Se;
  }, Pa = (s, y, G) => {
    let fe = "";
    return s && (fe += `--bannerBackground:${s};`), y && (fe += `--bannerTextColor:${y};`), G && (fe += `--bannerTextSize:${G}px;`), fe;
  }, At = (s, y) => Ze(s) ? y ? `#${s}` : s : $t(s), Ta = () => {
    f(Ye, !1), Pe.actions.close(), Xe.actions.close();
  }, Nt = () => {
    typeof z()?.action?.onClick == "function" && z().action.onClick();
  };
  C(() => (r(), l(), sr), () => {
    f(W, r() != null && l() === Zt.PUBLIC);
  }), C(() => h(), () => {
    f(_, h().device.mobile);
  }), C(() => (g(te()), e(_)), () => {
    Tt.set({
      screenXOffset: wa(te(), e(_)),
      screenYOffset: La(te(), e(_))
    });
  }), C(() => (g(V()), i(), P()), () => {
    f(x, ya(V(), i(), P().routes));
  }), C(() => g(te()), () => {
    f(M, st[te()] || st.None);
  }), C(() => (g(p()), g(ue())), () => {
    f(O, ot[p() || ue()] || ot.Large);
  }), C(() => (g(se()), g(ue())), () => {
    f(E, ot[se() || ue()] || ot.Large);
  }), C(
    () => (g(ne()), g(be()), g(Ce()), g(U()), g(j()), g(Y()), g(D()), h()),
    () => {
      f(m, pa(ne(), be(), Ce(), U(), j(), Y(), D(), h().device.width, h().device.height));
    }
  ), C(() => g(z()), () => {
    f(H, Pa(z()?.background, z()?.textColor, z()?.textSize));
  }), C(() => (g(z()), e(M)), () => {
    f(K, !!z()?.text?.trim?.() && e(M) !== "none");
  }), C(() => (c(), A()), () => {
    f(ee, !c().inBuilder && A().open && !A().ignoreClicksOutside);
  }), C(() => c(), () => {
    f(k, c().inBuilder ? `${c().screen?._id}-screen` : "screen");
  }), C(() => c(), () => {
    f(w, c().inBuilder ? `${c().screen?._id}-navigation` : "navigation");
  }), De(), ze();
  var Je = fl();
  let Bt;
  var kt = u(Je), Ut = u(kt);
  {
    var Ca = (s) => {
      var y = nl(), G = u(y), fe = u(G), Z = T(fe);
      {
        var ye = (xe) => {
          Jt(xe, {
            cta: !0,
            $$events: { click: Nt },
            children: (Fe, Ke) => {
              Be();
              var Se = Ne();
              $(() => ie(Se, (g(z()), o(() => z().action.label)))), n(Fe, Se);
            },
            $$slots: { default: !0 }
          });
        };
        L(Z, (xe) => {
          g(z()), o(() => z()?.action) && xe(ye);
        });
      }
      d(G), d(y), $(() => {
        at(y, e(H)), ie(fe, `${g(z()), o(() => z()?.text) ?? ""} `);
      }), n(s, y);
    };
    L(Ut, (s) => {
      e(K) && (e(M) !== "left" || e(_)) && s(Ca);
    });
  }
  var qt = T(Ut, 2), Mt = u(qt);
  {
    var $a = (s) => {
      var y = dl(), G = u(y), fe = vr(() => c().inBuilder ? me.actions.selectComponent(e(w)) : null);
      let Z;
      var ye = u(G);
      let xe;
      var Fe = u(ye), Ke = u(Fe);
      {
        var Se = (F) => {
          var J = sl(), Te = u(J);
          Ae(Te, {
            hoverable: !0,
            name: "list",
            color: "var(--navTextColor)",
            $$events: { click: () => f(Ye, !e(Ye)) }
          }), d(J), n(F, J);
        };
        L(Ke, (F) => {
          e(x), o(() => e(x).length) && F(Se);
        });
      }
      var ct = T(Ke, 2);
      let Ft;
      var Wt = u(ct);
      {
        var Ua = (F) => {
          {
            let J = Me(() => oe() && !e($e));
            oa(F, {
              get logoUrl() {
                return qe();
              },
              get logoLinkUrl() {
                return Q();
              },
              get openLogoLinkInNewTab() {
                return X();
              },
              get hideLogo() {
                return e(J);
              },
              get title() {
                return le();
              },
              get linkable() {
                return _e;
              },
              isInternal: Ze,
              getSanitizedUrl: At
            });
          }
        };
        L(Wt, (F) => {
          Pt() === "top" && F(Ua);
        });
      }
      var qa = T(Wt, 2);
      {
        var Ma = (F) => {
          dr(F, {
            get size() {
              return ma();
            },
            get textAlign() {
              return R();
            },
            get color() {
              return ba();
            },
            children: (J, Te) => {
              Be();
              var We = Ne();
              $(() => ie(We, le())), n(J, We);
            },
            $$slots: { default: !0 }
          });
        };
        L(qa, (F) => {
          !pe() && le() && !e($e) && F(Ma);
        });
      }
      d(ct);
      var Rt = T(ct, 2);
      {
        var Ea = (F) => {
          var J = ol(), Te = u(J);
          at(Te, "", {}, { color: "var(--navTextColor)" }), d(J), Le("click", J, ur(() => {
            f(He, ae()), Re.set({}), f($e, !e($e));
          })), n(F, J);
        };
        L(Rt, (F) => {
          te() === "Left" && Ve() && !e(_) && !e($e) && F(Ea);
        });
      }
      var za = T(Rt, 2);
      {
        var Oa = (F) => {
          var J = il(), Te = u(J);
          sa(Te, {
            compact: !0,
            get showLoginButton() {
              return Ie();
            },
            get isPublicPreview() {
              return e(W);
            }
          }), d(J), n(F, J);
        };
        L(za, (F) => {
          q() || F(Oa);
        });
      }
      d(Fe);
      var wt = T(Fe, 2);
      let Ht;
      var vt = T(wt, 2);
      let Vt;
      var Ia = u(vt);
      {
        var Fa = (F) => {
          var J = Ue(), Te = ce(J);
          fa(Te, 1, () => e(x), ga, (We, ve) => {
            var dt = Ue(), je = ce(dt);
            {
              var et = (tt) => {
                {
                  let Ha = Me(() => (e(ve), o(() => e(ve)._styles?.custom))), Va = Me(() => te() === "Left");
                  Yr(tt, {
                    get type() {
                      return e(ve), o(() => e(ve).type);
                    },
                    get text() {
                      return e(ve), o(() => e(ve).text);
                    },
                    get url() {
                      return e(ve), o(() => e(ve).url);
                    },
                    get subLinks() {
                      return e(ve), o(() => e(ve).subLinks);
                    },
                    get icon() {
                      return e(ve), o(() => e(ve).icon);
                    },
                    get internalLink() {
                      return e(ve), o(() => e(ve).internalLink);
                    },
                    get customStyles() {
                      return e(Ha);
                    },
                    get leftNav() {
                      return e(Va);
                    },
                    get mobile() {
                      return e(_);
                    },
                    get navStateStore() {
                      return Re;
                    },
                    get collapsed() {
                      return e($e);
                    },
                    $$events: { clickLink: Ta }
                  });
                }
              };
              L(je, (tt) => {
                e(ve), o(() => Sa(e(ve)._conditions)) && tt(et);
              });
            }
            n(We, dt);
          }), n(F, J);
        };
        L(Ia, (F) => {
          e(x), o(() => e(x).length) && F(Fa);
        });
      }
      d(vt);
      var Wa = T(vt, 2);
      {
        var Ra = (F) => {
          var J = vl();
          let Te;
          var We = u(J);
          sa(We, {
            get collapsed() {
              return e($e);
            },
            get showLoginButton() {
              return Ie();
            },
            get isPublicPreview() {
              return e(W);
            }
          });
          var ve = T(We, 2);
          {
            var dt = (je) => {
              var et = cl(), tt = u(et);
              oa(tt, {
                get logoUrl() {
                  return qe();
                },
                get logoLinkUrl() {
                  return Q();
                },
                get openLogoLinkInNewTab() {
                  return X();
                },
                get hideLogo() {
                  return oe();
                },
                get title() {
                  return le();
                },
                get linkable() {
                  return _e;
                },
                isInternal: Ze,
                getSanitizedUrl: At
              }), d(et), n(je, et);
            };
            L(ve, (je) => {
              Pt() === "bottom" && je(dt);
            });
          }
          d(J), $((je) => Te = ge(J, 1, "user left svelte-qff93a", null, Te, je), [() => ({ collapsed: e($e) })]), n(F, J);
        };
        L(Wa, (F) => {
          q() || F(Ra);
        });
      }
      d(ye), d(G), d(y), $(
        (F, J, Te, We, ve) => {
          ge(y, 1, `interactive component ${e(w) ?? ""}`, "svelte-qff93a"), we(y, "data-id", e(w)), Z = ge(G, 1, `nav-wrapper ${e(w) ?? ""}-dom`, "svelte-qff93a", Z, F), at(G, e(m)), xe = ge(ye, 1, `nav nav--${e(M) ?? ""} size--${e(O) ?? ""}`, "svelte-qff93a", xe, J), Ft = ge(ct, 1, "logo svelte-qff93a", null, Ft, Te), Ht = ge(wt, 1, "mobile-click-handler svelte-qff93a", null, Ht, We), Vt = ge(vt, 1, "links svelte-qff93a", null, Vt, ve);
        },
        [
          () => ({
            sticky: ke(),
            hidden: P().queryParams?.peek,
            clickable: c().inBuilder
          }),
          () => ({ collapsed: e($e) }),
          () => ({ "collapsed-logo": e($e) }),
          () => ({ visible: e(Ye) }),
          () => ({ visible: e(Ye) })
        ]
      ), Le("click", wt, () => f(Ye, !1)), Le("click", ye, () => {
        e($e) && (Re.set(e(He)), f(He, {}), f($e, !1));
      }), Le("click", G, function(...F) {
        e(fe)?.apply(this, F);
      }), n(s, y);
    };
    L(Mt, (s) => {
      e(M) !== "none" && s($a);
    });
  }
  var yt = T(Mt, 2), Et = u(yt), zt = u(Et);
  {
    var Aa = (s) => {
      var y = ul(), G = u(y), fe = u(G), Z = T(fe);
      {
        var ye = (xe) => {
          Jt(xe, {
            cta: !0,
            $$events: { click: Nt },
            children: (Fe, Ke) => {
              Be();
              var Se = Ne();
              $(() => ie(Se, (g(z()), o(() => z().action.label)))), n(Fe, Se);
            },
            $$slots: { default: !0 }
          });
        };
        L(Z, (xe) => {
          g(z()), o(() => z()?.action) && xe(ye);
        });
      }
      d(G), d(y), $(() => {
        at(y, e(H)), ie(fe, `${g(z()), o(() => z()?.text) ?? ""} `);
      }), n(s, y);
    };
    L(zt, (s) => {
      e(K) && e(M) === "left" && !e(_) && s(Aa);
    });
  }
  var St = T(zt, 2), Na = u(St);
  bt(Na, t, "default", {}, null), d(St), d(Et), d(yt), d(qt), d(kt);
  var it = T(kt, 2);
  let Ot;
  var It = u(it), Ba = u(It);
  Ae(Ba, {
    color: "var(--spectrum-global-color-gray-600)",
    name: "caret-line-right",
    hoverable: !0,
    $$events: {
      click(...s) {
        Pe.actions.close?.apply(this, s);
      }
    }
  }), d(It), d(it), mt(it, (s, y) => cr?.(s, y), () => e(ee) ? Pe.actions.close : null), Be(2), d(Je), $(
    (s, y) => {
      Bt = ge(Je, 1, `component layout layout--${e(M) ?? ""}`, "svelte-qff93a", Bt, s), we(Je, "data-id", e(k)), ge(St, 1, `main size--${e(E) ?? ""}`, "svelte-qff93a"), Ot = ge(it, 1, "svelte-qff93a", null, Ot, y);
    },
    [
      () => ({ desktop: !e(_), mobile: !!e(_) }),
      () => ({
        open: A().open,
        builder: c().inBuilder
      })
    ]
  ), Le("click", yt, () => {
    c().inBuilder && me.actions.selectComponent(e(k));
  }), n(v, Je), Oe(), B();
}
export {
  ml as default
};
