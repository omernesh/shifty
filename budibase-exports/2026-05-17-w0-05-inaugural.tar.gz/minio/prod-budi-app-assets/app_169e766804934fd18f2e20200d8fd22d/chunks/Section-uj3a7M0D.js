import { g as H, h as g, p as S, W as I, j as r, l as J, k as K, m as L, E as N, u as Q, X as U, v as V, t as z, d as f, w as Y, y as Z, z as v, B as _, c as C, s as ee, f as $, r as O, i as w, A as k, a as x, x as M, n as te, q as se, S as ae, T as ne } from "./index-CMyk0zjR.js";
import re from "./Placeholder-DdLpQoxl.js";
var oe = $("<div><!></div>"), le = $("<div><!> <!></div>");
function ue(j, o) {
  H(o, !1);
  const n = () => M(q, "$component", p), A = () => M(R, "$builderStore", p), [p, W] = Z(), b = v(), { styleable: B, builderStore: R } = g("sdk"), q = g("component");
  let s = S(o, "type", 8, "mainSidebar"), D = S(o, "minSize", 8, 250), l = {
    mainSidebar: 2,
    sidebarMain: 2,
    oneColumn: 1,
    twoColumns: 2,
    threeColumns: 3
  }, d = v(), u = v();
  const E = (e) => {
    const t = new ResizeObserver((i) => {
      if (!i?.[0])
        return;
      const m = i[0].target;
      _(u, m.clientWidth);
    });
    return t.observe(e), t;
  };
  function P(e) {
    const t = Math.floor(e / D()) || 100;
    if (l[s()] <= t)
      return !1;
    if (l[s()] > t)
      return t;
  }
  I(() => {
    let e = E(r(d));
    return () => {
      e.disconnect();
    };
  }), J(() => r(u), () => {
    _(b, P(r(u)));
  }), K(), L();
  var a = le(), h = C(a);
  N(h, o, "default", {}, null);
  var T = ee(h, 2);
  {
    var X = (e) => {
      var t = te(), i = se(t);
      ae(
        i,
        1,
        () => (w(s()), n(), k(() => new Array(l[s()] - n().children))),
        ne,
        (m, ie) => {
          var c = oe();
          let y;
          var F = C(c);
          re(F, {}), O(c), z((G) => y = x(c, 1, "svelte-145y9cj", null, y, G), [() => ({ placeholder: A().inBuilder })]), f(m, c);
        }
      ), f(e, t);
    };
    Q(T, (e) => {
      w(s()), n(), k(() => l[s()] - n().children > 0) && e(X);
    });
  }
  O(a), U(a, (e) => _(d, e), () => r(d)), V(a, (e, t) => B?.(e, t), () => n().styles), z(() => x(a, 1, `${s() ?? ""} columns-${r(b) ?? ""}`, "svelte-145y9cj")), f(j, a), Y(), W();
}
export {
  ue as default
};
