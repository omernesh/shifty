import { g as A, p as m, h as p, Z as E, m as G, u as S, v as Z, t as j, a as z, d as n, w as B, y as D, c as d, f as H, r as u, x as I, n as f, q as _, E as b } from "./index-CMyk0zjR.js";
import J from "./Section-uj3a7M0D.js";
var K = H('<div class="wrapper svelte-penoqt"><div><!></div></div>');
function N(g, s) {
  A(s, !1);
  const h = () => I(P, "$component", y), [y, x] = D();
  let o = m(s, "labelPosition", 8, "above"), r = m(s, "type", 8, "oneColumn");
  const { styleable: C } = p("sdk"), P = p("component");
  E("field-group", { labelPosition: o() }), G();
  var a = K(), l = d(a);
  let i;
  var q = d(l);
  {
    var F = (e) => {
      J(e, {
        get type() {
          return r();
        },
        children: (t, c) => {
          var v = f(), w = _(v);
          b(w, s, "default", {}, null), n(t, v);
        },
        $$slots: { default: !0 }
      });
    }, k = (e) => {
      var t = f(), c = _(t);
      b(c, s, "default", {}, null), n(e, t);
    };
    S(q, (e) => {
      o() === "above" && r() !== "oneColumn" ? e(F) : e(k, !1);
    });
  }
  u(l), u(a), Z(a, (e, t) => C?.(e, t), () => h().styles), j((e) => i = z(l, 1, "spectrum-Form svelte-penoqt", null, i, e), [
    () => ({ "spectrum-Form--labelsAbove": o() === "above" })
  ]), n(g, a), B(), x();
}
export {
  N as default
};
