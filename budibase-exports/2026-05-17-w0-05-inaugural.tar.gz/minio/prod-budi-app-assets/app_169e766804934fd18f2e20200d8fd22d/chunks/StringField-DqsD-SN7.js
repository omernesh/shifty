import { g as q, p as t, m as j, n as w, q as z, u as B, d as H, B as h, j as l, w as P, z as o, H as D, d0 as E, A as r } from "./index-CMyk0zjR.js";
import { F as G } from "./Field-DlAvOihk.js";
function M(c, e) {
  q(e, !1);
  let v = t(e, "field", 8), b = t(e, "label", 8), m = t(e, "placeholder", 8), g = t(e, "type", 8, "text"), y = t(e, "disabled", 8, !1), p = t(e, "readonly", 8, !1), x = t(e, "validation", 8), _ = t(e, "defaultValue", 8, ""), A = t(e, "align", 8), s = t(e, "onChange", 8), C = t(e, "runOnInput", 8, !1), F = t(e, "span", 8), I = t(e, "helpText", 8, null), a = o(), u = o();
  const S = (n) => {
    l(u).setValue(n.detail) && s()?.({ value: n.detail });
  }, T = (n) => {
    s()?.({ value: n.target.value });
  };
  j();
  {
    let n = D(() => g() === "number" ? "number" : "string");
    G(c, {
      get label() {
        return b();
      },
      get field() {
        return v();
      },
      get disabled() {
        return y();
      },
      get readonly() {
        return p();
      },
      get validation() {
        return x();
      },
      get defaultValue() {
        return _();
      },
      get span() {
        return F();
      },
      get helpText() {
        return I();
      },
      get type() {
        return l(n);
      },
      get fieldState() {
        return l(a);
      },
      set fieldState(d) {
        h(a, d);
      },
      get fieldApi() {
        return l(u);
      },
      set fieldApi(d) {
        h(u, d);
      },
      children: (d, J) => {
        var f = w(), V = z(f);
        {
          var O = (i) => {
            E(i, {
              updateOnChange: !1,
              get value() {
                return l(a), r(() => l(a).value);
              },
              get disabled() {
                return l(a), r(() => l(a).disabled);
              },
              get readonly() {
                return l(a), r(() => l(a).readonly);
              },
              get id() {
                return l(a), r(() => l(a).fieldId);
              },
              get placeholder() {
                return m();
              },
              get type() {
                return g();
              },
              get align() {
                return A();
              },
              $$events: {
                change: S,
                input(...k) {
                  (C() ? T : void 0)?.apply(this, k);
                }
              }
            });
          };
          B(V, (i) => {
            l(a) && i(O);
          });
        }
        H(d, f);
      },
      $$slots: { default: !0 },
      $$legacy: !0
    });
  }
  P();
}
export {
  M as default
};
