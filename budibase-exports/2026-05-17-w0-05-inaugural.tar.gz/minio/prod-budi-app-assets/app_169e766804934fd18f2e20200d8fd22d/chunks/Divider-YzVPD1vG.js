import { g as f, h as s, p as a, m as u, v as h, t as D, d as _, w as g, y as z, f as $, a as x, x as y } from "./index-CMyk0zjR.js";
var b = $("<hr/>");
function w(o, e) {
  f(e, !1);
  const r = () => y(l, "$component", i), [i, c] = z(), { styleable: n } = s("sdk"), l = s("component");
  let p = a(e, "size", 8, "M"), m = a(e, "vertical", 8, !1);
  u();
  var t = b();
  h(t, (v, d) => n?.(v, d), () => r().styles), D(() => x(t, 1, `spectrum-Divider spectrum-Divider--${m() ? "vertical" : "horizontal"} spectrum-Dialog-divider spectrum-Divider--size${p() ?? ""}`)), _(o, t), g(), c();
}
export {
  w as default
};
