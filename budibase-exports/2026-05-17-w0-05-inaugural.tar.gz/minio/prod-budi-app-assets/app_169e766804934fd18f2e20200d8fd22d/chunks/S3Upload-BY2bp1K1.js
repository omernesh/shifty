import { g as te, p as i, h as y, W as ae, o as le, l as se, j as e, k as re, m as ne, u as A, t as ie, a as oe, d as P, B as d, w as de, x as _, aj as ce, y as ue, z as g, bS as fe, s as q, c as C, f as B, r as U, d5 as ge, A as z, q as ve, P as pe, ci as me, H as he } from "./index-CMyk0zjR.js";
import { F as ye } from "./Field-DlAvOihk.js";
var _e = B('<div class="overlay svelte-niqlvh"></div> <div class="loading svelte-niqlvh"><!></div>', 1), be = B("<div><!> <!></div>");
function xe(D, s) {
  te(s, !1);
  const b = () => _(ce, "$builderStore", v), $ = () => _(G, "$context", v), S = () => _(K, "$component", v), [v, E] = ue();
  let I = i(s, "datasourceId", 8), W = i(s, "bucket", 8), j = i(s, "key", 8), L = i(s, "field", 8), M = i(s, "label", 8), R = i(s, "disabled", 8, !1), V = i(s, "validation", 8), F = i(s, "onChange", 8);
  const G = y("context");
  let r = g(), p = g(), m = g([]);
  const { API: H, notificationStore: h, uploadStore: x } = y("sdk"), K = y("component"), T = 1e9 * 5;
  let o, c = g(!1);
  const J = () => {
    h.actions.warning("Files cannot exceed 5GB. Please try again with a smaller file.");
  }, N = async (t) => b().inBuilder ? [] : await new Promise((a) => {
    if (!t?.length)
      return [];
    o = t[0], o.type?.startsWith("image") || a([{ name: o.name, type: o.type }]);
    const l = new FileReader();
    l.addEventListener(
      "load",
      () => {
        a([{ url: l.result, name: o.name, type: o.type }]);
      },
      !1
    ), l.readAsDataURL(t[0]);
  }), O = async () => {
    const t = fe(j(), $());
    d(c, !0);
    try {
      const a = await H.externalUpload(I(), W(), t, o);
      return h.actions.success("File uploaded successfully"), d(c, !1), a;
    } catch (a) {
      h.actions.error(`Error uploading file: ${a?.message || a}`), d(c, !1);
    }
  }, Q = (t) => {
    d(m, t.detail);
    let a = me(t.detail) || [];
    a.forEach((u) => {
      u.type?.startsWith("image") && delete u.url;
    });
    const l = e(p).setValue(a);
    F() && l && F()({ value: a });
  };
  ae(() => {
    x.actions.registerFileUpload(S().id, O);
  }), le(() => {
    x.actions.unregisterFileUpload(S().id);
  }), se(() => e(r), () => {
    e(r)?.value?.length || d(m, []);
  }), re(), ne(), ye(D, {
    get label() {
      return M();
    },
    get field() {
      return L();
    },
    get disabled() {
      return R();
    },
    get validation() {
      return V();
    },
    type: "s3upload",
    defaultValue: [],
    get fieldState() {
      return e(r);
    },
    set fieldState(t) {
      d(r, t);
    },
    get fieldApi() {
      return e(p);
    },
    set fieldApi(t) {
      d(p, t);
    },
    children: (t, a) => {
      var l = be();
      let u;
      var k = C(l);
      {
        var X = (n) => {
          {
            let f = he(() => (e(c), e(r), z(() => e(c) || e(r).disabled)));
            ge(n, {
              get value() {
                return e(m);
              },
              get disabled() {
                return e(f);
              },
              get error() {
                return e(r), z(() => e(r).error);
              },
              processFiles: N,
              handleFileTooLarge: J,
              maximum: 1,
              fileSizeLimit: T,
              $$events: { change: Q }
            });
          }
        };
        A(k, (n) => {
          e(r) && n(X);
        });
      }
      var Y = q(k, 2);
      {
        var Z = (n) => {
          var f = _e(), w = q(ve(f), 2), ee = C(w);
          pe(ee, {}), U(w), P(n, f);
        };
        A(Y, (n) => {
          e(c) && n(Z);
        });
      }
      U(l), ie((n) => u = oe(l, 1, "content svelte-niqlvh", null, u, n), [() => ({ builder: b().inBuilder })]), P(t, l);
    },
    $$slots: { default: !0 },
    $$legacy: !0
  }), de(), E();
}
export {
  xe as default
};
