import { g as K, p as L, h as f, a7 as M, Z as N, l as r, i as h, k as O, m as Q, n as $, q as x, u as y, d as l, w as R, x as n, j as C, y as T, z as k, D as U, B as w, c as V, E as W, r as X, v as Y, f as ee } from "./index-CMyk0zjR.js";
import te from "./Placeholder-DdLpQoxl.js";
var oe = ee("<div><!></div>");
function re(B, c) {
  K(c, !1);
  const i = () => n(C(_), "$formState", o), d = () => n(j, "$builderStore", o), u = () => n(q, "$componentStore", o), m = () => n(z, "$component", o), [o, F] = T(), _ = k(), S = k();
  let e = L(c, "step", 8, 1);
  const { styleable: P, builderStore: j, componentStore: q } = f("sdk"), z = f("component"), s = f("form"), v = M(e() || 1);
  N("form-step", v), r(() => h(e()), () => {
    v.set(e() || 1);
  }), r(() => {
  }, () => {
    U(w(_, s?.formState), "$formState", o);
  }), r(() => i(), () => {
    w(S, i()?.currentStep);
  }), r(
    () => (d(), u(), m(), h(e())),
    () => {
      s && d().inBuilder && u().selectedComponentPath?.includes(m().id) && s.formApi.setStep(e());
    }
  ), O(), Q();
  var b = $(), A = x(b);
  {
    var D = (t) => {
      te(t, { text: "Form steps need to be wrapped in a form" });
    }, E = (t) => {
      var g = $(), Z = x(g);
      {
        var G = (p) => {
          var a = oe(), H = V(a);
          W(H, c, "default", {}, null), X(a), Y(a, (I, J) => P?.(I, J), () => m().styles), l(p, a);
        };
        y(
          Z,
          (p) => {
            e() === C(S) && p(G);
          },
          !0
        );
      }
      l(t, g);
    };
    y(A, (t) => {
      s ? t(E, !1) : t(D);
    });
  }
  l(B, b), R(), F();
}
export {
  re as default
};
