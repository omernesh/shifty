import { g as N, p as t, m as W, n as P, q as j, u as q, d as B, B as m, j as a, w as H, z as c, A as d } from "./index-CMyk0zjR.js";
import { D as E } from "./DatePicker-Do344ytB.js";
import { F as G } from "./Field-DlAvOihk.js";
function Q(h, e) {
  N(e, !1);
  let b = t(e, "field", 8), y = t(e, "label", 8), T = t(e, "placeholder", 8), v = t(e, "disabled", 8, !1), D = t(e, "readonly", 8, !1), O = t(e, "enableTime", 8, !0), g = t(e, "timeOnly", 8, !1), S = t(e, "time24hr", 8, !1), k = t(e, "ignoreTimezones", 8, !1), A = t(e, "startDayOfWeek", 8, "Monday"), V = t(e, "validation", 8), x = t(e, "defaultValue", 8), o = t(e, "onChange", 8), z = t(e, "span", 8), _ = t(e, "helpText", 8, null), w = t(e, "valueAsTimestamp", 8, !1), l = c(), u = c();
  const C = (n) => {
    let r = n.detail;
    g() && w() && (F(r) || (r = I(r)));
    const s = a(u).setValue(r);
    o() && s && o()({ value: r });
  }, F = (n) => !isNaN(new Date(n)), I = (n) => {
    let [r, s] = n.split(":").map(Number);
    const i = /* @__PURE__ */ new Date();
    return i.setHours(r), i.setMinutes(s), i.setSeconds(0), i.setMilliseconds(0), i.toISOString();
  };
  W(), G(h, {
    get label() {
      return y();
    },
    get field() {
      return b();
    },
    get disabled() {
      return v();
    },
    get readonly() {
      return D();
    },
    get validation() {
      return V();
    },
    get defaultValue() {
      return x();
    },
    get span() {
      return z();
    },
    get helpText() {
      return _();
    },
    type: "datetime",
    get fieldState() {
      return a(l);
    },
    set fieldState(n) {
      m(l, n);
    },
    get fieldApi() {
      return a(u);
    },
    set fieldApi(n) {
      m(u, n);
    },
    children: (n, r) => {
      var s = P(), i = j(s);
      {
        var M = (f) => {
          E(f, {
            get value() {
              return a(l), d(() => a(l).value);
            },
            get disabled() {
              return a(l), d(() => a(l).disabled);
            },
            get readonly() {
              return a(l), d(() => a(l).readonly);
            },
            get error() {
              return a(l), d(() => a(l).error);
            },
            get id() {
              return a(l), d(() => a(l).fieldId);
            },
            get enableTime() {
              return O();
            },
            get timeOnly() {
              return g();
            },
            get time24hr() {
              return S();
            },
            get ignoreTimezones() {
              return k();
            },
            get startDayOfWeek() {
              return A();
            },
            get placeholder() {
              return T();
            },
            $$events: { change: C }
          });
        };
        q(i, (f) => {
          a(l) && f(M);
        });
      }
      B(n, s);
    },
    $$slots: { default: !0 },
    $$legacy: !0
  }), H();
}
export {
  Q as default
};
