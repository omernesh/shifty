import { bJ as w, g as B, p as a, b1 as D, l as i, i as n, k as h, m as E, cw as F, Y as V, j as o, w as I, z as f, B as c } from "./index-CMyk0zjR.js";
import U from "./RelationshipField-J3NHbz83.js";
import { c as z, g as d } from "./users-DI_wYCOX.js";
function k(p, t) {
  const s = w(t, ["children", "$$slots", "$$events", "$$legacy"]);
  B(t, !1);
  const r = f(), l = f();
  let u = a(t, "defaultValue", 8), m = a(t, "type", 24, () => D.BB_REFERENCE), _ = a(t, "multi", 24, () => {
  }), y = a(t, "defaultRows", 24, () => []);
  function g(e) {
    return Array.isArray(e) ? e.map((b) => d(b)) : d(e);
  }
  function R(e) {
    return z(e) ? g(e) : e;
  }
  i(() => n(u()), () => {
    c(r, R(u()));
  }), i(() => n(s), () => {
    c(l, s);
  }), h(), E(), U(p, F(() => o(l), {
    get type() {
      return m();
    },
    datasourceType: "user",
    primaryDisplay: "email",
    get defaultValue() {
      return o(r);
    },
    get defaultRows() {
      return y();
    },
    get multi() {
      return _();
    },
    $$events: {
      rows(e) {
        V.call(this, t, e);
      }
    }
  })), I();
}
export {
  k as default
};
