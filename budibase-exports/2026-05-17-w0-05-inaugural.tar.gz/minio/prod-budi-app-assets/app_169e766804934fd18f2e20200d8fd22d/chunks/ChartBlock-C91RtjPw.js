import { g as Ce, p as t, m as fe, Q as be, R as ee, n as xe, q as ve, u as we, d as Ae, B as ke, j as a, H as te, w as Le, z as ye, i as l, cz as le, A as ze } from "./index-CMyk0zjR.js";
function _e(ae, e) {
  Ce(e, !1);
  let ie = t(e, "filter", 8), ne = t(e, "sortColumn", 8), ue = t(e, "sortOrder", 8), me = t(e, "limit", 8), ce = t(e, "autoRefresh", 8), m = t(e, "chartTitle", 8), c = t(e, "chartType", 8), de = t(e, "dataSource", 8), d = t(e, "palette", 8), o = t(e, "c1", 8), h = t(e, "c2", 8), g = t(e, "c3", 8), s = t(e, "c4", 8), r = t(e, "c5", 8), C = t(e, "labelColumn", 8), f = t(e, "legend", 8), b = t(e, "animate", 8), x = t(e, "dataLabels", 8), v = t(e, "height", 8), w = t(e, "width", 8), A = t(e, "valueColumn", 8), k = t(e, "stacked", 8), L = t(e, "horizontal", 8), y = t(e, "valueColumns", 8), z = t(e, "valueUnits", 8), S = t(e, "yAxisLabel", 8), U = t(e, "xAxisLabel", 8), P = t(e, "yAxisUnits", 8), _ = t(e, "curve", 8), R = t(e, "gradient", 8), T = t(e, "closeColumn", 8), V = t(e, "openColumn", 8), B = t(e, "highColumn", 8), H = t(e, "lowColumn", 8), I = t(e, "dateColumn", 8), M = t(e, "bucketCount", 8), O = t(e, "autoMaxValue", 8), W = t(e, "maxValue", 8), X = t(e, "startAngle", 8), Y = t(e, "endAngle", 8), q = t(e, "showTrack", 8), j = t(e, "lineCap", 8), Q = t(e, "barLabels", 8), D = t(e, "offsetX", 8), E = t(e, "offsetY", 8), F = t(e, "textSize", 8), G = t(e, "showImage", 8), J = t(e, "imageURL", 8), K = t(e, "imageWidth", 8), N = t(e, "imageHeight", 8), Z = t(e, "titleSize", 8), p = t(e, "showPercentage", 8), i = ye();
  fe(), be(ae, {
    children: (oe, Se) => {
      {
        let he = te(() => ({
          dataSource: de(),
          filter: ie(),
          sortColumn: ne(),
          sortOrder: ue(),
          limit: me(),
          autoRefresh: ce()
        }));
        ee(oe, {
          type: "dataprovider",
          context: "provider",
          get props() {
            return a(he);
          },
          get id() {
            return a(i);
          },
          set id(n) {
            ke(i, n);
          },
          children: (n, Ue) => {
            var $ = xe(), ge = ve($);
            {
              var se = (u) => {
                {
                  let re = te(() => (l(le), a(i), l(v()), l(w()), l(m()), l(C()), l(A()), l(y()), l(d()), l(x()), l(f()), l(b()), l(z()), l(S()), l(U()), l(P()), l(k()), l(L()), l(_()), l(R()), l(T()), l(V()), l(B()), l(H()), l(I()), l(M()), l(o()), l(h()), l(g()), l(s()), l(r()), l(O()), l(W()), l(X()), l(Y()), l(q()), l(j()), l(Q()), l(D()), l(E()), l(F()), l(G()), l(J()), l(K()), l(N()), l(Z()), l(p()), ze(() => ({
                    dataProvider: `{{ literal ${le(a(i))} }}`,
                    height: v(),
                    width: w(),
                    title: m(),
                    labelColumn: C(),
                    valueColumn: A(),
                    valueColumns: y(),
                    palette: d(),
                    dataLabels: x(),
                    legend: f(),
                    animate: b(),
                    valueUnits: z(),
                    yAxisLabel: S(),
                    xAxisLabel: U(),
                    yAxisUnits: P(),
                    stacked: k(),
                    horizontal: L(),
                    curve: _(),
                    gradient: R(),
                    closeColumn: T(),
                    openColumn: V(),
                    highColumn: B(),
                    lowColumn: H(),
                    dateColumn: I(),
                    bucketCount: M(),
                    c1: o(),
                    c2: h(),
                    c3: g(),
                    c4: s(),
                    c5: r(),
                    autoMaxValue: O(),
                    maxValue: W(),
                    startAngle: X(),
                    endAngle: Y(),
                    showTrack: q(),
                    lineCap: j(),
                    barLabels: Q(),
                    offsetX: D(),
                    offsetY: E(),
                    textSize: F(),
                    showImage: G(),
                    imageURL: J(),
                    imageWidth: K(),
                    imageHeight: N(),
                    titleSize: Z(),
                    showPercentage: p()
                  }))));
                  ee(u, {
                    get type() {
                      return c();
                    },
                    get props() {
                      return a(re);
                    }
                  });
                }
              };
              we(ge, (u) => {
                a(i) && c() && u(se);
              });
            }
            Ae(n, $);
          },
          $$slots: { default: !0 },
          $$legacy: !0
        });
      }
    },
    $$slots: { default: !0 }
  }), Le();
}
export {
  _e as default
};
