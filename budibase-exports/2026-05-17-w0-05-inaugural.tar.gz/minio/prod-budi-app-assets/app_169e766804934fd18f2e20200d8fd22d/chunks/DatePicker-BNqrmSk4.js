import { g as f, p as t, $ as y, m as P, cg as D, w as x } from "./index-CMyk0zjR.js";
import { D as z } from "./DatePicker-Do344ytB.js";
function C(n, e) {
  f(e, !1);
  let a = t(e, "value", 12, null), i = t(e, "label", 24, () => {
  }), o = t(e, "labelPosition", 8, "above"), d = t(e, "disabled", 8, !1), u = t(e, "readonly", 8, !1), r = t(e, "error", 24, () => {
  }), g = t(e, "enableTime", 8, !0), s = t(e, "timeOnly", 8, !1), c = t(e, "placeholder", 8, null), m = t(e, "appendTo", 24, () => {
  }), b = t(e, "ignoreTimezones", 8, !1), h = t(e, "helpText", 24, () => {
  });
  const T = y(), v = (l) => {
    a(l.detail), T("change", l.detail);
  };
  P(), D(n, {
    get helpText() {
      return h();
    },
    get label() {
      return i();
    },
    get labelPosition() {
      return o();
    },
    get error() {
      return r();
    },
    children: (l, O) => {
      z(l, {
        get error() {
          return r();
        },
        get disabled() {
          return d();
        },
        get readonly() {
          return u();
        },
        get value() {
          return a();
        },
        get placeholder() {
          return c();
        },
        get enableTime() {
          return g();
        },
        get timeOnly() {
          return s();
        },
        get appendTo() {
          return m();
        },
        get ignoreTimezones() {
          return b();
        },
        $$events: { change: v }
      });
    },
    $$slots: { default: !0 }
  }), x();
}
export {
  C as D
};
