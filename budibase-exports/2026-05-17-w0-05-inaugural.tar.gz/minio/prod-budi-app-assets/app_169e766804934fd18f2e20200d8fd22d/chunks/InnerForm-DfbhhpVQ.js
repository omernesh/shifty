import { g as qe, y as ze, p as m, h as ae, cF as Me, a7 as M, aR as o, Z as re, l as b, D as T, B as _, j as s, a6 as O, i as le, k as Oe, m as Pe, n as Re, q as Ge, u as Le, d as P, w as Ne, x as A, z as y, ci as He, cJ as se, cK as Je, cL as Ke, aM as Ye, c as ne, E as ie, r as oe, v as de, t as ce, a as ue, aH as fe, b1 as Ze, f as me } from "./index-CMyk0zjR.js";
var Qe = me("<div><!></div>"), We = me("<div><!></div>");
function $e(ve, c) {
  qe(c, !1);
  const E = () => A(s(H), "$errors", v), U = () => A(s(N), "$values", v), k = () => A(p(), "$currentStep", v), R = () => A(s(J), "$enrichments", v), G = () => A(s(K), "$currentStepValid", v), L = () => A(Fe, "$component", v), [v, pe] = ze(), N = y(), H = y(), J = y(), I = y(), K = y(), w = y(), Y = y();
  let Se = m(c, "dataSource", 24, () => {
  }), Z = m(c, "disabled", 8, !1), he = m(c, "readonly", 8, !1), j = m(c, "initialValues", 24, () => {
  }), Q = m(c, "size", 24, () => {
  }), F = m(c, "schema", 24, () => {
  }), _e = m(c, "definition", 24, () => {
  }), be = m(c, "disableSchemaValidation", 8, !1), ye = m(c, "editAutoColumns", 8, !1), ge = m(c, "provideContext", 8, !0), p = m(c, "currentStep", 8);
  const Fe = ae("component"), { styleable: W, Provider: Ve, ActionTypes: C } = ae("sdk"), Ae = Me("validation");
  let d = y([]);
  const X = M({
    values: {},
    errors: {},
    valid: !0,
    currentStep: o(p())
  }), $ = (e, t) => O(e, (a) => a.reduce((r, n) => ({ ...r, [n.name]: t(n) }), {})), Ie = (e) => O(e, (t) => {
    const a = {};
    return t.forEach((r) => {
      if (r.type === "attachment") {
        const n = r.fieldState.value;
        let l = null;
        Array.isArray(n) && n[0] != null && (l = n[0].url), a[`${r.name}_first`] = l;
      }
    }), a;
  }), Ce = (e, t, a) => {
    let r = He(e || {});
    return Object.entries(t || {}).map(([l, i]) => {
      const h = S(l);
      return {
        key: l,
        value: i,
        lastUpdate: o(h).fieldState?.lastUpdate || 0
      };
    }).sort((l, i) => l.lastUpdate - i.lastUpdate).forEach(({ key: l, value: i }) => {
      se(r, l, i);
    }), Object.entries(a || {}).forEach(([l, i]) => {
      se(r, l, i);
    }), r;
  }, S = (e) => s(d).find((t) => o(t).name === e), xe = (e, t, a) => {
    if (Array.isArray(e) && a === Ze.ARRAY && t) {
      const r = t?.constraints?.inclusion || [];
      return e.map((l) => String(l)).filter((l) => r.includes(l));
    }
    return e;
  }, V = {
    registerField: (e, t, a = null, r = !1, n = !1, l, i = 1) => {
      if (!e)
        return;
      const h = be() ? null : F()?.[e]?.constraints, f = Je(h, l, e, _e(), Ae.required);
      a = xe(a, F()?.[e], t);
      let x = Ke(j(), e) ?? a, D = null, g = `id-${Ye()}`;
      const B = S(e), je = (u, z) => u == null || u === "" || u === z ? !1 : Array.isArray(u) ? u.length > 0 : !0;
      if (B) {
        const { fieldState: u } = o(B);
        g = u.fieldId, x = je(u.value, u.defaultValue) ? u.value : a, u.error && (D = f?.(x));
      }
      const Be = !!F()?.[e]?.autocolumn, q = M({
        name: e,
        type: t,
        step: i || 1,
        fieldState: {
          fieldId: g,
          value: x,
          error: D,
          disabled: Z() || r || Be && !ye(),
          readonly: he() || n || F()?.[e]?.readonly,
          defaultValue: a,
          validator: f,
          lastUpdate: Date.now()
        },
        fieldApi: Ee(e),
        fieldSchema: F()?.[e] ?? {}
      });
      if (B) {
        const u = s(d).filter((z) => o(z).name !== e);
        _(d, [...u, q]);
      } else
        _(d, [...s(d), q]);
      return q;
    },
    validate: () => {
      const e = s(d).filter((r) => o(r).step === o(p()));
      let t = !0, a = !1;
      return e.forEach((r) => {
        const n = o(r).fieldApi.validate();
        t = t && n, !t && !a && (ee({ field: o(r) }), a = !0);
      }), t;
    },
    reset: () => {
      s(d).forEach((e) => {
        o(e).fieldApi.reset();
      });
    },
    changeStep: ({ type: e, number: t }) => {
      e === "next" ? p().update((a) => a + 1) : e === "prev" ? p().update((a) => Math.max(1, a - 1)) : e === "first" ? p().set(1) : e === "specific" && t && !isNaN(t) && p().set(parseInt(t));
    },
    setStep: (e) => {
      e && p().set(e);
    },
    setFieldValue: (e, t) => {
      const a = S(e);
      if (!a)
        return;
      const { fieldApi: r } = o(a);
      r.setValue(t);
    },
    resetField: (e) => {
      const t = S(e);
      if (!t)
        return;
      const { fieldApi: a } = o(t);
      a.reset();
    }
  }, Ee = (e) => {
    const t = (l, i = !1) => {
      const h = S(e), { fieldState: f } = o(h), { validator: x } = f;
      if (!i && f.value === l)
        return !1;
      const D = x?.(l);
      return h.update((g) => (g.fieldState.value = l, g.fieldState.error = D, g.fieldState.lastUpdate = Date.now(), g)), !0;
    };
    return {
      setValue: t,
      reset: () => {
        const l = S(e), { fieldState: i } = o(l), h = i.defaultValue;
        l.update((f) => (f.fieldState.value = h, f.fieldState.error = null, f.fieldState.lastUpdate = Date.now(), f));
      },
      setDisabled: (l) => {
        const i = S(e), h = !!F()?.[e]?.autocolumn;
        i.update((f) => (f.fieldState.disabled = Z() || l || h, f));
      },
      deregister: () => {
        S(e).update((i) => (i.fieldState.validator = null, i.fieldState.error = null, i));
      },
      validate: () => {
        const l = S(e);
        return t(o(l).fieldState.value, !0), !o(l).fieldState.error;
      }
    };
  };
  re("form", {
    formState: X,
    formApi: V,
    // Datasource is needed by attachment fields to be able to upload files
    // to the correct table ID
    dataSource: Se()
  }), re("form-step", M(1));
  const Ue = ({ type: e, field: t, value: a }) => {
    e === "set" ? V.setFieldValue(t, a) : V.resetField(t);
  }, ee = (e) => {
    let t;
    typeof e.field == "string" ? t = o(S(e.field)) : t = e.field;
    const a = t.fieldState.fieldId, r = document.getElementById(a);
    r && r.focus({ preventScroll: !0 });
    const n = document.querySelector(`label[for="${a}"]`);
    n && (n.style.scrollMargin = "100px", n.scrollIntoView({ behavior: "smooth", block: "nearest" }));
  }, ke = [
    { type: C.ValidateForm, callback: V.validate },
    { type: C.ClearForm, callback: V.reset },
    {
      type: C.ChangeFormStep,
      callback: V.changeStep
    },
    {
      type: C.UpdateFieldValue,
      callback: Ue
    },
    { type: C.ScrollTo, callback: ee }
  ];
  b(() => s(d), () => {
    T(_(N, $(s(d), (e) => e.fieldState.value)), "$values", v);
  }), b(() => s(d), () => {
    T(_(H, $(s(d), (e) => e.fieldState.error)), "$errors", v);
  }), b(() => s(d), () => {
    T(_(J, Ie(s(d))), "$enrichments", v);
  }), b(() => E(), () => {
    _(I, !Object.values(E()).some((e) => e != null));
  }), b(() => (le(p()), s(d)), () => {
    T(
      _(K, O([p(), ...s(d)], ([e, ...t]) => !t.filter((a) => a.step === e).some((a) => a.fieldState.error != null))),
      "$currentStepValid",
      v
    );
  }), b(() => (U(), E(), s(I), k()), () => {
    X.set({
      values: U(),
      errors: E(),
      valid: s(I),
      currentStep: k()
    });
  }), b(
    () => (le(j()), U(), R()),
    () => {
      _(w, Ce(j(), U(), R()));
    }
  ), b(
    () => (s(w), s(I), k(), G()),
    () => {
      _(Y, {
        ...s(w),
        __value: s(w),
        __valid: s(I),
        __currentStep: k(),
        __currentStepValid: G()
      });
    }
  ), Oe(), Pe();
  var te = Re(), we = Ge(te);
  {
    var De = (e) => {
      Ve(e, {
        get actions() {
          return ke;
        },
        get data() {
          return s(Y);
        },
        children: (t, a) => {
          var r = Qe(), n = ne(r);
          ie(n, c, "default", {}, null), oe(r), de(r, (l, i) => W?.(l, i), () => L().styles), ce(() => ue(r, 1, fe(Q()))), P(t, r);
        },
        $$slots: { default: !0 }
      });
    }, Te = (e) => {
      var t = We(), a = ne(t);
      ie(a, c, "default", {}, null), oe(t), de(t, (r, n) => W?.(r, n), () => L().styles), ce(() => ue(t, 1, fe(Q()))), P(e, t);
    };
    Le(we, (e) => {
      ge() ? e(De) : e(Te, !1);
    });
  }
  P(ve, te), Ne(), pe();
}
export {
  $e as I
};
