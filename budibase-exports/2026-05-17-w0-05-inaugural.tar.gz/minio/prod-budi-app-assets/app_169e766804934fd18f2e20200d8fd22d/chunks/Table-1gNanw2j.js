import { p as l, c as S, E as Be, r as z, t as P, a as ve, ap as Xe, e as Ve, Y as ot, d as v, f as T, g as we, m as ye, i as s, A as p, b as ge, w as pe, a0 as Bt, s as te, I as He, cC as Ot, l as h, B as u, j as e, k as Oe, aI as pt, z as f, $ as Tt, q as ae, S as We, T as Je, n as he, u as N, a3 as gt, a4 as Ue, dc as Ct, a2 as rt, aE as It, bc as jt, aa as xt, bS as Nt, bt as Yt, bE as bt, cU as Ft, W as Gt, al as Xt, X as Vt, P as Wt, H as Ke, cL as Rt, ci as Jt, h as vt, o as Kt, dd as Ut, v as Qt, _ as Zt, x as kt, y as $t, aH as el } from "./index-CMyk0zjR.js";
import { c as tl } from "./table-CMyp87mQ.js";
var ll = T("<span><!></span>");
function Et(M, t) {
  let i = l(t, "size", 8, "M"), a = l(t, "grey", 8, !1), r = l(t, "red", 8, !1), b = l(t, "orange", 8, !1), m = l(t, "yellow", 8, !1), w = l(t, "seafoam", 8, !1), R = l(t, "green", 8, !1), D = l(t, "active", 8, !1), H = l(t, "inactive", 8, !1), k = l(t, "hoverable", 8, !1), y = l(t, "outlineColor", 8, null);
  var d = ll();
  let g;
  var B = S(d);
  Be(B, t, "default", {}, null), z(d), P(
    (F) => {
      g = ve(d, 1, "spectrum-Label svelte-1n3ntwl", null, g, F), Xe(d, y() ? `border: 2px solid ${y()}` : "");
    },
    [
      () => ({
        hoverable: k(),
        "spectrum-Label--small": i() === "S",
        "spectrum-Label--large": i() === "L",
        "spectrum-Label--grey": a(),
        "spectrum-Label--red": r(),
        "spectrum-Label--green": R(),
        "spectrum-Label--orange": b(),
        "spectrum-Label--yellow": m(),
        "spectrum-Label--seafoam": w(),
        "spectrum-Label--active": D(),
        "spectrum-Label--inactive": H()
      })
    ]
  ), Ve("click", d, function(F) {
    ot.call(this, t, F);
  }), v(M, d);
}
var al = T("<div> </div>");
function Ge(M, t) {
  we(t, !1);
  let i = l(t, "value", 8), a = l(t, "schema", 8);
  ye();
  var r = al();
  let b;
  var m = S(r, !0);
  z(r), P(
    (w, R) => {
      b = ve(r, 1, "svelte-sc2tmf", null, b, w), ge(m, R);
    },
    [
      () => ({ capitalise: a()?.capitalise }),
      () => (s(i()), p(() => typeof i() == "object" ? JSON.stringify(i()) : i()))
    ]
  ), v(M, r), pe();
}
var rl = T('<label class="spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-Checkbox--emphasized svelte-1pzamsw"><input type="checkbox" class="spectrum-Checkbox-input" id="checkbox-1" disabled/> <span class="spectrum-Checkbox-box svelte-1pzamsw"><!> <!></span></label>');
function ol(M, t) {
  let i = l(t, "value", 8);
  var a = rl(), r = S(a);
  Bt(r);
  var b = te(r, 2), m = S(b);
  He(m, { name: "check", size: "S" });
  var w = te(m, 2);
  He(w, { name: "minus", size: "S" }), z(b), z(a), P(() => Ot(r, !!i())), v(M, a);
}
var sl = T('<div class="svelte-q68b7"> </div>');
function nl(M, t) {
  we(t, !1);
  const i = f(), a = f(), r = f(), b = f();
  let m = l(t, "value", 8), w = l(t, "schema", 8);
  h(() => s(m()), () => {
    u(i, /* @__PURE__ */ new Date(`0-${m()}`));
  }), h(() => (e(i), s(w())), () => {
    u(a, !isNaN(e(i)) || w()?.timeOnly);
  }), h(() => s(w()), () => {
    u(r, w()?.dateOnly);
  }), h(() => (e(a), e(r)), () => {
    u(b, e(a) ? "HH:mm:ss" : e(r) ? "MMMM D YYYY" : "MMMM D YYYY, HH:mm");
  }), Oe(), ye();
  var R = sl(), D = S(R, !0);
  z(R), P((H) => ge(D, H), [
    () => (s(pt), e(a), e(i), s(m()), e(b), p(() => pt(e(a) ? e(i) : m()).format(e(b))))
  ]), v(M, R), pe();
}
var il = T("<div> </div>"), cl = T("<!> <!>", 1);
function St(M, t) {
  we(t, !1);
  const i = f(), a = f();
  let r = l(t, "row", 8), b = l(t, "value", 8), m = l(t, "schema", 8);
  const w = Tt(), R = 5, D = (g) => {
    g.stopPropagation(), w("clickrelationship", {
      tableId: r().tableId,
      rowId: r()._id,
      fieldName: m()?.name
    });
  };
  h(() => s(b()), () => {
    u(i, b()?.slice(0, R) ?? []);
  }), h(() => (s(b()), e(i)), () => {
    u(a, (b()?.length ?? 0) - e(i).length);
  }), Oe(), ye();
  var H = cl(), k = ae(H);
  We(k, 1, () => e(i), Je, (g, B) => {
    var F = he(), x = ae(F);
    {
      var L = (O) => {
        Et(O, {
          hoverable: !0,
          grey: !0,
          $$events: { click: D },
          children: (se, ee) => {
            gt();
            var J = Ue();
            P(() => ge(J, (e(B), p(() => e(B).primaryDisplay)))), v(se, J);
          },
          $$slots: { default: !0 }
        });
      };
      N(x, (O) => {
        e(B), p(() => e(B)?.primaryDisplay) && O(L);
      });
    }
    v(g, F);
  });
  var y = te(k, 2);
  {
    var d = (g) => {
      var B = il(), F = S(B);
      z(B), P(() => ge(F, `+${e(a) ?? ""} more`)), v(g, B);
    };
    N(y, (g) => {
      e(a) && g(d);
    });
  }
  v(M, H), pe();
}
var dl = T('<div class="center svelte-1ho6t7f"><img class="svelte-1ho6t7f"/></div>'), ul = T('<div class="file svelte-1ho6t7f"><!></div>'), vl = T("<div> </div>"), gl = T("<!> <!>", 1);
function fl(M, t) {
  we(t, !1);
  const i = f(), a = f();
  let r = l(t, "value", 8);
  const b = 5, m = ["png", "tiff", "gif", "raw", "jpg", "jpeg"], w = (y) => m.includes(y?.toLowerCase() ?? "");
  h(() => s(r()), () => {
    u(i, r()?.slice(0, b) ?? []);
  }), h(() => (s(r()), e(i)), () => {
    u(a, (r()?.length ?? 0) - e(i).length);
  }), Oe(), ye();
  var R = gl(), D = ae(R);
  We(D, 1, () => e(i), Je, (y, d) => {
    var g = he(), B = ae(g);
    {
      var F = (L) => {
        Ct(L, {
          quiet: !0,
          target: "_blank",
          get download() {
            return e(d), p(() => e(d).name);
          },
          get href() {
            return e(d), p(() => e(d).url);
          },
          $$events: {
            click: (O) => {
              O.stopPropagation();
            }
          },
          children: (O, se) => {
            var ee = dl(), J = S(ee);
            z(ee), P(() => {
              rt(ee, "title", (e(d), p(() => e(d).name))), rt(J, "src", (e(d), p(() => e(d).url))), rt(J, "alt", (e(d), p(() => e(d).extension)));
            }), v(O, ee);
          },
          $$slots: { default: !0 }
        });
      }, x = (L) => {
        var O = ul(), se = S(O);
        Ct(se, {
          quiet: !0,
          target: "_blank",
          get download() {
            return e(d), p(() => e(d).name);
          },
          get href() {
            return e(d), p(() => e(d).url);
          },
          $$events: {
            click: (ee) => {
              ee.stopPropagation();
            }
          },
          children: (ee, J) => {
            gt();
            var qe = Ue();
            P(() => ge(qe, (e(d), p(() => e(d).extension)))), v(ee, qe);
          },
          $$slots: { default: !0 }
        }), z(O), P(() => rt(O, "title", (e(d), p(() => e(d).name)))), v(L, O);
      };
      N(B, (L) => {
        e(d), p(() => w(e(d).extension)) ? L(F) : L(x, !1);
      });
    }
    v(y, g);
  });
  var H = te(D, 2);
  {
    var k = (y) => {
      var d = vl(), g = S(d);
      z(d), P(() => ge(g, `+${e(a) ?? ""} more`)), v(y, d);
    };
    N(H, (y) => {
      e(a) && y(k);
    });
  }
  v(M, R), pe();
}
var ml = T("<div> </div>"), hl = T("<!> <!>", 1);
function _l(M, t) {
  we(t, !1);
  const i = f(), a = f(), r = f();
  let b = l(t, "value", 8);
  const m = 5;
  h(() => s(b()), () => {
    u(i, Array.isArray(b()) ? b() : [b()].filter((k) => !!k));
  }), h(() => e(i), () => {
    u(a, e(i).slice(0, m));
  }), h(() => (e(i), e(a)), () => {
    u(r, e(i).length - e(a).length);
  }), Oe(), ye();
  var w = hl(), R = ae(w);
  We(R, 1, () => e(a), Je, (k, y) => {
    Et(k, {
      size: "S",
      grey: !0,
      children: (d, g) => {
        gt();
        var B = Ue();
        P(() => ge(B, e(y))), v(d, B);
      },
      $$slots: { default: !0 }
    });
  });
  var D = te(R, 2);
  {
    var H = (k) => {
      var y = ml(), d = S(y);
      z(y), P(() => ge(d, `+${e(r) ?? ""} more`)), v(k, y);
    };
    N(D, (k) => {
      e(r) && k(H);
    });
  }
  v(M, w), pe();
}
var bl = T("<div><!></div>");
function wl(M, t) {
  we(t, !1);
  let i = l(t, "value", 8);
  const a = async (m) => {
    m.stopPropagation();
    try {
      await jt(i()), xt.success("Copied to clipboard");
    } catch {
      xt.error("Failed to copy to clipboard. Check the dev console for the value."), console.warn("Failed to copy the value", i());
    }
  };
  ye();
  var r = bl(), b = S(r);
  He(b, { size: "S", name: "copy" }), z(r), Ve("click", r, It(a)), v(M, r), pe();
}
var yl = T('<div class="svelte-10fvnlm"><!></div>');
function pl(M, t) {
  we(t, !1);
  const i = f(), a = f(), r = f();
  let b = l(t, "row", 8), m = l(t, "schema", 8), w = l(t, "value", 8), R = l(t, "customRenderers", 24, () => []), D = l(t, "snippets", 8), H = f();
  const k = {
    boolean: ol,
    datetime: nl,
    link: St,
    attachment: fl,
    string: Ge,
    options: Ge,
    number: Ge,
    longform: Ge,
    array: _l,
    internal: wl,
    bb_reference: St
  }, y = (x) => x?.type === "datetime" && x?.template ? "string" : x?.type || "string", d = (x, L) => L ? Nt(L, { value: x, snippets: D() }) : x;
  h(() => s(m()), () => {
    u(i, y(m()));
  }), h(
    () => (s(R()), s(m())),
    () => {
      u(a, R()?.find((x) => x.column === m()?.name));
    }
  ), h(() => (e(a), e(i), Ge), () => {
    u(H, e(a)?.component ?? k[e(i)] ?? Ge);
  }), h(() => (s(w()), s(m())), () => {
    u(r, d(w(), m().template));
  }), Oe(), ye();
  var g = he(), B = ae(g);
  {
    var F = (x) => {
      var L = yl(), O = S(L);
      Yt(O, () => e(H), (se, ee) => {
        ee(se, {
          get row() {
            return b();
          },
          get schema() {
            return m();
          },
          get value() {
            return e(r);
          },
          $$events: {
            clickrelationship(J) {
              ot.call(this, t, J);
            },
            buttonclick(J) {
              ot.call(this, t, J);
            }
          },
          children: (J, qe) => {
            var G = he(), Qe = ae(G);
            Be(Qe, t, "default", {}, null), v(J, G);
          },
          $$slots: { default: !0 }
        });
      }), z(L), P(() => Xe(L, `--max-cell-width: ${s(m()), p(() => m().width ? "none" : "200px") ?? ""};`)), v(x, L);
    };
    N(B, (x) => {
      e(H) && (e(a) || e(r) != null && e(r) !== "") && x(F);
    });
  }
  v(M, g), pe();
}
var Cl = T('<div class="svelte-34xm6e"><!> <!></div>');
function zt(M, t) {
  we(t, !1);
  let i = l(t, "selected", 8), a = l(t, "onEdit", 8), r = l(t, "allowSelectRows", 8, !1), b = l(t, "allowEditRows", 8, !1), m = l(t, "data", 8);
  ye();
  var w = Cl(), R = S(w);
  {
    var D = (y) => {
      bt(y, {
        get value() {
          return i();
        },
        get disabled() {
          return s(m()), p(() => m().__disabled);
        }
      });
    };
    N(R, (y) => {
      s(r()), s(m()), p(() => r() && m().__selectable !== !1) && y(D);
    });
  }
  var H = te(R, 2);
  {
    var k = (y) => {
      Ft(y, {
        size: "S",
        $$events: {
          click(...d) {
            a()?.apply(this, d);
          }
        },
        children: (d, g) => {
          gt();
          var B = Ue("Edit");
          v(d, B);
        },
        $$slots: { default: !0 }
      });
    };
    N(H, (y) => {
      b() && y(k);
    });
  }
  z(w), v(M, w), pe();
}
var xl = T('<div class="loading svelte-1qzi7hd"><!></div>'), Rl = T("<div><!></div>"), kl = T('<div><div class="title svelte-1qzi7hd"> <!> <!> <!></div></div>'), Sl = T("<div><!></div>"), zl = T('<div class="spectrum-Table-head svelte-1qzi7hd"><!> <!> <!></div>'), Tl = T("<div><!></div>"), El = T("<div><!></div>"), Pl = T("<div><!></div>"), ql = T("<div><!> <!> <!></div>"), Al = T('<div class="placeholder-content svelte-1qzi7hd"><!> <div class="svelte-1qzi7hd"> </div></div>'), Ll = T("<div><!></div>"), Dl = T("<div><!> <!></div>"), Ml = T("<div><!></div>");
function Hl(M, t) {
  we(t, !1);
  const i = f(), a = f(), r = f(), b = f(), m = f(), w = f(), R = f(), D = f(), H = f(), k = f(), y = f();
  let d = l(t, "data", 24, () => []), g = l(t, "schema", 28, () => ({})), B = l(t, "showAutoColumns", 8, !1), F = l(t, "rowCount", 8, 0), x = l(t, "quiet", 8, !1), L = l(t, "loading", 8, !1), O = l(t, "allowSelectRows", 8, !1), se = l(t, "allowEditRows", 8, !0), ee = l(t, "allowEditColumns", 8, !0), J = l(t, "allowClickRows", 8, !0), qe = l(t, "selectOnRowClick", 8, !0), G = l(t, "selectedRows", 28, () => []), Qe = l(t, "customRenderers", 24, () => []), st = l(t, "disableSorting", 8, !1), nt = l(t, "autoSortColumns", 8, !0), Ze = l(t, "compact", 8, !1), it = l(t, "customPlaceholder", 8, !1), ze = l(t, "showHeaderBorder", 8, !0), xe = l(t, "hideHeader", 8, !1), ft = l(t, "placeholderText", 8, "No rows found"), ct = l(t, "snippets", 24, () => []), mt = l(t, "defaultSortColumn", 24, () => {
  }), V = l(t, "defaultSortOrder", 8, "Ascending"), dt = l(t, "rounded", 8, !1), ht = l(t, "stickyHeader", 8, !0), Te = l(t, "editColumnPosition", 8, "left"), Ie = l(t, "editColumnHeader", 8, "Edit");
  const je = Tt();
  let $e = f();
  const ut = 36;
  let re = f(), _e = f(), et = f(0), tt = f(!1), Ae = f(!1);
  const q = (c) => {
    let o = {};
    return Object.entries(c || {}).forEach(([n, A]) => {
      typeof A == "string" ? o[n] = { type: A, name: n } : o[n] = { ...A, name: n };
      const Y = o[n].width;
      Y != null && `${Y}`.trim().match(/^[0-9]+$/) && delete o[n].width;
    }), o;
  }, Z = (c, o, n, A, Y) => c ? A ? Math.min(n, A) : Math.min(n, Math.ceil(o / Y)) : A || 0, Ee = (c, o, n, A, Y, W) => Y ? `height: ${W + c * A}px;` : !o || !c || n <= o ? "" : `height: ${W + c * A}px;`, ne = (c, o, n, A) => {
    let Y = "grid-template-columns:";
    return n && A === "left" && (Y += " auto"), c?.forEach((W) => {
      const E = o[W];
      E.width && typeof E.width == "string" ? Y += ` ${E.width}` : Y += " minmax(auto, 1fr)";
    }), n && A === "right" && (Y += " auto"), Y += ";", Y;
  }, fe = (c, o, n) => (o = o ?? mt(), n = n ?? V(), !o || !n || st() ? c : c.slice().sort((A, Y) => {
    const W = A[o], E = Y[o];
    return n === "Descending" ? W > E ? -1 : 1 : W > E ? 1 : -1;
  })), le = (c) => {
    st() || c.sortable !== !1 && (c.name === e(re) ? u(_e, e(_e) === "Descending" ? "Ascending" : "Descending") : (u(re, c.name), u(_e, "Descending")), je("sort", { column: e(re), order: e(_e) }));
  }, lt = (c) => {
    let o = c?.displayName;
    return c && o === void 0 && (o = c.name), o || "";
  }, Re = (c, o, n) => {
    let A = [], Y = [];
    return Object.entries(c || {}).forEach(([W, E]) => {
      !W || !E || (!n || !E?.autocolumn ? A.push(E) : o && Y.push(E));
    }), A.sort((W, E) => {
      if (W.divider)
        return W;
      if (E.divider)
        return E;
      const ie = W.order || Number.MAX_SAFE_INTEGER, De = E.order || Number.MAX_SAFE_INTEGER, Ye = lt(W), _t = lt(E);
      return ie !== De ? ie < De ? W : E : Ye < _t ? W : E;
    }).concat(Y).map((W) => W.name);
  }, ke = (c, o) => {
    c.stopPropagation(), je("editcolumn", o);
  }, Ne = (c, o) => {
    c.stopPropagation(), je("editrow", Jt(o));
  }, Le = (c) => {
    O() && (G().some((o) => o._id === c._id) ? G(G().filter((o) => o._id !== c._id)) : G([...G(), c]));
  }, wt = (c) => {
    if (!!c.detail) {
      const n = [...G()];
      e(r).forEach((A) => {
        A.__selectable !== !1 && n.findIndex((Y) => Y._id === A._id) === -1 && n.push(A);
      }), G(n);
    } else
      G(G().filter((n) => e(r).every((A) => A._id !== n._id)));
  }, Pt = (c) => {
    let o = {};
    return Object.keys(c || {}).forEach((n) => {
      o[n] = "", c[n].color && (o[n] += `color: ${c[n].color};`), c[n].background && (o[n] += `background-color: ${c[n].background};`), c[n].align === "Center" && (o[n] += "justify-content: center; text-align: center;"), c[n].align === "Right" && (o[n] += "justify-content: flex-end; text-align: right;"), c[n].borderLeft && (o[n] += "border-left: 1px solid var(--spectrum-global-color-gray-200);"), c[n].borderLeft && (o[n] += "border-right: 1px solid var(--spectrum-global-color-gray-200);"), c[n].minWidth && (o[n] += `min-width: ${c[n].minWidth};`);
    }), o;
  }, qt = (c) => {
    const o = new ResizeObserver((n) => {
      if (!n?.[0])
        return;
      const A = n[0].target.getBoundingClientRect();
      u(et, A.height);
    });
    return o.observe(c), o;
  };
  Gt(() => {
    let c = qt(e($e));
    return () => {
      c.disconnect();
    };
  }), h(() => s(Ze()), () => {
    u(i, Ze() ? 46 : 55);
  }), h(() => s(g()), () => {
    g(q(g()));
  }), h(() => s(L()), () => {
    L() || u(tt, !0);
  }), h(
    () => (s(g()), s(B()), s(nt())),
    () => {
      u(a, Re(g(), B(), nt()));
    }
  ), h(() => (e(a), s(d())), () => {
    u(r, e(a)?.length ? d() || [] : []);
  }), h(() => e(r), () => {
    u(b, e(r)?.length || 0);
  }), h(
    () => (e(tt), e(et), e(r), s(F()), e(i)),
    () => {
      u(m, Z(e(tt), e(et), e(r).length, F(), e(i)));
    }
  ), h(() => s(xe()), () => {
    u(w, xe() ? 0 : ut);
  }), h(
    () => (e(m), s(F()), e(b), e(i), s(L()), e(w)),
    () => {
      u(R, Ee(e(m), F(), e(b), e(i), L(), e(w)));
    }
  ), h(() => (e(r), e(re), e(_e)), () => {
    u(D, fe(e(r), e(re), e(_e)));
  }), h(
    () => (s(se()), s(O())),
    () => {
      u(k, se() || O());
    }
  ), h(
    () => (e(a), s(g()), e(k), s(Te())),
    () => {
      u(H, ne(e(a), g(), e(k), Te()));
    }
  ), h(() => s(g()), () => {
    u(y, Pt(g()));
  }), h(() => (e(r), s(G())), () => {
    e(r).filter((o) => G().some((n) => o._id === n._id)).length === 0 && u(Ae, !1);
  }), Oe(), ye();
  var yt = he(), At = ae(yt);
  Xt(At, () => (e(a), p(() => e(a)?.length)), (c) => {
    var o = Ml();
    let n;
    var A = S(o);
    {
      var Y = (E) => {
        var ie = xl(), De = S(ie);
        Be(De, t, "loadingIndicator", {}, (Ye) => {
          Wt(Ye, {});
        }), z(ie), P(() => Xe(ie, e(R))), v(E, ie);
      }, W = (E) => {
        var ie = Dl();
        let De;
        var Ye = S(ie);
        {
          var _t = (me) => {
            var be = zl(), Me = S(be);
            {
              var at = (K) => {
                var C = Rl();
                let $;
                var Ce = S(C);
                {
                  var Se = (_) => {
                    bt(_, {
                      get value() {
                        return e(Ae);
                      },
                      set value(j) {
                        u(Ae, j);
                      },
                      $$events: { change: wt },
                      $$legacy: !0
                    });
                  }, Q = (_) => {
                    var j = he(), de = ae(j);
                    {
                      var U = (X) => {
                        var ue = Ue();
                        P(() => ge(ue, Ie())), v(X, ue);
                      };
                      N(
                        de,
                        (X) => {
                          Ie() && X(U);
                        },
                        !0
                      );
                    }
                    v(_, j);
                  };
                  N(Ce, (_) => {
                    O() ? _(Se) : _(Q, !1);
                  });
                }
                z(C), P((_) => $ = ve(C, 1, "spectrum-Table-headCell spectrum-Table-headCell--divider spectrum-Table-headCell--edit spectrum-Table-headCell--editLeft svelte-1qzi7hd", null, $, _), [() => ({ noBorderHeader: !ze() })]), v(K, C);
              };
              N(Me, (K) => {
                e(k) && Te() === "left" && K(at);
              });
            }
            var I = te(Me, 2);
            We(I, 1, () => e(a), Je, (K, C) => {
              var $ = kl();
              let Ce;
              var Se = S($), Q = S(Se), _ = te(Q);
              {
                var j = (oe) => {
                  He(oe, {
                    name: "magic-wand",
                    size: "S",
                    color: "var(--spectrum-global-color-gray-600)"
                  });
                };
                N(_, (oe) => {
                  s(g()), e(C), p(() => g()[e(C)]?.autocolumn) && oe(j);
                });
              }
              var de = te(_, 2);
              {
                var U = (oe) => {
                  He(oe, {
                    name: "caret-down",
                    size: "S",
                    color: "var(--spectrum-global-color-gray-700)"
                  });
                };
                N(de, (oe) => {
                  e(re) === e(C) && oe(U);
                });
              }
              var X = te(de, 2);
              {
                var ue = (oe) => {
                  He(oe, {
                    name: "pencil",
                    size: "S",
                    hoverable: !0,
                    color: "var(--spectrum-global-color-gray-600)",
                    hoverColor: "var(--spectrum-global-color-gray-900)",
                    $$events: { click: (Fe) => ke(Fe, e(C)) }
                  });
                };
                N(X, (oe) => {
                  s(ee()), s(g()), e(C), p(() => ee() && g()[e(C)]?.editable !== !1) && oe(ue);
                });
              }
              z(Se), z($), P(
                (oe, Fe) => {
                  Ce = ve($, 1, "spectrum-Table-headCell svelte-1qzi7hd", null, Ce, oe), rt(Se, "title", e(C)), ge(Q, `${Fe ?? ""} `);
                },
                [
                  () => ({
                    noBorderHeader: !ze(),
                    "spectrum-Table-headCell--alignCenter": g()[e(C)].align === "Center",
                    "spectrum-Table-headCell--alignRight": g()[e(C)].align === "Right",
                    "is-sortable": g()[e(C)].sortable !== !1,
                    "is-sorted-desc": e(re) === e(C) && e(_e) === "Descending",
                    "is-sorted-asc": e(re) === e(C) && e(_e) === "Ascending"
                  }),
                  () => (s(g()), e(C), p(() => lt(g()[e(C)])))
                ]
              ), Ve("click", $, () => le(g()[e(C)])), v(K, $);
            });
            var Pe = te(I, 2);
            {
              var ce = (K) => {
                var C = Sl();
                let $;
                var Ce = S(C);
                {
                  var Se = (_) => {
                    bt(_, {
                      get value() {
                        return e(Ae);
                      },
                      set value(j) {
                        u(Ae, j);
                      },
                      $$events: { change: wt },
                      $$legacy: !0
                    });
                  }, Q = (_) => {
                    var j = he(), de = ae(j);
                    {
                      var U = (X) => {
                        var ue = Ue();
                        P(() => ge(ue, Ie())), v(X, ue);
                      };
                      N(
                        de,
                        (X) => {
                          Ie() && X(U);
                        },
                        !0
                      );
                    }
                    v(_, j);
                  };
                  N(Ce, (_) => {
                    O() ? _(Se) : _(Q, !1);
                  });
                }
                z(C), P((_) => $ = ve(C, 1, "spectrum-Table-headCell spectrum-Table-headCell--divider spectrum-Table-headCell--edit spectrum-Table-headCell--editRight svelte-1qzi7hd", null, $, _), [() => ({ noBorderHeader: !ze() })]), v(K, C);
              };
              N(Pe, (K) => {
                e(k) && Te() === "right" && K(ce);
              });
            }
            z(be), v(me, be);
          };
          N(Ye, (me) => {
            e(a), s(xe()), p(() => e(a).length && !xe()) && me(_t);
          });
        }
        var Lt = te(Ye, 2);
        {
          var Dt = (me) => {
            var be = he(), Me = ae(be);
            We(Me, 1, () => e(D), Je, (at, I) => {
              var Pe = ql();
              let ce;
              var K = S(Pe);
              {
                var C = (Q) => {
                  var _ = Tl();
                  let j;
                  var de = S(_);
                  {
                    let U = Ke(() => (s(G()), e(I), p(() => G().findIndex((X) => X._id === e(I)._id) !== -1)));
                    zt(de, {
                      get data() {
                        return e(I);
                      },
                      get selected() {
                        return e(U);
                      },
                      onEdit: (X) => Ne(X, e(I)),
                      get allowSelectRows() {
                        return O();
                      },
                      get allowEditRows() {
                        return se();
                      }
                    });
                  }
                  z(_), P((U) => j = ve(_, 1, "spectrum-Table-cell spectrum-Table-cell--divider spectrum-Table-cell--edit spectrum-Table-cell--editLeft svelte-1qzi7hd", null, j, U), [() => ({ noBorderCheckbox: !ze() })]), Ve("click", _, (U) => {
                    e(I).__selectable !== !1 && (Le(e(I)), U.stopPropagation());
                  }), v(Q, _);
                };
                N(K, (Q) => {
                  e(k) && Te() === "left" && Q(C);
                });
              }
              var $ = te(K, 2);
              We($, 1, () => e(a), Je, (Q, _) => {
                var j = El();
                let de;
                var U = S(j);
                {
                  let X = Ke(() => (s(Rt), e(I), e(_), p(() => Rt(e(I), e(_)))));
                  pl(U, {
                    get customRenderers() {
                      return Qe();
                    },
                    get row() {
                      return e(I);
                    },
                    get snippets() {
                      return ct();
                    },
                    get schema() {
                      return s(g()), e(_), p(() => g()[e(_)]);
                    },
                    get value() {
                      return e(X);
                    },
                    $$events: {
                      clickrelationship(ue) {
                        ot.call(this, t, ue);
                      },
                      buttonclick(ue) {
                        ot.call(this, t, ue);
                      }
                    },
                    children: (ue, oe) => {
                      var Fe = he(), Ht = ae(Fe);
                      Be(Ht, t, "default", {}, null), v(ue, Fe);
                    },
                    $$slots: { default: !0 }
                  });
                }
                z(j), P(
                  (X) => {
                    de = ve(j, 1, "spectrum-Table-cell svelte-1qzi7hd", null, de, X), Xe(j, (e(y), e(_), p(() => e(y)[e(_)])));
                  },
                  [
                    () => ({
                      "spectrum-Table-cell--divider": !!g()[e(_)].divider
                    })
                  ]
                ), Ve("click", j, () => {
                  !g()[e(_)]?.preventSelectRow && (J() || e(I).__clickable) && (je("click", e(I)), qe() && Le(e(I)));
                }), v(Q, j);
              });
              var Ce = te($, 2);
              {
                var Se = (Q) => {
                  var _ = Pl();
                  let j;
                  var de = S(_);
                  {
                    let U = Ke(() => (s(G()), e(I), p(() => G().some((X) => X._id === e(I)._id))));
                    zt(de, {
                      get data() {
                        return e(I);
                      },
                      get selected() {
                        return e(U);
                      },
                      onEdit: (X) => Ne(X, e(I)),
                      get allowSelectRows() {
                        return O();
                      },
                      get allowEditRows() {
                        return se();
                      }
                    });
                  }
                  z(_), P((U) => j = ve(_, 1, "spectrum-Table-cell spectrum-Table-cell--divider spectrum-Table-cell--edit spectrum-Table-cell--editRight svelte-1qzi7hd", null, j, U), [() => ({ noBorderCheckbox: !ze() })]), Ve("click", _, (U) => {
                    e(I).__selectable !== !1 && (Le(e(I)), U.stopPropagation());
                  }), v(Q, _);
                };
                N(Ce, (Q) => {
                  e(k) && Te() === "right" && Q(Se);
                });
              }
              z(Pe), P((Q) => ce = ve(Pe, 1, "spectrum-Table-row svelte-1qzi7hd", null, ce, Q), [
                () => ({ clickable: J() || !!e(I).__clickable })
              ]), v(at, Pe);
            }), v(me, be);
          }, Mt = (me) => {
            var be = Ll();
            let Me;
            var at = S(be);
            {
              var I = (ce) => {
                var K = he(), C = ae(K);
                Be(C, t, "placeholder", {}, null), v(ce, K);
              }, Pe = (ce) => {
                var K = Al(), C = S(K);
                He(C, {
                  name: "table",
                  size: "XXL",
                  color: "var(--spectrum-global-color-gray-600)"
                });
                var $ = te(C, 2), Ce = S($, !0);
                z($), z(K), P(() => ge(Ce, ft())), v(ce, K);
              };
              N(at, (ce) => {
                it() ? ce(I) : ce(Pe, !1);
              });
            }
            z(be), P((ce) => Me = ve(be, 1, "placeholder svelte-1qzi7hd", null, Me, ce), [
              () => ({
                "placeholder--custom": it(),
                "placeholder--no-fields": !e(a)?.length
              })
            ]), v(me, be);
          };
          N(Lt, (me) => {
            e(D), p(() => e(D)?.length) ? me(Dt) : me(Mt, !1);
          });
        }
        z(ie), P(
          (me) => {
            De = ve(ie, 1, "spectrum-Table svelte-1qzi7hd", null, De, me), Xe(ie, `${e(R)}${e(H)}`);
          },
          [
            () => ({
              "no-scroll": !F(),
              rounded: dt(),
              "show-header": !xe()
            })
          ]
        ), v(E, ie);
      };
      N(A, (E) => {
        L() ? E(Y) : E(W, !1);
      });
    }
    z(o), Vt(o, (E) => u($e, E), () => e($e)), P(
      (E) => {
        n = ve(o, 1, "wrapper svelte-1qzi7hd", null, n, E), Xe(o, `--row-height: ${e(i)}px; --header-height: ${xe() ? 0 : ut}px;`);
      },
      [
        () => ({
          "wrapper--quiet": x(),
          "wrapper--compact": Ze(),
          "wrapper--sticky-header": ht()
        })
      ]
    ), v(c, o);
  }), v(M, yt), pe();
}
function Bl(M, t) {
  we(t, !1);
  let i = l(t, "row", 8);
  const { Provider: a, ContextScopes: r } = vt("sdk");
  ye(), a(M, {
    get data() {
      return i();
    },
    get scope() {
      return p(() => r.Local);
    },
    children: (b, m) => {
      var w = he(), R = ae(w);
      Be(R, t, "default", {}, null), v(b, w);
    },
    $$slots: { default: !0 }
  }), pe();
}
var Ol = T('<div class="row-count svelte-90j9v3"> </div>'), Il = T("<div><!> <!></div>");
function Yl(M, t) {
  we(t, !1);
  const i = () => kt(nt, "$context", r), a = () => kt(st, "$component", r), [r, b] = $t(), m = f(), w = f(), R = f(), D = f(), H = f(), k = f(), y = f(), d = f(), g = f(), B = f(), F = f();
  let x = l(t, "dataProvider", 8), L = l(t, "columns", 8), O = l(t, "rowCount", 8), se = l(t, "quiet", 8), ee = l(t, "size", 8), J = l(t, "allowSelectRows", 8), qe = l(t, "compact", 8), G = l(t, "onClick", 8), Qe = l(t, "noRowsMessage", 8);
  const st = vt("component"), nt = vt("context"), {
    styleable: Ze,
    getAction: it,
    ActionTypes: ze,
    rowSelectionStore: xe,
    generateGoldenSample: ft
  } = vt("sdk"), ct = `custom-${Math.random()}`, mt = [{ column: ct, component: Bl }];
  let V = f([]);
  const dt = () => ({ eventContext: { row: ft(e(D)) } }), ht = (q, Z, Ee, ne) => {
    if (Z?.length)
      return Z;
    let fe = [], le = [];
    return Object.entries(q).forEach(([Re, ke]) => {
      ke.visible !== !1 && (ke?.autocolumn || fe.push(Re));
    }), fe.concat(le).sort((Re, ke) => {
      if (Re === ne)
        return -1;
      if (ke === ne)
        return 1;
      const Ne = q[Re].order, Le = q[ke].order;
      return Ne === Le ? 0 : Ne == null ? 1 : Le == null || Ne < Le ? -1 : 1;
    });
  }, Te = (q, Z, Ee) => {
    let ne = {};
    return Ee && (ne[ct] = {
      displayName: null,
      order: 0,
      sortable: !1,
      divider: !0,
      width: "auto",
      preventSelectRow: !0
    }), Z.forEach((fe) => {
      const le = typeof fe == "string" ? fe : fe.name;
      q[le] && (ne[le] = q[le], tl(q[le]) || (ne[le].sortable = !1), typeof fe == "object" && (ne[le] = { ...ne[le], ...fe }));
    }), ne;
  }, Ie = (q) => {
    e(g)({ column: q.detail.column, order: q.detail.order });
  }, je = (q) => {
    G() && G()({ row: q.detail });
  }, $e = [
    {
      type: ze.ClearRowSelection,
      callback: () => u(V, [])
    }
  ];
  Kt(() => {
    xe.actions.updateSelection(a().id, []);
  }), h(() => i(), () => {
    u(m, i().snippets);
  }), h(() => a(), () => {
    u(w, a().children);
  }), h(() => s(x()), () => {
    u(R, x()?.loading ?? !1);
  }), h(() => s(x()), () => {
    u(D, x()?.rows || []);
  }), h(() => s(x()), () => {
    u(H, x()?.schema ?? {});
  }), h(() => s(x()), () => {
    u(k, x()?.primaryDisplay);
  }), h(
    () => (e(H), s(L()), e(k)),
    () => {
      u(y, ht(e(H), L(), !1, e(k)));
    }
  ), h(() => (e(H), e(y), e(w)), () => {
    u(d, Te(e(H), e(y), e(w)));
  }), h(() => s(x()), () => {
    u(g, it(x()?.id, ze.SetDataProviderSorting));
  }), h(() => s(x()), () => {
    u(B, x()?.datasource?.type === "table");
  }), h(() => (e(D), e(V)), () => {
    if (e(D)) {
      let q = e(D).map((Z) => Z._id);
      q.length && u(V, e(V).filter((Z) => q.includes(Z._id)));
    }
  }), h(() => (a(), e(V)), () => {
    xe.actions.updateSelection(a().id, e(V).length ? e(V)[0].tableId : "", e(V).map((q) => q._id));
  }), h(() => e(V), () => {
    u(F, { selectedRows: e(V) });
  }), Oe();
  var ut = { getAdditionalDataContext: dt };
  ye();
  var re = Il(), _e = S(re);
  Ut(_e, {
    get actions() {
      return $e;
    },
    get data() {
      return e(F);
    },
    children: (q, Z) => {
      {
        let Ee = Ke(() => J() && e(B)), ne = Ke(() => (s(L()), p(() => !L()?.length))), fe = Ke(() => Qe() || "No rows found");
        Hl(q, {
          get data() {
            return e(D);
          },
          get schema() {
            return e(d);
          },
          get loading() {
            return e(R);
          },
          get rowCount() {
            return O();
          },
          get quiet() {
            return se();
          },
          get compact() {
            return qe();
          },
          get customRenderers() {
            return mt;
          },
          get snippets() {
            return e(m);
          },
          get allowSelectRows() {
            return e(Ee);
          },
          allowEditRows: !1,
          allowEditColumns: !1,
          showAutoColumns: !0,
          disableSorting: !0,
          get autoSortColumns() {
            return e(ne);
          },
          get placeholderText() {
            return e(fe);
          },
          get selectedRows() {
            return e(V);
          },
          set selectedRows(le) {
            u(V, le);
          },
          $$events: { sort: Ie, click: je },
          children: (le, lt) => {
            var Re = he(), ke = ae(Re);
            Be(ke, t, "default", {}, null), v(le, Re);
          },
          $$slots: { default: !0 },
          $$legacy: !0
        });
      }
    },
    $$slots: { default: !0 }
  });
  var et = te(_e, 2);
  {
    var tt = (q) => {
      var Z = Ol(), Ee = S(Z);
      z(Z), P(() => ge(Ee, `${e(V), p(() => e(V).length) ?? ""} row${e(V), p(() => e(V).length === 1 ? "" : "s") ?? ""} selected`)), v(q, Z);
    };
    N(et, (q) => {
      s(J()), e(V), p(() => J() && e(V).length) && q(tt);
    });
  }
  z(re), Qt(re, (q, Z) => Ze?.(q, Z), () => a().styles), P(() => ve(re, 1, el(ee()), "svelte-90j9v3")), v(M, re), Zt(t, "getAdditionalDataContext", dt);
  var Ae = pe(ut);
  return b(), Ae;
}
export {
  Yl as default
};
