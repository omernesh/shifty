import { g as jt, p as r, h as q, l as m, i as a, j as t, k as Gt, m as Qt, n as dt, q as C, u as L, d as y, _ as Vt, w as Et, z as o, aR as ct, B as i, Q as Jt, R as s, A as h, s as N, H as d, cz as U, S as Kt, f as W } from "./index-CMyk0zjR.js";
import { e as Xt, a as Yt } from "./blocks-BhLb4SfE.js";
var Zt = W("<!> <!>", 1), $t = W("<!> <!>", 1), te = W("<!> <!>", 1);
function ae(ut, e) {
  jt(e, !1);
  const j = o(), G = o(), Q = o(), V = o();
  let w = r(e, "title", 8), x = r(e, "dataSource", 8), E = r(e, "searchColumns", 8), J = r(e, "filter", 8), gt = r(e, "sortColumn", 8), mt = r(e, "sortOrder", 8), ht = r(e, "paginate", 8), ft = r(e, "limit", 8), M = r(e, "showTitleButton", 8), pt = r(e, "titleButtonText", 8), K = r(e, "titleButtonURL", 8), X = r(e, "titleButtonPeek", 8), vt = r(e, "cardTitle", 8), _t = r(e, "cardSubtitle", 8), kt = r(e, "cardDescription", 8), Ct = r(e, "cardImageURL", 8), Y = r(e, "linkCardTitle", 8), Z = r(e, "cardURL", 8), yt = r(e, "cardPeek", 8), O = r(e, "cardHorizontal", 8), wt = r(e, "showCardButton", 8), xt = r(e, "cardButtonText", 8), Bt = r(e, "cardButtonOnClick", 8), $ = r(e, "linkColumn", 8), tt = r(e, "noRowsMessage", 8), Rt = r(e, "autoRefresh", 8);
  const Pt = q("context"), { fetchDatasourceSchema: Tt, generateGoldenSample: bt } = q("sdk"), St = q("component");
  let B = o(), f = o(), R = o(), z = o(), n = o(), et = o(!1);
  const rt = () => {
    const l = ct(Pt)[t(f)]?.rows || [], c = bt(l);
    return { [`${ct(St).id}-repeater`]: c };
  }, At = (l, c, P, D) => {
    if (!l || !c || !P)
      return null;
    const p = D || "_id", H = c.split("/:");
    return H.length > 1 ? `${H[0]}/{{ ${U(P)}.${U(p)} }}` : c;
  }, Lt = async (l) => {
    l && i(z, await Tt(l, { enrichRelationships: !0 })), i(et, !0);
  };
  m(() => a(x()), () => {
    Lt(x());
  }), m(
    () => (a(E()), t(z)),
    () => {
      Xt(E(), t(z)).then((l) => i(n, l));
    }
  ), m(
    () => (a(J()), t(n), t(B)),
    () => {
      i(j, Yt(J(), t(n), t(B)));
    }
  ), m(() => a(O()), () => {
    i(G, O() ? 420 : 300);
  }), m(
    () => (a(Y()), a(Z()), t(R), a($())),
    () => {
      i(Q, At(Y(), Z(), t(R), $()));
    }
  ), m(
    () => (a(X()), a(K())),
    () => {
      i(V, [
        {
          "##eventHandlerType": "Navigate To",
          parameters: { peek: X(), url: K() }
        }
      ]);
    }
  ), Gt();
  var Ut = { getAdditionalDataContext: rt };
  Qt();
  var at = dt(), Mt = C(at);
  {
    var Ot = (l) => {
      Jt(l, {
        children: (c, P) => {
          {
            let D = d(() => ({ dataSource: x(), disableSchemaValidation: !0 }));
            s(c, {
              type: "form",
              get props() {
                return t(D);
              },
              get id() {
                return t(B);
              },
              set id(p) {
                i(B, p);
              },
              children: (p, H) => {
                var lt = te(), nt = C(lt);
                {
                  var zt = (v) => {
                    s(v, {
                      type: "container",
                      props: {
                        direction: "row",
                        hAlign: "stretch",
                        vAlign: "middle",
                        gap: "M",
                        wrap: !0
                      },
                      styles: { normal: { "margin-bottom": "20px" } },
                      order: 0,
                      children: (_, Ht) => {
                        var T = $t(), b = C(T);
                        {
                          let S = d(() => ({ text: w() ? `## ${w()}` : "" }));
                          s(b, {
                            type: "textv2",
                            get props() {
                              return t(S);
                            },
                            order: 0
                          });
                        }
                        var k = N(b, 2);
                        s(k, {
                          type: "container",
                          props: {
                            direction: "row",
                            hAlign: "left",
                            vAlign: "middle",
                            gap: "M",
                            wrap: !0
                          },
                          order: 1,
                          children: (S, ot) => {
                            var it = Zt(), st = C(it);
                            {
                              var It = (u) => {
                                var A = dt(), I = C(A);
                                Kt(I, 3, () => t(n), (F) => F.name, (F, g, Nt) => {
                                  {
                                    let Wt = d(() => (t(g), h(() => ({
                                      field: t(g).name,
                                      placeholder: t(g).name,
                                      text: t(g).name,
                                      autoWidth: !0
                                    }))));
                                    s(F, {
                                      get type() {
                                        return t(g), h(() => t(g).componentType);
                                      },
                                      get props() {
                                        return t(Wt);
                                      },
                                      get order() {
                                        return t(Nt);
                                      },
                                      styles: { normal: { width: "192px" } }
                                    });
                                  }
                                }), y(u, A);
                              };
                              L(st, (u) => {
                                t(n), h(() => t(n)?.length) && u(It);
                              });
                            }
                            var Ft = N(st, 2);
                            {
                              var qt = (u) => {
                                {
                                  let A = d(() => ({
                                    onClick: t(V),
                                    text: pt(),
                                    type: "cta"
                                  })), I = d(() => (t(n), h(() => t(n)?.length ?? 0)));
                                  s(u, {
                                    type: "button",
                                    get props() {
                                      return t(A);
                                    },
                                    get order() {
                                      return t(I);
                                    }
                                  });
                                }
                              };
                              L(Ft, (u) => {
                                M() && u(qt);
                              });
                            }
                            y(S, it);
                          },
                          $$slots: { default: !0 }
                        }), y(_, T);
                      },
                      $$slots: { default: !0 }
                    });
                  };
                  L(nt, (v) => {
                    a(w()), t(n), a(M()), h(() => w() || t(n)?.length || M()) && v(zt);
                  });
                }
                var Dt = N(nt, 2);
                {
                  let v = d(() => ({
                    dataSource: x(),
                    filter: t(j),
                    sortColumn: gt(),
                    sortOrder: mt(),
                    paginate: ht(),
                    limit: ft(),
                    autoRefresh: Rt()
                  }));
                  s(Dt, {
                    type: "dataprovider",
                    get props() {
                      return t(v);
                    },
                    order: 1,
                    get id() {
                      return t(f);
                    },
                    set id(_) {
                      i(f, _);
                    },
                    children: (_, Ht) => {
                      {
                        let T = d(() => (a(U), t(f), a(tt()), h(() => ({
                          dataProvider: `{{ literal ${U(t(f))} }}`,
                          direction: "row",
                          hAlign: "stretch",
                          vAlign: "top",
                          gap: "M",
                          noRowsMessage: tt() || "No rows found"
                        })))), b = d(() => ({
                          custom: `display: grid;
grid-template-columns: repeat(auto-fill, minmax(min(${t(G)}px, 100%), 1fr));`
                        }));
                        s(_, {
                          type: "repeater",
                          context: "repeater",
                          get props() {
                            return t(T);
                          },
                          get styles() {
                            return t(b);
                          },
                          order: 0,
                          get id() {
                            return t(R);
                          },
                          set id(k) {
                            i(R, k);
                          },
                          children: (k, S) => {
                            {
                              let ot = d(() => ({
                                title: vt(),
                                subtitle: _t(),
                                description: kt(),
                                imageURL: Ct(),
                                horizontal: O(),
                                showButton: wt(),
                                buttonText: xt(),
                                buttonOnClick: Bt(),
                                linkURL: t(Q),
                                linkPeek: yt()
                              }));
                              s(k, {
                                type: "spectrumcard",
                                get props() {
                                  return t(ot);
                                },
                                styles: { normal: { width: "auto" } },
                                order: 0
                              });
                            }
                          },
                          $$slots: { default: !0 },
                          $$legacy: !0
                        });
                      }
                    },
                    $$slots: { default: !0 },
                    $$legacy: !0
                  });
                }
                y(p, lt);
              },
              $$slots: { default: !0 },
              $$legacy: !0
            });
          }
        },
        $$slots: { default: !0 }
      });
    };
    L(Mt, (l) => {
      t(et) && l(Ot);
    });
  }
  return y(ut, at), Vt(e, "getAdditionalDataContext", rt), Et(Ut);
}
export {
  ae as default
};
