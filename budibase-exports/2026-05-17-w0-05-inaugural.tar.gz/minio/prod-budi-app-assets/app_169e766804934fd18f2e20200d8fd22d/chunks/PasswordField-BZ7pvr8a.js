import { bJ as o, cw as p } from "./index-CMyk0zjR.js";
import t from "./StringField-DqsD-SN7.js";
function d(s, r) {
  const e = o(r, ["children", "$$slots", "$$events", "$$legacy"]);
  t(s, p(() => e, { type: "password" }));
}
export {
  d as default
};
