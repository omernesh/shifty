import { g as V, aI as s, p, h as E, z as r, o as $, l as d, i as P, j as t, k as q, m as z, aJ as B, B as c, v as C, d as J, w as S, x as T, y as F, c as G, f as H, r as K } from "./index-CMyk0zjR.js";
import { u as M } from "./utc-Dj9ZRWnW.js";
var N = H("<div><!></div>");
function W(D, i) {
  V(i, !1);
  const l = () => T(A, "$component", k), [k, w] = F(), n = r(), f = r(), h = r(), m = r();
  s.extend(M);
  let g = p(i, "dataProvider", 8), v = p(i, "field", 8), L = p(i, "defaultValue", 8);
  const A = E("component"), { styleable: Q, ActionTypes: _, getAction: x } = E("sdk"), b = [
    "Last 1 day",
    "Last 7 days",
    "Last 30 days",
    "Last 3 months",
    "Last 6 months",
    "Last 1 year"
  ];
  let u = r(b.includes(L()) ? L() : "Last 30 days");
  const j = (a, e) => {
    if (!a || !e)
      return null;
    let o = s.utc().subtract(1, "year"), R = s.utc().add(1, "day");
    return e === "Last 1 day" ? o = s.utc().subtract(1, "day") : e === "Last 7 days" ? o = s.utc().subtract(7, "days") : e === "Last 30 days" ? o = s.utc().subtract(30, "days") : e === "Last 3 months" ? o = s.utc().subtract(3, "months") : e === "Last 6 months" && (o = s.utc().subtract(6, "months")), {
      range: { [a]: { low: o.format(), high: R.format() } }
    };
  };
  $(() => {
    t(h)?.(l().id);
  }), d(() => P(g()), () => {
    c(n, g()?.id);
  }), d(() => t(n), () => {
    c(f, x(t(n), _.AddDataProviderQueryExtension));
  }), d(() => t(n), () => {
    c(h, x(t(n), _.RemoveDataProviderQueryExtension));
  }), d(() => (P(v()), t(u)), () => {
    c(m, j(v(), t(u)));
  }), d(() => (t(f), l(), t(m)), () => {
    t(f)?.(l().id, t(m));
  }), q(), z();
  var y = N(), I = G(y);
  B(I, {
    placeholder: null,
    get options() {
      return b;
    },
    get value() {
      return t(u);
    },
    $$events: { change: (a) => c(u, a.detail) }
  }), K(y), C(y, (a, e) => Q?.(a, e), () => l().styles), J(D, y), S(), w();
}
export {
  W as default
};
