import { g as Ge, p as l, $ as Ke, l as R, B as i, i as n, j as e, k as je, m as Ue, q as ge, c as f, a0 as Xt, r as u, s as S, I as Ye, X as yt, bT as Zt, u as oe, A as g, v as Kt, az as ea, t as Ae, a as Ve, d as _, ch as Bt, n as Te, S as Et, b as $e, e as Xe, T as Tt, a2 as Ft, a1 as ta, w as qe, z as b, H as re, f as K, cg as Wt, Y as We, aO as aa, y as Ot, cO as la, Z as ra, o as Gt, cP as At, _ as Lt, x as Ie, cQ as na, cR as sa, cS as oa, cT as ia, aC as wt, a3 as ot, a4 as it, E as vt, ap as zt, U as Nt, cU as Ut, a7 as dt, aR as qt, bK as da, cF as ua, D as ca, G as va, aJ as Ze, bt as Pt, cV as gt, aw as Ht, af as ft, b1 as z, cW as ga, bj as Mt, b0 as fa, h as Rt, cX as Dt, ae as pa, cH as ha, ci as pt, F as ba, bi as ma, cY as _a, ct as ya, C as Oa, at as wa, ad as xa, cZ as Aa, c_ as Ea } from "./index-CMyk0zjR.js";
import { D as Ta } from "./DatePicker-BNqrmSk4.js";
import { M as Fa } from "./Multiselect-BjsXMbjn.js";
import Ra from "./Button-XPjdZQUJ.js";
var Pa = K('<li role="option" aria-selected="true" tabindex="0"><span class="spectrum-Menu-itemLabel svelte-1mzui26"> </span> <div class="check svelte-1mzui26"><!></div></li>'), Ca = K('<li class="spectrum-Menu-item empty svelte-1mzui26">No results</li>'), Sa = K('<div><ul class="spectrum-Menu" role="listbox"><!></ul></div>'), Va = K('<div><div><input type="text" class="spectrum-Textfield-input spectrum-InputGroup-input svelte-1mzui26"/></div> <button class="spectrum-Picker spectrum-Picker--sizeM spectrum-InputGroup-button" tabindex="-1" aria-haspopup="true"><!></button></div> <!>', 1);
function ka(ee, t) {
  Ge(t, !1);
  const d = b();
  let p = l(t, "value", 24, () => {
  }), U = l(t, "id", 24, () => {
  }), v = l(t, "placeholder", 8, "Choose an option or type"), k = l(t, "disabled", 8, !1), r = l(t, "readonly", 8, !1), $ = l(t, "options", 24, () => []), y = l(t, "getOptionLabel", 8, (x) => `${x}`), q = l(t, "getOptionValue", 8, (x) => `${x}`), F = l(t, "popoverAutoWidth", 8, !1), H = l(t, "wrapText", 8, !1);
  const B = Ke();
  let m = b(!1), E = b(!1), ne = b(), V = b("");
  const te = (x) => x == null ? "" : String(x).toLowerCase(), se = (x, O = !0) => {
    B("change", x), i(m, !O);
  }, L = (x) => {
    const O = x.currentTarget.value;
    B("type", O), se(O, !1);
  }, o = (x) => {
    B("pick", x), se(x);
  };
  R(() => n(p()), () => {
    i(V, p() || "");
  }), R(
    () => (e(V), n($()), n(y()), n(q())),
    () => {
      i(d, !e(V).trim() || !$()?.length ? $() : $().filter((x) => {
        const O = te(y()(x)), j = te(q()(x)), h = te(e(V));
        return O.includes(h) || j.includes(h);
      }));
    }
  ), je(), Ue();
  var P = Va(), C = ge(P);
  let T;
  var I = f(C);
  let fe;
  var W = f(I);
  Xt(W), u(I);
  var N = S(I, 2), M = f(N);
  Ye(M, { name: "caret-down", size: "S" }), u(N), u(C), yt(C, (x) => i(ne, x), () => e(ne));
  var be = S(C, 2);
  {
    let x = re(() => F() ? "min-to-anchor" : "fixed-to-anchor"), O = re(() => F() ? 400 : void 0);
    Zt(be, {
      get anchor() {
        return e(ne);
      },
      get open() {
        return e(m);
      },
      get align() {
        return n(Bt), g(() => Bt.Left);
      },
      get widthMode() {
        return e(x);
      },
      get maxWidth() {
        return e(O);
      },
      closeOnScroll: !0,
      $$events: { close: () => i(m, !1) },
      children: (j, h) => {
        var A = Sa();
        let ie;
        var pe = f(A), ce = f(pe);
        {
          var Oe = (ae) => {
            var le = Te(), Fe = ge(le);
            Et(Fe, 1, () => e(d), Tt, (s, c) => {
              var a = Pa();
              let w;
              var G = f(a), J = f(G, !0);
              u(G);
              var me = S(G, 2), ke = f(me);
              Ye(ke, { name: "check", size: "S" }), u(me), u(a), Ae(
                (_e, xe) => {
                  w = Ve(a, 1, "spectrum-Menu-item svelte-1mzui26", null, w, _e), $e(J, xe);
                },
                [
                  () => ({ "is-selected": q()(e(c)) === p() }),
                  () => (n(y()), e(c), g(() => y()(e(c))))
                ]
              ), Xe("click", a, () => o(q()(e(c)))), _(s, a);
            }), _(ae, le);
          }, we = (ae) => {
            var le = Ca();
            _(ae, le);
          };
          oe(ce, (ae) => {
            e(d), g(() => e(d) && Array.isArray(e(d)) && e(d).length) ? ae(Oe) : ae(we, !1);
          });
        }
        u(pe), u(A), Kt(A, (ae, le) => ea?.(ae, le), () => () => {
          i(m, !1);
        }), Ae((ae) => ie = Ve(A, 1, "popover-content svelte-1mzui26", null, ie, ae), [
          () => ({ "auto-width": F(), "wrap-text": H() })
        ]), _(j, A);
      },
      $$slots: { default: !0 }
    });
  }
  Ae(
    (x, O) => {
      T = Ve(C, 1, "spectrum-InputGroup svelte-1mzui26", null, T, x), fe = Ve(I, 1, "spectrum-Textfield spectrum-InputGroup-textfield svelte-1mzui26", null, fe, O), Ft(W, "id", U()), ta(W, p() || ""), Ft(W, "placeholder", v() || ""), W.disabled = k(), W.readOnly = r(), N.disabled = k();
    },
    [
      () => ({
        "is-focused": e(m) || e(E),
        "is-disabled": k()
      }),
      () => ({
        "is-disabled": k(),
        "is-focused": e(m) || e(E)
      })
    ]
  ), Xe("focus", W, () => i(E, !0)), Xe("blur", W, () => {
    i(E, !1), B("blur");
  }), Xe("input", W, L), Xe("click", N, () => i(m, !e(m))), _(ee, P), qe();
}
function It(ee, t) {
  Ge(t, !1);
  let d = l(t, "value", 28, () => {
  }), p = l(t, "label", 24, () => {
  }), U = l(t, "disabled", 8, !1), v = l(t, "readonly", 8, !1), k = l(t, "labelPosition", 8, "above"), r = l(t, "error", 24, () => {
  }), $ = l(t, "placeholder", 8, "Choose an option or type"), y = l(t, "options", 24, () => []), q = l(t, "helpText", 24, () => {
  }), F = l(t, "required", 8, !1), H = l(t, "popoverAutoWidth", 8, !1), B = l(t, "wrapText", 8, !1);
  const m = (o, P) => {
    if (o && typeof o == "object" && P in o) {
      const T = o[P];
      return typeof T == "string" ? T : typeof T == "number" || typeof T == "boolean" ? String(T) : "";
    }
    return o == null ? "" : String(o);
  }, E = (o) => m(o, "label"), ne = (o) => m(o, "value");
  let V = l(t, "getOptionLabel", 8, E), te = l(t, "getOptionValue", 8, ne);
  const se = Ke(), L = (o) => {
    d(o.detail), se("change", o.detail);
  };
  Ue(), Wt(ee, {
    get helpText() {
      return q();
    },
    get label() {
      return p();
    },
    get labelPosition() {
      return k();
    },
    get error() {
      return r();
    },
    get required() {
      return F();
    },
    children: (o, P) => {
      ka(o, {
        get disabled() {
          return U();
        },
        get value() {
          return d();
        },
        get options() {
          return y();
        },
        get placeholder() {
          return $();
        },
        get readonly() {
          return v();
        },
        get getOptionLabel() {
          return V();
        },
        get getOptionValue() {
          return te();
        },
        get popoverAutoWidth() {
          return H();
        },
        get wrapText() {
          return B();
        },
        $$events: {
          change: L,
          pick(C) {
            We.call(this, t, C);
          },
          type(C) {
            We.call(this, t, C);
          },
          blur(C) {
            We.call(this, t, C);
          }
        }
      });
    },
    $$slots: { default: !0 }
  }), qe();
}
function $t(ee, t) {
  Ge(t, !1);
  const d = b();
  let p = l(t, "value", 28, () => []), U = l(t, "label", 24, () => {
  }), v = l(t, "disabled", 8, !1), k = l(t, "readonly", 8, !1), r = l(t, "labelPosition", 8, "above"), $ = l(t, "error", 24, () => {
  }), y = l(t, "placeholder", 24, () => {
  }), q = l(t, "options", 24, () => []), F = l(t, "getOptionLabel", 8, (I) => I), H = l(t, "getOptionValue", 8, (I) => I), B = l(t, "sort", 8, !1), m = l(t, "autoWidth", 8, !1), E = l(t, "popoverAutoWidth", 8, !1), ne = l(t, "autocomplete", 8, !1), V = l(t, "searchTerm", 28, () => {
  }), te = l(t, "customPopoverHeight", 24, () => {
  }), se = l(t, "helpText", 24, () => {
  }), L = l(t, "onOptionMouseenter", 8, () => {
  }), o = l(t, "onOptionMouseleave", 8, () => {
  }), P = l(t, "searchPlaceholder", 24, () => {
  });
  const C = Ke(), T = (I) => {
    p(I.detail), C("change", I.detail);
  };
  R(() => n(p()), () => {
    i(d, p() && !Array.isArray(p()) ? [p()] : p());
  }), je(), Ue(), Wt(ee, {
    get helpText() {
      return se();
    },
    get label() {
      return U();
    },
    get labelPosition() {
      return r();
    },
    get error() {
      return $();
    },
    children: (I, fe) => {
      Fa(I, {
        get disabled() {
          return v();
        },
        get readonly() {
          return k();
        },
        get options() {
          return q();
        },
        get placeholder() {
          return y();
        },
        get sort() {
          return B();
        },
        get getOptionLabel() {
          return F();
        },
        get getOptionValue() {
          return H();
        },
        get autoWidth() {
          return m();
        },
        get popoverAutoWidth() {
          return E();
        },
        get autocomplete() {
          return ne();
        },
        get customPopoverHeight() {
          return te();
        },
        get onOptionMouseenter() {
          return L();
        },
        get onOptionMouseleave() {
          return o();
        },
        get searchPlaceholder() {
          return P();
        },
        get value() {
          return e(d);
        },
        set value(W) {
          i(d, W);
        },
        get searchTerm() {
          return V();
        },
        set searchTerm(W) {
          V(W);
        },
        $$events: {
          change: T,
          click(W) {
            We.call(this, t, W);
          }
        },
        $$legacy: !0
      });
    },
    $$slots: { default: !0 }
  }), qe();
}
const Ba = "drawer-container", ht = dt([]), nt = dt(!1), bt = dt(!0), mt = dt(null), _t = dt(null);
let st;
const La = () => {
  const ee = document.getElementsByClassName(Ba)[0];
  if (st || !ee)
    return;
  st = new ResizeObserver((d) => {
    if (!d?.[0])
      return;
    const p = d[0].target.getBoundingClientRect();
    mt.set(p.left), _t.set(p.width);
  }), st.observe(ee);
  const t = ee.getBoundingClientRect();
  mt.set(t.left), _t.set(t.width);
}, za = () => {
  qt(ht).length || (st?.disconnect(), st = null, nt.set(!1), bt.set(!0), mt.set(null), _t.set(null));
};
var Na = K('<div class="text svelte-1189ub1"> </div>'), Ma = K('<div class="drawer-wrapper"><div></div> <div><header class="svelte-1189ub1"><!> <div class="buttons svelte-1189ub1"><!> <!> <!></div></header> <!> <div></div></div></div>');
function Yt(ee, t) {
  const d = aa(t);
  Ge(t, !1);
  const p = () => Ie(ht, "$openDrawers", y), U = () => Ie(na, "$overlayStack", y), v = () => Ie(mt, "$drawerLeft", y), k = () => Ie(_t, "$drawerWidth", y), r = () => Ie(nt, "$modal", y), $ = () => Ie(bt, "$resizable", y), [y, q] = Ot(), F = b(), H = b(), B = b(), m = b();
  let E = l(t, "title", 8, ""), ne = l(t, "forceModal", 8, !1), V = l(t, "zIndex", 8, void 0);
  const te = Ke(), se = 11;
  let L = b(!1), o = la.generate();
  const P = (h, A, ie, pe, ce) => {
    let Oe = `
      --scale-factor: ${N(h)};
      --spacing: ${se}px;
      ${ce != null ? `z-index: ${ce};` : ""}
    `;
    return pe || A == null || ie == null ? Oe : `
      ${Oe}
      left: ${A + se}px;
      width: ${ie - 2 * se}px;
    `;
  };
  function C() {
    e(L) || (ne() && (nt.set(!0), bt.set(!1)), La(), i(L, !0), te("drawerShow", o), ht.update((h) => [...h, o]), sa(o));
  }
  function T() {
    e(L) && (i(L, !1), te("drawerHide", o), ht.update((h) => h.filter((A) => A !== o)), oa(o), za());
  }
  ra("drawer", { hide: T, show: C, modal: nt, resizable: bt });
  const I = (h) => h < 0.5 ? 2 * h * h : 1 - Math.pow(-2 * h + 2, 2) / 2, fe = () => ({
    duration: 260,
    css: (h) => {
      const A = I(h);
      return `
          transform: translateY(calc(${(1 - A) * 200}px - 800px * (1 - var(--scale-factor))));
          opacity: ${A};
        `;
    }
  }), W = () => ({
    duration: 260,
    css: (h) => `opacity: ${I(h)};`
  }), N = (h) => 1 - (1 - 1 / (h * h + 1)) * 0.1;
  Gt(() => {
    e(L) && T();
  }), R(() => p(), () => {
    i(F, p().length - p().indexOf(o) - 1);
  }), R(() => U(), () => {
    i(H, U().indexOf(o));
  }), R(() => (n(V()), e(H), At), () => {
    i(B, V() ?? (e(H) === -1 ? At : At + e(H)));
  }), R(
    () => (e(F), v(), k(), r(), e(B)),
    () => {
      i(m, P(e(F), v(), k(), r(), e(B)));
    }
  ), je();
  var M = { show: C, hide: T };
  Ue();
  var be = Te(), x = ge(be);
  {
    var O = (h) => {
      ia(h, {
        target: ".modal-container",
        children: (A, ie) => {
          var pe = Ma(), ce = f(pe);
          let Oe;
          var we = S(ce, 2);
          let ae;
          var le = f(we), Fe = f(le);
          {
            var s = (D) => {
              var Y = Te(), he = ge(Y);
              vt(he, t, "title", {}, null), _(D, Y);
            }, c = (D) => {
              var Y = Na(), he = f(Y, !0);
              u(Y), Ae(() => $e(he, E() || "Bindings")), _(D, Y);
            };
            oe(Fe, (D) => {
              g(() => d.title) ? D(s) : D(c, !1);
            });
          }
          var a = S(Fe, 2), w = f(a);
          wt(w, {
            secondary: !0,
            quiet: !0,
            $$events: { click: T },
            children: (D, Y) => {
              ot();
              var he = it("Cancel");
              _(D, he);
            },
            $$slots: { default: !0 }
          });
          var G = S(w, 2);
          vt(G, t, "buttons", {}, null);
          var J = S(G, 2);
          {
            var me = (D) => {
              Ut(D, {
                size: "M",
                quiet: !0,
                get selected() {
                  return r();
                },
                $$events: { click: () => nt.set(!r()) },
                children: (Y, he) => {
                  {
                    let X = re(() => r() ? "arrows-in-simple" : "arrows-out-simple");
                    Ye(Y, {
                      get name() {
                        return e(X);
                      },
                      size: "S"
                    });
                  }
                },
                $$slots: { default: !0 }
              });
            };
            oe(J, (D) => {
              $() && D(me);
            });
          }
          u(a), u(le);
          var ke = S(le, 2);
          vt(ke, t, "body", {}, null);
          var _e = S(ke, 2);
          let xe;
          u(we), u(pe), Ae(
            (D, Y, he) => {
              Oe = Ve(ce, 1, "underlay svelte-1189ub1", null, Oe, D), zt(ce, `z-index: ${e(B) - 1}`), ae = Ve(we, 1, "drawer svelte-1189ub1", null, ae, Y), zt(we, e(m)), xe = Ve(_e, 1, "overlay svelte-1189ub1", null, xe, he);
            },
            [
              () => ({ hidden: !r() }),
              () => ({ stacked: e(F) > 0, modal: r() }),
              () => ({ hidden: r() || e(F) === 0 })
            ]
          ), Nt(3, ce, () => W), Nt(3, we, () => fe), _(A, pe);
        },
        $$slots: { default: !0 }
      });
    };
    oe(x, (h) => {
      e(L) && h(O);
    });
  }
  _(ee, be), Lt(t, "show", C), Lt(t, "hide", T);
  var j = qe(M);
  return q(), j;
}
var Da = K('<div class="user-control"><!></div>');
function Ia(ee, t) {
  Ge(t, !1);
  const d = () => Ie(e(v), "$fetch", p), [p, U] = Ot(), v = b(), k = b(), r = b();
  let $ = l(t, "API", 24, da), y = l(t, "value", 8, null), q = l(t, "disabled", 8), F = l(t, "multiselect", 8, !1);
  const H = ua("picker");
  R(() => n($()), () => {
    ca(
      i(v, va({
        API: $(),
        datasource: { type: "user" },
        options: { limit: 100 }
      })),
      "$fetch",
      p
    );
  }), R(() => d(), () => {
    i(k, d().rows);
  }), R(() => (n(F()), Ze), () => {
    i(r, F() ? $t : Ze);
  }), je(), Ue();
  var B = Da(), m = f(B);
  Pt(m, () => e(r), (E, ne) => {
    ne(E, {
      get value() {
        return y();
      },
      autocomplete: !0,
      get options() {
        return e(k);
      },
      getOptionLabel: (V) => V.email,
      getOptionValue: (V) => V._id,
      get disabled() {
        return q();
      },
      get searchPlaceholder() {
        return g(() => H.searchPlaceholder);
      },
      popoverAutoWidth: !0,
      $$events: {
        change(V) {
          We.call(this, t, V);
        }
      }
    });
  }), u(B), _(ee, B), qe(), U();
}
var Wa = K("<div><!></div>"), Ga = K("<div><!></div>"), Ua = K('<div><!> <div><div class="field svelte-1alme8h"><!></div> <div class="binding-control svelte-1alme8h"><!></div></div></div>');
function qa(ee, t) {
  Ge(t, !1);
  const d = b(), p = b(), U = b(), v = b(), k = b();
  let r = l(t, "filter", 8), $ = l(t, "disabled", 8, !1), y = l(t, "bindings", 24, () => []), q = l(t, "allowBindings", 8, !1), F = l(t, "schemaFields", 8), H = l(t, "panel", 8), B = l(t, "drawerTitle", 8), m = l(t, "toReadable", 8), E = l(t, "toRuntime", 8), ne = l(t, "evaluationContext", 24, () => ({}));
  const V = Ke(), { OperatorOptions: te, FilterValueType: se } = Ht;
  let L = b();
  const o = (s) => F().find((a) => a.name === s)?.constraints?.inclusion || [], P = (s) => F().find((c) => c.name === s.field), C = (s) => {
    i(U, s.detail);
  }, T = (s) => {
    i(d, s.detail), V("change", {
      value: E() ? E()(y(), e(d)) : e(d)
    });
  }, I = () => {
    V("change", {
      value: E() ? E()(y(), e(U)) : e(U),
      valueType: e(U) ? se.BINDING : se.VALUE
    });
  }, fe = (s) => !s || !isNaN(new Date(s).valueOf()), W = (s) => {
    let c = [];
    if (Array.isArray(s))
      c = s;
    else if (s && typeof s == "string")
      c = s.split(",");
    else
      return !s;
    return c.every((a) => P(r())?.constraints?.inclusion?.includes(a));
  }, N = (s) => s === "false" || s === "true" || s == "", M = (s) => {
    let c = [];
    if (Array.isArray(s))
      c = s;
    else if (s && typeof s == "string")
      c = s.split(",");
    else
      return !s;
    return c.every((a) => a.startsWith("ro_"));
  }, be = {
    date: fe,
    datetime: fe,
    bb_reference: M,
    bb_reference_single: M,
    array: W,
    longform: (s) => !gt(s),
    options: (s) => !gt(s) && !ga(s)?.length,
    boolean: N
  }, x = (s) => {
    const c = be[r().type];
    return c ? c(s) : !0;
  }, O = (s) => (Array.isArray(s) ? s.join(",") : e(p)) ?? "";
  R(() => n(r()), () => {
    i(d, r()?.value);
  }), R(
    () => (n(m()), n(y()), e(d)),
    () => {
      i(p, m() ? m()(y(), e(d)) : e(d));
    }
  ), R(() => e(d), () => {
    i(U, O(e(d)));
  }), R(() => e(d), () => {
    i(v, gt(e(d)));
  }), R(() => e(d), () => {
    i(k, x(e(d)));
  }), je(), Ue();
  var j = Ua(), h = f(j);
  {
    let s = re(() => (n(B()), n(r()), g(() => B() || r().field)));
    yt(
      Yt(h, {
        get title() {
          return e(s);
        },
        forceModal: !0,
        $$events: {
          drawerHide(c) {
            We.call(this, t, c);
          },
          drawerShow(c) {
            We.call(this, t, c);
          }
        },
        $$slots: {
          buttons: (c, a) => {
            wt(c, {
              cta: !0,
              slot: "buttons",
              $$events: {
                click: () => {
                  I(), e(L).hide();
                }
              },
              children: (w, G) => {
                ot();
                var J = it("Confirm");
                _(w, J);
              },
              $$slots: { default: !0 }
            });
          },
          body: (c, a) => {
            var w = Te(), G = ge(w);
            Pt(G, H, (J, me) => {
              me(J, {
                slot: "body",
                get value() {
                  return e(U);
                },
                allowJS: !0,
                allowHelpers: !0,
                allowHBS: !0,
                get bindings() {
                  return y();
                },
                get context() {
                  return ne();
                },
                $$events: { change: C }
              });
            }), _(c, w);
          }
        },
        $$legacy: !0
      }),
      (c) => i(L, c),
      () => e(L)
    );
  }
  var A = S(h, 2);
  let ie;
  var pe = f(A), ce = f(pe);
  {
    var Oe = (s) => {
      {
        let c = re(() => e(v) ? "(JavaScript function)" : e(p));
        ft(s, {
          get disabled() {
            return n(r()), g(() => r().noValue);
          },
          get readonly() {
            return e(v);
          },
          get value() {
            return e(c);
          },
          $$events: { change: T }
        });
      }
    }, we = (s) => {
      var c = Wa(), a = f(c);
      {
        var w = (J) => {
          ft(J, {
            get disabled() {
              return n(r()), g(() => r().noValue);
            },
            get value() {
              return e(p);
            },
            $$events: { change: T }
          });
        }, G = (J) => {
          var me = Te(), ke = ge(me);
          {
            var _e = (D) => {
              {
                let Y = re(() => (n(r()), g(() => o(r().field))));
                $t(D, {
                  get disabled() {
                    return n(r()), g(() => r().noValue);
                  },
                  get options() {
                    return e(Y);
                  },
                  get value() {
                    return e(p);
                  },
                  popoverAutoWidth: !0,
                  $$events: { change: T }
                });
              }
            }, xe = (D) => {
              var Y = Te(), he = ge(Y);
              {
                var X = (Be) => {
                  {
                    let et = re(() => (n(r()), g(() => o(r().field))));
                    It(Be, {
                      get disabled() {
                        return n(r()), g(() => r().noValue);
                      },
                      get options() {
                        return e(et);
                      },
                      get value() {
                        return e(p);
                      },
                      popoverAutoWidth: !0,
                      wrapText: !0,
                      $$events: { change: T }
                    });
                  }
                }, Re = (Be) => {
                  var et = Te(), Pe = ge(et);
                  {
                    var Le = (ve) => {
                      It(ve, {
                        get disabled() {
                          return n(r()), g(() => r().noValue);
                        },
                        options: [
                          { label: "True", value: "true" },
                          { label: "False", value: "false" }
                        ],
                        get value() {
                          return e(p);
                        },
                        popoverAutoWidth: !0,
                        $$events: { change: T }
                      });
                    }, ze = (ve) => {
                      var de = Te(), Ne = ge(de);
                      {
                        var Ce = (ye) => {
                          {
                            let Z = re(() => (n(r()), g(() => !P(r())?.dateOnly))), ue = re(() => (n(r()), g(() => P(r())?.timeOnly)));
                            Ta(ye, {
                              get disabled() {
                                return n(r()), g(() => r().noValue);
                              },
                              get enableTime() {
                                return e(Z);
                              },
                              get timeOnly() {
                                return e(ue);
                              },
                              get value() {
                                return e(p);
                              },
                              $$events: { change: T }
                            });
                          }
                        }, De = (ye) => {
                          var Z = Te(), ue = ge(Z);
                          {
                            var Ee = (Se) => {
                              {
                                let at = re(() => (n(r()), g(() => [te.In.value, te.ContainsAny.value].includes(r().operator))));
                                Ia(Se, {
                                  get multiselect() {
                                    return e(at);
                                  },
                                  get disabled() {
                                    return n(r()), g(() => r().noValue);
                                  },
                                  get value() {
                                    return e(p);
                                  },
                                  $$events: { change: T }
                                });
                              }
                            }, tt = (Se) => {
                              ft(Se, { disabled: !0 });
                            };
                            oe(
                              ue,
                              (Se) => {
                                n(z), n(r()), g(() => [z.BB_REFERENCE, z.BB_REFERENCE_SINGLE].includes(r().type)) ? Se(Ee) : Se(tt, !1);
                              },
                              !0
                            );
                          }
                          _(ye, Z);
                        };
                        oe(
                          Ne,
                          (ye) => {
                            n(r()), n(z), g(() => r().type === z.DATETIME) ? ye(Ce) : ye(De, !1);
                          },
                          !0
                        );
                      }
                      _(ve, de);
                    };
                    oe(
                      Pe,
                      (ve) => {
                        n(r()), n(z), g(() => r().type === z.BOOLEAN) ? ve(Le) : ve(ze, !1);
                      },
                      !0
                    );
                  }
                  _(Be, et);
                };
                oe(
                  he,
                  (Be) => {
                    n(r()), n(z), g(() => r().type === z.OPTIONS) ? Be(X) : Be(Re, !1);
                  },
                  !0
                );
              }
              _(D, Y);
            };
            oe(
              ke,
              (D) => {
                n(r()), n(z), n(Mt), g(() => r().type === z.ARRAY || r().type === z.OPTIONS && r().operator === Mt.ONE_OF) ? D(_e) : D(xe, !1);
              },
              !0
            );
          }
          _(J, me);
        };
        oe(a, (J) => {
          n(z), n(r()), g(() => [
            z.STRING,
            z.LONGFORM,
            z.NUMBER,
            z.BIGINT,
            z.FORMULA,
            z.AI,
            z.BARCODEQR
          ].includes(r().type)) ? J(w) : J(G, !1);
        });
      }
      u(c), _(s, c);
    };
    oe(ce, (s) => {
      n(r()), g(() => r().valueType === se.BINDING) ? s(Oe) : s(we, !1);
    });
  }
  u(pe);
  var ae = S(pe, 2), le = f(ae);
  {
    var Fe = (s) => {
      var c = Ga();
      let a;
      var w = f(c);
      Ye(w, { size: "S", weight: "fill", name: "lightning" }), u(c), Ae((G) => a = Ve(c, 1, "icon svelte-1alme8h", null, a, G), [() => ({ binding: r().valueType === "Binding" })]), Xe("click", c, () => {
        e(L).show();
      }), _(s, c);
    };
    oe(le, (s) => {
      n($()), n(q()), n(r()), g(() => !$() && q() && !r().noValue) && s(Fe);
    });
  }
  u(ae), u(A), u(j), Ae((s) => ie = Ve(A, 1, "field-wrap svelte-1alme8h", null, ie, s), [
    () => ({ bindings: q(), valid: e(k) })
  ]), _(ee, j), qe();
}
var Ha = K('<div class="icon binding svelte-z4ihso"><!></div>'), $a = K('<div><!> <div><div class="field svelte-z4ihso"><!></div> <div class="binding-control svelte-z4ihso"><!></div></div></div>');
function Ya(ee, t) {
  Ge(t, !1);
  const d = b(), p = b(), U = b();
  let v = l(t, "filter", 8), k = l(t, "disabled", 8, !1), r = l(t, "bindings", 24, () => []), $ = l(t, "panel", 8), y = l(t, "drawerTitle", 8), q = l(t, "toReadable", 8), F = l(t, "toRuntime", 8), H = l(t, "evaluationContext", 24, () => ({}));
  const B = Ke();
  let m = b(), E = b();
  const ne = (N) => {
    i(p, N.detail);
  }, V = (N) => {
    i(E, N.detail), B("change", {
      field: F() ? F()(r(), e(E)) : e(E)
    });
  }, te = () => {
    B("change", {
      field: F() ? F()(r(), e(p)) : e(p)
    });
  }, se = (N) => Array.isArray(N) ? N.join(",") : e(d);
  R(() => n(v()), () => {
    i(E, v()?.field);
  }), R(
    () => (n(q()), n(r()), e(E)),
    () => {
      i(d, q() ? q()(r(), e(E)) : e(E));
    }
  ), R(() => e(E), () => {
    i(p, se(e(E)));
  }), R(() => e(E), () => {
    i(U, gt(e(E)));
  }), je(), Ue();
  var L = $a(), o = f(L);
  {
    let N = re(() => y() || "");
    yt(
      Yt(o, {
        get title() {
          return e(N);
        },
        forceModal: !0,
        $$events: {
          drawerHide(M) {
            We.call(this, t, M);
          },
          drawerShow(M) {
            We.call(this, t, M);
          }
        },
        $$slots: {
          buttons: (M, be) => {
            wt(M, {
              cta: !0,
              slot: "buttons",
              $$events: {
                click: () => {
                  te(), e(m).hide();
                }
              },
              children: (x, O) => {
                ot();
                var j = it("Confirm");
                _(x, j);
              },
              $$slots: { default: !0 }
            });
          },
          body: (M, be) => {
            var x = Te(), O = ge(x);
            Pt(O, $, (j, h) => {
              h(j, {
                slot: "body",
                get value() {
                  return e(p);
                },
                allowJS: !0,
                allowHelpers: !0,
                allowHBS: !0,
                get bindings() {
                  return r();
                },
                get context() {
                  return H();
                },
                $$events: { change: ne }
              });
            }), _(M, x);
          }
        },
        $$legacy: !0
      }),
      (M) => i(m, M),
      () => e(m)
    );
  }
  var P = S(o, 2);
  Ve(P, 1, "field-wrap svelte-z4ihso", null, {}, { bindings: !0 });
  var C = f(P), T = f(C);
  {
    let N = re(() => e(U) ? "(JavaScript function)" : e(d));
    ft(T, {
      get disabled() {
        return n(v()), g(() => v().noValue);
      },
      get readonly() {
        return e(U);
      },
      get value() {
        return e(N);
      },
      $$events: { change: V }
    });
  }
  u(C);
  var I = S(C, 2), fe = f(I);
  {
    var W = (N) => {
      var M = Ha(), be = f(M);
      Ye(be, { size: "S", weight: "fill", name: "lightning" }), u(M), Xe("click", M, () => {
        e(m).show();
      }), _(N, M);
    };
    oe(fe, (N) => {
      k() || N(W);
    });
  }
  u(I), u(P), u(L), _(ee, L), qe();
}
var ja = K('<div class="global-filter-header svelte-1bn7luf"><span> </span> <span class="operator-picker svelte-1bn7luf"><!></span> <span> </span></div>'), Ja = K('<div class="filter svelte-1bn7luf"><!> <!> <!> <!></div>'), Qa = K('<div class="group svelte-1bn7luf"><div class="group-header svelte-1bn7luf"><div class="group-options svelte-1bn7luf"><span> </span> <span class="operator-picker svelte-1bn7luf"><!></span> <span> </span></div> <div class="group-actions svelte-1bn7luf"><!> <!></div></div> <div class="filters svelte-1bn7luf"></div></div>'), Xa = K('<div class="filter-groups svelte-1bn7luf"></div>'), Za = K('<div class="empty-filter svelte-1bn7luf"><span>Return</span> <span class="empty-filter-picker svelte-1bn7luf"><!></span> <span> </span></div>'), Ka = K('<a target="_blank"><!></a>'), el = K('<!> <div class="add-group svelte-1bn7luf"><!> <!></div>', 1), tl = K('<!> <!> <!> <div class="filters-footer svelte-1bn7luf"><!></div>', 1), al = K("<div><!></div>");
function ll(ee, t) {
  Ge(t, !1);
  const d = () => Ie(O, "$context", p), [p, U] = Ot(), v = b(), k = b(), r = b(), $ = Ke(), {
    OperatorOptions: y,
    DEFAULT_BB_DATASOURCE_ID: q,
    FilterOperator: F,
    OnEmptyFilter: H,
    FilterValueType: B
  } = Ht;
  let m = l(t, "schemaFields", 12), E = l(t, "filters", 8), ne = l(t, "tables", 24, () => []), V = l(t, "datasource", 8), te = l(t, "behaviourFilters", 8, !1), se = l(t, "allowBindings", 8, !1), L = l(t, "allowOnEmpty", 8, !0), o = l(t, "builderType", 8, "filter"), P = l(t, "docsURL", 8, "https://docs.budibase.com/docs/searchfilter-data"), C = l(t, "bindings", 8), T = l(t, "panel", 8), I = l(t, "toReadable", 8), fe = l(t, "toRuntime", 8), W = l(t, "evaluationContext", 24, () => ({}));
  const N = (a) => Array.isArray(a) ? ha(a) : pt(a), M = Object.values(F).map((a) => ({ value: a, label: fa(a) })), be = {
    [H.RETURN_ALL]: "All rows",
    [H.RETURN_NONE]: "No rows"
  }, x = Object.values(H).map((a) => ({ value: a, label: be[a] })), O = Rt("context"), j = (a) => {
    const w = a.type;
    pe(a), ce(a), Oe(a, w);
  }, h = (a) => {
    ce(a), Oe(a, a.type);
  }, A = (a) => m().find((w) => w.name === a.field), ie = (a) => o() === "condition" ? [y.Equals, y.NotEquals] : !a?.field && !a?.name ? [] : ya(a, a.field || a.name, V()), pe = (a) => {
    const w = m().find((G) => G.name === a.field);
    a.type = w?.type, a.subtype = w?.subtype, a.formulaType = w?.formulaType, a.constraints = w?.constraints, a.externalType = A(a)?.externalType;
  }, ce = (a) => {
    const w = ie(a).map((J) => J.value);
    w.includes(a.operator) || (a.operator = w[0] ?? y.Equals.value);
    const G = [y.Empty.value, y.NotEmpty.value];
    a.noValue = G.includes(a.operator);
  }, Oe = (a, w) => {
    if (a.noValue) {
      a.value = null;
      return;
    }
    Array.isArray(a.value) ? (a.valueType !== "Value" || a.type !== z.ARRAY) && (a.value = null) : a.type === z.ARRAY && a.valueType === "Value" ? a.value = [] : w !== a.type && (w === z.BB_REFERENCE || a.type === z.BB_REFERENCE) && (a.value = a.type === z.ARRAY ? [] : null);
  }, we = (a) => a == 0 ? "When" : { [F.ANY]: "or", [F.ALL]: "and" }[e(v).logicalOperator], ae = (a, w, G) => {
    const J = pt(a);
    le({ groupIdx: w, filterIdx: G, filter: { ...J } });
  }, le = (a) => {
    const {
      groupIdx: w,
      filterIdx: G,
      filter: J,
      group: me,
      addFilter: ke,
      addGroup: _e,
      deleteGroup: xe,
      deleteFilter: D,
      logicalOperator: Y,
      onEmptyFilter: he
    } = a;
    let X = pt(e(v)), Re = X?.groups?.[w];
    Re?.filters?.[G] ? D ? (Re.filters.splice(G, 1), Re.filters.length === 0 && X.groups.splice(w, 1)) : J && (Re.filters[G] = J) : Re ? xe ? X.groups.splice(w, 1) : ke ? Re.filters.push({
      valueType: B.VALUE,
      ...o() === "condition" ? {
        operator: y.Equals.value,
        type: z.STRING
      } : {}
    }) : me && (X.groups[w] = { ...Re, ...me }) : _e ? (X?.groups?.length || (X = {
      logicalOperator: ma.ALL,
      onEmptyFilter: ba.RETURN_NONE,
      groups: []
    }), X.groups.push({
      logicalOperator: _a.ANY,
      filters: [
        {
          valueType: B.VALUE,
          ...o() === "condition" ? { operator: y.Equals.value } : {}
        }
      ]
    })) : Y ? X = { ...X, logicalOperator: Y } : he && (X = { ...X, onEmptyFilter: he }), X = X.groups.length ? X : null, $("change", X);
  };
  R(() => n(E()), () => {
    i(v, N(E()));
  }), R(
    () => (n(ne()), n(V()), n(m())),
    () => {
      ne().find((a) => a._id === V()?.tableId && a.sourceId === q) && !m().some((a) => a.name === "_id") && m([...m(), { name: "_id", type: "string" }]);
    }
  ), R(() => n(o()), () => {
    i(k, o() === "filter" ? "Show data which matches" : "Run branch when matching");
  }), R(() => n(m()), () => {
    i(r, (m() || []).filter((a) => !a.calculationType).map((a) => ({ label: a.displayName || a.name, value: a.name })));
  }), je(), Ue();
  var Fe = al();
  let s;
  var c = f(Fe);
  Dt(c, {
    noPadding: !0,
    children: (a, w) => {
      var G = Te(), J = ge(G);
      {
        var me = (_e) => {
          var xe = tl(), D = ge(xe);
          vt(D, t, "filtering-hero-content", {}, null);
          var Y = S(D, 2);
          {
            var he = (Pe) => {
              var Le = ja(), ze = f(Le), ve = f(ze, !0);
              u(ze);
              var de = S(ze, 2), Ne = f(de);
              {
                let ye = re(() => (e(v), g(() => e(v)?.logicalOperator)));
                Ze(Ne, {
                  get value() {
                    return e(ye);
                  },
                  get options() {
                    return M;
                  },
                  getOptionLabel: (Z) => Z.label,
                  getOptionValue: (Z) => Z.value,
                  placeholder: !1,
                  popoverAutoWidth: !0,
                  $$events: {
                    change: (Z) => {
                      le({ logicalOperator: Z.detail });
                    }
                  }
                });
              }
              u(de);
              var Ce = S(de, 2), De = f(Ce);
              u(Ce), u(Le), Ae(() => {
                $e(ve, e(k)), $e(De, `of the following ${o() ?? ""} groups:`);
              }), _(Pe, Le);
            };
            oe(Y, (Pe) => {
              e(v), g(() => e(v)?.groups?.length) && Pe(he);
            });
          }
          var X = S(Y, 2);
          {
            var Re = (Pe) => {
              var Le = Xa();
              Et(
                Le,
                5,
                () => (e(v), g(() => e(v)?.groups)),
                Tt,
                (ze, ve, de) => {
                  var Ne = Qa(), Ce = f(Ne), De = f(Ce), ye = f(De), Z = f(ye, !0);
                  u(ye);
                  var ue = S(ye, 2), Ee = f(ue);
                  {
                    let lt = re(() => (e(ve), g(() => e(ve)?.logicalOperator)));
                    Ze(Ee, {
                      get value() {
                        return e(lt);
                      },
                      get options() {
                        return M;
                      },
                      getOptionLabel: (Q) => Q.label,
                      getOptionValue: (Q) => Q.value,
                      placeholder: !1,
                      popoverAutoWidth: !0,
                      $$events: {
                        change: (Q) => {
                          le({ groupIdx: de, group: { logicalOperator: Q.detail } });
                        }
                      }
                    });
                  }
                  u(ue);
                  var tt = S(ue, 2), Se = f(tt);
                  u(tt), u(De);
                  var at = S(De, 2), ut = f(at);
                  Ye(ut, {
                    name: "plus",
                    hoverable: !0,
                    hoverColor: "var(--ink)",
                    $$events: {
                      click: () => {
                        le({ groupIdx: de, addFilter: !0 });
                      }
                    }
                  });
                  var Je = S(ut, 2);
                  Ye(Je, {
                    name: "trash",
                    hoverable: !0,
                    hoverColor: "var(--ink)",
                    $$events: {
                      click: () => {
                        le({ groupIdx: de, deleteGroup: !0 });
                      }
                    }
                  }), u(at), u(Ce);
                  var Ct = S(Ce, 2);
                  Et(Ct, 5, () => (e(ve), g(() => e(ve).filters)), Tt, (lt, Q, rt) => {
                    var xt = Ja(), St = f(xt);
                    {
                      var jt = (Me) => {
                        Ze(Me, {
                          get value() {
                            return e(Q), g(() => e(Q).field);
                          },
                          get options() {
                            return e(r);
                          },
                          placeholder: "Column",
                          popoverAutoWidth: !0,
                          $$events: {
                            change: (Qe) => {
                              const He = { ...e(Q), field: Qe.detail };
                              j(He), ae(He, de, rt);
                            }
                          }
                        });
                      }, Jt = (Me) => {
                        Ya(Me, {
                          placeholder: "Value",
                          get filter() {
                            return e(Q);
                          },
                          drawerTitle: "Edit Binding",
                          get bindings() {
                            return C();
                          },
                          get panel() {
                            return T();
                          },
                          get toReadable() {
                            return I();
                          },
                          get toRuntime() {
                            return fe();
                          },
                          get evaluationContext() {
                            return W();
                          },
                          $$events: {
                            change: (Qe) => {
                              const He = { ...e(Q), field: Qe.detail.field };
                              ae(He, de, rt);
                            }
                          }
                        });
                      };
                      oe(St, (Me) => {
                        o() === "filter" ? Me(jt) : Me(Jt, !1);
                      });
                    }
                    var Vt = S(St, 2);
                    {
                      let Me = re(() => (e(Q), n(o()), g(() => !e(Q).field && o() === "filter"))), Qe = re(() => (e(Q), g(() => ie(e(Q)))));
                      Ze(Vt, {
                        get value() {
                          return e(Q), g(() => e(Q).operator);
                        },
                        get disabled() {
                          return e(Me);
                        },
                        get options() {
                          return e(Qe);
                        },
                        placeholder: !1,
                        popoverAutoWidth: !0,
                        $$events: {
                          change: (He) => {
                            const ct = { ...e(Q), operator: He.detail };
                            h(ct), ae(ct, de, rt);
                          }
                        }
                      });
                    }
                    var kt = S(Vt, 2);
                    {
                      let Me = re(() => (e(Q), n(o()), g(() => !e(Q).field && o() === "filter"))), Qe = re(() => o() === "condition" ? "Edit binding" : null), He = re(() => (e(Q), n(o()), n(z), g(() => ({
                        ...e(Q),
                        ...o() === "condition" ? { type: z.STRING } : {}
                      }))));
                      qa(kt, {
                        placeholder: "Value",
                        get disabled() {
                          return e(Me);
                        },
                        get drawerTitle() {
                          return e(Qe);
                        },
                        get allowBindings() {
                          return se();
                        },
                        get filter() {
                          return e(He);
                        },
                        get schemaFields() {
                          return m();
                        },
                        get bindings() {
                          return C();
                        },
                        get panel() {
                          return T();
                        },
                        get toReadable() {
                          return I();
                        },
                        get toRuntime() {
                          return fe();
                        },
                        get evaluationContext() {
                          return W();
                        },
                        $$events: {
                          change: (ct) => {
                            ae({ ...e(Q), ...ct.detail }, de, rt);
                          }
                        }
                      });
                    }
                    var Qt = S(kt, 2);
                    Ut(Qt, {
                      size: "M",
                      icon: "trash",
                      $$events: {
                        click: () => {
                          le({ groupIdx: de, filterIdx: rt, deleteFilter: !0 });
                        }
                      }
                    }), u(xt), _(lt, xt);
                  }), u(Ct), u(Ne), Ae(
                    (lt) => {
                      $e(Z, lt), $e(Se, `of the following ${o() ?? ""}s are matched:`);
                    },
                    [
                      () => (e(v), g(() => we(de, e(v).logicalOperator)))
                    ]
                  ), _(ze, Ne);
                }
              ), u(Le), _(Pe, Le);
            };
            oe(X, (Pe) => {
              e(v), g(() => e(v)?.groups?.length) && Pe(Re);
            });
          }
          var Be = S(X, 2), et = f(Be);
          Dt(et, {
            noPadding: !0,
            children: (Pe, Le) => {
              var ze = el(), ve = ge(ze);
              {
                var de = (Z) => {
                  var ue = Za(), Ee = S(f(ue), 2), tt = f(Ee);
                  {
                    let ut = re(() => (e(v), g(() => e(v)?.onEmptyFilter)));
                    Ze(tt, {
                      get value() {
                        return e(ut);
                      },
                      get options() {
                        return x;
                      },
                      getOptionLabel: (Je) => Je.label,
                      getOptionValue: (Je) => Je.value,
                      placeholder: !1,
                      popoverAutoWidth: !0,
                      $$events: {
                        change: (Je) => {
                          le({ onEmptyFilter: Je.detail });
                        }
                      }
                    });
                  }
                  u(Ee);
                  var Se = S(Ee, 2), at = f(Se);
                  u(Se), u(ue), Ae(() => $e(at, `when all ${o() ?? ""}s are empty`)), _(Z, ue);
                };
                oe(ve, (Z) => {
                  n(te()), n(L()), e(v), g(() => te() && L() && e(v)?.groups?.length) && Z(de);
                });
              }
              var Ne = S(ve, 2), Ce = f(Ne);
              wt(Ce, {
                icon: "plus-circle",
                size: "M",
                secondary: !0,
                $$events: {
                  click: () => {
                    le({ addGroup: !0 });
                  }
                },
                children: (Z, ue) => {
                  ot();
                  var Ee = it();
                  Ae(() => $e(Ee, `Add ${o() ?? ""} group`)), _(Z, Ee);
                },
                $$slots: { default: !0 }
              });
              var De = S(Ce, 2);
              {
                var ye = (Z) => {
                  var ue = Ka(), Ee = f(ue);
                  Ye(Ee, {
                    name: "question",
                    color: "var(--spectrum-global-color-gray-600)"
                  }), u(ue), Ae(() => Ft(ue, "href", P())), _(Z, ue);
                };
                oe(De, (Z) => {
                  P() && Z(ye);
                });
              }
              u(Ne), _(Pe, ze);
            },
            $$slots: { default: !0 }
          }), u(Be), _(_e, xe);
        }, ke = (_e) => {
          pa(_e, {
            size: "S",
            children: (xe, D) => {
              ot();
              var Y = it("None of the table column can be used for filtering.");
              _(xe, Y);
            },
            $$slots: { default: !0 }
          });
        };
        oe(J, (_e) => {
          e(r), g(() => e(r)?.length) ? _e(me) : _e(ke, !1);
        });
      }
      _(a, G);
    },
    $$slots: { default: !0 }
  }), u(Fe), Ae((a) => s = Ve(Fe, 1, "container svelte-1bn7luf", null, s, a), [() => ({ mobile: d()?.device?.mobile })]), _(ee, Fe), qe(), U();
}
var rl = K("<!> <!>", 1);
function dl(ee, t) {
  Ge(t, !1);
  const d = () => Ie(E, "$component", p), [p, U] = Ot(), v = b(), k = b(), r = b(), $ = b(), y = b(), q = b(), F = b();
  let H = l(t, "dataProvider", 8), B = l(t, "allowedFields", 8), m = l(t, "size", 8, "M");
  const E = Rt("component"), { builderStore: ne, ActionTypes: V, getAction: te, fetchDatasourceSchema: se } = Rt("sdk");
  let L = b(), o = b(), P = b(), C = b(!1), T = b();
  async function I(O) {
    O && i(T, await se(O, { enrichRelationships: !0 })), i(C, !0);
  }
  function fe(O, j) {
    if (!e(C))
      return {};
    let h = {};
    return j?.length ? j?.forEach((A) => {
      O?.[A.name] ? (h[A.name] = O[A.name], h[A.name].displayName = A.displayName) : O?.[A] && (h[A] = O[A]);
    }) : h = O || {}, Object.values(h || {}).filter((A) => !Aa.includes(A.type)).concat(e(r) ? [{ name: "_id", type: "string" }] : []);
  }
  const W = () => {
    qt(ne).inBuilder || (i(o, e(P) ? pt(e(P)) : null), e(L).show());
  }, N = () => {
    i(P, Ea(e(o)));
  };
  Gt(() => {
    e(y)?.(d().id);
  }), R(() => n(H()), () => {
    i(v, H()?.id);
  }), R(() => n(H()), () => {
    i(k, H()?.datasource);
  }), R(() => e(k), () => {
    i(r, ["table", "link", "viewV2"].includes(e(k)?.type));
  }), R(() => e(v), () => {
    i($, te(e(v), V.AddDataProviderQueryExtension));
  }), R(() => e(v), () => {
    i(y, te(e(v), V.RemoveDataProviderQueryExtension));
  }), R(() => e(k), () => {
    I(e(k));
  }), R(() => (e(T), n(B())), () => {
    i(q, fe(e(T), B()));
  }), R(() => e(P), () => {
    i(F, e(P)?.groups?.reduce(
      (O, j) => (O += j?.filters?.length || 0, O),
      0
    ));
  }), R(
    () => (e(F), e(P), e($), d(), e(y)),
    () => {
      if (e(F)) {
        const O = Oa(e(P));
        delete O.onEmptyFilter, e($)?.(d().id, O);
      } else
        e(y)?.(d().id);
    }
  ), je(), Ue();
  var M = Te(), be = ge(M);
  {
    var x = (O) => {
      var j = rl(), h = ge(j);
      {
        let ie = re(() => (e(P), g(() => e(P)?.groups?.length > 0)));
        Ra(h, {
          onClick: W,
          icon: "ri-filter-3-line",
          text: "Filter",
          get size() {
            return m();
          },
          type: "secondary",
          quiet: !0,
          get active() {
            return e(ie);
          }
        });
      }
      var A = S(h, 2);
      yt(
        wa(A, {
          children: (ie, pe) => {
            xa(ie, {
              title: "Edit filters",
              size: "XL",
              onConfirm: N,
              children: (ce, Oe) => {
                ll(ce, {
                  get filters() {
                    return e(o);
                  },
                  get schemaFields() {
                    return e(q);
                  },
                  get datasource() {
                    return e(k);
                  },
                  filtersLabel: null,
                  $$events: {
                    change: (we) => {
                      i(o, we.detail);
                    }
                  }
                });
              },
              $$slots: { default: !0 }
            });
          },
          $$slots: { default: !0 },
          $$legacy: !0
        }),
        (ie) => i(L, ie),
        () => e(L)
      ), _(O, j);
    };
    oe(be, (O) => {
      e(C) && O(x);
    });
  }
  _(ee, M), qe(), U();
}
export {
  dl as default
};
