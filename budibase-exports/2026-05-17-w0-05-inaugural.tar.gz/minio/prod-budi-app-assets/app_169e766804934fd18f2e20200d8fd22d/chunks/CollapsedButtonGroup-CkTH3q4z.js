import { p as r, q as _, aC as Y, a3 as x, a4 as b, t as $, b as k, d as u, j as t, Y as i, B as q, s as D, X as E, bT as F, bB as J, n as K, S as L, T as N, z as y, H as z, f as O, as as Q, A as f } from "./index-CMyk0zjR.js";
var R = O("<!> <!>", 1);
function W(B, a) {
  let C = r(a, "buttons", 8), P = r(a, "text", 8, "Action"), w = r(a, "size", 8, "M"), A = r(a, "align", 8, "left"), M = r(a, "offset", 8), S = r(a, "animate", 8), o = r(a, "quiet", 8, !1), d = y(), c = y();
  const T = async (e) => {
    t(c).hide(), await e.onClick?.();
  };
  var g = R(), h = _(g);
  {
    let e = z(() => !o()), m = z(() => !o());
    Y(h, {
      get size() {
        return w();
      },
      icon: "caret-down",
      get quiet() {
        return o();
      },
      get primary() {
        return o();
      },
      get cta() {
        return t(e);
      },
      get newStyles() {
        return t(m);
      },
      reverse: !0,
      get ref() {
        return t(d);
      },
      set ref(s) {
        q(d, s);
      },
      $$events: {
        click: [
          () => t(c)?.show(),
          function(s) {
            i.call(this, a, s);
          }
        ]
      },
      children: (s, G) => {
        x();
        var n = b();
        $(() => k(n, P() || "Action")), u(s, n);
      },
      $$slots: { default: !0 },
      $$legacy: !0
    });
  }
  var j = D(h, 2);
  E(
    F(j, {
      get align() {
        return A();
      },
      get anchor() {
        return t(d);
      },
      get offset() {
        return M();
      },
      get animate() {
        return S();
      },
      resizable: !1,
      $$events: {
        close(e) {
          i.call(this, a, e);
        },
        open(e) {
          i.call(this, a, e);
        },
        mouseenter(e) {
          i.call(this, a, e);
        },
        mouseleave(e) {
          i.call(this, a, e);
        }
      },
      children: (e, m) => {
        J(e, {
          children: (s, G) => {
            var n = K(), H = _(n);
            L(H, 1, C, N, (I, l) => {
              Q(I, {
                get icon() {
                  return t(l), f(() => t(l).icon);
                },
                get disabled() {
                  return t(l), f(() => t(l).disabled);
                },
                $$events: { click: () => T(t(l)) },
                children: (X, U) => {
                  x();
                  var v = b();
                  $(() => k(v, (t(l), f(() => t(l).text || "Button")))), u(X, v);
                },
                $$slots: { default: !0 }
              });
            }), u(s, n);
          },
          $$slots: { default: !0 }
        });
      },
      $$slots: { default: !0 },
      $$legacy: !0
    }),
    (e) => q(c, e),
    () => t(c)
  ), u(B, g);
}
export {
  W as C
};
