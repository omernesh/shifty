import { g as it, p as o, h as ee, cy as st, l as m, i as t, j as e, k as dt, m as ct, n as ke, q as k, u as _, d as B, _ as ut, w as ft, x as mt, y as pt, z as n, aR as gt, B as l, cz as p, Q as vt, R as u, A as h, s as T, H as g, S as ht, cA as Be, cB as Te, f as te } from "./index-CMyk0zjR.js";
import { e as wt, a as yt } from "./blocks-BhLb4SfE.js";
var bt = te("<!> <!>", 1), _t = te("<!> <!>", 1), Ct = te("<!> <!> <!> <!>", 1);
function Bt(De, a) {
  it(a, !1);
  const ae = () => mt(He, "$component", Re), [Re, $e] = pt(), D = n(), C = n(), S = n(), oe = n(), U = n(), x = n(), E = n(), re = n();
  let R = o(a, "title", 8), s = o(a, "dataSource", 8), le = o(a, "searchColumns", 8), ne = o(a, "filter", 8), Ae = o(a, "sortColumn", 8), Le = o(a, "sortOrder", 8), Oe = o(a, "paginate", 8), ie = o(a, "tableColumns", 8), j = o(a, "rowCount", 8), se = o(a, "quiet", 8), de = o(a, "compact", 8), V = o(a, "size", 8), ce = o(a, "allowSelectRows", 8), G = o(a, "clickBehaviour", 8), ue = o(a, "onClick", 8), $ = o(a, "showTitleButton", 8), Ie = o(a, "titleButtonText", 8), K = o(a, "titleButtonClickBehaviour", 8), fe = o(a, "onClickTitleButton", 8), me = o(a, "noRowsMessage", 8), A = o(a, "sidePanelFields", 8), Q = o(a, "sidePanelShowDelete", 8), pe = o(a, "sidePanelSaveLabel", 8), ge = o(a, "sidePanelDeleteLabel", 8), L = o(a, "notificationOverride", 8), Fe = o(a, "autoRefresh", 8);
  const { fetchDatasourceSchema: ze, API: qe, generateGoldenSample: Me } = ee("sdk"), He = ee("component"), Ne = ee("context"), ve = `ID_${st.generate()}`;
  let O = n(), P = n(), I = n(), F = n(), z = n(), y = n(), q = n(), f = n(), he = n(!1);
  const we = () => {
    const r = gt(Ne)[e(P)]?.rows;
    return { eventContext: { row: Me(r) } };
  }, Ue = (r) => {
    let i = Q() === !1 ? "" : r;
    return i?.trim() === "" ? "" : i || "Delete";
  }, Ee = async (r) => {
    if (r?.type === "table") {
      const i = await qe.fetchTableDefinition(r?.tableId);
      l(y, i.schema), l(q, i.primaryDisplay);
    } else r && l(y, await ze(r, { enrichRelationships: !0 }));
    l(he, !0);
  }, je = (r) => r ? Object.entries(r).filter((i) => !i[1].autocolumn).map((i) => i[0]) : [], Ve = (r, i) => {
    if (!i || !r)
      return "Edit";
    const M = `${p(r + "-repeater")}.${p(i)}`;
    return `{{#if ${M}}}{{${M}}}{{else}}Details{{/if}}`;
  };
  m(
    () => (t(ge()), t(Q())),
    () => {
      l(D, Ue(ge(), Q()));
    }
  ), m(() => ae(), () => {
    l(C, ae().id);
  }), m(() => t(s()), () => {
    l(S, s()?.type === "table" || s()?.type === "viewV2");
  }), m(() => t(s()), () => {
    Ee(s());
  }), m(
    () => (t(le()), e(y)),
    () => {
      wt(le(), e(y)).then((r) => l(f, r));
    }
  ), m(
    () => (t(ne()), e(f), e(O)),
    () => {
      l(oe, yt(ne(), e(f), e(O)));
    }
  ), m(() => (e(I), e(q)), () => {
    l(U, Ve(e(I), e(q)));
  }), m(() => e(y), () => {
    l(x, je(e(y)));
  }), m(
    () => (t(G()), e(S), t(ue()), e(F)),
    () => {
      l(E, G() === "actions" || !e(S) ? ue() : [
        {
          id: 0,
          "##eventHandlerType": "Update State",
          parameters: {
            key: ve,
            type: "set",
            persist: !1,
            value: `{{ ${p("eventContext")}.${p("row")}._id }}`
          }
        },
        {
          id: 1,
          "##eventHandlerType": "Open Side Panel",
          parameters: { id: e(F) }
        }
      ]);
    }
  ), m(
    () => (t(K()), e(S), t(fe()), e(z)),
    () => {
      l(re, K() === "actions" || !e(S) ? fe() : [
        {
          id: 0,
          "##eventHandlerType": "Open Side Panel",
          parameters: { id: e(z) }
        }
      ]);
    }
  ), dt();
  var Ge = { getAdditionalDataContext: we };
  ct();
  var ye = ke(), Ke = k(ye);
  {
    var Qe = (r) => {
      vt(r, {
        children: (i, Je) => {
          {
            let M = g(() => ({
              dataSource: s(),
              disableSchemaValidation: !0,
              editAutoColumns: !0,
              size: V()
            }));
            u(i, {
              type: "form",
              get props() {
                return e(M);
              },
              get id() {
                return e(O);
              },
              set id(W) {
                l(O, W);
              },
              children: (W, St) => {
                var be = Ct(), _e = k(be);
                {
                  var Xe = (d) => {
                    u(d, {
                      type: "container",
                      props: {
                        direction: "row",
                        hAlign: "stretch",
                        vAlign: "middle",
                        gap: "M",
                        wrap: !0
                      },
                      styles: { normal: { "margin-bottom": "20px" } },
                      order: 0,
                      children: (c, J) => {
                        var v = _t(), H = k(v);
                        {
                          let X = g(() => ({ text: R() ? `## ${R()}` : "" }));
                          u(H, {
                            type: "textv2",
                            get props() {
                              return e(X);
                            },
                            order: 0
                          });
                        }
                        var tt = T(H, 2);
                        u(tt, {
                          type: "container",
                          props: {
                            direction: "row",
                            hAlign: "left",
                            vAlign: "center",
                            gap: "M",
                            wrap: !0
                          },
                          order: 1,
                          children: (X, xt) => {
                            var xe = bt(), Pe = k(xe);
                            {
                              var at = (w) => {
                                var N = ke(), Y = k(N);
                                ht(Y, 3, () => e(f), (Z) => Z.name, (Z, b, lt) => {
                                  {
                                    let nt = g(() => (e(b), h(() => ({
                                      field: e(b).name,
                                      placeholder: e(b).name,
                                      text: e(b).name,
                                      autoWidth: !0
                                    }))));
                                    u(Z, {
                                      get type() {
                                        return e(b), h(() => e(b).componentType);
                                      },
                                      get props() {
                                        return e(nt);
                                      },
                                      styles: { normal: { width: "192px" } },
                                      get order() {
                                        return e(lt);
                                      }
                                    });
                                  }
                                }), B(w, N);
                              };
                              _(Pe, (w) => {
                                e(f), h(() => e(f)?.length) && w(at);
                              });
                            }
                            var ot = T(Pe, 2);
                            {
                              var rt = (w) => {
                                {
                                  let N = g(() => ({
                                    onClick: e(re),
                                    text: Ie(),
                                    type: "cta"
                                  })), Y = g(() => (e(f), h(() => e(f)?.length ?? 0)));
                                  u(w, {
                                    type: "button",
                                    get props() {
                                      return e(N);
                                    },
                                    get order() {
                                      return e(Y);
                                    }
                                  });
                                }
                              };
                              _(ot, (w) => {
                                $() && w(rt);
                              });
                            }
                            B(X, xe);
                          },
                          $$slots: { default: !0 }
                        }), B(c, v);
                      },
                      $$slots: { default: !0 }
                    });
                  };
                  _(_e, (d) => {
                    t(R()), e(f), t($()), h(() => R() || e(f)?.length || $()) && d(Xe);
                  });
                }
                var Ce = T(_e, 2);
                {
                  let d = g(() => ({
                    dataSource: s(),
                    filter: e(oe),
                    sortColumn: Ae() || e(q),
                    sortOrder: Le(),
                    paginate: Oe(),
                    limit: j(),
                    autoRefresh: Fe()
                  }));
                  u(Ce, {
                    type: "dataprovider",
                    get props() {
                      return e(d);
                    },
                    context: "provider",
                    order: 1,
                    get id() {
                      return e(P);
                    },
                    set id(c) {
                      l(P, c);
                    },
                    children: (c, J) => {
                      {
                        let v = g(() => (t(p), e(P), t(ie()), t(j()), t(se()), t(de()), t(ce()), t(V()), e(E), t(me()), h(() => ({
                          dataProvider: `{{ literal ${p(e(P))} }}`,
                          columns: ie(),
                          rowCount: j(),
                          quiet: se(),
                          compact: de(),
                          allowSelectRows: ce(),
                          size: V(),
                          onClick: e(E),
                          noRowsMessage: me() || "No rows found"
                        }))));
                        u(c, {
                          type: "table",
                          context: "table",
                          get props() {
                            return e(v);
                          }
                        });
                      }
                    },
                    $$slots: { default: !0 },
                    $$legacy: !0
                  });
                }
                var Se = T(Ce, 2);
                {
                  var Ye = (d) => {
                    u(d, {
                      name: "Details side panel",
                      type: "sidepanel",
                      context: "details-side-panel",
                      order: 2,
                      get id() {
                        return e(F);
                      },
                      set id(c) {
                        l(F, c);
                      },
                      children: (c, J) => {
                        {
                          let v = g(() => (t(s()), t(Be), e(C), e(D), t(pe()), t(L()), t(p), t(A()), e(x), e(U), h(() => ({
                            dataSource: s(),
                            buttonPosition: "top",
                            buttons: Te({
                              _id: e(C) + "-form-edit",
                              showDeleteButton: e(D) !== "",
                              showSaveButton: !0,
                              saveButtonLabel: pe() || "Save",
                              deleteButtonLabel: e(D),
                              notificationOverride: L(),
                              actionType: "Update",
                              dataSource: s()
                            }),
                            actionType: "Update",
                            rowId: `{{ ${p("state")}.${p(ve)} }}`,
                            fields: A() || e(x),
                            title: e(U),
                            labelPosition: "left"
                          }))));
                          u(c, {
                            name: "Details form block",
                            type: "formblock",
                            context: "form-edit",
                            get props() {
                              return e(v);
                            },
                            get id() {
                              return e(I);
                            },
                            set id(H) {
                              l(I, H);
                            },
                            $$legacy: !0
                          });
                        }
                      },
                      $$slots: { default: !0 },
                      $$legacy: !0
                    });
                  };
                  _(Se, (d) => {
                    G() === "details" && d(Ye);
                  });
                }
                var Ze = T(Se, 2);
                {
                  var et = (d) => {
                    u(d, {
                      name: "New row side panel",
                      type: "sidepanel",
                      context: "new-side-panel",
                      order: 3,
                      get id() {
                        return e(z);
                      },
                      set id(c) {
                        l(z, c);
                      },
                      children: (c, J) => {
                        {
                          let v = g(() => (t(s()), t(Be), e(C), t(L()), t(A()), e(x), h(() => ({
                            dataSource: s(),
                            buttonPosition: "top",
                            buttons: Te({
                              _id: e(C) + "-form-new",
                              showDeleteButton: !1,
                              showSaveButton: !0,
                              saveButtonLabel: "Save",
                              notificationOverride: L(),
                              actionType: "Create",
                              dataSource: s()
                            }),
                            actionType: "Create",
                            fields: A() || e(x),
                            title: "Create Row",
                            labelPosition: "left"
                          }))));
                          u(c, {
                            name: "New row form block",
                            type: "formblock",
                            context: "form-new",
                            get props() {
                              return e(v);
                            }
                          });
                        }
                      },
                      $$slots: { default: !0 },
                      $$legacy: !0
                    });
                  };
                  _(Ze, (d) => {
                    $() && K() === "new" && d(et);
                  });
                }
                B(W, be);
              },
              $$slots: { default: !0 },
              $$legacy: !0
            });
          }
        },
        $$slots: { default: !0 }
      });
    };
    _(Ke, (r) => {
      e(he) && r(Qe);
    });
  }
  B(De, ye), ut(a, "getAdditionalDataContext", we);
  var We = ft(Ge);
  return $e(), We;
}
export {
  Bt as default
};
