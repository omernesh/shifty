import { bJ as s, g as l, m as o, cw as d, i as c, b1 as a, A as m, w as A } from "./index-CMyk0zjR.js";
import f from "./AttachmentField-fOk4V3WS.js";
function g(r, t) {
  const p = s(t, ["children", "$$slots", "$$events", "$$legacy"]), i = s(p, []);
  l(t, !1);
  const n = {
    get: (e) => (!Array.isArray(e) && e ? [e] : e) || [],
    set: (e) => e[0] || null
  };
  o(), f(r, d(() => i, {
    get type() {
      return c(a), m(() => a.ATTACHMENT_SINGLE);
    },
    maximum: 1,
    defaultValue: null,
    get fieldApiMapper() {
      return n;
    }
  })), A();
}
export {
  g as default
};
