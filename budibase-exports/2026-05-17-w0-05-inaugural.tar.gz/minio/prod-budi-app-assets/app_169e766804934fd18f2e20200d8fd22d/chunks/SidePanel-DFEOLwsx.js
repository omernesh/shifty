import { g as M, h as C, p as I, l as u, j as l, i as A, k as F, m as G, al as H, v as P, t as J, a as L, d as k, w as N, x as g, y as Q, z as $, c as R, f as T, r as U, n as V, q as W, E as X, B as b } from "./index-CMyk0zjR.js";
var Y = T("<div><!></div>");
function ee(w, d) {
  M(d, !1);
  const m = () => g(O, "$builderStore", c), e = () => g(B, "$component", c), a = () => g(r, "$sidePanelStore", c), _ = () => g(j, "$dndIsDragging", c), [c, x] = Q(), o = $(), B = C("component"), { styleable: D, sidePanelStore: r, builderStore: O, dndIsDragging: j } = C("sdk");
  let h = I(d, "onClose", 8), v = I(d, "ignoreClicksOutside", 8), y = $(null);
  const E = async () => {
    h() && await h()();
  }, q = (t, s) => {
    const i = (K) => {
      const f = document.getElementById("side-panel-container"), p = t;
      K ? f.contains(p) || f.appendChild(p) : f.contains(p) && (f.removeChild(p), E());
    };
    return i(s), { update: i, destroy: () => i(!1) };
  };
  u(
    () => (m(), e(), a(), _()),
    () => {
      m().inBuilder && (e().inSelectedPath && a().contentId !== e().id ? r.actions.open(e().id) : !e().inSelectedPath && a().contentId === e().id && !_() && r.actions.close());
    }
  ), u(() => (a(), e()), () => {
    b(o, a().contentId === e().id);
  }), u(() => (l(o), A(v())), () => {
    l(o) && (r.actions.setIgnoreClicksOutside(v()), b(y, Math.random()));
  }), F(), G();
  var n = Y();
  let S;
  var z = R(n);
  H(
    z,
    () => l(
      // Apply initial visibility
      y
    ),
    (t) => {
      var s = V(), i = W(s);
      X(i, d, "default", {}, null), k(t, s);
    }
  ), U(n), P(n, (t, s) => D?.(t, s), () => e().styles), P(n, (t, s) => q?.(t, s), () => l(o)), J((t) => S = L(n, 1, "side-panel svelte-hyrpaj", null, S, t), [() => ({ open: l(o) })]), k(w, n), N(), x();
}
export {
  ee as default
};
