import { g as m, h as e, m as h, v as u, d, w as v, y as f, f as y, x as $ } from "./index-CMyk0zjR.js";
var b = y('<div class="svelte-1mucq5o"><h1 class="svelte-1mucq5o">Screen Slot</h1> <span class="svelte-1mucq5o">The screens that you create will be displayed inside this box. <br/> This box is just a placeholder, to show you the position of screens.</span></div>');
function S(t, o) {
  m(o, !1);
  const a = () => $(p, "$component", n), [n, c] = f(), { styleable: l } = e("sdk"), p = e("component");
  h();
  var s = b();
  u(s, (r, i) => l?.(r, i), () => ({ ...a().styles, empty: !0 })), d(t, s), v(), c();
}
export {
  S as default
};
