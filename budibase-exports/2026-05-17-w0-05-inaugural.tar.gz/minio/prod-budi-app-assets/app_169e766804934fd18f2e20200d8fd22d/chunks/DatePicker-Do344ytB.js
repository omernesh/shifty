import { g as R, p as t, l as E, i as T, k as U, m as Z, c as S, u as H, s as X, a0 as re, r as G, X as $, t as F, a as q, a2 as B, a1 as ne, j as l, e as ie, Y as K, d as D, w as ee, z as y, I as J, f as M, B as d, cn as se, ch as ue, ce as oe, W as ce, q as N, bT as de, n as ve, cE as fe, H as Q, cf as ge } from "./index-CMyk0zjR.js";
var me = M('<div class="error-icon svelte-1rlhaz8"><!></div>'), he = M('<button type="button" tabindex="-1"><!></button>'), be = M('<div aria-required="false" aria-haspopup="true"><div><!> <input data-input="" type="text"/></div> <!></div>');
function _e(V, e) {
  R(e, !1);
  const k = y();
  let v = t(e, "anchor", 12), c = t(e, "disabled", 8), f = t(e, "readonly", 8), g = t(e, "error", 8), C = t(e, "focused", 8), m = t(e, "placeholder", 8), z = t(e, "id", 8), P = t(e, "value", 8), h = t(e, "icon", 8), x = t(e, "enableTime", 8), I = t(e, "timeOnly", 8);
  E(
    () => (T(P()), T(x()), T(I())),
    () => {
      d(k, se(P(), { enableTime: x(), timeOnly: I() }));
    }
  ), U(), Z();
  var s = be();
  let W;
  var b = S(s);
  let w;
  var p = S(b);
  {
    var _ = (a) => {
      var r = me(), o = S(r);
      J(o, {
        name: "warning",
        color: "var(--spectrum-semantic-negative-color-icon)"
      }), G(r), D(a, r);
    };
    H(p, (a) => {
      g() && a(_);
    });
  }
  var i = X(p, 2);
  re(i);
  let u;
  G(b);
  var L = X(b, 2);
  {
    var j = (a) => {
      var r = he();
      let o;
      var O = S(r);
      J(O, {
        get name() {
          return h();
        }
      }), G(r), F((n) => o = q(r, 1, "spectrum-Picker spectrum-Picker--sizeM spectrum-InputGroup-button", null, o, n), [() => ({ "is-invalid": !!g() })]), D(a, r);
    };
    H(L, (a) => {
      !c() && !f() && a(j);
    });
  }
  G(s), $(s, (a) => v(a), () => v()), F(
    (a, r, o) => {
      W = q(s, 1, "spectrum-InputGroup spectrum-Datepicker svelte-1rlhaz8", null, W, a), B(s, "aria-readonly", f()), w = q(b, 1, "spectrum-Textfield spectrum-InputGroup-textfield svelte-1rlhaz8", null, w, r), i.disabled = c(), i.readOnly = f(), u = q(i, 1, "spectrum-Textfield-input spectrum-InputGroup-input svelte-1rlhaz8", null, u, o), B(i, "placeholder", m()), B(i, "id", z()), ne(i, l(k));
    },
    [
      () => ({
        "is-disabled": c() || f(),
        "is-invalid": !!g(),
        "is-focused": C()
      }),
      () => ({ "is-disabled": c(), "is-invalid": !!g() }),
      () => ({ "is-disabled": c() })
    ]
  ), ie("click", s, function(a) {
    K.call(this, e, a);
  }), D(V, s), ee();
}
var ye = M("<!> <!>", 1);
function pe(V, e) {
  R(e, !1);
  const k = y(), v = y();
  let c = t(e, "id", 8, null), f = t(e, "disabled", 8, !1), g = t(e, "readonly", 8, !1), C = t(e, "error", 8, null), m = t(e, "enableTime", 8, !0), z = t(e, "value", 8, null), P = t(e, "placeholder", 8, null), h = t(e, "timeOnly", 8, !1), x = t(e, "ignoreTimezones", 8, !1), I = t(e, "useKeyboardShortcuts", 8, !0), s = t(e, "appendTo", 24, () => {
  }), W = t(e, "api", 12, null), b = t(e, "align", 24, () => ue.Left);
  const w = oe();
  let p = t(e, "startDayOfWeek", 24, () => {
  }), _ = y(!1), i = y(), u = y();
  const L = () => {
    d(_, !0);
  }, j = () => {
    d(_, !1);
  };
  ce(() => {
    W({
      open: () => l(u)?.show(),
      close: () => l(u)?.hide()
    });
  }), E(() => T(p()), () => {
    d(k, p() ?? w);
  }), E(
    () => (T(z()), T(m())),
    () => {
      d(v, ge(z(), { enableTime: m() }));
    }
  ), U(), Z();
  var a = ye(), r = N(a);
  {
    let O = Q(() => h() ? "clock" : "calendar");
    _e(r, {
      get disabled() {
        return f();
      },
      get readonly() {
        return g();
      },
      get error() {
        return C();
      },
      get placeholder() {
        return P();
      },
      get id() {
        return c();
      },
      get enableTime() {
        return m();
      },
      get timeOnly() {
        return h();
      },
      get focused() {
        return l(_);
      },
      get value() {
        return l(v);
      },
      get icon() {
        return l(O);
      },
      get anchor() {
        return l(i);
      },
      set anchor(n) {
        d(i, n);
      },
      $$events: {
        click(...n) {
          l(u)?.show?.apply(this, n);
        }
      },
      $$legacy: !0
    });
  }
  var o = X(r, 2);
  {
    let O = Q(() => h() ? "fixed-to-anchor" : "no-anchor");
    $(
      de(o, {
        get portalTarget() {
          return s();
        },
        get anchor() {
          return l(i);
        },
        get align() {
          return b();
        },
        get widthMode() {
          return l(O);
        },
        resizable: !1,
        $$events: {
          open: [
            function(n) {
              K.call(this, e, n);
            },
            L
          ],
          close: [
            function(n) {
              K.call(this, e, n);
            },
            j
          ]
        },
        children: (n, Te) => {
          var Y = ve(), te = N(Y);
          {
            var ae = (A) => {
              fe(A, {
                get useKeyboardShortcuts() {
                  return I();
                },
                get ignoreTimezones() {
                  return x();
                },
                get enableTime() {
                  return m();
                },
                get timeOnly() {
                  return h();
                },
                get startDayOfWeek() {
                  return l(k);
                },
                get value() {
                  return l(v);
                },
                $$events: {
                  change(le) {
                    K.call(this, e, le);
                  }
                }
              });
            };
            H(te, (A) => {
              l(_) && A(ae);
            });
          }
          D(n, Y);
        },
        $$slots: { default: !0 },
        $$legacy: !0
      }),
      (n) => d(u, n),
      () => l(u)
    );
  }
  D(V, a), ee();
}
export {
  pe as D
};
