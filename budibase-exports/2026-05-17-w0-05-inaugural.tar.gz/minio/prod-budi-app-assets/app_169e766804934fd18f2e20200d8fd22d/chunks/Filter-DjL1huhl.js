import { g as Ge, y as et, p as u, ce as Pt, $ as tt, l as d, i as v, B as r, j as e, cf as it, k as rt, m as Ue, c as M, s as ye, I as Ot, r as j, d as x, w as $e, x as xe, z as l, a7 as Et, aI as Ne, f as he, cg as kt, bj as Ve, ch as Mt, h as Ze, b1 as i, q as ne, E as jt, X as Xe, bT as Vt, u as ie, Y as ut, aJ as vt, A as g, aC as At, a3 as Ft, a4 as Dt, t as Ye, b as He, e as Rt, _ as ft, ci as Ke, cj as pt, bh as Gt, ck as Ut, H as me, af as gt, n as ge, al as mt, bt as $t, cl as yt, cm as Je, a as ot, a2 as Wt, b0 as qt, cn as st, bf as Qt, Z as Yt, bi as qe, F as ht, W as Ht, o as Jt, co as Zt, cp as Me, S as Xt, cq as Qe, T as Kt, C as er, J as tr, cr as _t, D as rr, cs as ar, G as nr, ct as or } from "./index-CMyk0zjR.js";
import sr from "./Container-DZk6eaJf.js";
import { D as lr } from "./DatePicker-BNqrmSk4.js";
import { D as bt } from "./DatePicker-Do344ytB.js";
import { C as ir } from "./CheckboxGroup-e3gaeUuD.js";
import { R as Tt } from "./RadioGroup-CqvV35Hf.js";
import ur from "./BBReferenceField-BjJGUYoe.js";
import { u as cr } from "./utc-Dj9ZRWnW.js";
import { F as lt } from "./datasources-CWO_iMHp.js";
var dr = he('<div class="date-range svelte-2900xs"><!> <div class="arrow svelte-2900xs"><!></div> <!></div>');
function vr(ee, n) {
  Ge(n, !1);
  const I = () => xe(T, "$valueStore", S), [S, ue] = et(), t = l(), _ = l(), z = l();
  let h = u(n, "enableTime", 8, !1), V = u(n, "timeOnly", 8, !1), G = u(n, "ignoreTimezones", 8, !1);
  const N = Pt();
  let Z = u(n, "startDayOfWeek", 24, () => {
  }), D = u(n, "value", 24, () => []);
  const b = tt(), T = Et();
  let R = l(), A = l();
  const _e = (f) => {
    !Array.isArray(f) || !f[0] || !f[1] ? (r(R, null), r(A, null)) : (r(R, Ne(f[0])), r(A, Ne(f[1])));
  }, ce = (f) => {
    const a = f ? h() ? Ne(f) : Ne(f).startOf("day") : null;
    a && (!e(A) || a.isAfter(e(A))) ? r(A, h() ? a : a.endOf("day")) : a || r(A, null), b("change", [a, e(A)]);
  }, X = (f) => {
    const a = f ? h() ? Ne(f) : Ne(f).startOf("day") : null;
    a && (!e(R) || a.isBefore(e(R))) ? r(R, h() ? a : a.startOf("day")) : a || r(R, null), b("change", [e(R), a]);
  };
  d(() => v(D()), () => {
    T.set(D() || []);
  }), d(() => I(), () => {
    _e(I());
  }), d(() => v(Z()), () => {
    r(t, Z() ?? N);
  }), d(() => (e(R), v(h())), () => {
    r(_, e(R) ? it(e(R), { enableTime: h() }) : void 0);
  }), d(() => (e(A), v(h())), () => {
    r(z, e(A) ? it(e(A), { enableTime: h() }) : void 0);
  }), rt(), Ue();
  var U = dr(), $ = M(U);
  bt($, {
    get value() {
      return e(_);
    },
    get enableTime() {
      return h();
    },
    get timeOnly() {
      return V();
    },
    get ignoreTimezones() {
      return G();
    },
    get startDayOfWeek() {
      return e(t);
    },
    $$events: { change: (f) => ce(f.detail) }
  });
  var C = ye($, 2), te = M(C);
  Ot(te, { name: "caret-right" }), j(C);
  var K = ye(C, 2);
  bt(K, {
    get value() {
      return e(z);
    },
    get enableTime() {
      return h();
    },
    get timeOnly() {
      return V();
    },
    get ignoreTimezones() {
      return G();
    },
    get startDayOfWeek() {
      return e(t);
    },
    $$events: { change: (f) => X(f.detail) }
  }), j(U), x(ee, U), $e(), ue();
}
function fr(ee, n) {
  Ge(n, !1);
  let I = u(n, "value", 12, void 0), S = u(n, "label", 8, null), ue = u(n, "labelPosition", 8, "above"), t = u(n, "disabled", 8, !1), _ = u(n, "readonly", 8, !1), z = u(n, "error", 8, null), h = u(n, "helpText", 8, null), V = u(n, "appendTo", 8, void 0), G = u(n, "ignoreTimezones", 8, !1), N = u(n, "enableTime", 8, !1), Z = u(n, "timeOnly", 8, !1);
  const D = tt(), b = (T) => {
    I(T.detail), D("change", T.detail);
  };
  Ue(), kt(ee, {
    get helpText() {
      return h();
    },
    get label() {
      return S();
    },
    get labelPosition() {
      return ue();
    },
    get error() {
      return z();
    },
    children: (T, R) => {
      vr(T, {
        get error() {
          return z();
        },
        get disabled() {
          return t();
        },
        get readonly() {
          return _();
        },
        get value() {
          return I();
        },
        get appendTo() {
          return V();
        },
        get ignoreTimezones() {
          return G();
        },
        get enableTime() {
          return N();
        },
        get timeOnly() {
          return Z();
        },
        $$events: { change: b }
      });
    },
    $$slots: { default: !0 }
  }), $e();
}
function we(ee) {
  return ee === Ve.CONTAINS_ANY || ee === Ve.ONE_OF;
}
var pr = he('<div class="operator svelte-1jhm1bi"><!></div> <!> <!>', 1), gr = he('<div class="filter-popover svelte-1jhm1bi"><div class="filter-popover-body svelte-1jhm1bi"><!></div></div>'), mr = he('<div class="anchor"><!></div> <!>', 1);
function yr(ee, n) {
  Ge(n, !1);
  const I = () => xe(ce, "$rowCache", S), [S, ue] = et(), t = l(), _ = l(), z = l();
  Ne.extend(cr);
  const h = () => e(X)?.show(), V = () => e(X)?.hide();
  let G = u(n, "align", 24, () => Mt.Left), N = u(n, "showPopover", 8, !0), Z = u(n, "filter", 24, () => {
  }), D = u(n, "schema", 8, null), b = u(n, "buttonText", 24, () => {
  }), T = u(n, "config", 24, () => {
  }), R = u(n, "defaultOperator", 24, () => {
  }), A = u(n, "operators", 24, () => {
  });
  const _e = tt(), ce = Ze("rows");
  let X = l(), U = l(), $ = l(!1), C = l(), te = l(), K = l();
  const f = (s) => {
    if (!s)
      return;
    const c = [s.low, s.high];
    if (c.filter((p) => p).length === 2)
      return c;
  }, a = (s) => {
    if (!s) return;
    const c = Ke(s), p = we(s.operator);
    p && typeof s.value == "string" && ![i.STRING, i.NUMBER].includes(s.type) ? c.value = [s.value] : p && !s?.value?.length ? delete c.value : !p && Array.isArray(s.value) && (c.value = s.value[0]);
    const O = [pt.Empty.value, pt.NotEmpty.value];
    return c.noValue = O.includes(c.operator), c?.operator || delete c.value, c;
  }, w = (s) => s ? e(_)?.constraints?.inclusion ?? [] : [], L = (s, c, p) => {
    if (s)
      return Ke(s);
    if (!c || !p)
      return;
    const O = c[p.field], Oe = O?.type === i.BOOLEAN ? "true" : void 0, Ee = {
      valueType: Ut.VALUE,
      field: p.field,
      type: O?.type,
      operator: Gt.EMPTY,
      value: Oe
    }, F = (Fe) => Fe && A()?.find((je) => je.value === Fe)?.value, P = A()?.[0]?.value, H = F(p?.defaultOperator), Ae = F(R());
    return {
      ...Ee,
      operator: H ?? Ae ?? P
    };
  }, W = (s) => {
    !s || !e(t) || r(t, a({ ...e(t), value: s.value }));
  }, re = (s) => {
    const c = s.detail.reduce(
      (p, O) => (p[O._id] = O, p),
      {}
    );
    ce.update((p) => ({ ...p, ...c }));
  };
  d(
    () => (v(Z()), v(D()), v(T())),
    () => {
      r(t, L(Z(), D(), T()));
    }
  ), d(() => (v(T()), v(D())), () => {
    r(_, T() ? D()?.[T()?.field] : void 0);
  }), d(() => e(_), () => {
    r(z, w(e(_)));
  }), d(() => (e(_), i), () => {
    e(_)?.type === i.DATETIME && (r(C, !e(_)?.dateOnly), r(te, !!e(_)?.timeOnly), r(K, !!e(_)?.ignoreTimezones));
  }), rt();
  var Y = { show: h, hide: V };
  Ue();
  var fe = mr(), ae = ne(fe), Ce = M(ae);
  jt(Ce, n, "anchor", {}, null), j(ae), Xe(ae, (s) => r(U, s), () => e(U));
  var be = ye(ae, 2);
  Xe(
    Vt(be, {
      minWidth: 300,
      maxWidth: 300,
      get anchor() {
        return e(U);
      },
      get align() {
        return G();
      },
      get showPopover() {
        return N();
      },
      customZIndex: 5,
      get open() {
        return e($);
      },
      set open(s) {
        r($, s);
      },
      $$events: {
        open(s) {
          ut.call(this, n, s);
        },
        close(s) {
          ut.call(this, n, s);
        }
      },
      children: (s, c) => {
        var p = gr(), O = M(p), Oe = M(O);
        {
          var Ee = (F) => {
            var P = pr(), H = ne(P), Ae = M(H);
            {
              let q = me(() => (e(t), g(() => !e(t).field)));
              vt(Ae, {
                quiet: !0,
                get value() {
                  return e(t), g(() => e(t).operator);
                },
                get disabled() {
                  return e(q);
                },
                get options() {
                  return A();
                },
                autoWidth: !0,
                $$events: {
                  change: (se) => {
                    if (!e(t)) return;
                    const de = a({ ...e(t), operator: se.detail });
                    r(t, { ...de || e(t) });
                  }
                }
              });
            }
            j(H);
            var Fe = ye(H, 2);
            {
              var je = (q) => {
                gt(q, {
                  get disabled() {
                    return e(t), g(() => e(t).noValue);
                  },
                  get value() {
                    return e(t), g(() => e(t).value);
                  },
                  $$events: {
                    change: (se) => {
                      e(t) && r(t, a({ ...e(t), value: se.detail }));
                    }
                  }
                });
              }, at = (q) => {
                var se = ge(), de = ne(se);
                {
                  var Ie = (pe) => {
                    const Se = me(() => (v(we), e(t), g(() => we(e(t).operator)))), o = me(() => e(Se) ? ir : Tt);
                    var m = ge(), E = ne(m);
                    mt(E, () => e(o), (y) => {
                      var k = ge(), Q = ne(k);
                      {
                        let B = me(() => (e(t), g(() => e(t).value || [])));
                        $t(Q, () => e(o), (J, le) => {
                          le(J, {
                            get value() {
                              return e(B);
                            },
                            get disabled() {
                              return e(t), g(() => e(t).noValue);
                            },
                            get options() {
                              return e(z);
                            },
                            direction: "vertical",
                            $$events: {
                              change: (ve) => {
                                e(t) && r(t, a({ ...e(t), value: ve.detail }));
                              }
                            }
                          });
                        });
                      }
                      x(y, k);
                    }), x(pe, m);
                  }, Be = (pe) => {
                    var Se = ge(), o = ne(Se);
                    {
                      var m = (y) => {
                        Tt(y, {
                          get value() {
                            return e(t), g(() => e(t).value);
                          },
                          get disabled() {
                            return e(t), g(() => e(t).noValue);
                          },
                          get options() {
                            return e(z);
                          },
                          direction: "vertical",
                          $$events: {
                            change: (k) => {
                              e(t) && r(t, a({ ...e(t), value: k.detail }));
                            }
                          }
                        });
                      }, E = (y) => {
                        var k = ge(), Q = ne(k);
                        {
                          var B = (le) => {
                            {
                              let ve = me(() => (e(t), g(() => f(e(t).value))));
                              fr(le, {
                                get enableTime() {
                                  return e(C);
                                },
                                get timeOnly() {
                                  return e(te);
                                },
                                get ignoreTimezones() {
                                  return e(K);
                                },
                                get value() {
                                  return e(ve);
                                },
                                $$events: {
                                  change: (De) => {
                                    const [Re, ze] = De.detail, Te = e(C) ? Re.utc().format() : yt(Re, {
                                      enableTime: e(C),
                                      timeOnly: e(te),
                                      ignoreTimezones: e(K)
                                    }), Le = e(C) ? ze.utc().format() : yt(ze, {
                                      enableTime: e(C),
                                      timeOnly: e(te),
                                      ignoreTimezones: e(K)
                                    });
                                    e(t) && r(t, a({
                                      ...e(t),
                                      value: { low: Te, high: Le }
                                    }));
                                  }
                                }
                              });
                            }
                          }, J = (le) => {
                            var ve = ge(), De = ne(ve);
                            {
                              var Re = (Te) => {
                                lr(Te, {
                                  get enableTime() {
                                    return e(C);
                                  },
                                  get timeOnly() {
                                    return e(te);
                                  },
                                  get ignoreTimezones() {
                                    return e(K);
                                  },
                                  get disabled() {
                                    return e(t), g(() => e(t).noValue);
                                  },
                                  get value() {
                                    return e(t), g(() => e(t).value);
                                  },
                                  $$events: {
                                    change: (Le) => {
                                      e(t) && r(t, a({ ...e(t), value: Le.detail }));
                                    }
                                  }
                                });
                              }, ze = (Te) => {
                                var Le = ge(), Nt = ne(Le);
                                {
                                  var wt = (Pe) => {
                                    vt(Pe, {
                                      get value() {
                                        return e(t), g(() => e(t).value);
                                      },
                                      get disabled() {
                                        return e(t), g(() => e(t).noValue);
                                      },
                                      options: [
                                        { label: "True", value: "true" },
                                        { label: "False", value: "false" }
                                      ],
                                      $$events: {
                                        change: (We) => {
                                          e(t) && r(t, a({ ...e(t), value: We.detail }));
                                        }
                                      }
                                    });
                                  }, xt = (Pe) => {
                                    var We = ge(), Ct = ne(We);
                                    {
                                      var It = (ke) => {
                                        const ct = me(() => (v(we), e(t), g(() => we(e(t).operator))));
                                        var dt = ge(), St = ne(dt);
                                        mt(St, () => e(ct), (zt) => {
                                          {
                                            let Lt = me(() => (I(), g(() => Object.values(I()))));
                                            ur(zt, {
                                              get disabled() {
                                                return e(t), g(() => e(t).noValue);
                                              },
                                              get defaultValue() {
                                                return e(t), g(() => e(t).value);
                                              },
                                              get multi() {
                                                return e(ct);
                                              },
                                              onChange: W,
                                              get defaultRows() {
                                                return e(Lt);
                                              },
                                              $$events: { rows: re }
                                            });
                                          }
                                        }), x(ke, dt);
                                      }, Bt = (ke) => {
                                        gt(ke, { disabled: !0 });
                                      };
                                      ie(
                                        Ct,
                                        (ke) => {
                                          e(t), v(i), g(() => e(t).type && [i.BB_REFERENCE, i.BB_REFERENCE_SINGLE].includes(e(t).type)) ? ke(It) : ke(Bt, !1);
                                        },
                                        !0
                                      );
                                    }
                                    x(Pe, We);
                                  };
                                  ie(
                                    Nt,
                                    (Pe) => {
                                      e(t), v(i), g(() => e(t).type === i.BOOLEAN) ? Pe(wt) : Pe(xt, !1);
                                    },
                                    !0
                                  );
                                }
                                x(Te, Le);
                              };
                              ie(
                                De,
                                (Te) => {
                                  e(t), v(i), g(() => e(t).type === i.DATETIME) ? Te(Re) : Te(ze, !1);
                                },
                                !0
                              );
                            }
                            x(le, ve);
                          };
                          ie(
                            Q,
                            (le) => {
                              e(t), v(i), g(() => e(t).type === i.DATETIME && e(t).operator === "range") ? le(B) : le(J, !1);
                            },
                            !0
                          );
                        }
                        x(y, k);
                      };
                      ie(
                        o,
                        (y) => {
                          e(t), v(i), g(() => e(t).type === i.OPTIONS) ? y(m) : y(E, !1);
                        },
                        !0
                      );
                    }
                    x(pe, Se);
                  };
                  ie(
                    de,
                    (pe) => {
                      e(t), v(i), v(Ve), g(() => e(t)?.type && e(t)?.type === i.ARRAY || e(t).type === i.OPTIONS && e(t).operator === Ve.ONE_OF) ? pe(Ie) : pe(Be, !1);
                    },
                    !0
                  );
                }
                x(q, se);
              };
              ie(Fe, (q) => {
                e(t), v(i), g(() => e(t)?.type && [
                  i.STRING,
                  i.LONGFORM,
                  i.NUMBER,
                  i.BIGINT,
                  i.FORMULA,
                  i.AI
                ].includes(e(t).type)) ? q(je) : q(at, !1);
              });
            }
            var nt = ye(Fe, 2);
            At(nt, {
              cta: !0,
              $$events: {
                click: () => {
                  const q = a(e(t)), { noValue: se, value: de, operator: Ie } = q || {};
                  _e("change", !se && !de || !Ie ? void 0 : q), V();
                }
              },
              children: (q, se) => {
                Ft();
                var de = Dt();
                Ye(() => He(de, b() || "Apply")), x(q, de);
              },
              $$slots: { default: !0 }
            }), x(F, P);
          };
          ie(Oe, (F) => {
            e(t) && e(_) && F(Ee);
          });
        }
        j(O), j(p), x(s, p);
      },
      $$slots: { default: !0 },
      $$legacy: !0
    }),
    (s) => r(X, s),
    () => e(X)
  ), Rt("click", ae, h), x(ee, fe), ft(n, "show", h), ft(n, "hide", V);
  var oe = $e(Y);
  return ue(), oe;
}
var hr = he('<span class="display svelte-zc2c1d"> </span>'), _r = he('<span class="filterMeta"> </span>'), br = he('<div slot="anchor"><div><div><div class="toggle-wrap svelte-zc2c1d"><!></div> <span><span class="field"> </span> <!></span> <!></div></div></div>');
function Tr(ee, n) {
  Ge(n, !1);
  const I = () => xe(ce, "$rowCache", S), [S, ue] = et(), t = l(), _ = l(), z = l(), h = l(), V = l();
  let G = u(n, "disabled", 8, !1), N = u(n, "size", 8, "S"), Z = u(n, "buttonText", 8, "Apply"), D = u(n, "defaultOperator", 24, () => {
  }), b = u(n, "filter", 24, () => {
  }), T = u(n, "config", 24, () => {
  }), R = u(n, "schema", 8, null), A = u(n, "operators", 24, () => {
  });
  const _e = tt(), ce = Ze("rows");
  let X = l(), U = l(), $ = l(), C = l();
  const te = (a, w) => {
    if (!a || !w || w.type !== i.DATETIME) return "";
    if (a.operator === Je.RANGE) {
      const re = !w.dateOnly, { high: Y, low: fe } = a.value;
      return `${st(fe, { enableTime: re })}
        - ${st(Y, { enableTime: re })}`;
    }
    const L = it(a.value, { enableTime: !w.dateOnly });
    return `${st(L, { enableTime: !w.dateOnly })}`;
  }, K = (a) => {
    const w = Array.isArray(a) && a?.length > 1 ? `+${a?.length - 1} more` : void 0;
    return r($, w), r(C, `${a?.join(", ")}`), `${a?.[0]}`;
  }, f = (a, w) => {
    if (r($, void 0), r(C, void 0), !a || !w) return;
    let L = a.value;
    if (w.type === i.BOOLEAN)
      L = qt(a.value);
    else if (w.type === i.DATETIME)
      L = te(a, w);
    else if (w.type === i.ARRAY)
      if (!we(a.operator))
        L = a.value;
      else {
        const W = Array.isArray(a.value) ? a.value : [a.value];
        L = K(W);
      }
    else if (w.type === i.BB_REFERENCE || w.type === i.BB_REFERENCE_SINGLE) {
      let W = "";
      if (!we(a.operator))
        W = I()?.[a.value]?.email ?? a.value;
      else {
        const re = Array.isArray(a.value) ? a.value : [a.value];
        W = K(re.map((Y) => I()?.[Y]?.email ?? Y));
      }
      L = W;
    }
    return `${e(z)?.label.toLowerCase()} ${a.noValue ? "" : L}`;
  };
  d(() => v(b()), () => {
    r(t, b() ? "x-circle" : "sliders-horizontal");
  }), d(() => (v(T()), v(R())), () => {
    r(_, T() ? R()?.[T()?.field] : void 0);
  }), d(() => (v(b()), v(A())), () => {
    r(z, b() ? A()?.find((a) => a.value === b().operator) : void 0);
  }), d(() => (e(z), Je), () => {
    r(h, e(z)?.value !== Je.RANGE);
  }), d(() => (v(b()), e(_)), () => {
    r(V, f(b(), e(_)));
  }), rt(), Ue(), Xe(
    yr(ee, {
      get filter() {
        return b();
      },
      get operators() {
        return A();
      },
      get schema() {
        return R();
      },
      get config() {
        return T();
      },
      get buttonText() {
        return Z();
      },
      get defaultOperator() {
        return D();
      },
      $$events: {
        change(a) {
          ut.call(this, n, a);
        }
      },
      $$slots: {
        anchor: (a, w) => {
          var L = br(), W = M(L);
          let re;
          var Y = M(W);
          let fe;
          var ae = M(Y), Ce = M(ae);
          Ot(Ce, {
            get name() {
              return e(t);
            },
            get size() {
              return N();
            }
          }), j(ae);
          var be = ye(ae, 2);
          let oe;
          var s = M(be), c = M(s, !0);
          j(s);
          var p = ye(s, 2);
          {
            var O = (F) => {
              var P = hr(), H = M(P, !0);
              j(P), Ye(() => He(H, e(V))), x(F, P);
            };
            ie(p, (F) => {
              b() && F(O);
            });
          }
          j(be);
          var Oe = ye(be, 2);
          {
            var Ee = (F) => {
              var P = _r(), H = M(P, !0);
              j(P), Ye(() => He(H, e($))), x(F, P);
            };
            ie(Oe, (F) => {
              e($) && F(Ee);
            });
          }
          j(Y), Xe(Y, (F) => r(U, F), () => e(U)), j(W), j(L), Ye(
            (F, P, H, Ae) => {
              re = ot(W, 1, "filter-button-wrap svelte-zc2c1d", null, re, F), fe = ot(Y, 1, `new-styles spectrum-Button spectrum-Button--secondary spectrum-Button--size${P ?? ""}`, "svelte-zc2c1d", fe, H), Wt(Y, "title", e(C) || e(V)), oe = ot(be, 1, "spectrum-Button-label svelte-zc2c1d", null, oe, Ae), He(c, (v(T()), g(() => T()?.label || T()?.field)));
            },
            [
              () => ({ inactive: !b() }),
              () => (v(N()), g(() => N().toUpperCase())),
              () => ({ "is-disabled": G() }),
              () => ({ truncate: e(h) })
            ]
          ), Rt("click", ae, (F) => {
            b() && F.stopPropagation(), G() || _e("toggle");
          }), x(a, L);
        }
      },
      $$legacy: !0
    }),
    (a) => r(X, a),
    () => e(X)
  ), $e(), ue();
}
var Or = he("<!> <!>", 1), Er = he('<div><div class="filters svelte-116ylo9"><!></div></div>');
function Br(ee, n) {
  Ge(n, !1);
  const I = () => xe(W, "$memoFilters", _), S = () => xe(re, "$component", _), ue = () => xe(e(oe), "$userFetch", _), t = () => xe(Qe, "$uiStateStore", _), [_, z] = et(), h = l(), V = l(), G = l(), N = l(), Z = l(), D = l(), b = l(), T = l(), R = l(), A = l(), _e = l(), ce = l(), X = l(), U = l(), $ = l();
  let C = u(n, "persistFilters", 8, !1), te = u(n, "showClear", 8, !1), K = u(n, "filterConfig", 24, () => []), f = u(n, "targetComponent", 8), a = u(n, "size", 8, "M"), w = u(n, "buttonText", 8, "Apply"), L = u(n, "defaultOperator", 24, () => {
  });
  const W = Qt({}), re = Ze("component"), { API: Y, fetchDatasourceSchema: fe, getRelationshipSchemaAdditions: ae } = Ze("sdk"), Ce = Et({});
  Yt("rows", Ce);
  const be = {
    logicalOperator: qe.ALL,
    onEmptyFilter: ht.RETURN_NONE,
    groups: [
      {
        logicalOperator: qe.ALL,
        // could be configurable
        filters: []
      }
    ]
  };
  let oe = l(), s = l(!1), c = l({}), p = l(), O = l(null);
  const Oe = (o) => {
    !e(O) && o ? (r(O, o), e(s) || Ie()) : e(O) && !o && (r(s, !1), r(O, null), r(c, {}), r(p, null));
  }, Ee = (o, m) => {
    if (!o?.field || !o.columnType || !m)
      return [];
    const E = o.columnType || m[o.field].type;
    let y = or({ type: E }, o.field, e(G));
    const k = E === i.DATETIME, Q = {
      rangeHigh: k ? "Before" : void 0,
      rangeLow: k ? "After" : void 0,
      [lt.EQUAL]: "Is",
      [lt.NOT_EQUAL]: "Is not"
    };
    return y = [
      ...y,
      ...E === i.DATETIME ? [{ value: Je.RANGE, label: "Between" }] : []
    ], y.filter((B) => !(k && B.value === lt.ONE_OF)).map((B) => ({ ...B, label: Q[B.value] || B.label }));
  }, F = (o) => {
    const m = Ke(be);
    if (delete m.onEmptyFilter, m.groups) {
      const E = m.groups;
      E[0].filters = Object.values(o);
    }
    return m;
  }, P = (o) => {
    if (!(!S()?.id || !e(N))) {
      if (Object.keys(e(c)).length == 0) {
        e(ce)?.(S().id), H();
        return;
      }
      C() && H(), e(_e)?.(S().id, e(b) ? o : e(V));
    }
  }, H = () => {
    Qe.update((o) => ({
      ...o,
      [S().id]: {
        sourceId: e(G).resourceId,
        filters: e(c)
      }
    }));
  }, Ae = () => {
    Qe.update((o) => (delete o[S().id], o));
  }, Fe = [
    i.ATTACHMENT_SINGLE,
    i.ATTACHMENTS,
    i.AI
  ];
  async function je(o) {
    if (o) {
      const m = await fe(o, { enrichRelationships: !0, formSchema: !1 }), E = Object.entries(m || {}).filter(([Q, B]) => !Fe.includes(B.type)), y = Object.fromEntries(E), k = await ae(y);
      r(p, { ...y, ...k });
    } else
      r(p, null);
  }
  const at = (o, m) => Ee(o, m), nt = () => {
    r(c, {}), Qe.update((o) => (delete o[S().id], o));
  }, q = (o) => {
    let m = {
      logicalOperator: qe.ALL,
      filters: [
        {
          field: "_id",
          operator: Ve.ONE_OF,
          value: Array.isArray(o) ? o : [o]
        }
      ]
    }, E = o ? {
      logicalOperator: qe.ALL,
      groups: [m],
      onEmptyFilter: ht.RETURN_NONE
    } : void 0;
    const y = { type: "user", tableId: ar.USER_METADATA };
    return nr({
      API: Y,
      datasource: y,
      options: { filter: E, limit: 100 }
    });
  }, se = (o) => {
    const m = Object.entries(o || {}).filter(([E, y]) => y.type === i.BB_REFERENCE_SINGLE || y.type === i.BB_REFERENCE);
    return Object.fromEntries(m);
  }, de = (o) => {
    const m = Object.entries(o || {}).reduce(
      (y, [k, Q]) => ((Q.type === i.BB_REFERENCE_SINGLE || Q.type === i.BB_REFERENCE) && Q.value && (y = [
        ...y,
        ...Array.isArray(Q.value) ? Q.value : [Q.value]
      ]), y),
      []
    ), E = new Set(m);
    return Array.from(E);
  }, Ie = () => {
    if (C()) {
      const o = t()[S().id]?.filters;
      r(c, Ke(o || {}));
    }
    r(s, !0);
  };
  Ht(() => {
    C() ? Ie() : Ae();
  }), Jt(() => {
    e(ce)?.(S().id);
  }), d(() => e(c), () => {
    W.set(e(c));
  }), d(() => I(), () => {
    r(h, F(I()));
  }), d(() => (e(h), Zt), () => {
    r(V, e(h) ? er(e(h)) : null);
  }), d(() => v(f()), () => {
    r(G, f()?.embeddedData?.dataSource ?? f()?.datasource);
  }), d(() => v(f()), () => {
    r(N, f()?.embeddedData?.componentId ?? f()?.id);
  }), d(() => e(N), () => {
    r(Z, tr.actions.getComponentById(e(N)));
  }), d(() => v(f()), () => {
    r(D, (f()?.embeddedData?.loaded ?? f()?.loaded) || !1);
  }), d(() => (e(D), e(Z)), () => {
    e(D) && Oe(e(Z));
  }), d(() => (e(O), e(G)), () => {
    e(O) && je(e(G));
  }), d(() => e(O), () => {
    r(b, e(O)?._component === "@budibase/standard-components/gridblock");
  }), d(() => (v(K()), e(p)), () => {
    r(T, K()?.filter((o) => o.active && e(p)?.[o.field]));
  }), d(() => (e(b), Me), () => {
    r(R, e(b) ? Me.AddDataProviderFilterExtension : Me.AddDataProviderQueryExtension);
  }), d(() => (e(b), Me), () => {
    r(A, e(b) ? Me.RemoveDataProviderFilterExtension : Me.RemoveDataProviderQueryExtension);
  }), d(
    () => (e(N), e(D), e(R)),
    () => {
      r(_e, e(N) && e(D) ? _t(e(N), e(R)) : null);
    }
  ), d(
    () => (e(N), e(D), e(A)),
    () => {
      r(ce, e(N) && e(D) ? _t(e(N), e(A)) : null);
    }
  ), d(
    () => (e(s), e(O), e(D), e(h)),
    () => {
      e(s) && e(O) && e(D) && P(e(h));
    }
  ), d(() => I(), () => {
    r(X, se(I()));
  }), d(() => e(X), () => {
    r(U, de(e(X)));
  }), d(() => (e(oe), e(U)), () => {
    !e(oe) && e(U).length && rr(r(oe, q(e(U))), "$userFetch", _);
  }), d(() => (e(oe), ue()), () => {
    r($, e(oe) ? ue()?.rows : []);
  }), d(() => e($), () => {
    if (e($).length) {
      const o = e($).reduce(
        (m, E) => (m[E._id] = E, m),
        {}
      );
      Ce.update((m) => ({ ...m, ...o }));
    }
  }), rt(), Ue();
  var Be = Er(), pe = M(Be), Se = M(pe);
  sr(Se, {
    wrap: !0,
    direction: "row",
    hAlign: "left",
    vAlign: "top",
    gap: "S",
    children: (o, m) => {
      var E = Or(), y = ne(E);
      Xt(y, 1, () => e(T) || [], Kt, (B, J) => {
        const le = me(() => (I(), e(J), g(() => I()[e(J).field])));
        {
          let ve = me(() => (e(J), e(p), g(() => at(e(J), e(p)))));
          Tr(B, {
            get size() {
              return a();
            },
            get config() {
              return e(J);
            },
            get filter() {
              return e(le);
            },
            get schema() {
              return e(p);
            },
            get buttonText() {
              return w();
            },
            get defaultOperator() {
              return L();
            },
            get operators() {
              return e(ve);
            },
            $$events: {
              change: (De) => {
                if (De.detail)
                  r(c, { ...e(c), [e(J).field]: De.detail });
                else {
                  const { [e(J).field]: Re, ...ze } = e(c);
                  r(c, { ...ze });
                }
              },
              toggle: () => {
                const { [e(J).field]: De, ...Re } = e(c);
                r(c, { ...Re });
              }
            }
          });
        }
      });
      var k = ye(y, 2);
      {
        var Q = (B) => {
          At(B, {
            get size() {
              return a();
            },
            secondary: !0,
            $$events: { click: nt },
            children: (J, le) => {
              Ft();
              var ve = Dt("Clear all");
              x(J, ve);
            },
            $$slots: { default: !0 }
          });
        };
        ie(k, (B) => {
          v(te()), e(c), g(() => te() && Object.keys(e(c)).length) && B(Q);
        });
      }
      x(o, E);
    },
    $$slots: { default: !0 }
  }), j(pe), j(Be), x(ee, Be), $e(), z();
}
export {
  Br as default
};
