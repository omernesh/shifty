import { g as be, p as i, $ as _e, l as y, B as C, i as a, j as e, k as ge, m as xe, c as n, u as Y, A as g, s as A, r as o, t as j, a as G, ap as fe, d as q, w as ke, z as S, a0 as Z, I as $, a2 as ee, cC as se, b as ae, e as le, n as ye, q as Ce, S as Ae, H as D, T as Ge, f as E } from "./index-CMyk0zjR.js";
var Se = E('<div><label class="spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-1srh935"><input type="checkbox" class="spectrum-Checkbox-input svelte-1srh935"/> <span class="spectrum-Checkbox-box"><span><!></span></span> <span class="spectrum-Checkbox-label"> </span></label></div>'), ze = E('<div><label class="spectrum-Checkbox spectrum-Checkbox--sizeM spectrum-FieldGroup-item svelte-1srh935"><input type="checkbox" class="spectrum-Checkbox-input svelte-1srh935"/> <span class="spectrum-Checkbox-box"><span><!></span></span> <span class="spectrum-Checkbox-label"> </span></label></div>'), Fe = E("<div><!> <!></div>");
function Oe(te, r) {
  be(r, !1);
  const b = S(), B = S(), I = S(), z = S(), H = S();
  let M = i(r, "direction", 8, "vertical"), u = i(r, "value", 24, () => []), t = i(r, "options", 24, () => []), J = i(r, "disabled", 8, !1), K = i(r, "readonly", 8, !1), V = i(r, "columns", 8, 1), F = i(r, "getOptionLabel", 8, (s) => `${s}`), v = i(r, "getOptionValue", 8, (s) => s), N = i(r, "showSelectAll", 8, !1), P = i(r, "selectAllText", 8, "Select all");
  const w = _e(), ce = (s) => {
    u().includes(s) ? w("change", u().filter((l) => l !== s)) : w("change", [...u(), s]);
  }, re = () => {
    if (e(b))
      w("change", []);
    else {
      const s = t().map((l) => v()(l));
      w("change", s);
    }
  };
  y(
    () => (a(t()), a(u()), a(v())),
    () => {
      C(b, t().length > 0 && t().every((s) => u().includes(v()(s))));
    }
  ), y(
    () => (a(t()), a(u()), a(v())),
    () => {
      C(B, t().length === 0 || t().every((s) => !u().includes(v()(s))));
    }
  ), y(() => (e(b), e(B)), () => {
    C(I, !e(b) && !e(B));
  }), y(() => (a(M()), a(V())), () => {
    C(z, M() === "horizontal" && V() > 1 ? `repeat(${V()}, minmax(0, 1fr))` : void 0);
  }), y(() => e(z), () => {
    C(H, !!e(z));
  }), ge(), xe();
  var x = Fe();
  let Q, R;
  var U = n(x);
  {
    var ne = (s) => {
      var l = Se();
      let O;
      var L = n(l), c = n(L);
      Z(c);
      var h = A(c, 2), _ = n(h);
      let d;
      var T = n(_);
      {
        let m = D(() => e(I) ? "minus" : "check");
        $(T, {
          get name() {
            return e(m);
          },
          weight: "bold",
          color: "var(--spectrum-global-color-gray-50)"
        });
      }
      o(_), o(h);
      var f = A(h, 2), p = n(f, !0);
      o(f), o(L), o(l), j(
        (m, k) => {
          ee(l, "title", P()), O = G(l, 1, "spectrum-Checkbox spectrum-FieldGroup-item select-all-checkbox svelte-1srh935", null, O, m), se(c, e(b)), c.disabled = J(), d = G(_, 1, "icon svelte-1srh935", null, d, k), ae(p, P());
        },
        [
          () => ({ readonly: K() }),
          () => ({ checked: e(b) || e(I) })
        ]
      ), le("change", c, re), q(s, l);
    };
    Y(U, (s) => {
      a(N()), a(t()), g(() => N() && t()?.length > 0) && s(ne);
    });
  }
  var oe = A(U, 2);
  {
    var ie = (s) => {
      var l = ye(), O = Ce(l);
      Ae(O, 1, t, Ge, (L, c) => {
        const h = D(() => (a(v()), e(c), g(() => v()(e(c))))), _ = D(() => (a(u()), a(e(h)), g(() => u().includes(e(h)))));
        var d = ze();
        let T;
        var f = n(d), p = n(f);
        Z(p);
        var m = A(p, 2), k = n(m);
        let W;
        var ue = n(k);
        $(ue, {
          name: "check",
          weight: "bold",
          color: "var(--spectrum-global-color-gray-50)"
        }), o(k), o(m);
        var X = A(m, 2), de = n(X, !0);
        o(X), o(f), o(d), j(
          (ve, he, pe, me) => {
            ee(d, "title", ve), T = G(d, 1, "spectrum-Checkbox spectrum-FieldGroup-item svelte-1srh935", null, T, he), se(p, e(_)), p.disabled = J(), W = G(k, 1, "icon svelte-1srh935", null, W, pe), ae(de, me);
          },
          [
            () => (a(F()), e(c), g(() => F()(e(c)))),
            () => ({ readonly: K() }),
            () => ({ checked: e(_) }),
            () => (a(F()), e(c), g(() => F()(e(c))))
          ]
        ), le("change", p, () => ce(e(h))), q(L, d);
      }), q(s, l);
    };
    Y(oe, (s) => {
      a(t()), g(() => t() && Array.isArray(t())) && s(ie);
    });
  }
  o(x), j(
    (s, l) => {
      Q = G(x, 1, `spectrum-FieldGroup spectrum-FieldGroup--${M()}`, "svelte-1srh935", Q, s), R = fe(x, "", R, l);
    },
    [
      () => ({ horizontal: e(H) }),
      () => ({ "grid-template-columns": e(z) })
    ]
  ), q(te, x), ke();
}
export {
  Oe as C
};
