import { bJ as i, cw as r } from "./index-CMyk0zjR.js";
import o from "./StringField-DqsD-SN7.js";
function a(t, e) {
  const s = i(e, ["children", "$$slots", "$$events", "$$legacy"]);
  o(t, r(() => s, { type: "bigint" }));
}
export {
  a as default
};
