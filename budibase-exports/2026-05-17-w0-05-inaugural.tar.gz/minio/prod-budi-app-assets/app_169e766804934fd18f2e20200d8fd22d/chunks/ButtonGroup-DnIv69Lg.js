import { J, K, M as N, N as O, O as Q, g as R, p as a, h as m, l as F, i as k, k as I, m as L, Q as V, R as B, n as x, q as A, u as W, d as y, j as n, H as h, w as X, x as Y, y as Z, S as $, T as tt, z as et, B as nt, A as st } from "./index-CMyk0zjR.js";
import { C as it } from "./CollapsedButtonGroup-CkTH3q4z.js";
let r;
const ot = () => {
  if (r)
    return r;
  const e = J.actions.getComponentDefinition(
    "@budibase/standard-components/button"
  );
  if (!e)
    return r = {}, r;
  const t = K(e);
  let i = {};
  return t?.forEach((s) => {
    i[s.key] = s;
  }), r = i, r;
}, at = (e) => {
  if (!e?.length)
    return { visible: !0, settingUpdates: {} };
  let t = !e.find((l) => l.action === "show");
  const i = O(e), s = Q(i);
  return s.visible != null && (t = s.visible), { visible: t, settingUpdates: s.settingUpdates };
}, lt = (e, t, i, s) => {
  const l = e?._conditions || e?.conditions, d = N(
    {
      ...e,
      _conditions: l
    },
    t,
    s
  ), { visible: p, settingUpdates: f } = at(
    d._conditions
  );
  if (!p)
    return null;
  const u = {
    ...d,
    ...f
  };
  return {
    ...u,
    onClick: async () => {
      await (typeof u.onClick == "function" ? u.onClick : i(e.onClick, t))?.();
    }
  };
}, ct = (e, t, i) => {
  if (!e?.length)
    return [];
  const s = ot();
  return e.map(
    (l) => lt(
      l,
      t,
      i,
      s
    )
  ).filter(Boolean);
};
function gt(e, t) {
  R(t, !1);
  const i = () => Y(M, "$context", s), [s, l] = Z(), d = et();
  let p = a(t, "buttons", 24, () => []), f = a(t, "direction", 8, "row"), u = a(t, "hAlign", 8, "left"), v = a(t, "vAlign", 8, "top"), S = a(t, "gap", 8, "S"), _ = a(t, "collapsed", 8, !1), w = a(t, "collapsedText", 8, "Action"), z = a(t, "collapsedSize", 8, "M");
  const { enrichButtonActions: D } = m("sdk"), M = m("context");
  F(
    () => (k(_()), k(p()), i()),
    () => {
      nt(d, _() ? ct(p(), i(), D) : null);
    }
  ), I(), L(), V(e, {
    children: (b, rt) => {
      {
        let q = h(() => ({
          direction: f(),
          hAlign: u(),
          vAlign: v(),
          gap: S(),
          wrap: !0
        }));
        B(b, {
          type: "container",
          get props() {
            return n(q);
          },
          styles: { normal: { height: "100%" } },
          children: (U, dt) => {
            var C = x(), P = A(C);
            {
              var T = (c) => {
                {
                  let g = h(() => w() || "Action");
                  it(c, {
                    get text() {
                      return n(g);
                    },
                    get buttons() {
                      return n(d);
                    },
                    get size() {
                      return z();
                    }
                  });
                }
              }, G = (c) => {
                var g = x(), j = A(g);
                $(j, 1, p, tt, (E, o) => {
                  {
                    let H = h(() => (n(o), st(() => ({
                      text: n(o)?.text || "Button",
                      onClick: n(o)?.onClick,
                      type: n(o)?.type,
                      quiet: n(o)?.quiet,
                      disabled: n(o)?.disabled,
                      icon: n(o)?.icon,
                      gap: n(o)?.gap,
                      size: n(o)?.size || "M",
                      _conditions: n(o)?._conditions || n(o)?.conditions
                    }))));
                    B(E, {
                      type: "button",
                      get props() {
                        return n(H);
                      }
                    });
                  }
                }), y(c, g);
              };
              W(P, (c) => {
                _() ? c(T) : c(G, !1);
              });
            }
            y(U, C);
          },
          $$slots: { default: !0 }
        });
      }
    },
    $$slots: { default: !0 }
  }), X(), l();
}
export {
  gt as default
};
