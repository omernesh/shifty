import { g as G, p as i, $ as I, l as g, i as B, j as a, k as J, m as K, c as L, d4 as M, X as Q, B as n, s as R, E as U, r as W, t as Z, ap as N, a as $, a2 as P, a1 as ee, e as d, Y as j, d as te, _, w as ae, z as u, f as se } from "./index-CMyk0zjR.js";
var le = se('<div><textarea class="spectrum-Textfield-input svelte-1xssmuf"></textarea> <!></div>');
function ne(w, e) {
  G(e, !1);
  const m = u(), v = u();
  let z = i(e, "value", 8, ""), A = i(e, "placeholder", 24, () => {
  }), o = i(e, "disabled", 8, !1), b = i(e, "readonly", 8, !1), D = i(e, "id", 24, () => {
  }), x = i(e, "height", 24, () => {
  }), y = i(e, "minHeight", 24, () => {
  }), C = i(e, "align", 8, null), F = i(e, "updateOnChange", 8, !1);
  const H = () => ({
    start: a(l).selectionStart,
    end: a(l).selectionEnd
  }), S = I();
  let f = u(!1), l = u(), h = u(!1);
  function T() {
    a(l).focus();
  }
  function p() {
    return a(l).value;
  }
  const V = () => {
    n(f, !1), E();
  }, X = () => {
    n(h, a(l).clientHeight < a(l).scrollHeight), F() && E();
  }, E = () => {
    b() || o() || S("change", a(l).value);
  }, O = (s, c) => c == null ? "" : typeof c != "number" || isNaN(c) ? `${s}:${c};` : `${s}:${c}px;`;
  g(() => B(x()), () => {
    n(m, O("height", x()));
  }), g(() => B(y()), () => {
    n(v, O("min-height", y()));
  }), g(() => a(h), () => {
    S("scrollable", a(h));
  }), J();
  var Y = { getCaretPosition: H, focus: T, contents: p };
  K();
  var r = le();
  let k;
  var t = L(r);
  M(t), Q(t, (s) => n(l, s), () => a(l));
  var q = R(t, 2);
  return U(q, e, "default", {}, null), W(r), Z(
    (s) => {
      N(r, `${a(m)}${a(v)}`), k = $(r, 1, "spectrum-Textfield spectrum-Textfield--multiline svelte-1xssmuf", null, k, s), P(t, "placeholder", A() || ""), N(t, C() ? `text-align: ${C()}` : ""), t.disabled = o(), t.readOnly = b(), P(t, "id", D()), ee(t, z() || "");
    },
    [
      () => ({ "is-disabled": o(), "is-focused": a(f) })
    ]
  ), d("input", t, X), d("focus", t, () => n(f, !0)), d("blur", t, V), d("blur", t, function(s) {
    j.call(this, e, s);
  }), d("keypress", t, function(s) {
    j.call(this, e, s);
  }), te(w, r), _(e, "getCaretPosition", H), _(e, "focus", T), _(e, "contents", p), ae(Y);
}
export {
  ne as T
};
