import { g as W, h as b, p as t, l as y, i as R, k as X, m as Y, n as c, q as d, u as m, d as n, w as Z, y as $, A as p, j as a, x as ee, z as C, B as q, S as te, E as ae, H as se, T as re, s as oe, c as ne, r as le, t as ie, b as ce, f as de } from "./index-CMyk0zjR.js";
import fe from "./Placeholder-DdLpQoxl.js";
import ge from "./Container-DZk6eaJf.js";
var ve = de('<div class="noRows svelte-1kdie20"><i class="ri-list-check-2 svelte-1kdie20"></i> </div>');
function ke(M, e) {
  W(e, !1);
  const h = () => ee(E, "$component", S), [S, j] = $(), f = C(), k = C(), { Provider: z, ContextScopes: B } = b("sdk"), E = b("component");
  let g = t(e, "dataProvider", 8), x = t(e, "noRowsMessage", 8), H = t(e, "direction", 8), L = t(e, "hAlign", 8), T = t(e, "vAlign", 8), D = t(e, "gap", 8), F = t(e, "scope", 24, () => B.Local);
  y(() => R(g()), () => {
    q(f, g()?.rows ?? []);
  }), y(() => R(g()), () => {
    q(k, g()?.loaded ?? !0);
  }), X(), Y(), ge(M, {
    get direction() {
      return H();
    },
    get hAlign() {
      return L();
    },
    get vAlign() {
      return T();
    },
    get gap() {
      return D();
    },
    wrap: !0,
    children: (G, ue) => {
      var A = c(), I = d(A);
      {
        var J = (s) => {
          fe(s, {});
        }, K = (s) => {
          var w = c(), N = d(w);
          {
            var O = (r) => {
              var l = c(), v = d(l);
              te(v, 1, () => a(f), re, (u, o, i) => {
                {
                  let _ = se(() => (a(o), p(() => ({ ...a(o), index: i }))));
                  z(u, {
                    get data() {
                      return a(_);
                    },
                    get scope() {
                      return F();
                    },
                    children: (U, _e) => {
                      var P = c(), V = d(P);
                      ae(V, e, "default", {}, null), n(U, P);
                    },
                    $$slots: { default: !0 }
                  });
                }
              }), n(r, l);
            }, Q = (r) => {
              var l = c(), v = d(l);
              {
                var u = (o) => {
                  var i = ve(), _ = oe(ne(i), 1, !0);
                  le(i), ie(() => ce(_, x())), n(o, i);
                };
                m(
                  v,
                  (o) => {
                    a(k) && x() && o(u);
                  },
                  !0
                );
              }
              n(r, l);
            };
            m(
              N,
              (r) => {
                a(f), p(() => a(f).length > 0) ? r(O) : r(Q, !1);
              },
              !0
            );
          }
          n(s, w);
        };
        m(I, (s) => {
          h(), p(() => h().empty) ? s(J) : s(K, !1);
        });
      }
      n(G, A);
    },
    $$slots: { default: !0 }
  }), Z(), j();
}
export {
  ke as default
};
