import { g as Ke, p as d, b1 as x, h as ze, cF as Je, $ as Qe, l, i as p, j as e, k as We, m as Xe, n as fe, q as pe, u as Ye, d as ye, B as a, w as Ze, x as $e, y as et, z as i, bt as tt, cG as rt, H as B, A as C, D as at, cH as lt, cs as it, G as st, bF as M, bA as nt, bh as ot, F as ge, bi as Q, bC as ct } from "./index-CMyk0zjR.js";
import { M as dt } from "./Multiselect-BjsXMbjn.js";
import { F as ut } from "./Field-DlAvOihk.js";
function gt(he, o) {
  Ke(o, !1);
  const _ = () => $e(e(U), "$fetch", W), [W, me] = et(), h = i(), E = i(), w = i(), v = i(), F = i(), P = i(), b = i(), U = i(), S = i(), g = i(), X = i(), O = i(), D = i(), Y = i(), V = i(), Z = i();
  let _e = d(o, "field", 24, () => {
  }), be = d(o, "label", 24, () => {
  }), Oe = d(o, "placeholder", 24, () => {
  }), j = d(o, "disabled", 8, !1), G = d(o, "readonly", 8, !1), Ae = d(o, "validation", 24, () => {
  }), Ee = d(o, "autocomplete", 8, !0), $ = d(o, "defaultValue", 24, () => {
  }), ee = d(o, "onChange", 8), I = d(o, "filter", 24, () => {
  }), q = d(o, "datasourceType", 8, "table"), te = d(o, "primaryDisplay", 24, () => {
  }), we = d(o, "span", 24, () => {
  }), Fe = d(o, "helpText", 24, () => {
  }), Se = d(o, "wrapText", 8, !1), N = d(o, "type", 24, () => x.LINK), re = d(o, "multi", 24, () => {
  }), ae = d(o, "tableId", 24, () => {
  }), le = d(o, "defaultRows", 24, () => []);
  const De = ze("sdk") ?? {}, { API: ie } = De, se = Je("picker");
  let T = d(o, "workspaceUsersOnly", 8, !1);
  const Te = Qe();
  let y = i(), H = i(), A = i(), R = i(), L = i(!1), k = i([]), c = i({}), K = !1;
  const ve = (t, r) => r ? de(t) : de(t)[0], Ie = (t, r, s, n, u) => {
    const f = r === "table" ? { type: r, tableId: n } : {
      type: u ? "table" : r,
      tableId: it.USER_METADATA
    };
    return st({
      API: ie,
      datasource: f,
      options: { filter: s, limit: t ? 100 : 1 }
    });
  }, Ne = (t) => t ? Array.isArray(t) ? t : [t] : [], Re = (t, r, s) => {
    if (t) {
      const n = Array.isArray(t) ? t : [t];
      for (let u of n) {
        const f = J(u, s);
        f && M(c, e(c)[f._id] = f);
      }
    }
    for (let n of r) {
      const u = J(n, s);
      u && M(c, e(c)[u._id] = u);
    }
    a(c, e(c));
  }, z = (t) => q() === "user" && T() ? t.replace(`ro_${ct.USERS}_`, "") : t, J = (t, r) => typeof t == "string" && e(c)[t] ? e(c)[t] : !t || typeof t != "object" || !t?._id ? null : Object.keys(t).length === 2 && "primaryDisplay" in t ? {
    _id: z(t._id),
    primaryDisplay: ce(t.primaryDisplay)
  } : r ? {
    _id: z(t._id),
    primaryDisplay: ce(t[r])
  } : { _id: z(t._id), primaryDisplay: t._id }, Le = async (t, r, s) => {
    if (!(K || !t.length || !r || !s)) {
      K = !0;
      try {
        const n = await ie.searchTable(r, { query: { oneOf: { _id: t } } });
        for (let u of n.rows) {
          const f = J(u, s);
          f && M(c, e(c)[f._id] = f);
        }
        a(c, e(c)), ne(e(c));
      } catch (n) {
        console.error("Error loading missing row IDs", n);
      } finally {
        for (let n of t)
          e(c)[n] || M(c, e(c)[n] = { _id: n, primaryDisplay: n });
        K = !1;
      }
    }
  }, ne = (t) => {
    let r = Object.values(t);
    r.length !== e(k).length && (a(k, r), oe());
  }, oe = () => {
    const t = e(v).reduce((r, s) => ({ ...r, [s]: !0 }), {});
    e(k).sort((r, s) => {
      const n = !!t[r._id], u = !!t[s._id];
      return n === u ? r.primaryDisplay < s.primaryDisplay ? -1 : 1 : n ? -1 : 1;
    });
  }, ce = (t) => typeof t == "string" ? t : JSON.stringify(t), ke = (t) => !t || typeof t != "string" ? t : t.includes(",") ? t.split(",") : t, xe = (t) => Array.isArray(t) ? lt(t) : t;
  async function Be(t, r) {
    if (!r)
      return;
    let s, n = {
      logicalOperator: Q.ALL,
      filters: [
        {
          field: r,
          operator: ot.STRING,
          value: t
        }
      ]
    };
    t && e(b) ? s = {
      logicalOperator: Q.ALL,
      groups: [n, e(b)],
      onEmptyFilter: ge.RETURN_NONE
    } : t ? s = {
      logicalOperator: Q.ALL,
      groups: [n],
      onEmptyFilter: ge.RETURN_NONE
    } : s = e(b), await e(U)?.update({ filter: s });
  }
  const Ce = nt(Be, 250), de = (t) => t ? (Array.isArray(t) || (t = [t]), t = t.map((r) => typeof r == "object" ? r._id : r), t) : [], Me = (t) => {
    let r = t.detail;
    e(h) || (r = r == null ? [] : [r]), N() === x.BB_REFERENCE_SINGLE && r && Array.isArray(r) && (r = r[0] || null);
    const s = e(H).setValue(r);
    ee() && s && ee()({ value: r });
  };
  l(
    () => (p(I()), p(T())),
    () => {
      I(), T(), a(c, {});
    }
  ), l(
    () => (p(re()), p(N()), e(A)),
    () => {
      a(h, re() ?? ([x.LINK, x.BB_REFERENCE].includes(N()) && e(A)?.relationshipType !== "one-to-many"));
    }
  ), l(() => e(y), () => {
    a(E, e(y)?.value);
  }), l(() => (e(E), e(h)), () => {
    a(w, ve(e(E), e(h)));
  }), l(() => e(w), () => {
    a(v, Ne(e(w)));
  }), l(() => (p(ae()), e(A)), () => {
    a(F, ae() ?? e(A)?.tableId);
  }), l(() => (p(j()), p(G())), () => {
    a(P, !j() && !G());
  }), l(() => p(I()), () => {
    a(b, xe(I()));
  }), l(
    () => (e(P), p(q()), e(b), e(F), p(T())),
    () => {
      at(a(U, Ie(e(P), q(), e(b), e(F), T())), "$fetch", W);
    }
  ), l(() => _(), () => {
    a(S, _()?.definition);
  }), l(() => (p(te()), e(S)), () => {
    a(g, te() || (e(S) && "primaryDisplay" in e(S) ? e(S).primaryDisplay : void 0));
  }), l(() => e(g), () => {
    a(X, e(g) ? se.searchByFieldPlaceholder.replace("{field}", e(g)) : se.searchPlaceholder);
  }), l(() => _(), () => {
    a(O, _()?.rows || []);
  }), l(() => e(O), () => {
    e(O) && Te("rows", e(O));
  }), l(
    () => (e(E), e(O), p(le()), e(g)),
    () => {
      Re(e(E), [...e(O), ...le() || []], e(g));
    }
  ), l(() => (e(v), e(c)), () => {
    a(D, e(v).filter((t) => !e(c)[t]));
  }), l(
    () => (e(D), e(F), e(g)),
    () => {
      Le(e(D), e(F), e(g));
    }
  ), l(() => e(c), () => {
    ne(e(c));
  }), l(() => e(L), () => {
    !e(L) && oe();
  }), l(() => (e(R), e(g)), () => {
    Ce(e(R) || "", e(g));
  }), l(() => p($()), () => {
    a(Y, ke($()));
  }), l(() => e(h), () => {
    a(V, e(h) ? [] : void 0);
  }), l(() => (e(D), e(V), e(w)), () => {
    a(Z, e(D).length ? e(V) : e(w));
  }), We(), Xe(), ut(he, {
    get label() {
      return be();
    },
    get field() {
      return _e();
    },
    get disabled() {
      return j();
    },
    get readonly() {
      return G();
    },
    get validation() {
      return Ae();
    },
    get type() {
      return N();
    },
    get span() {
      return we();
    },
    get helpText() {
      return Fe();
    },
    get defaultValue() {
      return e(Y);
    },
    get fieldState() {
      return e(y);
    },
    set fieldState(t) {
      a(y, t);
    },
    get fieldApi() {
      return e(H);
    },
    set fieldApi(t) {
      a(H, t);
    },
    get fieldSchema() {
      return e(A);
    },
    set fieldSchema(t) {
      a(A, t);
    },
    children: (t, r) => {
      var s = fe(), n = pe(s);
      {
        var u = (f) => {
          var ue = fe(), Pe = pe(ue);
          {
            let Ue = B(() => (e(y), C(() => e(y)?.fieldId))), Ve = B(() => (e(y), C(() => e(y)?.disabled))), je = B(() => (e(y), C(() => e(y)?.readonly))), Ge = B(() => (_(), C(() => !!_()?.loading)));
            tt(Pe, () => e(h) ? dt : rt, (qe, He) => {
              He(qe, {
                get value() {
                  return e(Z);
                },
                get id() {
                  return e(Ue);
                },
                get disabled() {
                  return e(Ve);
                },
                get readonly() {
                  return e(je);
                },
                get loading() {
                  return e(Ge);
                },
                getOptionLabel: (m) => m.primaryDisplay,
                getOptionValue: (m) => m._id,
                get options() {
                  return e(k);
                },
                get placeholder() {
                  return Oe();
                },
                get autocomplete() {
                  return Ee();
                },
                get searchPlaceholder() {
                  return e(X);
                },
                get wrapText() {
                  return Se();
                },
                get searchTerm() {
                  return e(R);
                },
                set searchTerm(m) {
                  a(R, m);
                },
                get open() {
                  return e(L);
                },
                set open(m) {
                  a(L, m);
                },
                $$events: { change: Me },
                $$legacy: !0
              });
            });
          }
          ye(f, ue);
        };
        Ye(n, (f) => {
          e(y) && f(u);
        });
      }
      ye(t, s);
    },
    $$slots: { default: !0 },
    $$legacy: !0
  }), Ze(), me();
}
export {
  gt as default
};
