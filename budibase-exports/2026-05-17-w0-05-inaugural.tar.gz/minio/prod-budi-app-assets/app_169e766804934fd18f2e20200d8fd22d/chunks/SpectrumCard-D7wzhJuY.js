import { g as Z, p as s, h as w, m as $, u as m, v as ee, am as te, t as c, a as B, b as f, e as D, d as o, w as ae, y as se, s as _, c as i, f as d, r, x as ie, ap as re, aC as le, a3 as ne, a4 as oe } from "./index-CMyk0zjR.js";
var ve = d('<div class="spectrum-Card-coverPhoto svelte-eemyhf"></div>'), ce = d('<div class="spectrum-Card-content"><div class="spectrum-Card-subtitle spectrum-Detail spectrum-Detail--sizeS svelte-eemyhf"> </div></div>'), de = d('<div class="spectrum-Card-footer svelte-eemyhf"> </div>'), ue = d('<div class="spectrum-Card-footer button-container svelte-eemyhf"><!></div>'), me = d('<div tabindex="0" role="figure"><!> <div class="spectrum-Card-container svelte-eemyhf"><div class="spectrum-Card-body"><div class="spectrum-Card-header"><div> </div></div> <!></div> <!> <!></div></div>');
function pe(T, a) {
  Z(a, !1);
  const H = () => ie(I, "$component", O), [O, X] = se();
  let j = s(a, "title", 8), y = s(a, "subtitle", 8), g = s(a, "description", 8), x = s(a, "imageURL", 8), p = s(a, "linkURL", 8), q = s(a, "linkPeek", 8), A = s(a, "horizontal", 8), h = s(a, "showButton", 8), E = s(a, "buttonText", 8), k = s(a, "buttonOnClick", 8);
  const { styleable: F, routeStore: G } = w("sdk"), I = w("component"), J = (e) => {
    if (!p())
      return !1;
    e.preventDefault(), e.stopPropagation(), G.actions.navigate(p(), q());
  };
  $();
  var l = me();
  let z;
  var L = i(l);
  {
    var K = (e) => {
      var t = ve();
      c(() => re(t, `background-image: url(${x() ?? ""})`)), o(e, t);
    };
    m(L, (e) => {
      x() && e(K);
    });
  }
  var P = _(L, 2), C = i(P), b = i(C), u = i(b);
  let R;
  var M = i(u, !0);
  r(u), r(b);
  var N = _(b, 2);
  {
    var Q = (e) => {
      var t = ce(), n = i(t), v = i(n, !0);
      r(n), r(t), c(() => f(v, y())), o(e, t);
    };
    m(N, (e) => {
      y() && e(Q);
    });
  }
  r(C);
  var S = _(C, 2);
  {
    var V = (e) => {
      var t = de(), n = i(t, !0);
      r(t), c(() => f(n, g())), o(e, t);
    };
    m(S, (e) => {
      g() && e(V);
    });
  }
  var W = _(S, 2);
  {
    var Y = (e) => {
      var t = ue(), n = i(t);
      le(n, {
        secondary: !0,
        $$events: {
          click(...v) {
            k()?.apply(this, v);
          }
        },
        children: (v, fe) => {
          ne();
          var U = oe();
          c(() => f(U, E() || "Click me")), o(v, U);
        },
        $$slots: { default: !0 }
      }), r(t), o(e, t);
    };
    m(W, (e) => {
      h() && e(Y);
    });
  }
  r(P), r(l), ee(l, (e, t) => F?.(e, t), () => H().styles), te(() => D("click", l, function(...e) {
    (h() ? null : k())?.apply(this, e);
  })), c(
    (e, t) => {
      z = B(l, 1, "spectrum-Card svelte-eemyhf", null, z, e), R = B(u, 1, "spectrum-Card-title spectrum-Heading spectrum-Heading--sizeXS svelte-eemyhf", null, R, t), f(M, j() || "Card Title");
    },
    [
      () => ({
        horizontal: A(),
        clickable: k() && !h()
      }),
      () => ({ link: p() })
    ]
  ), D("click", u, J), o(T, l), ae(), X();
}
export {
  pe as default
};
