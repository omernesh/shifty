import { b$ as i, c0 as t, cs as e } from "./index-CMyk0zjR.js";
function l(n) {
  if (!n)
    return !1;
  const r = n.builder?.apps?.length;
  return !!!n.builder?.global && r != null && r > 0;
}
function f(n) {
  return n ? n.builder?.global || l(n) || s(n) : !1;
}
function s(n) {
  return n ? !!n.builder?.creator : !1;
}
function u(n) {
  if (typeof n != "string")
    return n;
  const r = `${i.ROW}${t}${e.USER_METADATA}${t}`;
  return n.startsWith(r) ? n.split(r)[1] : n;
}
function c(n) {
  return typeof n != "string" ? !1 : n.includes(`${i.USER}${t}`);
}
export {
  c,
  u as g,
  f as h
};
