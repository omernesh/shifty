import { b_ as Zs, aL as Qs } from "./index-CMyk0zjR.js";
function Js(ke, ye) {
  for (var k = 0; k < ye.length; k++) {
    const W = ye[k];
    if (typeof W != "string" && !Array.isArray(W)) {
      for (const N in W)
        if (N !== "default" && !(N in ke)) {
          const I = Object.getOwnPropertyDescriptor(W, N);
          I && Object.defineProperty(ke, N, I.get ? I : {
            enumerable: !0,
            get: () => W[N]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(ke, Symbol.toStringTag, { value: "Module" }));
}
var cn = { exports: {} }, $s = cn.exports, vo;
function zt() {
  return vo || (vo = 1, (function(ke, ye) {
    (function(k, W) {
      ke.exports = W();
    })($s, (function() {
      var k = navigator.userAgent, W = navigator.platform, N = /gecko\/\d/i.test(k), I = /MSIE \d/.test(k), H = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(k), z = /Edge\/(\d+)/.exec(k), T = I || H || z, P = T && (I ? document.documentMode || 6 : +(z || H)[1]), re = !z && /WebKit\//.test(k), Q = re && /Qt\/\d+\.\d+/.test(k), K = !z && /Chrome\/(\d+)/.exec(k), fe = K && +K[1], ie = /Opera\//.test(k), Se = /Apple Computer/.test(navigator.vendor), de = /Mac OS X 1\d\D([8-9]|\d\d)\D/.test(k), ce = /PhantomJS/.test(k), _ = Se && (/Mobile\/\w+/.test(k) || navigator.maxTouchPoints > 2), X = /Android/.test(k), q = _ || X || /webOS|BlackBerry|Opera Mini|Opera Mobi|IEMobile/i.test(k), j = _ || /Mac/.test(W), ue = /\bCrOS\b/.test(k), Z = /win/i.test(W), se = ie && k.match(/Version\/(\d*\.\d*)/);
      se && (se = Number(se[1])), se && se >= 15 && (ie = !1, re = !0);
      var me = j && (Q || ie && (se == null || se < 12.11)), Ue = N || T && P >= 9;
      function ae(e) {
        return new RegExp("(^|\\s)" + e + "(?:$|\\s)\\s*");
      }
      var Le = function(e, t) {
        var i = e.className, r = ae(t).exec(i);
        if (r) {
          var n = i.slice(r.index + r[0].length);
          e.className = i.slice(0, r.index) + (n ? r[1] + n : "");
        }
      };
      function Ee(e) {
        for (var t = e.childNodes.length; t > 0; --t)
          e.removeChild(e.firstChild);
        return e;
      }
      function He(e, t) {
        return Ee(e).appendChild(t);
      }
      function E(e, t, i, r) {
        var n = document.createElement(e);
        if (i && (n.className = i), r && (n.style.cssText = r), typeof t == "string")
          n.appendChild(document.createTextNode(t));
        else if (t)
          for (var a = 0; a < t.length; ++a)
            n.appendChild(t[a]);
        return n;
      }
      function ee(e, t, i, r) {
        var n = E(e, t, i, r);
        return n.setAttribute("role", "presentation"), n;
      }
      var J;
      document.createRange ? J = function(e, t, i, r) {
        var n = document.createRange();
        return n.setEnd(r || e, i), n.setStart(e, t), n;
      } : J = function(e, t, i) {
        var r = document.body.createTextRange();
        try {
          r.moveToElementText(e.parentNode);
        } catch {
          return r;
        }
        return r.collapse(!0), r.moveEnd("character", i), r.moveStart("character", t), r;
      };
      function De(e, t) {
        if (t.nodeType == 3 && (t = t.parentNode), e.contains)
          return e.contains(t);
        do
          if (t.nodeType == 11 && (t = t.host), t == e)
            return !0;
        while (t = t.parentNode);
      }
      function We(e) {
        var t = e.ownerDocument || e, i;
        try {
          i = e.activeElement;
        } catch {
          i = t.body || null;
        }
        for (; i && i.shadowRoot && i.shadowRoot.activeElement; )
          i = i.shadowRoot.activeElement;
        return i;
      }
      function rt(e, t) {
        var i = e.className;
        ae(t).test(i) || (e.className += (i ? " " : "") + t);
      }
      function _t(e, t) {
        for (var i = e.split(" "), r = 0; r < i.length; r++)
          i[r] && !ae(i[r]).test(t) && (t += " " + i[r]);
        return t;
      }
      var D = function(e) {
        e.select();
      };
      _ ? D = function(e) {
        e.selectionStart = 0, e.selectionEnd = e.value.length;
      } : T && (D = function(e) {
        try {
          e.select();
        } catch {
        }
      });
      function p(e) {
        return e.display.wrapper.ownerDocument;
      }
      function G(e) {
        return ze(e.display.wrapper);
      }
      function ze(e) {
        return e.getRootNode ? e.getRootNode() : e.ownerDocument;
      }
      function Te(e) {
        return p(e).defaultView;
      }
      function Je(e) {
        var t = Array.prototype.slice.call(arguments, 1);
        return function() {
          return e.apply(null, t);
        };
      }
      function $e(e, t, i) {
        t || (t = {});
        for (var r in e)
          Object.prototype.hasOwnProperty.call(e, r) && (i !== !1 || !Object.prototype.hasOwnProperty.call(t, r)) && (t[r] = e[r]);
        return t;
      }
      function Ke(e, t, i, r, n) {
        t == null && (t = e.search(/[^\s\u00a0]/), t == -1 && (t = e.length));
        for (var a = r || 0, l = n || 0; ; ) {
          var u = e.indexOf("	", a);
          if (u < 0 || u >= t)
            return l + (t - a);
          l += u - a, l += i - l % i, a = u + 1;
        }
      }
      var Ye = function() {
        this.id = null, this.f = null, this.time = 0, this.handler = Je(this.onTimeout, this);
      };
      Ye.prototype.onTimeout = function(e) {
        e.id = 0, e.time <= +/* @__PURE__ */ new Date() ? e.f() : setTimeout(e.handler, e.time - +/* @__PURE__ */ new Date());
      }, Ye.prototype.set = function(e, t) {
        this.f = t;
        var i = +/* @__PURE__ */ new Date() + e;
        (!this.id || i < this.time) && (clearTimeout(this.id), this.id = setTimeout(this.handler, e), this.time = i);
      };
      function Pe(e, t) {
        for (var i = 0; i < e.length; ++i)
          if (e[i] == t)
            return i;
        return -1;
      }
      var _e = 50, Ve = { toString: function() {
        return "CodeMirror.Pass";
      } }, at = { scroll: !1 }, Ce = { origin: "*mouse" }, Dt = { origin: "+move" };
      function At(e, t, i) {
        for (var r = 0, n = 0; ; ) {
          var a = e.indexOf("	", r);
          a == -1 && (a = e.length);
          var l = a - r;
          if (a == e.length || n + l >= t)
            return r + Math.min(l, t - n);
          if (n += a - r, n += i - n % i, r = a + 1, n >= t)
            return r;
        }
      }
      var it = [""];
      function Ht(e) {
        for (; it.length <= e; )
          it.push(xe(it) + " ");
        return it[e];
      }
      function xe(e) {
        return e[e.length - 1];
      }
      function ot(e, t) {
        for (var i = [], r = 0; r < e.length; r++)
          i[r] = t(e[r], r);
        return i;
      }
      function Wt(e, t, i) {
        for (var r = 0, n = i(t); r < e.length && i(e[r]) <= n; )
          r++;
        e.splice(r, 0, t);
      }
      function ar() {
      }
      function O(e, t) {
        var i;
        return Object.create ? i = Object.create(e) : (ar.prototype = e, i = new ar()), t && $e(t, i), i;
      }
      var R = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;
      function F(e) {
        return /\w/.test(e) || e > "" && (e.toUpperCase() != e.toLowerCase() || R.test(e));
      }
      function d(e, t) {
        return t ? t.source.indexOf("\\w") > -1 && F(e) ? !0 : t.test(e) : F(e);
      }
      function h(e) {
        for (var t in e)
          if (e.hasOwnProperty(t) && e[t])
            return !1;
        return !0;
      }
      var C = /[\u0300-\u036f\u0483-\u0489\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u065e\u0670\u06d6-\u06dc\u06de-\u06e4\u06e7\u06e8\u06ea-\u06ed\u0711\u0730-\u074a\u07a6-\u07b0\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0900-\u0902\u093c\u0941-\u0948\u094d\u0951-\u0955\u0962\u0963\u0981\u09bc\u09be\u09c1-\u09c4\u09cd\u09d7\u09e2\u09e3\u0a01\u0a02\u0a3c\u0a41\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a70\u0a71\u0a75\u0a81\u0a82\u0abc\u0ac1-\u0ac5\u0ac7\u0ac8\u0acd\u0ae2\u0ae3\u0b01\u0b3c\u0b3e\u0b3f\u0b41-\u0b44\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b82\u0bbe\u0bc0\u0bcd\u0bd7\u0c3e-\u0c40\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0cbc\u0cbf\u0cc2\u0cc6\u0ccc\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0d3e\u0d41-\u0d44\u0d4d\u0d57\u0d62\u0d63\u0dca\u0dcf\u0dd2-\u0dd4\u0dd6\u0ddf\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0f18\u0f19\u0f35\u0f37\u0f39\u0f71-\u0f7e\u0f80-\u0f84\u0f86\u0f87\u0f90-\u0f97\u0f99-\u0fbc\u0fc6\u102d-\u1030\u1032-\u1037\u1039\u103a\u103d\u103e\u1058\u1059\u105e-\u1060\u1071-\u1074\u1082\u1085\u1086\u108d\u109d\u135f\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b7-\u17bd\u17c6\u17c9-\u17d3\u17dd\u180b-\u180d\u18a9\u1920-\u1922\u1927\u1928\u1932\u1939-\u193b\u1a17\u1a18\u1a56\u1a58-\u1a5e\u1a60\u1a62\u1a65-\u1a6c\u1a73-\u1a7c\u1a7f\u1b00-\u1b03\u1b34\u1b36-\u1b3a\u1b3c\u1b42\u1b6b-\u1b73\u1b80\u1b81\u1ba2-\u1ba5\u1ba8\u1ba9\u1c2c-\u1c33\u1c36\u1c37\u1cd0-\u1cd2\u1cd4-\u1ce0\u1ce2-\u1ce8\u1ced\u1dc0-\u1de6\u1dfd-\u1dff\u200c\u200d\u20d0-\u20f0\u2cef-\u2cf1\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua66f-\ua672\ua67c\ua67d\ua6f0\ua6f1\ua802\ua806\ua80b\ua825\ua826\ua8c4\ua8e0-\ua8f1\ua926-\ua92d\ua947-\ua951\ua980-\ua982\ua9b3\ua9b6-\ua9b9\ua9bc\uaa29-\uaa2e\uaa31\uaa32\uaa35\uaa36\uaa43\uaa4c\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uabe5\uabe8\uabed\udc00-\udfff\ufb1e\ufe00-\ufe0f\ufe20-\ufe26\uff9e\uff9f]/;
      function o(e) {
        return e.charCodeAt(0) >= 768 && C.test(e);
      }
      function f(e, t, i) {
        for (; (i < 0 ? t > 0 : t < e.length) && o(e.charAt(t)); )
          t += i;
        return t;
      }
      function v(e, t, i) {
        for (var r = t > i ? -1 : 1; ; ) {
          if (t == i)
            return t;
          var n = (t + i) / 2, a = r < 0 ? Math.ceil(n) : Math.floor(n);
          if (a == t)
            return e(a) ? t : i;
          e(a) ? i = a : t = a + r;
        }
      }
      function x(e, t, i, r) {
        if (!e)
          return r(t, i, "ltr", 0);
        for (var n = !1, a = 0; a < e.length; ++a) {
          var l = e[a];
          (l.from < i && l.to > t || t == i && l.to == t) && (r(Math.max(l.from, t), Math.min(l.to, i), l.level == 1 ? "rtl" : "ltr", a), n = !0);
        }
        n || r(t, i, "ltr");
      }
      var b = null;
      function M(e, t, i) {
        var r;
        b = null;
        for (var n = 0; n < e.length; ++n) {
          var a = e[n];
          if (a.from < t && a.to > t)
            return n;
          a.to == t && (a.from != a.to && i == "before" ? r = n : b = n), a.from == t && (a.from != a.to && i != "before" ? r = n : b = n);
        }
        return r ?? b;
      }
      var w = /* @__PURE__ */ (function() {
        var e = "bbbbbbbbbtstwsbbbbbbbbbbbbbbssstwNN%%%NNNNNN,N,N1111111111NNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNbbbbbbsbbbbbbbbbbbbbbbbbbbbbbbbbb,N%%%%NNNNLNNNNN%%11NLNNN1LNNNNNLLLLLLLLLLLLLLLLLLLLLLLNLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLN", t = "nnnnnnNNr%%r,rNNmmmmmmmmmmmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmmmmmmmmmmmmmmnnnnnnnnnn%nnrrrmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmnNmmmmmmrrmmNmmmmrr1111111111";
        function i(c) {
          return c <= 247 ? e.charAt(c) : 1424 <= c && c <= 1524 ? "R" : 1536 <= c && c <= 1785 ? t.charAt(c - 1536) : 1774 <= c && c <= 2220 ? "r" : 8192 <= c && c <= 8203 ? "w" : c == 8204 ? "b" : "L";
        }
        var r = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/, n = /[stwN]/, a = /[LRr]/, l = /[Lb1n]/, u = /[1n]/;
        function s(c, g, m) {
          this.level = c, this.from = g, this.to = m;
        }
        return function(c, g) {
          var m = g == "ltr" ? "L" : "R";
          if (c.length == 0 || g == "ltr" && !r.test(c))
            return !1;
          for (var L = c.length, S = [], U = 0; U < L; ++U)
            S.push(i(c.charCodeAt(U)));
          for (var Y = 0, V = m; Y < L; ++Y) {
            var le = S[Y];
            le == "m" ? S[Y] = V : V = le;
          }
          for (var he = 0, oe = m; he < L; ++he) {
            var pe = S[he];
            pe == "1" && oe == "r" ? S[he] = "n" : a.test(pe) && (oe = pe, pe == "r" && (S[he] = "R"));
          }
          for (var Fe = 1, we = S[0]; Fe < L - 1; ++Fe) {
            var Re = S[Fe];
            Re == "+" && we == "1" && S[Fe + 1] == "1" ? S[Fe] = "1" : Re == "," && we == S[Fe + 1] && (we == "1" || we == "n") && (S[Fe] = we), we = Re;
          }
          for (var Qe = 0; Qe < L; ++Qe) {
            var vt = S[Qe];
            if (vt == ",")
              S[Qe] = "N";
            else if (vt == "%") {
              var tt = void 0;
              for (tt = Qe + 1; tt < L && S[tt] == "%"; ++tt)
                ;
              for (var It = Qe && S[Qe - 1] == "!" || tt < L && S[tt] == "1" ? "1" : "N", Tt = Qe; Tt < tt; ++Tt)
                S[Tt] = It;
              Qe = tt - 1;
            }
          }
          for (var ft = 0, Bt = m; ft < L; ++ft) {
            var yt = S[ft];
            Bt == "L" && yt == "1" ? S[ft] = "L" : a.test(yt) && (Bt = yt);
          }
          for (var ht = 0; ht < L; ++ht)
            if (n.test(S[ht])) {
              var ct = void 0;
              for (ct = ht + 1; ct < L && n.test(S[ct]); ++ct)
                ;
              for (var nt = (ht ? S[ht - 1] : m) == "L", Mt = (ct < L ? S[ct] : m) == "L", Jr = nt == Mt ? nt ? "L" : "R" : m, pr = ht; pr < ct; ++pr)
                S[pr] = Jr;
              ht = ct - 1;
            }
          for (var wt = [], $t, mt = 0; mt < L; )
            if (l.test(S[mt])) {
              var sa = mt;
              for (++mt; mt < L && l.test(S[mt]); ++mt)
                ;
              wt.push(new s(0, sa, mt));
            } else {
              var nr = mt, Ar = wt.length, Er = g == "rtl" ? 1 : 0;
              for (++mt; mt < L && S[mt] != "L"; ++mt)
                ;
              for (var Ft = nr; Ft < mt; )
                if (u.test(S[Ft])) {
                  nr < Ft && (wt.splice(Ar, 0, new s(1, nr, Ft)), Ar += Er);
                  var $r = Ft;
                  for (++Ft; Ft < mt && u.test(S[Ft]); ++Ft)
                    ;
                  wt.splice(Ar, 0, new s(2, $r, Ft)), Ar += Er, nr = Ft;
                } else
                  ++Ft;
              nr < mt && wt.splice(Ar, 0, new s(1, nr, mt));
            }
          return g == "ltr" && (wt[0].level == 1 && ($t = c.match(/^\s+/)) && (wt[0].from = $t[0].length, wt.unshift(new s(0, 0, $t[0].length))), xe(wt).level == 1 && ($t = c.match(/\s+$/)) && (xe(wt).to -= $t[0].length, wt.push(new s(0, L - $t[0].length, L)))), g == "rtl" ? wt.reverse() : wt;
        };
      })();
      function y(e, t) {
        var i = e.order;
        return i == null && (i = e.order = w(e.text, t)), i;
      }
      var B = [], A = function(e, t, i) {
        if (e.addEventListener)
          e.addEventListener(t, i, !1);
        else if (e.attachEvent)
          e.attachEvent("on" + t, i);
        else {
          var r = e._handlers || (e._handlers = {});
          r[t] = (r[t] || B).concat(i);
        }
      };
      function ne(e, t) {
        return e._handlers && e._handlers[t] || B;
      }
      function ge(e, t, i) {
        if (e.removeEventListener)
          e.removeEventListener(t, i, !1);
        else if (e.detachEvent)
          e.detachEvent("on" + t, i);
        else {
          var r = e._handlers, n = r && r[t];
          if (n) {
            var a = Pe(n, i);
            a > -1 && (r[t] = n.slice(0, a).concat(n.slice(a + 1)));
          }
        }
      }
      function ve(e, t) {
        var i = ne(e, t);
        if (i.length)
          for (var r = Array.prototype.slice.call(arguments, 2), n = 0; n < i.length; ++n)
            i[n].apply(null, r);
      }
      function te(e, t, i) {
        return typeof t == "string" && (t = { type: t, preventDefault: function() {
          this.defaultPrevented = !0;
        } }), ve(e, i || t.type, e, t), Ze(t) || t.codemirrorIgnore;
      }
      function Be(e) {
        var t = e._handlers && e._handlers.cursorActivity;
        if (t)
          for (var i = e.curOp.cursorActivityHandlers || (e.curOp.cursorActivityHandlers = []), r = 0; r < t.length; ++r)
            Pe(i, t[r]) == -1 && i.push(t[r]);
      }
      function Me(e, t) {
        return ne(e, t).length > 0;
      }
      function Ie(e) {
        e.prototype.on = function(t, i) {
          A(this, t, i);
        }, e.prototype.off = function(t, i) {
          ge(this, t, i);
        };
      }
      function Ae(e) {
        e.preventDefault ? e.preventDefault() : e.returnValue = !1;
      }
      function Xe(e) {
        e.stopPropagation ? e.stopPropagation() : e.cancelBubble = !0;
      }
      function Ze(e) {
        return e.defaultPrevented != null ? e.defaultPrevented : e.returnValue == !1;
      }
      function ut(e) {
        Ae(e), Xe(e);
      }
      function kt(e) {
        return e.target || e.srcElement;
      }
      function bt(e) {
        var t = e.which;
        return t == null && (e.button & 1 ? t = 1 : e.button & 2 ? t = 3 : e.button & 4 && (t = 2)), j && e.ctrlKey && t == 1 && (t = 3), t;
      }
      var Lr = (function() {
        if (T && P < 9)
          return !1;
        var e = E("div");
        return "draggable" in e || "dragDrop" in e;
      })(), Tr;
      function Ti(e) {
        if (Tr == null) {
          var t = E("span", "​");
          He(e, E("span", [t, document.createTextNode("x")])), e.firstChild.offsetHeight != 0 && (Tr = t.offsetWidth <= 1 && t.offsetHeight > 2 && !(T && P < 8));
        }
        var i = Tr ? E("span", "​") : E("span", " ", null, "display: inline-block; width: 1px; margin-right: -1px");
        return i.setAttribute("cm-text", ""), i;
      }
      var Vr;
      function ei(e) {
        if (Vr != null)
          return Vr;
        var t = He(e, document.createTextNode("AخA")), i = J(t, 0, 1).getBoundingClientRect(), r = J(t, 1, 2).getBoundingClientRect();
        return Ee(e), !i || i.left == i.right ? !1 : Vr = r.right - i.right < 3;
      }
      var ti = `

b`.split(/\n/).length != 3 ? function(e) {
        for (var t = 0, i = [], r = e.length; t <= r; ) {
          var n = e.indexOf(`
`, t);
          n == -1 && (n = e.length);
          var a = e.slice(t, e.charAt(n - 1) == "\r" ? n - 1 : n), l = a.indexOf("\r");
          l != -1 ? (i.push(a.slice(0, l)), t += l + 1) : (i.push(a), t = n + 1);
        }
        return i;
      } : function(e) {
        return e.split(/\r\n?|\n/);
      }, hn = window.getSelection ? function(e) {
        try {
          return e.selectionStart != e.selectionEnd;
        } catch {
          return !1;
        }
      } : function(e) {
        var t;
        try {
          t = e.ownerDocument.selection.createRange();
        } catch {
        }
        return !t || t.parentElement() != e ? !1 : t.compareEndPoints("StartToEnd", t) != 0;
      }, xt = (function() {
        var e = E("div");
        return "oncopy" in e ? !0 : (e.setAttribute("oncopy", "return;"), typeof e.oncopy == "function");
      })(), Xt = null;
      function qt(e) {
        if (Xt != null)
          return Xt;
        var t = He(e, E("span", "x")), i = t.getBoundingClientRect(), r = J(t, 0, 1).getBoundingClientRect();
        return Xt = Math.abs(i.left - r.left) > 1;
      }
      var Rt = {}, Nt = {};
      function gr(e, t) {
        arguments.length > 2 && (t.dependencies = Array.prototype.slice.call(arguments, 2)), Rt[e] = t;
      }
      function Bi(e, t) {
        Nt[e] = t;
      }
      function Br(e) {
        if (typeof e == "string" && Nt.hasOwnProperty(e))
          e = Nt[e];
        else if (e && typeof e.name == "string" && Nt.hasOwnProperty(e.name)) {
          var t = Nt[e.name];
          typeof t == "string" && (t = { name: t }), e = O(t, e), e.name = t.name;
        } else {
          if (typeof e == "string" && /^[\w\-]+\/[\w\-]+\+xml$/.test(e))
            return Br("application/xml");
          if (typeof e == "string" && /^[\w\-]+\/[\w\-]+\+json$/.test(e))
            return Br("application/json");
        }
        return typeof e == "string" ? { name: e } : e || { name: "null" };
      }
      function Mr(e, t) {
        t = Br(t);
        var i = Rt[t.name];
        if (!i)
          return Mr(e, "text/plain");
        var r = i(e, t);
        if (Nr.hasOwnProperty(t.name)) {
          var n = Nr[t.name];
          for (var a in n)
            n.hasOwnProperty(a) && (r.hasOwnProperty(a) && (r["_" + a] = r[a]), r[a] = n[a]);
        }
        if (r.name = t.name, t.helperType && (r.helperType = t.helperType), t.modeProps)
          for (var l in t.modeProps)
            r[l] = t.modeProps[l];
        return r;
      }
      var Nr = {};
      function Zo(e, t) {
        var i = Nr.hasOwnProperty(e) ? Nr[e] : Nr[e] = {};
        $e(t, i);
      }
      function vr(e, t) {
        if (t === !0)
          return t;
        if (e.copyState)
          return e.copyState(t);
        var i = {};
        for (var r in t) {
          var n = t[r];
          n instanceof Array && (n = n.concat([])), i[r] = n;
        }
        return i;
      }
      function dn(e, t) {
        for (var i; e.innerMode && (i = e.innerMode(t), !(!i || i.mode == e)); )
          t = i.state, e = i.mode;
        return i || { mode: e, state: t };
      }
      function ga(e, t, i) {
        return e.startState ? e.startState(t, i) : !0;
      }
      var st = function(e, t, i) {
        this.pos = this.start = 0, this.string = e, this.tabSize = t || 8, this.lastColumnPos = this.lastColumnValue = 0, this.lineStart = 0, this.lineOracle = i;
      };
      st.prototype.eol = function() {
        return this.pos >= this.string.length;
      }, st.prototype.sol = function() {
        return this.pos == this.lineStart;
      }, st.prototype.peek = function() {
        return this.string.charAt(this.pos) || void 0;
      }, st.prototype.next = function() {
        if (this.pos < this.string.length)
          return this.string.charAt(this.pos++);
      }, st.prototype.eat = function(e) {
        var t = this.string.charAt(this.pos), i;
        if (typeof e == "string" ? i = t == e : i = t && (e.test ? e.test(t) : e(t)), i)
          return ++this.pos, t;
      }, st.prototype.eatWhile = function(e) {
        for (var t = this.pos; this.eat(e); )
          ;
        return this.pos > t;
      }, st.prototype.eatSpace = function() {
        for (var e = this.pos; /[\s\u00a0]/.test(this.string.charAt(this.pos)); )
          ++this.pos;
        return this.pos > e;
      }, st.prototype.skipToEnd = function() {
        this.pos = this.string.length;
      }, st.prototype.skipTo = function(e) {
        var t = this.string.indexOf(e, this.pos);
        if (t > -1)
          return this.pos = t, !0;
      }, st.prototype.backUp = function(e) {
        this.pos -= e;
      }, st.prototype.column = function() {
        return this.lastColumnPos < this.start && (this.lastColumnValue = Ke(this.string, this.start, this.tabSize, this.lastColumnPos, this.lastColumnValue), this.lastColumnPos = this.start), this.lastColumnValue - (this.lineStart ? Ke(this.string, this.lineStart, this.tabSize) : 0);
      }, st.prototype.indentation = function() {
        return Ke(this.string, null, this.tabSize) - (this.lineStart ? Ke(this.string, this.lineStart, this.tabSize) : 0);
      }, st.prototype.match = function(e, t, i) {
        if (typeof e == "string") {
          var r = function(l) {
            return i ? l.toLowerCase() : l;
          }, n = this.string.substr(this.pos, e.length);
          if (r(n) == r(e))
            return t !== !1 && (this.pos += e.length), !0;
        } else {
          var a = this.string.slice(this.pos).match(e);
          return a && a.index > 0 ? null : (a && t !== !1 && (this.pos += a[0].length), a);
        }
      }, st.prototype.current = function() {
        return this.string.slice(this.start, this.pos);
      }, st.prototype.hideFirstChars = function(e, t) {
        this.lineStart += e;
        try {
          return t();
        } finally {
          this.lineStart -= e;
        }
      }, st.prototype.lookAhead = function(e) {
        var t = this.lineOracle;
        return t && t.lookAhead(e);
      }, st.prototype.baseToken = function() {
        var e = this.lineOracle;
        return e && e.baseToken(this.pos);
      };
      function be(e, t) {
        if (t -= e.first, t < 0 || t >= e.size)
          throw new Error("There is no line " + (t + e.first) + " in the document.");
        for (var i = e; !i.lines; )
          for (var r = 0; ; ++r) {
            var n = i.children[r], a = n.chunkSize();
            if (t < a) {
              i = n;
              break;
            }
            t -= a;
          }
        return i.lines[t];
      }
      function mr(e, t, i) {
        var r = [], n = t.line;
        return e.iter(t.line, i.line + 1, function(a) {
          var l = a.text;
          n == i.line && (l = l.slice(0, i.ch)), n == t.line && (l = l.slice(t.ch)), r.push(l), ++n;
        }), r;
      }
      function pn(e, t, i) {
        var r = [];
        return e.iter(t, i, function(n) {
          r.push(n.text);
        }), r;
      }
      function Yt(e, t) {
        var i = t - e.height;
        if (i)
          for (var r = e; r; r = r.parent)
            r.height += i;
      }
      function Ge(e) {
        if (e.parent == null)
          return null;
        for (var t = e.parent, i = Pe(t.lines, e), r = t.parent; r; t = r, r = r.parent)
          for (var n = 0; r.children[n] != t; ++n)
            i += r.children[n].chunkSize();
        return i + t.first;
      }
      function xr(e, t) {
        var i = e.first;
        e: do {
          for (var r = 0; r < e.children.length; ++r) {
            var n = e.children[r], a = n.height;
            if (t < a) {
              e = n;
              continue e;
            }
            t -= a, i += n.chunkSize();
          }
          return i;
        } while (!e.lines);
        for (var l = 0; l < e.lines.length; ++l) {
          var u = e.lines[l], s = u.height;
          if (t < s)
            break;
          t -= s;
        }
        return i + l;
      }
      function ri(e, t) {
        return t >= e.first && t < e.first + e.size;
      }
      function gn(e, t) {
        return String(e.lineNumberFormatter(t + e.firstLineNumber));
      }
      function $(e, t, i) {
        if (i === void 0 && (i = null), !(this instanceof $))
          return new $(e, t, i);
        this.line = e, this.ch = t, this.sticky = i;
      }
      function Ne(e, t) {
        return e.line - t.line || e.ch - t.ch;
      }
      function vn(e, t) {
        return e.sticky == t.sticky && Ne(e, t) == 0;
      }
      function mn(e) {
        return $(e.line, e.ch);
      }
      function Mi(e, t) {
        return Ne(e, t) < 0 ? t : e;
      }
      function Ni(e, t) {
        return Ne(e, t) < 0 ? e : t;
      }
      function va(e, t) {
        return Math.max(e.first, Math.min(t, e.first + e.size - 1));
      }
      function Oe(e, t) {
        if (t.line < e.first)
          return $(e.first, 0);
        var i = e.first + e.size - 1;
        return t.line > i ? $(i, be(e, i).text.length) : Qo(t, be(e, t.line).text.length);
      }
      function Qo(e, t) {
        var i = e.ch;
        return i == null || i > t ? $(e.line, t) : i < 0 ? $(e.line, 0) : e;
      }
      function ma(e, t) {
        for (var i = [], r = 0; r < t.length; r++)
          i[r] = Oe(e, t[r]);
        return i;
      }
      var Oi = function(e, t) {
        this.state = e, this.lookAhead = t;
      }, Zt = function(e, t, i, r) {
        this.state = t, this.doc = e, this.line = i, this.maxLookAhead = r || 0, this.baseTokens = null, this.baseTokenPos = 1;
      };
      Zt.prototype.lookAhead = function(e) {
        var t = this.doc.getLine(this.line + e);
        return t != null && e > this.maxLookAhead && (this.maxLookAhead = e), t;
      }, Zt.prototype.baseToken = function(e) {
        if (!this.baseTokens)
          return null;
        for (; this.baseTokens[this.baseTokenPos] <= e; )
          this.baseTokenPos += 2;
        var t = this.baseTokens[this.baseTokenPos + 1];
        return {
          type: t && t.replace(/( |^)overlay .*/, ""),
          size: this.baseTokens[this.baseTokenPos] - e
        };
      }, Zt.prototype.nextLine = function() {
        this.line++, this.maxLookAhead > 0 && this.maxLookAhead--;
      }, Zt.fromSaved = function(e, t, i) {
        return t instanceof Oi ? new Zt(e, vr(e.mode, t.state), i, t.lookAhead) : new Zt(e, vr(e.mode, t), i);
      }, Zt.prototype.save = function(e) {
        var t = e !== !1 ? vr(this.doc.mode, this.state) : this.state;
        return this.maxLookAhead > 0 ? new Oi(t, this.maxLookAhead) : t;
      };
      function xa(e, t, i, r) {
        var n = [e.state.modeGen], a = {};
        ka(
          e,
          t.text,
          e.doc.mode,
          i,
          function(c, g) {
            return n.push(c, g);
          },
          a,
          r
        );
        for (var l = i.state, u = function(c) {
          i.baseTokens = n;
          var g = e.state.overlays[c], m = 1, L = 0;
          i.state = !0, ka(e, t.text, g.mode, i, function(S, U) {
            for (var Y = m; L < S; ) {
              var V = n[m];
              V > S && n.splice(m, 1, S, n[m + 1], V), m += 2, L = Math.min(S, V);
            }
            if (U)
              if (g.opaque)
                n.splice(Y, m - Y, S, "overlay " + U), m = Y + 2;
              else
                for (; Y < m; Y += 2) {
                  var le = n[Y + 1];
                  n[Y + 1] = (le ? le + " " : "") + "overlay " + U;
                }
          }, a), i.state = l, i.baseTokens = null, i.baseTokenPos = 1;
        }, s = 0; s < e.state.overlays.length; ++s) u(s);
        return { styles: n, classes: a.bgClass || a.textClass ? a : null };
      }
      function ya(e, t, i) {
        if (!t.styles || t.styles[0] != e.state.modeGen) {
          var r = ii(e, Ge(t)), n = t.text.length > e.options.maxHighlightLength && vr(e.doc.mode, r.state), a = xa(e, t, r);
          n && (r.state = n), t.stateAfter = r.save(!n), t.styles = a.styles, a.classes ? t.styleClasses = a.classes : t.styleClasses && (t.styleClasses = null), i === e.doc.highlightFrontier && (e.doc.modeFrontier = Math.max(e.doc.modeFrontier, ++e.doc.highlightFrontier));
        }
        return t.styles;
      }
      function ii(e, t, i) {
        var r = e.doc, n = e.display;
        if (!r.mode.startState)
          return new Zt(r, !0, t);
        var a = Jo(e, t, i), l = a > r.first && be(r, a - 1).stateAfter, u = l ? Zt.fromSaved(r, l, a) : new Zt(r, ga(r.mode), a);
        return r.iter(a, t, function(s) {
          xn(e, s.text, u);
          var c = u.line;
          s.stateAfter = c == t - 1 || c % 5 == 0 || c >= n.viewFrom && c < n.viewTo ? u.save() : null, u.nextLine();
        }), i && (r.modeFrontier = u.line), u;
      }
      function xn(e, t, i, r) {
        var n = e.doc.mode, a = new st(t, e.options.tabSize, i);
        for (a.start = a.pos = r || 0, t == "" && Da(n, i.state); !a.eol(); )
          yn(n, a, i.state), a.start = a.pos;
      }
      function Da(e, t) {
        if (e.blankLine)
          return e.blankLine(t);
        if (e.innerMode) {
          var i = dn(e, t);
          if (i.mode.blankLine)
            return i.mode.blankLine(i.state);
        }
      }
      function yn(e, t, i, r) {
        for (var n = 0; n < 10; n++) {
          r && (r[0] = dn(e, i).mode);
          var a = e.token(t, i);
          if (t.pos > t.start)
            return a;
        }
        throw new Error("Mode " + e.name + " failed to advance stream.");
      }
      var ba = function(e, t, i) {
        this.start = e.start, this.end = e.pos, this.string = e.current(), this.type = t || null, this.state = i;
      };
      function Ca(e, t, i, r) {
        var n = e.doc, a = n.mode, l;
        t = Oe(n, t);
        var u = be(n, t.line), s = ii(e, t.line, i), c = new st(u.text, e.options.tabSize, s), g;
        for (r && (g = []); (r || c.pos < t.ch) && !c.eol(); )
          c.start = c.pos, l = yn(a, c, s.state), r && g.push(new ba(c, l, vr(n.mode, s.state)));
        return r ? g : new ba(c, l, s.state);
      }
      function wa(e, t) {
        if (e)
          for (; ; ) {
            var i = e.match(/(?:^|\s+)line-(background-)?(\S+)/);
            if (!i)
              break;
            e = e.slice(0, i.index) + e.slice(i.index + i[0].length);
            var r = i[1] ? "bgClass" : "textClass";
            t[r] == null ? t[r] = i[2] : new RegExp("(?:^|\\s)" + i[2] + "(?:$|\\s)").test(t[r]) || (t[r] += " " + i[2]);
          }
        return e;
      }
      function ka(e, t, i, r, n, a, l) {
        var u = i.flattenSpans;
        u == null && (u = e.options.flattenSpans);
        var s = 0, c = null, g = new st(t, e.options.tabSize, r), m, L = e.options.addModeClass && [null];
        for (t == "" && wa(Da(i, r.state), a); !g.eol(); ) {
          if (g.pos > e.options.maxHighlightLength ? (u = !1, l && xn(e, t, r, g.pos), g.pos = t.length, m = null) : m = wa(yn(i, g, r.state, L), a), L) {
            var S = L[0].name;
            S && (m = "m-" + (m ? S + " " + m : S));
          }
          if (!u || c != m) {
            for (; s < g.start; )
              s = Math.min(g.start, s + 5e3), n(s, c);
            c = m;
          }
          g.start = g.pos;
        }
        for (; s < g.pos; ) {
          var U = Math.min(g.pos, s + 5e3);
          n(U, c), s = U;
        }
      }
      function Jo(e, t, i) {
        for (var r, n, a = e.doc, l = i ? -1 : t - (e.doc.mode.innerMode ? 1e3 : 100), u = t; u > l; --u) {
          if (u <= a.first)
            return a.first;
          var s = be(a, u - 1), c = s.stateAfter;
          if (c && (!i || u + (c instanceof Oi ? c.lookAhead : 0) <= a.modeFrontier))
            return u;
          var g = Ke(s.text, null, e.options.tabSize);
          (n == null || r > g) && (n = u - 1, r = g);
        }
        return n;
      }
      function $o(e, t) {
        if (e.modeFrontier = Math.min(e.modeFrontier, t), !(e.highlightFrontier < t - 10)) {
          for (var i = e.first, r = t - 1; r > i; r--) {
            var n = be(e, r).stateAfter;
            if (n && (!(n instanceof Oi) || r + n.lookAhead < t)) {
              i = r + 1;
              break;
            }
          }
          e.highlightFrontier = Math.min(e.highlightFrontier, i);
        }
      }
      var Sa = !1, Vt = !1;
      function Vo() {
        Sa = !0;
      }
      function eu() {
        Vt = !0;
      }
      function Ii(e, t, i) {
        this.marker = e, this.from = t, this.to = i;
      }
      function ni(e, t) {
        if (e)
          for (var i = 0; i < e.length; ++i) {
            var r = e[i];
            if (r.marker == t)
              return r;
          }
      }
      function tu(e, t) {
        for (var i, r = 0; r < e.length; ++r)
          e[r] != t && (i || (i = [])).push(e[r]);
        return i;
      }
      function ru(e, t, i) {
        var r = i && window.WeakSet && (i.markedSpans || (i.markedSpans = /* @__PURE__ */ new WeakSet()));
        r && e.markedSpans && r.has(e.markedSpans) ? e.markedSpans.push(t) : (e.markedSpans = e.markedSpans ? e.markedSpans.concat([t]) : [t], r && r.add(e.markedSpans)), t.marker.attachLine(e);
      }
      function iu(e, t, i) {
        var r;
        if (e)
          for (var n = 0; n < e.length; ++n) {
            var a = e[n], l = a.marker, u = a.from == null || (l.inclusiveLeft ? a.from <= t : a.from < t);
            if (u || a.from == t && l.type == "bookmark" && (!i || !a.marker.insertLeft)) {
              var s = a.to == null || (l.inclusiveRight ? a.to >= t : a.to > t);
              (r || (r = [])).push(new Ii(l, a.from, s ? null : a.to));
            }
          }
        return r;
      }
      function nu(e, t, i) {
        var r;
        if (e)
          for (var n = 0; n < e.length; ++n) {
            var a = e[n], l = a.marker, u = a.to == null || (l.inclusiveRight ? a.to >= t : a.to > t);
            if (u || a.from == t && l.type == "bookmark" && (!i || a.marker.insertLeft)) {
              var s = a.from == null || (l.inclusiveLeft ? a.from <= t : a.from < t);
              (r || (r = [])).push(new Ii(
                l,
                s ? null : a.from - t,
                a.to == null ? null : a.to - t
              ));
            }
          }
        return r;
      }
      function Dn(e, t) {
        if (t.full)
          return null;
        var i = ri(e, t.from.line) && be(e, t.from.line).markedSpans, r = ri(e, t.to.line) && be(e, t.to.line).markedSpans;
        if (!i && !r)
          return null;
        var n = t.from.ch, a = t.to.ch, l = Ne(t.from, t.to) == 0, u = iu(i, n, l), s = nu(r, a, l), c = t.text.length == 1, g = xe(t.text).length + (c ? n : 0);
        if (u)
          for (var m = 0; m < u.length; ++m) {
            var L = u[m];
            if (L.to == null) {
              var S = ni(s, L.marker);
              S ? c && (L.to = S.to == null ? null : S.to + g) : L.to = n;
            }
          }
        if (s)
          for (var U = 0; U < s.length; ++U) {
            var Y = s[U];
            if (Y.to != null && (Y.to += g), Y.from == null) {
              var V = ni(u, Y.marker);
              V || (Y.from = g, c && (u || (u = [])).push(Y));
            } else
              Y.from += g, c && (u || (u = [])).push(Y);
          }
        u && (u = Fa(u)), s && s != u && (s = Fa(s));
        var le = [u];
        if (!c) {
          var he = t.text.length - 2, oe;
          if (he > 0 && u)
            for (var pe = 0; pe < u.length; ++pe)
              u[pe].to == null && (oe || (oe = [])).push(new Ii(u[pe].marker, null, null));
          for (var Fe = 0; Fe < he; ++Fe)
            le.push(oe);
          le.push(s);
        }
        return le;
      }
      function Fa(e) {
        for (var t = 0; t < e.length; ++t) {
          var i = e[t];
          i.from != null && i.from == i.to && i.marker.clearWhenEmpty !== !1 && e.splice(t--, 1);
        }
        return e.length ? e : null;
      }
      function au(e, t, i) {
        var r = null;
        if (e.iter(t.line, i.line + 1, function(S) {
          if (S.markedSpans)
            for (var U = 0; U < S.markedSpans.length; ++U) {
              var Y = S.markedSpans[U].marker;
              Y.readOnly && (!r || Pe(r, Y) == -1) && (r || (r = [])).push(Y);
            }
        }), !r)
          return null;
        for (var n = [{ from: t, to: i }], a = 0; a < r.length; ++a)
          for (var l = r[a], u = l.find(0), s = 0; s < n.length; ++s) {
            var c = n[s];
            if (!(Ne(c.to, u.from) < 0 || Ne(c.from, u.to) > 0)) {
              var g = [s, 1], m = Ne(c.from, u.from), L = Ne(c.to, u.to);
              (m < 0 || !l.inclusiveLeft && !m) && g.push({ from: c.from, to: u.from }), (L > 0 || !l.inclusiveRight && !L) && g.push({ from: u.to, to: c.to }), n.splice.apply(n, g), s += g.length - 3;
            }
          }
        return n;
      }
      function Aa(e) {
        var t = e.markedSpans;
        if (t) {
          for (var i = 0; i < t.length; ++i)
            t[i].marker.detachLine(e);
          e.markedSpans = null;
        }
      }
      function Ea(e, t) {
        if (t) {
          for (var i = 0; i < t.length; ++i)
            t[i].marker.attachLine(e);
          e.markedSpans = t;
        }
      }
      function Hi(e) {
        return e.inclusiveLeft ? -1 : 0;
      }
      function Ri(e) {
        return e.inclusiveRight ? 1 : 0;
      }
      function bn(e, t) {
        var i = e.lines.length - t.lines.length;
        if (i != 0)
          return i;
        var r = e.find(), n = t.find(), a = Ne(r.from, n.from) || Hi(e) - Hi(t);
        if (a)
          return -a;
        var l = Ne(r.to, n.to) || Ri(e) - Ri(t);
        return l || t.id - e.id;
      }
      function La(e, t) {
        var i = Vt && e.markedSpans, r;
        if (i)
          for (var n = void 0, a = 0; a < i.length; ++a)
            n = i[a], n.marker.collapsed && (t ? n.from : n.to) == null && (!r || bn(r, n.marker) < 0) && (r = n.marker);
        return r;
      }
      function Ta(e) {
        return La(e, !0);
      }
      function Pi(e) {
        return La(e, !1);
      }
      function lu(e, t) {
        var i = Vt && e.markedSpans, r;
        if (i)
          for (var n = 0; n < i.length; ++n) {
            var a = i[n];
            a.marker.collapsed && (a.from == null || a.from < t) && (a.to == null || a.to > t) && (!r || bn(r, a.marker) < 0) && (r = a.marker);
          }
        return r;
      }
      function Ba(e, t, i, r, n) {
        var a = be(e, t), l = Vt && a.markedSpans;
        if (l)
          for (var u = 0; u < l.length; ++u) {
            var s = l[u];
            if (s.marker.collapsed) {
              var c = s.marker.find(0), g = Ne(c.from, i) || Hi(s.marker) - Hi(n), m = Ne(c.to, r) || Ri(s.marker) - Ri(n);
              if (!(g >= 0 && m <= 0 || g <= 0 && m >= 0) && (g <= 0 && (s.marker.inclusiveRight && n.inclusiveLeft ? Ne(c.to, i) >= 0 : Ne(c.to, i) > 0) || g >= 0 && (s.marker.inclusiveRight && n.inclusiveLeft ? Ne(c.from, r) <= 0 : Ne(c.from, r) < 0)))
                return !0;
            }
          }
      }
      function Ut(e) {
        for (var t; t = Ta(e); )
          e = t.find(-1, !0).line;
        return e;
      }
      function ou(e) {
        for (var t; t = Pi(e); )
          e = t.find(1, !0).line;
        return e;
      }
      function uu(e) {
        for (var t, i; t = Pi(e); )
          e = t.find(1, !0).line, (i || (i = [])).push(e);
        return i;
      }
      function Cn(e, t) {
        var i = be(e, t), r = Ut(i);
        return i == r ? t : Ge(r);
      }
      function Ma(e, t) {
        if (t > e.lastLine())
          return t;
        var i = be(e, t), r;
        if (!lr(e, i))
          return t;
        for (; r = Pi(i); )
          i = r.find(1, !0).line;
        return Ge(i) + 1;
      }
      function lr(e, t) {
        var i = Vt && t.markedSpans;
        if (i) {
          for (var r = void 0, n = 0; n < i.length; ++n)
            if (r = i[n], !!r.marker.collapsed) {
              if (r.from == null)
                return !0;
              if (!r.marker.widgetNode && r.from == 0 && r.marker.inclusiveLeft && wn(e, t, r))
                return !0;
            }
        }
      }
      function wn(e, t, i) {
        if (i.to == null) {
          var r = i.marker.find(1, !0);
          return wn(e, r.line, ni(r.line.markedSpans, i.marker));
        }
        if (i.marker.inclusiveRight && i.to == t.text.length)
          return !0;
        for (var n = void 0, a = 0; a < t.markedSpans.length; ++a)
          if (n = t.markedSpans[a], n.marker.collapsed && !n.marker.widgetNode && n.from == i.to && (n.to == null || n.to != i.from) && (n.marker.inclusiveLeft || i.marker.inclusiveRight) && wn(e, t, n))
            return !0;
      }
      function er(e) {
        e = Ut(e);
        for (var t = 0, i = e.parent, r = 0; r < i.lines.length; ++r) {
          var n = i.lines[r];
          if (n == e)
            break;
          t += n.height;
        }
        for (var a = i.parent; a; i = a, a = i.parent)
          for (var l = 0; l < a.children.length; ++l) {
            var u = a.children[l];
            if (u == i)
              break;
            t += u.height;
          }
        return t;
      }
      function zi(e) {
        if (e.height == 0)
          return 0;
        for (var t = e.text.length, i, r = e; i = Ta(r); ) {
          var n = i.find(0, !0);
          r = n.from.line, t += n.from.ch - n.to.ch;
        }
        for (r = e; i = Pi(r); ) {
          var a = i.find(0, !0);
          t -= r.text.length - a.from.ch, r = a.to.line, t += r.text.length - a.to.ch;
        }
        return t;
      }
      function kn(e) {
        var t = e.display, i = e.doc;
        t.maxLine = be(i, i.first), t.maxLineLength = zi(t.maxLine), t.maxLineChanged = !0, i.iter(function(r) {
          var n = zi(r);
          n > t.maxLineLength && (t.maxLineLength = n, t.maxLine = r);
        });
      }
      var Or = function(e, t, i) {
        this.text = e, Ea(this, t), this.height = i ? i(this) : 1;
      };
      Or.prototype.lineNo = function() {
        return Ge(this);
      }, Ie(Or);
      function su(e, t, i, r) {
        e.text = t, e.stateAfter && (e.stateAfter = null), e.styles && (e.styles = null), e.order != null && (e.order = null), Aa(e), Ea(e, i);
        var n = r ? r(e) : 1;
        n != e.height && Yt(e, n);
      }
      function fu(e) {
        e.parent = null, Aa(e);
      }
      var cu = {}, hu = {};
      function Na(e, t) {
        if (!e || /^\s*$/.test(e))
          return null;
        var i = t.addModeClass ? hu : cu;
        return i[e] || (i[e] = e.replace(/\S+/g, "cm-$&"));
      }
      function Oa(e, t) {
        var i = ee("span", null, null, re ? "padding-right: .1px" : null), r = {
          pre: ee("pre", [i], "CodeMirror-line"),
          content: i,
          col: 0,
          pos: 0,
          cm: e,
          trailingSpace: !1,
          splitSpaces: e.getOption("lineWrapping")
        };
        t.measure = {};
        for (var n = 0; n <= (t.rest ? t.rest.length : 0); n++) {
          var a = n ? t.rest[n - 1] : t.line, l = void 0;
          r.pos = 0, r.addToken = pu, ei(e.display.measure) && (l = y(a, e.doc.direction)) && (r.addToken = vu(r.addToken, l)), r.map = [];
          var u = t != e.display.externalMeasured && Ge(a);
          mu(a, r, ya(e, a, u)), a.styleClasses && (a.styleClasses.bgClass && (r.bgClass = _t(a.styleClasses.bgClass, r.bgClass || "")), a.styleClasses.textClass && (r.textClass = _t(a.styleClasses.textClass, r.textClass || ""))), r.map.length == 0 && r.map.push(0, 0, r.content.appendChild(Ti(e.display.measure))), n == 0 ? (t.measure.map = r.map, t.measure.cache = {}) : ((t.measure.maps || (t.measure.maps = [])).push(r.map), (t.measure.caches || (t.measure.caches = [])).push({}));
        }
        if (re) {
          var s = r.content.lastChild;
          (/\bcm-tab\b/.test(s.className) || s.querySelector && s.querySelector(".cm-tab")) && (r.content.className = "cm-tab-wrap-hack");
        }
        return ve(e, "renderLine", e, t.line, r.pre), r.pre.className && (r.textClass = _t(r.pre.className, r.textClass || "")), r;
      }
      function du(e) {
        var t = E("span", "•", "cm-invalidchar");
        return t.title = "\\u" + e.charCodeAt(0).toString(16), t.setAttribute("aria-label", t.title), t;
      }
      function pu(e, t, i, r, n, a, l) {
        if (t) {
          var u = e.splitSpaces ? gu(t, e.trailingSpace) : t, s = e.cm.state.specialChars, c = !1, g;
          if (!s.test(t))
            e.col += t.length, g = document.createTextNode(u), e.map.push(e.pos, e.pos + t.length, g), T && P < 9 && (c = !0), e.pos += t.length;
          else {
            g = document.createDocumentFragment();
            for (var m = 0; ; ) {
              s.lastIndex = m;
              var L = s.exec(t), S = L ? L.index - m : t.length - m;
              if (S) {
                var U = document.createTextNode(u.slice(m, m + S));
                T && P < 9 ? g.appendChild(E("span", [U])) : g.appendChild(U), e.map.push(e.pos, e.pos + S, U), e.col += S, e.pos += S;
              }
              if (!L)
                break;
              m += S + 1;
              var Y = void 0;
              if (L[0] == "	") {
                var V = e.cm.options.tabSize, le = V - e.col % V;
                Y = g.appendChild(E("span", Ht(le), "cm-tab")), Y.setAttribute("role", "presentation"), Y.setAttribute("cm-text", "	"), e.col += le;
              } else L[0] == "\r" || L[0] == `
` ? (Y = g.appendChild(E("span", L[0] == "\r" ? "␍" : "␤", "cm-invalidchar")), Y.setAttribute("cm-text", L[0]), e.col += 1) : (Y = e.cm.options.specialCharPlaceholder(L[0]), Y.setAttribute("cm-text", L[0]), T && P < 9 ? g.appendChild(E("span", [Y])) : g.appendChild(Y), e.col += 1);
              e.map.push(e.pos, e.pos + 1, Y), e.pos++;
            }
          }
          if (e.trailingSpace = u.charCodeAt(t.length - 1) == 32, i || r || n || c || a || l) {
            var he = i || "";
            r && (he += r), n && (he += n);
            var oe = E("span", [g], he, a);
            if (l)
              for (var pe in l)
                l.hasOwnProperty(pe) && pe != "style" && pe != "class" && oe.setAttribute(pe, l[pe]);
            return e.content.appendChild(oe);
          }
          e.content.appendChild(g);
        }
      }
      function gu(e, t) {
        if (e.length > 1 && !/  /.test(e))
          return e;
        for (var i = t, r = "", n = 0; n < e.length; n++) {
          var a = e.charAt(n);
          a == " " && i && (n == e.length - 1 || e.charCodeAt(n + 1) == 32) && (a = " "), r += a, i = a == " ";
        }
        return r;
      }
      function vu(e, t) {
        return function(i, r, n, a, l, u, s) {
          n = n ? n + " cm-force-border" : "cm-force-border";
          for (var c = i.pos, g = c + r.length; ; ) {
            for (var m = void 0, L = 0; L < t.length && (m = t[L], !(m.to > c && m.from <= c)); L++)
              ;
            if (m.to >= g)
              return e(i, r, n, a, l, u, s);
            e(i, r.slice(0, m.to - c), n, a, null, u, s), a = null, r = r.slice(m.to - c), c = m.to;
          }
        };
      }
      function Ia(e, t, i, r) {
        var n = !r && i.widgetNode;
        n && e.map.push(e.pos, e.pos + t, n), !r && e.cm.display.input.needsContentAttribute && (n || (n = e.content.appendChild(document.createElement("span"))), n.setAttribute("cm-marker", i.id)), n && (e.cm.display.input.setUneditable(n), e.content.appendChild(n)), e.pos += t, e.trailingSpace = !1;
      }
      function mu(e, t, i) {
        var r = e.markedSpans, n = e.text, a = 0;
        if (!r) {
          for (var l = 1; l < i.length; l += 2)
            t.addToken(t, n.slice(a, a = i[l]), Na(i[l + 1], t.cm.options));
          return;
        }
        for (var u = n.length, s = 0, c = 1, g = "", m, L, S = 0, U, Y, V, le, he; ; ) {
          if (S == s) {
            U = Y = V = L = "", he = null, le = null, S = 1 / 0;
            for (var oe = [], pe = void 0, Fe = 0; Fe < r.length; ++Fe) {
              var we = r[Fe], Re = we.marker;
              if (Re.type == "bookmark" && we.from == s && Re.widgetNode)
                oe.push(Re);
              else if (we.from <= s && (we.to == null || we.to > s || Re.collapsed && we.to == s && we.from == s)) {
                if (we.to != null && we.to != s && S > we.to && (S = we.to, Y = ""), Re.className && (U += " " + Re.className), Re.css && (L = (L ? L + ";" : "") + Re.css), Re.startStyle && we.from == s && (V += " " + Re.startStyle), Re.endStyle && we.to == S && (pe || (pe = [])).push(Re.endStyle, we.to), Re.title && ((he || (he = {})).title = Re.title), Re.attributes)
                  for (var Qe in Re.attributes)
                    (he || (he = {}))[Qe] = Re.attributes[Qe];
                Re.collapsed && (!le || bn(le.marker, Re) < 0) && (le = we);
              } else we.from > s && S > we.from && (S = we.from);
            }
            if (pe)
              for (var vt = 0; vt < pe.length; vt += 2)
                pe[vt + 1] == S && (Y += " " + pe[vt]);
            if (!le || le.from == s)
              for (var tt = 0; tt < oe.length; ++tt)
                Ia(t, 0, oe[tt]);
            if (le && (le.from || 0) == s) {
              if (Ia(
                t,
                (le.to == null ? u + 1 : le.to) - s,
                le.marker,
                le.from == null
              ), le.to == null)
                return;
              le.to == s && (le = !1);
            }
          }
          if (s >= u)
            break;
          for (var It = Math.min(u, S); ; ) {
            if (g) {
              var Tt = s + g.length;
              if (!le) {
                var ft = Tt > It ? g.slice(0, It - s) : g;
                t.addToken(
                  t,
                  ft,
                  m ? m + U : U,
                  V,
                  s + ft.length == S ? Y : "",
                  L,
                  he
                );
              }
              if (Tt >= It) {
                g = g.slice(It - s), s = It;
                break;
              }
              s = Tt, V = "";
            }
            g = n.slice(a, a = i[c++]), m = Na(i[c++], t.cm.options);
          }
        }
      }
      function Ha(e, t, i) {
        this.line = t, this.rest = uu(t), this.size = this.rest ? Ge(xe(this.rest)) - i + 1 : 1, this.node = this.text = null, this.hidden = lr(e, t);
      }
      function Wi(e, t, i) {
        for (var r = [], n, a = t; a < i; a = n) {
          var l = new Ha(e.doc, be(e.doc, a), a);
          n = a + l.size, r.push(l);
        }
        return r;
      }
      var Ir = null;
      function xu(e) {
        Ir ? Ir.ops.push(e) : e.ownsGroup = Ir = {
          ops: [e],
          delayedCallbacks: []
        };
      }
      function yu(e) {
        var t = e.delayedCallbacks, i = 0;
        do {
          for (; i < t.length; i++)
            t[i].call(null);
          for (var r = 0; r < e.ops.length; r++) {
            var n = e.ops[r];
            if (n.cursorActivityHandlers)
              for (; n.cursorActivityCalled < n.cursorActivityHandlers.length; )
                n.cursorActivityHandlers[n.cursorActivityCalled++].call(null, n.cm);
          }
        } while (i < t.length);
      }
      function Du(e, t) {
        var i = e.ownsGroup;
        if (i)
          try {
            yu(i);
          } finally {
            Ir = null, t(i);
          }
      }
      var ai = null;
      function dt(e, t) {
        var i = ne(e, t);
        if (i.length) {
          var r = Array.prototype.slice.call(arguments, 2), n;
          Ir ? n = Ir.delayedCallbacks : ai ? n = ai : (n = ai = [], setTimeout(bu, 0));
          for (var a = function(u) {
            n.push(function() {
              return i[u].apply(null, r);
            });
          }, l = 0; l < i.length; ++l)
            a(l);
        }
      }
      function bu() {
        var e = ai;
        ai = null;
        for (var t = 0; t < e.length; ++t)
          e[t]();
      }
      function Ra(e, t, i, r) {
        for (var n = 0; n < t.changes.length; n++) {
          var a = t.changes[n];
          a == "text" ? wu(e, t) : a == "gutter" ? za(e, t, i, r) : a == "class" ? Sn(e, t) : a == "widget" && ku(e, t, r);
        }
        t.changes = null;
      }
      function li(e) {
        return e.node == e.text && (e.node = E("div", null, null, "position: relative"), e.text.parentNode && e.text.parentNode.replaceChild(e.node, e.text), e.node.appendChild(e.text), T && P < 8 && (e.node.style.zIndex = 2)), e.node;
      }
      function Cu(e, t) {
        var i = t.bgClass ? t.bgClass + " " + (t.line.bgClass || "") : t.line.bgClass;
        if (i && (i += " CodeMirror-linebackground"), t.background)
          i ? t.background.className = i : (t.background.parentNode.removeChild(t.background), t.background = null);
        else if (i) {
          var r = li(t);
          t.background = r.insertBefore(E("div", null, i), r.firstChild), e.display.input.setUneditable(t.background);
        }
      }
      function Pa(e, t) {
        var i = e.display.externalMeasured;
        return i && i.line == t.line ? (e.display.externalMeasured = null, t.measure = i.measure, i.built) : Oa(e, t);
      }
      function wu(e, t) {
        var i = t.text.className, r = Pa(e, t);
        t.text == t.node && (t.node = r.pre), t.text.parentNode.replaceChild(r.pre, t.text), t.text = r.pre, r.bgClass != t.bgClass || r.textClass != t.textClass ? (t.bgClass = r.bgClass, t.textClass = r.textClass, Sn(e, t)) : i && (t.text.className = i);
      }
      function Sn(e, t) {
        Cu(e, t), t.line.wrapClass ? li(t).className = t.line.wrapClass : t.node != t.text && (t.node.className = "");
        var i = t.textClass ? t.textClass + " " + (t.line.textClass || "") : t.line.textClass;
        t.text.className = i || "";
      }
      function za(e, t, i, r) {
        if (t.gutter && (t.node.removeChild(t.gutter), t.gutter = null), t.gutterBackground && (t.node.removeChild(t.gutterBackground), t.gutterBackground = null), t.line.gutterClass) {
          var n = li(t);
          t.gutterBackground = E(
            "div",
            null,
            "CodeMirror-gutter-background " + t.line.gutterClass,
            "left: " + (e.options.fixedGutter ? r.fixedPos : -r.gutterTotalWidth) + "px; width: " + r.gutterTotalWidth + "px"
          ), e.display.input.setUneditable(t.gutterBackground), n.insertBefore(t.gutterBackground, t.text);
        }
        var a = t.line.gutterMarkers;
        if (e.options.lineNumbers || a) {
          var l = li(t), u = t.gutter = E("div", null, "CodeMirror-gutter-wrapper", "left: " + (e.options.fixedGutter ? r.fixedPos : -r.gutterTotalWidth) + "px");
          if (u.setAttribute("aria-hidden", "true"), e.display.input.setUneditable(u), l.insertBefore(u, t.text), t.line.gutterClass && (u.className += " " + t.line.gutterClass), e.options.lineNumbers && (!a || !a["CodeMirror-linenumbers"]) && (t.lineNumber = u.appendChild(
            E(
              "div",
              gn(e.options, i),
              "CodeMirror-linenumber CodeMirror-gutter-elt",
              "left: " + r.gutterLeft["CodeMirror-linenumbers"] + "px; width: " + e.display.lineNumInnerWidth + "px"
            )
          )), a)
            for (var s = 0; s < e.display.gutterSpecs.length; ++s) {
              var c = e.display.gutterSpecs[s].className, g = a.hasOwnProperty(c) && a[c];
              g && u.appendChild(E(
                "div",
                [g],
                "CodeMirror-gutter-elt",
                "left: " + r.gutterLeft[c] + "px; width: " + r.gutterWidth[c] + "px"
              ));
            }
        }
      }
      function ku(e, t, i) {
        t.alignable && (t.alignable = null);
        for (var r = ae("CodeMirror-linewidget"), n = t.node.firstChild, a = void 0; n; n = a)
          a = n.nextSibling, r.test(n.className) && t.node.removeChild(n);
        Wa(e, t, i);
      }
      function Su(e, t, i, r) {
        var n = Pa(e, t);
        return t.text = t.node = n.pre, n.bgClass && (t.bgClass = n.bgClass), n.textClass && (t.textClass = n.textClass), Sn(e, t), za(e, t, i, r), Wa(e, t, r), t.node;
      }
      function Wa(e, t, i) {
        if (_a(e, t.line, t, i, !0), t.rest)
          for (var r = 0; r < t.rest.length; r++)
            _a(e, t.rest[r], t, i, !1);
      }
      function _a(e, t, i, r, n) {
        if (t.widgets)
          for (var a = li(i), l = 0, u = t.widgets; l < u.length; ++l) {
            var s = u[l], c = E("div", [s.node], "CodeMirror-linewidget" + (s.className ? " " + s.className : ""));
            s.handleMouseEvents || c.setAttribute("cm-ignore-events", "true"), Fu(s, c, i, r), e.display.input.setUneditable(c), n && s.above ? a.insertBefore(c, i.gutter || i.text) : a.appendChild(c), dt(s, "redraw");
          }
      }
      function Fu(e, t, i, r) {
        if (e.noHScroll) {
          (i.alignable || (i.alignable = [])).push(t);
          var n = r.wrapperWidth;
          t.style.left = r.fixedPos + "px", e.coverGutter || (n -= r.gutterTotalWidth, t.style.paddingLeft = r.gutterTotalWidth + "px"), t.style.width = n + "px";
        }
        e.coverGutter && (t.style.zIndex = 5, t.style.position = "relative", e.noHScroll || (t.style.marginLeft = -r.gutterTotalWidth + "px"));
      }
      function oi(e) {
        if (e.height != null)
          return e.height;
        var t = e.doc.cm;
        if (!t)
          return 0;
        if (!De(document.body, e.node)) {
          var i = "position: relative;";
          e.coverGutter && (i += "margin-left: -" + t.display.gutters.offsetWidth + "px;"), e.noHScroll && (i += "width: " + t.display.wrapper.clientWidth + "px;"), He(t.display.measure, E("div", [e.node], null, i));
        }
        return e.height = e.node.parentNode.offsetHeight;
      }
      function tr(e, t) {
        for (var i = kt(t); i != e.wrapper; i = i.parentNode)
          if (!i || i.nodeType == 1 && i.getAttribute("cm-ignore-events") == "true" || i.parentNode == e.sizer && i != e.mover)
            return !0;
      }
      function _i(e) {
        return e.lineSpace.offsetTop;
      }
      function Fn(e) {
        return e.mover.offsetHeight - e.lineSpace.offsetHeight;
      }
      function qa(e) {
        if (e.cachedPaddingH)
          return e.cachedPaddingH;
        var t = He(e.measure, E("pre", "x", "CodeMirror-line-like")), i = window.getComputedStyle ? window.getComputedStyle(t) : t.currentStyle, r = { left: parseInt(i.paddingLeft), right: parseInt(i.paddingRight) };
        return !isNaN(r.left) && !isNaN(r.right) && (e.cachedPaddingH = r), r;
      }
      function Qt(e) {
        return _e - e.display.nativeBarWidth;
      }
      function yr(e) {
        return e.display.scroller.clientWidth - Qt(e) - e.display.barWidth;
      }
      function An(e) {
        return e.display.scroller.clientHeight - Qt(e) - e.display.barHeight;
      }
      function Au(e, t, i) {
        var r = e.options.lineWrapping, n = r && yr(e);
        if (!t.measure.heights || r && t.measure.width != n) {
          var a = t.measure.heights = [];
          if (r) {
            t.measure.width = n;
            for (var l = t.text.firstChild.getClientRects(), u = 0; u < l.length - 1; u++) {
              var s = l[u], c = l[u + 1];
              Math.abs(s.bottom - c.bottom) > 2 && a.push((s.bottom + c.top) / 2 - i.top);
            }
          }
          a.push(i.bottom - i.top);
        }
      }
      function Ua(e, t, i) {
        if (e.line == t)
          return { map: e.measure.map, cache: e.measure.cache };
        if (e.rest) {
          for (var r = 0; r < e.rest.length; r++)
            if (e.rest[r] == t)
              return { map: e.measure.maps[r], cache: e.measure.caches[r] };
          for (var n = 0; n < e.rest.length; n++)
            if (Ge(e.rest[n]) > i)
              return { map: e.measure.maps[n], cache: e.measure.caches[n], before: !0 };
        }
      }
      function Eu(e, t) {
        t = Ut(t);
        var i = Ge(t), r = e.display.externalMeasured = new Ha(e.doc, t, i);
        r.lineN = i;
        var n = r.built = Oa(e, r);
        return r.text = n.pre, He(e.display.lineMeasure, n.pre), r;
      }
      function Ga(e, t, i, r) {
        return Jt(e, Hr(e, t), i, r);
      }
      function En(e, t) {
        if (t >= e.display.viewFrom && t < e.display.viewTo)
          return e.display.view[Cr(e, t)];
        var i = e.display.externalMeasured;
        if (i && t >= i.lineN && t < i.lineN + i.size)
          return i;
      }
      function Hr(e, t) {
        var i = Ge(t), r = En(e, i);
        r && !r.text ? r = null : r && r.changes && (Ra(e, r, i, Nn(e)), e.curOp.forceUpdate = !0), r || (r = Eu(e, t));
        var n = Ua(r, t, i);
        return {
          line: t,
          view: r,
          rect: null,
          map: n.map,
          cache: n.cache,
          before: n.before,
          hasHeights: !1
        };
      }
      function Jt(e, t, i, r, n) {
        t.before && (i = -1);
        var a = i + (r || ""), l;
        return t.cache.hasOwnProperty(a) ? l = t.cache[a] : (t.rect || (t.rect = t.view.text.getBoundingClientRect()), t.hasHeights || (Au(e, t.view, t.rect), t.hasHeights = !0), l = Tu(e, t, i, r), l.bogus || (t.cache[a] = l)), {
          left: l.left,
          right: l.right,
          top: n ? l.rtop : l.top,
          bottom: n ? l.rbottom : l.bottom
        };
      }
      var ja = { left: 0, right: 0, top: 0, bottom: 0 };
      function Ka(e, t, i) {
        for (var r, n, a, l, u, s, c = 0; c < e.length; c += 3)
          if (u = e[c], s = e[c + 1], t < u ? (n = 0, a = 1, l = "left") : t < s ? (n = t - u, a = n + 1) : (c == e.length - 3 || t == s && e[c + 3] > t) && (a = s - u, n = a - 1, t >= s && (l = "right")), n != null) {
            if (r = e[c + 2], u == s && i == (r.insertLeft ? "left" : "right") && (l = i), i == "left" && n == 0)
              for (; c && e[c - 2] == e[c - 3] && e[c - 1].insertLeft; )
                r = e[(c -= 3) + 2], l = "left";
            if (i == "right" && n == s - u)
              for (; c < e.length - 3 && e[c + 3] == e[c + 4] && !e[c + 5].insertLeft; )
                r = e[(c += 3) + 2], l = "right";
            break;
          }
        return { node: r, start: n, end: a, collapse: l, coverStart: u, coverEnd: s };
      }
      function Lu(e, t) {
        var i = ja;
        if (t == "left")
          for (var r = 0; r < e.length && (i = e[r]).left == i.right; r++)
            ;
        else
          for (var n = e.length - 1; n >= 0 && (i = e[n]).left == i.right; n--)
            ;
        return i;
      }
      function Tu(e, t, i, r) {
        var n = Ka(t.map, i, r), a = n.node, l = n.start, u = n.end, s = n.collapse, c;
        if (a.nodeType == 3) {
          for (var g = 0; g < 4; g++) {
            for (; l && o(t.line.text.charAt(n.coverStart + l)); )
              --l;
            for (; n.coverStart + u < n.coverEnd && o(t.line.text.charAt(n.coverStart + u)); )
              ++u;
            if (T && P < 9 && l == 0 && u == n.coverEnd - n.coverStart ? c = a.parentNode.getBoundingClientRect() : c = Lu(J(a, l, u).getClientRects(), r), c.left || c.right || l == 0)
              break;
            u = l, l = l - 1, s = "right";
          }
          T && P < 11 && (c = Bu(e.display.measure, c));
        } else {
          l > 0 && (s = r = "right");
          var m;
          e.options.lineWrapping && (m = a.getClientRects()).length > 1 ? c = m[r == "right" ? m.length - 1 : 0] : c = a.getBoundingClientRect();
        }
        if (T && P < 9 && !l && (!c || !c.left && !c.right)) {
          var L = a.parentNode.getClientRects()[0];
          L ? c = { left: L.left, right: L.left + Pr(e.display), top: L.top, bottom: L.bottom } : c = ja;
        }
        for (var S = c.top - t.rect.top, U = c.bottom - t.rect.top, Y = (S + U) / 2, V = t.view.measure.heights, le = 0; le < V.length - 1 && !(Y < V[le]); le++)
          ;
        var he = le ? V[le - 1] : 0, oe = V[le], pe = {
          left: (s == "right" ? c.right : c.left) - t.rect.left,
          right: (s == "left" ? c.left : c.right) - t.rect.left,
          top: he,
          bottom: oe
        };
        return !c.left && !c.right && (pe.bogus = !0), e.options.singleCursorHeightPerLine || (pe.rtop = S, pe.rbottom = U), pe;
      }
      function Bu(e, t) {
        if (!window.screen || screen.logicalXDPI == null || screen.logicalXDPI == screen.deviceXDPI || !qt(e))
          return t;
        var i = screen.logicalXDPI / screen.deviceXDPI, r = screen.logicalYDPI / screen.deviceYDPI;
        return {
          left: t.left * i,
          right: t.right * i,
          top: t.top * r,
          bottom: t.bottom * r
        };
      }
      function Xa(e) {
        if (e.measure && (e.measure.cache = {}, e.measure.heights = null, e.rest))
          for (var t = 0; t < e.rest.length; t++)
            e.measure.caches[t] = {};
      }
      function Ya(e) {
        e.display.externalMeasure = null, Ee(e.display.lineMeasure);
        for (var t = 0; t < e.display.view.length; t++)
          Xa(e.display.view[t]);
      }
      function ui(e) {
        Ya(e), e.display.cachedCharWidth = e.display.cachedTextHeight = e.display.cachedPaddingH = null, e.options.lineWrapping || (e.display.maxLineChanged = !0), e.display.lineNumChars = null;
      }
      function Za(e) {
        return K && X ? -(e.body.getBoundingClientRect().left - parseInt(getComputedStyle(e.body).marginLeft)) : e.defaultView.pageXOffset || (e.documentElement || e.body).scrollLeft;
      }
      function Qa(e) {
        return K && X ? -(e.body.getBoundingClientRect().top - parseInt(getComputedStyle(e.body).marginTop)) : e.defaultView.pageYOffset || (e.documentElement || e.body).scrollTop;
      }
      function Ln(e) {
        var t = Ut(e), i = t.widgets, r = 0;
        if (i)
          for (var n = 0; n < i.length; ++n)
            i[n].above && (r += oi(i[n]));
        return r;
      }
      function qi(e, t, i, r, n) {
        if (!n) {
          var a = Ln(t);
          i.top += a, i.bottom += a;
        }
        if (r == "line")
          return i;
        r || (r = "local");
        var l = er(t);
        if (r == "local" ? l += _i(e.display) : l -= e.display.viewOffset, r == "page" || r == "window") {
          var u = e.display.lineSpace.getBoundingClientRect();
          l += u.top + (r == "window" ? 0 : Qa(p(e)));
          var s = u.left + (r == "window" ? 0 : Za(p(e)));
          i.left += s, i.right += s;
        }
        return i.top += l, i.bottom += l, i;
      }
      function Ja(e, t, i) {
        if (i == "div")
          return t;
        var r = t.left, n = t.top;
        if (i == "page")
          r -= Za(p(e)), n -= Qa(p(e));
        else if (i == "local" || !i) {
          var a = e.display.sizer.getBoundingClientRect();
          r += a.left, n += a.top;
        }
        var l = e.display.lineSpace.getBoundingClientRect();
        return { left: r - l.left, top: n - l.top };
      }
      function Ui(e, t, i, r, n) {
        return r || (r = be(e.doc, t.line)), qi(e, r, Ga(e, r, t.ch, n), i);
      }
      function Gt(e, t, i, r, n, a) {
        r = r || be(e.doc, t.line), n || (n = Hr(e, r));
        function l(U, Y) {
          var V = Jt(e, n, U, Y ? "right" : "left", a);
          return Y ? V.left = V.right : V.right = V.left, qi(e, r, V, i);
        }
        var u = y(r, e.doc.direction), s = t.ch, c = t.sticky;
        if (s >= r.text.length ? (s = r.text.length, c = "before") : s <= 0 && (s = 0, c = "after"), !u)
          return l(c == "before" ? s - 1 : s, c == "before");
        function g(U, Y, V) {
          var le = u[Y], he = le.level == 1;
          return l(V ? U - 1 : U, he != V);
        }
        var m = M(u, s, c), L = b, S = g(s, m, c == "before");
        return L != null && (S.other = g(s, L, c != "before")), S;
      }
      function $a(e, t) {
        var i = 0;
        t = Oe(e.doc, t), e.options.lineWrapping || (i = Pr(e.display) * t.ch);
        var r = be(e.doc, t.line), n = er(r) + _i(e.display);
        return { left: i, right: i, top: n, bottom: n + r.height };
      }
      function Tn(e, t, i, r, n) {
        var a = $(e, t, i);
        return a.xRel = n, r && (a.outside = r), a;
      }
      function Bn(e, t, i) {
        var r = e.doc;
        if (i += e.display.viewOffset, i < 0)
          return Tn(r.first, 0, null, -1, -1);
        var n = xr(r, i), a = r.first + r.size - 1;
        if (n > a)
          return Tn(r.first + r.size - 1, be(r, a).text.length, null, 1, 1);
        t < 0 && (t = 0);
        for (var l = be(r, n); ; ) {
          var u = Mu(e, l, n, t, i), s = lu(l, u.ch + (u.xRel > 0 || u.outside > 0 ? 1 : 0));
          if (!s)
            return u;
          var c = s.find(1);
          if (c.line == n)
            return c;
          l = be(r, n = c.line);
        }
      }
      function Va(e, t, i, r) {
        r -= Ln(t);
        var n = t.text.length, a = v(function(l) {
          return Jt(e, i, l - 1).bottom <= r;
        }, n, 0);
        return n = v(function(l) {
          return Jt(e, i, l).top > r;
        }, a, n), { begin: a, end: n };
      }
      function el(e, t, i, r) {
        i || (i = Hr(e, t));
        var n = qi(e, t, Jt(e, i, r), "line").top;
        return Va(e, t, i, n);
      }
      function Mn(e, t, i, r) {
        return e.bottom <= i ? !1 : e.top > i ? !0 : (r ? e.left : e.right) > t;
      }
      function Mu(e, t, i, r, n) {
        n -= er(t);
        var a = Hr(e, t), l = Ln(t), u = 0, s = t.text.length, c = !0, g = y(t, e.doc.direction);
        if (g) {
          var m = (e.options.lineWrapping ? Ou : Nu)(e, t, i, a, g, r, n);
          c = m.level != 1, u = c ? m.from : m.to - 1, s = c ? m.to : m.from - 1;
        }
        var L = null, S = null, U = v(function(Fe) {
          var we = Jt(e, a, Fe);
          return we.top += l, we.bottom += l, Mn(we, r, n, !1) ? (we.top <= n && we.left <= r && (L = Fe, S = we), !0) : !1;
        }, u, s), Y, V, le = !1;
        if (S) {
          var he = r - S.left < S.right - r, oe = he == c;
          U = L + (oe ? 0 : 1), V = oe ? "after" : "before", Y = he ? S.left : S.right;
        } else {
          !c && (U == s || U == u) && U++, V = U == 0 ? "after" : U == t.text.length ? "before" : Jt(e, a, U - (c ? 1 : 0)).bottom + l <= n == c ? "after" : "before";
          var pe = Gt(e, $(i, U, V), "line", t, a);
          Y = pe.left, le = n < pe.top ? -1 : n >= pe.bottom ? 1 : 0;
        }
        return U = f(t.text, U, 1), Tn(i, U, V, le, r - Y);
      }
      function Nu(e, t, i, r, n, a, l) {
        var u = v(function(m) {
          var L = n[m], S = L.level != 1;
          return Mn(Gt(
            e,
            $(i, S ? L.to : L.from, S ? "before" : "after"),
            "line",
            t,
            r
          ), a, l, !0);
        }, 0, n.length - 1), s = n[u];
        if (u > 0) {
          var c = s.level != 1, g = Gt(
            e,
            $(i, c ? s.from : s.to, c ? "after" : "before"),
            "line",
            t,
            r
          );
          Mn(g, a, l, !0) && g.top > l && (s = n[u - 1]);
        }
        return s;
      }
      function Ou(e, t, i, r, n, a, l) {
        var u = Va(e, t, r, l), s = u.begin, c = u.end;
        /\s/.test(t.text.charAt(c - 1)) && c--;
        for (var g = null, m = null, L = 0; L < n.length; L++) {
          var S = n[L];
          if (!(S.from >= c || S.to <= s)) {
            var U = S.level != 1, Y = Jt(e, r, U ? Math.min(c, S.to) - 1 : Math.max(s, S.from)).right, V = Y < a ? a - Y + 1e9 : Y - a;
            (!g || m > V) && (g = S, m = V);
          }
        }
        return g || (g = n[n.length - 1]), g.from < s && (g = { from: s, to: g.to, level: g.level }), g.to > c && (g = { from: g.from, to: c, level: g.level }), g;
      }
      var Dr;
      function Rr(e) {
        if (e.cachedTextHeight != null)
          return e.cachedTextHeight;
        if (Dr == null) {
          Dr = E("pre", null, "CodeMirror-line-like");
          for (var t = 0; t < 49; ++t)
            Dr.appendChild(document.createTextNode("x")), Dr.appendChild(E("br"));
          Dr.appendChild(document.createTextNode("x"));
        }
        He(e.measure, Dr);
        var i = Dr.offsetHeight / 50;
        return i > 3 && (e.cachedTextHeight = i), Ee(e.measure), i || 1;
      }
      function Pr(e) {
        if (e.cachedCharWidth != null)
          return e.cachedCharWidth;
        var t = E("span", "xxxxxxxxxx"), i = E("pre", [t], "CodeMirror-line-like");
        He(e.measure, i);
        var r = t.getBoundingClientRect(), n = (r.right - r.left) / 10;
        return n > 2 && (e.cachedCharWidth = n), n || 10;
      }
      function Nn(e) {
        for (var t = e.display, i = {}, r = {}, n = t.gutters.clientLeft, a = t.gutters.firstChild, l = 0; a; a = a.nextSibling, ++l) {
          var u = e.display.gutterSpecs[l].className;
          i[u] = a.offsetLeft + a.clientLeft + n, r[u] = a.clientWidth;
        }
        return {
          fixedPos: On(t),
          gutterTotalWidth: t.gutters.offsetWidth,
          gutterLeft: i,
          gutterWidth: r,
          wrapperWidth: t.wrapper.clientWidth
        };
      }
      function On(e) {
        return e.scroller.getBoundingClientRect().left - e.sizer.getBoundingClientRect().left;
      }
      function tl(e) {
        var t = Rr(e.display), i = e.options.lineWrapping, r = i && Math.max(5, e.display.scroller.clientWidth / Pr(e.display) - 3);
        return function(n) {
          if (lr(e.doc, n))
            return 0;
          var a = 0;
          if (n.widgets)
            for (var l = 0; l < n.widgets.length; l++)
              n.widgets[l].height && (a += n.widgets[l].height);
          return i ? a + (Math.ceil(n.text.length / r) || 1) * t : a + t;
        };
      }
      function In(e) {
        var t = e.doc, i = tl(e);
        t.iter(function(r) {
          var n = i(r);
          n != r.height && Yt(r, n);
        });
      }
      function br(e, t, i, r) {
        var n = e.display;
        if (!i && kt(t).getAttribute("cm-not-content") == "true")
          return null;
        var a, l, u = n.lineSpace.getBoundingClientRect();
        try {
          a = t.clientX - u.left, l = t.clientY - u.top;
        } catch {
          return null;
        }
        var s = Bn(e, a, l), c;
        if (r && s.xRel > 0 && (c = be(e.doc, s.line).text).length == s.ch) {
          var g = Ke(c, c.length, e.options.tabSize) - c.length;
          s = $(s.line, Math.max(0, Math.round((a - qa(e.display).left) / Pr(e.display)) - g));
        }
        return s;
      }
      function Cr(e, t) {
        if (t >= e.display.viewTo || (t -= e.display.viewFrom, t < 0))
          return null;
        for (var i = e.display.view, r = 0; r < i.length; r++)
          if (t -= i[r].size, t < 0)
            return r;
      }
      function Et(e, t, i, r) {
        t == null && (t = e.doc.first), i == null && (i = e.doc.first + e.doc.size), r || (r = 0);
        var n = e.display;
        if (r && i < n.viewTo && (n.updateLineNumbers == null || n.updateLineNumbers > t) && (n.updateLineNumbers = t), e.curOp.viewChanged = !0, t >= n.viewTo)
          Vt && Cn(e.doc, t) < n.viewTo && ur(e);
        else if (i <= n.viewFrom)
          Vt && Ma(e.doc, i + r) > n.viewFrom ? ur(e) : (n.viewFrom += r, n.viewTo += r);
        else if (t <= n.viewFrom && i >= n.viewTo)
          ur(e);
        else if (t <= n.viewFrom) {
          var a = Gi(e, i, i + r, 1);
          a ? (n.view = n.view.slice(a.index), n.viewFrom = a.lineN, n.viewTo += r) : ur(e);
        } else if (i >= n.viewTo) {
          var l = Gi(e, t, t, -1);
          l ? (n.view = n.view.slice(0, l.index), n.viewTo = l.lineN) : ur(e);
        } else {
          var u = Gi(e, t, t, -1), s = Gi(e, i, i + r, 1);
          u && s ? (n.view = n.view.slice(0, u.index).concat(Wi(e, u.lineN, s.lineN)).concat(n.view.slice(s.index)), n.viewTo += r) : ur(e);
        }
        var c = n.externalMeasured;
        c && (i < c.lineN ? c.lineN += r : t < c.lineN + c.size && (n.externalMeasured = null));
      }
      function or(e, t, i) {
        e.curOp.viewChanged = !0;
        var r = e.display, n = e.display.externalMeasured;
        if (n && t >= n.lineN && t < n.lineN + n.size && (r.externalMeasured = null), !(t < r.viewFrom || t >= r.viewTo)) {
          var a = r.view[Cr(e, t)];
          if (a.node != null) {
            var l = a.changes || (a.changes = []);
            Pe(l, i) == -1 && l.push(i);
          }
        }
      }
      function ur(e) {
        e.display.viewFrom = e.display.viewTo = e.doc.first, e.display.view = [], e.display.viewOffset = 0;
      }
      function Gi(e, t, i, r) {
        var n = Cr(e, t), a, l = e.display.view;
        if (!Vt || i == e.doc.first + e.doc.size)
          return { index: n, lineN: i };
        for (var u = e.display.viewFrom, s = 0; s < n; s++)
          u += l[s].size;
        if (u != t) {
          if (r > 0) {
            if (n == l.length - 1)
              return null;
            a = u + l[n].size - t, n++;
          } else
            a = u - t;
          t += a, i += a;
        }
        for (; Cn(e.doc, i) != i; ) {
          if (n == (r < 0 ? 0 : l.length - 1))
            return null;
          i += r * l[n - (r < 0 ? 1 : 0)].size, n += r;
        }
        return { index: n, lineN: i };
      }
      function Iu(e, t, i) {
        var r = e.display, n = r.view;
        n.length == 0 || t >= r.viewTo || i <= r.viewFrom ? (r.view = Wi(e, t, i), r.viewFrom = t) : (r.viewFrom > t ? r.view = Wi(e, t, r.viewFrom).concat(r.view) : r.viewFrom < t && (r.view = r.view.slice(Cr(e, t))), r.viewFrom = t, r.viewTo < i ? r.view = r.view.concat(Wi(e, r.viewTo, i)) : r.viewTo > i && (r.view = r.view.slice(0, Cr(e, i)))), r.viewTo = i;
      }
      function rl(e) {
        for (var t = e.display.view, i = 0, r = 0; r < t.length; r++) {
          var n = t[r];
          !n.hidden && (!n.node || n.changes) && ++i;
        }
        return i;
      }
      function si(e) {
        e.display.input.showSelection(e.display.input.prepareSelection());
      }
      function il(e, t) {
        t === void 0 && (t = !0);
        var i = e.doc, r = {}, n = r.cursors = document.createDocumentFragment(), a = r.selection = document.createDocumentFragment(), l = e.options.$customCursor;
        l && (t = !0);
        for (var u = 0; u < i.sel.ranges.length; u++)
          if (!(!t && u == i.sel.primIndex)) {
            var s = i.sel.ranges[u];
            if (!(s.from().line >= e.display.viewTo || s.to().line < e.display.viewFrom)) {
              var c = s.empty();
              if (l) {
                var g = l(e, s);
                g && Hn(e, g, n);
              } else (c || e.options.showCursorWhenSelecting) && Hn(e, s.head, n);
              c || Hu(e, s, a);
            }
          }
        return r;
      }
      function Hn(e, t, i) {
        var r = Gt(e, t, "div", null, null, !e.options.singleCursorHeightPerLine), n = i.appendChild(E("div", " ", "CodeMirror-cursor"));
        if (n.style.left = r.left + "px", n.style.top = r.top + "px", n.style.height = Math.max(0, r.bottom - r.top) * e.options.cursorHeight + "px", /\bcm-fat-cursor\b/.test(e.getWrapperElement().className)) {
          var a = Ui(e, t, "div", null, null), l = a.right - a.left;
          n.style.width = (l > 0 ? l : e.defaultCharWidth()) + "px";
        }
        if (r.other) {
          var u = i.appendChild(E("div", " ", "CodeMirror-cursor CodeMirror-secondarycursor"));
          u.style.display = "", u.style.left = r.other.left + "px", u.style.top = r.other.top + "px", u.style.height = (r.other.bottom - r.other.top) * 0.85 + "px";
        }
      }
      function ji(e, t) {
        return e.top - t.top || e.left - t.left;
      }
      function Hu(e, t, i) {
        var r = e.display, n = e.doc, a = document.createDocumentFragment(), l = qa(e.display), u = l.left, s = Math.max(r.sizerWidth, yr(e) - r.sizer.offsetLeft) - l.right, c = n.direction == "ltr";
        function g(oe, pe, Fe, we) {
          pe < 0 && (pe = 0), pe = Math.round(pe), we = Math.round(we), a.appendChild(E("div", null, "CodeMirror-selected", "position: absolute; left: " + oe + `px;
                             top: ` + pe + "px; width: " + (Fe ?? s - oe) + `px;
                             height: ` + (we - pe) + "px"));
        }
        function m(oe, pe, Fe) {
          var we = be(n, oe), Re = we.text.length, Qe, vt;
          function tt(ft, Bt) {
            return Ui(e, $(oe, ft), "div", we, Bt);
          }
          function It(ft, Bt, yt) {
            var ht = el(e, we, null, ft), ct = Bt == "ltr" == (yt == "after") ? "left" : "right", nt = yt == "after" ? ht.begin : ht.end - (/\s/.test(we.text.charAt(ht.end - 1)) ? 2 : 1);
            return tt(nt, ct)[ct];
          }
          var Tt = y(we, n.direction);
          return x(Tt, pe || 0, Fe ?? Re, function(ft, Bt, yt, ht) {
            var ct = yt == "ltr", nt = tt(ft, ct ? "left" : "right"), Mt = tt(Bt - 1, ct ? "right" : "left"), Jr = pe == null && ft == 0, pr = Fe == null && Bt == Re, wt = ht == 0, $t = !Tt || ht == Tt.length - 1;
            if (Mt.top - nt.top <= 3) {
              var mt = (c ? Jr : pr) && wt, sa = (c ? pr : Jr) && $t, nr = mt ? u : (ct ? nt : Mt).left, Ar = sa ? s : (ct ? Mt : nt).right;
              g(nr, nt.top, Ar - nr, nt.bottom);
            } else {
              var Er, Ft, $r, fa;
              ct ? (Er = c && Jr && wt ? u : nt.left, Ft = c ? s : It(ft, yt, "before"), $r = c ? u : It(Bt, yt, "after"), fa = c && pr && $t ? s : Mt.right) : (Er = c ? It(ft, yt, "before") : u, Ft = !c && Jr && wt ? s : nt.right, $r = !c && pr && $t ? u : Mt.left, fa = c ? It(Bt, yt, "after") : s), g(Er, nt.top, Ft - Er, nt.bottom), nt.bottom < Mt.top && g(u, nt.bottom, null, Mt.top), g($r, Mt.top, fa - $r, Mt.bottom);
            }
            (!Qe || ji(nt, Qe) < 0) && (Qe = nt), ji(Mt, Qe) < 0 && (Qe = Mt), (!vt || ji(nt, vt) < 0) && (vt = nt), ji(Mt, vt) < 0 && (vt = Mt);
          }), { start: Qe, end: vt };
        }
        var L = t.from(), S = t.to();
        if (L.line == S.line)
          m(L.line, L.ch, S.ch);
        else {
          var U = be(n, L.line), Y = be(n, S.line), V = Ut(U) == Ut(Y), le = m(L.line, L.ch, V ? U.text.length + 1 : null).end, he = m(S.line, V ? 0 : null, S.ch).start;
          V && (le.top < he.top - 2 ? (g(le.right, le.top, null, le.bottom), g(u, he.top, he.left, he.bottom)) : g(le.right, le.top, he.left - le.right, le.bottom)), le.bottom < he.top && g(u, le.bottom, null, he.top);
        }
        i.appendChild(a);
      }
      function Rn(e) {
        if (e.state.focused) {
          var t = e.display;
          clearInterval(t.blinker);
          var i = !0;
          t.cursorDiv.style.visibility = "", e.options.cursorBlinkRate > 0 ? t.blinker = setInterval(function() {
            e.hasFocus() || zr(e), t.cursorDiv.style.visibility = (i = !i) ? "" : "hidden";
          }, e.options.cursorBlinkRate) : e.options.cursorBlinkRate < 0 && (t.cursorDiv.style.visibility = "hidden");
        }
      }
      function nl(e) {
        e.hasFocus() || (e.display.input.focus(), e.state.focused || zn(e));
      }
      function Pn(e) {
        e.state.delayingBlurEvent = !0, setTimeout(function() {
          e.state.delayingBlurEvent && (e.state.delayingBlurEvent = !1, e.state.focused && zr(e));
        }, 100);
      }
      function zn(e, t) {
        e.state.delayingBlurEvent && !e.state.draggingText && (e.state.delayingBlurEvent = !1), e.options.readOnly != "nocursor" && (e.state.focused || (ve(e, "focus", e, t), e.state.focused = !0, rt(e.display.wrapper, "CodeMirror-focused"), !e.curOp && e.display.selForContextMenu != e.doc.sel && (e.display.input.reset(), re && setTimeout(function() {
          return e.display.input.reset(!0);
        }, 20)), e.display.input.receivedFocus()), Rn(e));
      }
      function zr(e, t) {
        e.state.delayingBlurEvent || (e.state.focused && (ve(e, "blur", e, t), e.state.focused = !1, Le(e.display.wrapper, "CodeMirror-focused")), clearInterval(e.display.blinker), setTimeout(function() {
          e.state.focused || (e.display.shift = !1);
        }, 150));
      }
      function Ki(e) {
        for (var t = e.display, i = t.lineDiv.offsetTop, r = Math.max(0, t.scroller.getBoundingClientRect().top), n = t.lineDiv.getBoundingClientRect().top, a = 0, l = 0; l < t.view.length; l++) {
          var u = t.view[l], s = e.options.lineWrapping, c = void 0, g = 0;
          if (!u.hidden) {
            if (n += u.line.height, T && P < 8) {
              var m = u.node.offsetTop + u.node.offsetHeight;
              c = m - i, i = m;
            } else {
              var L = u.node.getBoundingClientRect();
              c = L.bottom - L.top, !s && u.text.firstChild && (g = u.text.firstChild.getBoundingClientRect().right - L.left - 1);
            }
            var S = u.line.height - c;
            if ((S > 5e-3 || S < -5e-3) && (n < r && (a -= S), Yt(u.line, c), al(u.line), u.rest))
              for (var U = 0; U < u.rest.length; U++)
                al(u.rest[U]);
            if (g > e.display.sizerWidth) {
              var Y = Math.ceil(g / Pr(e.display));
              Y > e.display.maxLineLength && (e.display.maxLineLength = Y, e.display.maxLine = u.line, e.display.maxLineChanged = !0);
            }
          }
        }
        Math.abs(a) > 2 && (t.scroller.scrollTop += a);
      }
      function al(e) {
        if (e.widgets)
          for (var t = 0; t < e.widgets.length; ++t) {
            var i = e.widgets[t], r = i.node.parentNode;
            r && (i.height = r.offsetHeight);
          }
      }
      function Xi(e, t, i) {
        var r = i && i.top != null ? Math.max(0, i.top) : e.scroller.scrollTop;
        r = Math.floor(r - _i(e));
        var n = i && i.bottom != null ? i.bottom : r + e.wrapper.clientHeight, a = xr(t, r), l = xr(t, n);
        if (i && i.ensure) {
          var u = i.ensure.from.line, s = i.ensure.to.line;
          u < a ? (a = u, l = xr(t, er(be(t, u)) + e.wrapper.clientHeight)) : Math.min(s, t.lastLine()) >= l && (a = xr(t, er(be(t, s)) - e.wrapper.clientHeight), l = s);
        }
        return { from: a, to: Math.max(l, a + 1) };
      }
      function Ru(e, t) {
        if (!te(e, "scrollCursorIntoView")) {
          var i = e.display, r = i.sizer.getBoundingClientRect(), n = null, a = i.wrapper.ownerDocument;
          if (t.top + r.top < 0 ? n = !0 : t.bottom + r.top > (a.defaultView.innerHeight || a.documentElement.clientHeight) && (n = !1), n != null && !ce) {
            var l = E("div", "​", null, `position: absolute;
                         top: ` + (t.top - i.viewOffset - _i(e.display)) + `px;
                         height: ` + (t.bottom - t.top + Qt(e) + i.barHeight) + `px;
                         left: ` + t.left + "px; width: " + Math.max(2, t.right - t.left) + "px;");
            e.display.lineSpace.appendChild(l), l.scrollIntoView(n), e.display.lineSpace.removeChild(l);
          }
        }
      }
      function Pu(e, t, i, r) {
        r == null && (r = 0);
        var n;
        !e.options.lineWrapping && t == i && (i = t.sticky == "before" ? $(t.line, t.ch + 1, "before") : t, t = t.ch ? $(t.line, t.sticky == "before" ? t.ch - 1 : t.ch, "after") : t);
        for (var a = 0; a < 5; a++) {
          var l = !1, u = Gt(e, t), s = !i || i == t ? u : Gt(e, i);
          n = {
            left: Math.min(u.left, s.left),
            top: Math.min(u.top, s.top) - r,
            right: Math.max(u.left, s.left),
            bottom: Math.max(u.bottom, s.bottom) + r
          };
          var c = Wn(e, n), g = e.doc.scrollTop, m = e.doc.scrollLeft;
          if (c.scrollTop != null && (ci(e, c.scrollTop), Math.abs(e.doc.scrollTop - g) > 1 && (l = !0)), c.scrollLeft != null && (wr(e, c.scrollLeft), Math.abs(e.doc.scrollLeft - m) > 1 && (l = !0)), !l)
            break;
        }
        return n;
      }
      function zu(e, t) {
        var i = Wn(e, t);
        i.scrollTop != null && ci(e, i.scrollTop), i.scrollLeft != null && wr(e, i.scrollLeft);
      }
      function Wn(e, t) {
        var i = e.display, r = Rr(e.display);
        t.top < 0 && (t.top = 0);
        var n = e.curOp && e.curOp.scrollTop != null ? e.curOp.scrollTop : i.scroller.scrollTop, a = An(e), l = {};
        t.bottom - t.top > a && (t.bottom = t.top + a);
        var u = e.doc.height + Fn(i), s = t.top < r, c = t.bottom > u - r;
        if (t.top < n)
          l.scrollTop = s ? 0 : t.top;
        else if (t.bottom > n + a) {
          var g = Math.min(t.top, (c ? u : t.bottom) - a);
          g != n && (l.scrollTop = g);
        }
        var m = e.options.fixedGutter ? 0 : i.gutters.offsetWidth, L = e.curOp && e.curOp.scrollLeft != null ? e.curOp.scrollLeft : i.scroller.scrollLeft - m, S = yr(e) - i.gutters.offsetWidth, U = t.right - t.left > S;
        return U && (t.right = t.left + S), t.left < 10 ? l.scrollLeft = 0 : t.left < L ? l.scrollLeft = Math.max(0, t.left + m - (U ? 0 : 10)) : t.right > S + L - 3 && (l.scrollLeft = t.right + (U ? 0 : 10) - S), l;
      }
      function _n(e, t) {
        t != null && (Yi(e), e.curOp.scrollTop = (e.curOp.scrollTop == null ? e.doc.scrollTop : e.curOp.scrollTop) + t);
      }
      function Wr(e) {
        Yi(e);
        var t = e.getCursor();
        e.curOp.scrollToPos = { from: t, to: t, margin: e.options.cursorScrollMargin };
      }
      function fi(e, t, i) {
        (t != null || i != null) && Yi(e), t != null && (e.curOp.scrollLeft = t), i != null && (e.curOp.scrollTop = i);
      }
      function Wu(e, t) {
        Yi(e), e.curOp.scrollToPos = t;
      }
      function Yi(e) {
        var t = e.curOp.scrollToPos;
        if (t) {
          e.curOp.scrollToPos = null;
          var i = $a(e, t.from), r = $a(e, t.to);
          ll(e, i, r, t.margin);
        }
      }
      function ll(e, t, i, r) {
        var n = Wn(e, {
          left: Math.min(t.left, i.left),
          top: Math.min(t.top, i.top) - r,
          right: Math.max(t.right, i.right),
          bottom: Math.max(t.bottom, i.bottom) + r
        });
        fi(e, n.scrollLeft, n.scrollTop);
      }
      function ci(e, t) {
        Math.abs(e.doc.scrollTop - t) < 2 || (N || Un(e, { top: t }), ol(e, t, !0), N && Un(e), pi(e, 100));
      }
      function ol(e, t, i) {
        t = Math.max(0, Math.min(e.display.scroller.scrollHeight - e.display.scroller.clientHeight, t)), !(e.display.scroller.scrollTop == t && !i) && (e.doc.scrollTop = t, e.display.scrollbars.setScrollTop(t), e.display.scroller.scrollTop != t && (e.display.scroller.scrollTop = t));
      }
      function wr(e, t, i, r) {
        t = Math.max(0, Math.min(t, e.display.scroller.scrollWidth - e.display.scroller.clientWidth)), !((i ? t == e.doc.scrollLeft : Math.abs(e.doc.scrollLeft - t) < 2) && !r) && (e.doc.scrollLeft = t, hl(e), e.display.scroller.scrollLeft != t && (e.display.scroller.scrollLeft = t), e.display.scrollbars.setScrollLeft(t));
      }
      function hi(e) {
        var t = e.display, i = t.gutters.offsetWidth, r = Math.round(e.doc.height + Fn(e.display));
        return {
          clientHeight: t.scroller.clientHeight,
          viewHeight: t.wrapper.clientHeight,
          scrollWidth: t.scroller.scrollWidth,
          clientWidth: t.scroller.clientWidth,
          viewWidth: t.wrapper.clientWidth,
          barLeft: e.options.fixedGutter ? i : 0,
          docHeight: r,
          scrollHeight: r + Qt(e) + t.barHeight,
          nativeBarWidth: t.nativeBarWidth,
          gutterWidth: i
        };
      }
      var kr = function(e, t, i) {
        this.cm = i;
        var r = this.vert = E("div", [E("div", null, null, "min-width: 1px")], "CodeMirror-vscrollbar"), n = this.horiz = E("div", [E("div", null, null, "height: 100%; min-height: 1px")], "CodeMirror-hscrollbar");
        r.tabIndex = n.tabIndex = -1, e(r), e(n), A(r, "scroll", function() {
          r.clientHeight && t(r.scrollTop, "vertical");
        }), A(n, "scroll", function() {
          n.clientWidth && t(n.scrollLeft, "horizontal");
        }), this.checkedZeroWidth = !1, T && P < 8 && (this.horiz.style.minHeight = this.vert.style.minWidth = "18px");
      };
      kr.prototype.update = function(e) {
        var t = e.scrollWidth > e.clientWidth + 1, i = e.scrollHeight > e.clientHeight + 1, r = e.nativeBarWidth;
        if (i) {
          this.vert.style.display = "block", this.vert.style.bottom = t ? r + "px" : "0";
          var n = e.viewHeight - (t ? r : 0);
          this.vert.firstChild.style.height = Math.max(0, e.scrollHeight - e.clientHeight + n) + "px";
        } else
          this.vert.scrollTop = 0, this.vert.style.display = "", this.vert.firstChild.style.height = "0";
        if (t) {
          this.horiz.style.display = "block", this.horiz.style.right = i ? r + "px" : "0", this.horiz.style.left = e.barLeft + "px";
          var a = e.viewWidth - e.barLeft - (i ? r : 0);
          this.horiz.firstChild.style.width = Math.max(0, e.scrollWidth - e.clientWidth + a) + "px";
        } else
          this.horiz.style.display = "", this.horiz.firstChild.style.width = "0";
        return !this.checkedZeroWidth && e.clientHeight > 0 && (r == 0 && this.zeroWidthHack(), this.checkedZeroWidth = !0), { right: i ? r : 0, bottom: t ? r : 0 };
      }, kr.prototype.setScrollLeft = function(e) {
        this.horiz.scrollLeft != e && (this.horiz.scrollLeft = e), this.disableHoriz && this.enableZeroWidthBar(this.horiz, this.disableHoriz, "horiz");
      }, kr.prototype.setScrollTop = function(e) {
        this.vert.scrollTop != e && (this.vert.scrollTop = e), this.disableVert && this.enableZeroWidthBar(this.vert, this.disableVert, "vert");
      }, kr.prototype.zeroWidthHack = function() {
        var e = j && !de ? "12px" : "18px";
        this.horiz.style.height = this.vert.style.width = e, this.horiz.style.visibility = this.vert.style.visibility = "hidden", this.disableHoriz = new Ye(), this.disableVert = new Ye();
      }, kr.prototype.enableZeroWidthBar = function(e, t, i) {
        e.style.visibility = "";
        function r() {
          var n = e.getBoundingClientRect(), a = i == "vert" ? document.elementFromPoint(n.right - 1, (n.top + n.bottom) / 2) : document.elementFromPoint((n.right + n.left) / 2, n.bottom - 1);
          a != e ? e.style.visibility = "hidden" : t.set(1e3, r);
        }
        t.set(1e3, r);
      }, kr.prototype.clear = function() {
        var e = this.horiz.parentNode;
        e.removeChild(this.horiz), e.removeChild(this.vert);
      };
      var di = function() {
      };
      di.prototype.update = function() {
        return { bottom: 0, right: 0 };
      }, di.prototype.setScrollLeft = function() {
      }, di.prototype.setScrollTop = function() {
      }, di.prototype.clear = function() {
      };
      function _r(e, t) {
        t || (t = hi(e));
        var i = e.display.barWidth, r = e.display.barHeight;
        ul(e, t);
        for (var n = 0; n < 4 && i != e.display.barWidth || r != e.display.barHeight; n++)
          i != e.display.barWidth && e.options.lineWrapping && Ki(e), ul(e, hi(e)), i = e.display.barWidth, r = e.display.barHeight;
      }
      function ul(e, t) {
        var i = e.display, r = i.scrollbars.update(t);
        i.sizer.style.paddingRight = (i.barWidth = r.right) + "px", i.sizer.style.paddingBottom = (i.barHeight = r.bottom) + "px", i.heightForcer.style.borderBottom = r.bottom + "px solid transparent", r.right && r.bottom ? (i.scrollbarFiller.style.display = "block", i.scrollbarFiller.style.height = r.bottom + "px", i.scrollbarFiller.style.width = r.right + "px") : i.scrollbarFiller.style.display = "", r.bottom && e.options.coverGutterNextToScrollbar && e.options.fixedGutter ? (i.gutterFiller.style.display = "block", i.gutterFiller.style.height = r.bottom + "px", i.gutterFiller.style.width = t.gutterWidth + "px") : i.gutterFiller.style.display = "";
      }
      var sl = { native: kr, null: di };
      function fl(e) {
        e.display.scrollbars && (e.display.scrollbars.clear(), e.display.scrollbars.addClass && Le(e.display.wrapper, e.display.scrollbars.addClass)), e.display.scrollbars = new sl[e.options.scrollbarStyle](function(t) {
          e.display.wrapper.insertBefore(t, e.display.scrollbarFiller), A(t, "mousedown", function() {
            e.state.focused && setTimeout(function() {
              return e.display.input.focus();
            }, 0);
          }), t.setAttribute("cm-not-content", "true");
        }, function(t, i) {
          i == "horizontal" ? wr(e, t) : ci(e, t);
        }, e), e.display.scrollbars.addClass && rt(e.display.wrapper, e.display.scrollbars.addClass);
      }
      var _u = 0;
      function Sr(e) {
        e.curOp = {
          cm: e,
          viewChanged: !1,
          // Flag that indicates that lines might need to be redrawn
          startHeight: e.doc.height,
          // Used to detect need to update scrollbar
          forceUpdate: !1,
          // Used to force a redraw
          updateInput: 0,
          // Whether to reset the input textarea
          typing: !1,
          // Whether this reset should be careful to leave existing text (for compositing)
          changeObjs: null,
          // Accumulated changes, for firing change events
          cursorActivityHandlers: null,
          // Set of handlers to fire cursorActivity on
          cursorActivityCalled: 0,
          // Tracks which cursorActivity handlers have been called already
          selectionChanged: !1,
          // Whether the selection needs to be redrawn
          updateMaxLine: !1,
          // Set when the widest line needs to be determined anew
          scrollLeft: null,
          scrollTop: null,
          // Intermediate scroll position, not pushed to DOM yet
          scrollToPos: null,
          // Used to scroll to a specific position
          focus: !1,
          id: ++_u,
          // Unique ID
          markArrays: null
          // Used by addMarkedSpan
        }, xu(e.curOp);
      }
      function Fr(e) {
        var t = e.curOp;
        t && Du(t, function(i) {
          for (var r = 0; r < i.ops.length; r++)
            i.ops[r].cm.curOp = null;
          qu(i);
        });
      }
      function qu(e) {
        for (var t = e.ops, i = 0; i < t.length; i++)
          Uu(t[i]);
        for (var r = 0; r < t.length; r++)
          Gu(t[r]);
        for (var n = 0; n < t.length; n++)
          ju(t[n]);
        for (var a = 0; a < t.length; a++)
          Ku(t[a]);
        for (var l = 0; l < t.length; l++)
          Xu(t[l]);
      }
      function Uu(e) {
        var t = e.cm, i = t.display;
        Zu(t), e.updateMaxLine && kn(t), e.mustUpdate = e.viewChanged || e.forceUpdate || e.scrollTop != null || e.scrollToPos && (e.scrollToPos.from.line < i.viewFrom || e.scrollToPos.to.line >= i.viewTo) || i.maxLineChanged && t.options.lineWrapping, e.update = e.mustUpdate && new Zi(t, e.mustUpdate && { top: e.scrollTop, ensure: e.scrollToPos }, e.forceUpdate);
      }
      function Gu(e) {
        e.updatedDisplay = e.mustUpdate && qn(e.cm, e.update);
      }
      function ju(e) {
        var t = e.cm, i = t.display;
        e.updatedDisplay && Ki(t), e.barMeasure = hi(t), i.maxLineChanged && !t.options.lineWrapping && (e.adjustWidthTo = Ga(t, i.maxLine, i.maxLine.text.length).left + 3, t.display.sizerWidth = e.adjustWidthTo, e.barMeasure.scrollWidth = Math.max(i.scroller.clientWidth, i.sizer.offsetLeft + e.adjustWidthTo + Qt(t) + t.display.barWidth), e.maxScrollLeft = Math.max(0, i.sizer.offsetLeft + e.adjustWidthTo - yr(t))), (e.updatedDisplay || e.selectionChanged) && (e.preparedSelection = i.input.prepareSelection());
      }
      function Ku(e) {
        var t = e.cm;
        e.adjustWidthTo != null && (t.display.sizer.style.minWidth = e.adjustWidthTo + "px", e.maxScrollLeft < t.doc.scrollLeft && wr(t, Math.min(t.display.scroller.scrollLeft, e.maxScrollLeft), !0), t.display.maxLineChanged = !1);
        var i = e.focus && e.focus == We(G(t));
        e.preparedSelection && t.display.input.showSelection(e.preparedSelection, i), (e.updatedDisplay || e.startHeight != t.doc.height) && _r(t, e.barMeasure), e.updatedDisplay && jn(t, e.barMeasure), e.selectionChanged && Rn(t), t.state.focused && e.updateInput && t.display.input.reset(e.typing), i && nl(e.cm);
      }
      function Xu(e) {
        var t = e.cm, i = t.display, r = t.doc;
        if (e.updatedDisplay && cl(t, e.update), i.wheelStartX != null && (e.scrollTop != null || e.scrollLeft != null || e.scrollToPos) && (i.wheelStartX = i.wheelStartY = null), e.scrollTop != null && ol(t, e.scrollTop, e.forceScroll), e.scrollLeft != null && wr(t, e.scrollLeft, !0, !0), e.scrollToPos) {
          var n = Pu(
            t,
            Oe(r, e.scrollToPos.from),
            Oe(r, e.scrollToPos.to),
            e.scrollToPos.margin
          );
          Ru(t, n);
        }
        var a = e.maybeHiddenMarkers, l = e.maybeUnhiddenMarkers;
        if (a)
          for (var u = 0; u < a.length; ++u)
            a[u].lines.length || ve(a[u], "hide");
        if (l)
          for (var s = 0; s < l.length; ++s)
            l[s].lines.length && ve(l[s], "unhide");
        i.wrapper.offsetHeight && (r.scrollTop = t.display.scroller.scrollTop), e.changeObjs && ve(t, "changes", t, e.changeObjs), e.update && e.update.finish();
      }
      function Ot(e, t) {
        if (e.curOp)
          return t();
        Sr(e);
        try {
          return t();
        } finally {
          Fr(e);
        }
      }
      function pt(e, t) {
        return function() {
          if (e.curOp)
            return t.apply(e, arguments);
          Sr(e);
          try {
            return t.apply(e, arguments);
          } finally {
            Fr(e);
          }
        };
      }
      function St(e) {
        return function() {
          if (this.curOp)
            return e.apply(this, arguments);
          Sr(this);
          try {
            return e.apply(this, arguments);
          } finally {
            Fr(this);
          }
        };
      }
      function gt(e) {
        return function() {
          var t = this.cm;
          if (!t || t.curOp)
            return e.apply(this, arguments);
          Sr(t);
          try {
            return e.apply(this, arguments);
          } finally {
            Fr(t);
          }
        };
      }
      function pi(e, t) {
        e.doc.highlightFrontier < e.display.viewTo && e.state.highlight.set(t, Je(Yu, e));
      }
      function Yu(e) {
        var t = e.doc;
        if (!(t.highlightFrontier >= e.display.viewTo)) {
          var i = +/* @__PURE__ */ new Date() + e.options.workTime, r = ii(e, t.highlightFrontier), n = [];
          t.iter(r.line, Math.min(t.first + t.size, e.display.viewTo + 500), function(a) {
            if (r.line >= e.display.viewFrom) {
              var l = a.styles, u = a.text.length > e.options.maxHighlightLength ? vr(t.mode, r.state) : null, s = xa(e, a, r, !0);
              u && (r.state = u), a.styles = s.styles;
              var c = a.styleClasses, g = s.classes;
              g ? a.styleClasses = g : c && (a.styleClasses = null);
              for (var m = !l || l.length != a.styles.length || c != g && (!c || !g || c.bgClass != g.bgClass || c.textClass != g.textClass), L = 0; !m && L < l.length; ++L)
                m = l[L] != a.styles[L];
              m && n.push(r.line), a.stateAfter = r.save(), r.nextLine();
            } else
              a.text.length <= e.options.maxHighlightLength && xn(e, a.text, r), a.stateAfter = r.line % 5 == 0 ? r.save() : null, r.nextLine();
            if (+/* @__PURE__ */ new Date() > i)
              return pi(e, e.options.workDelay), !0;
          }), t.highlightFrontier = r.line, t.modeFrontier = Math.max(t.modeFrontier, r.line), n.length && Ot(e, function() {
            for (var a = 0; a < n.length; a++)
              or(e, n[a], "text");
          });
        }
      }
      var Zi = function(e, t, i) {
        var r = e.display;
        this.viewport = t, this.visible = Xi(r, e.doc, t), this.editorIsHidden = !r.wrapper.offsetWidth, this.wrapperHeight = r.wrapper.clientHeight, this.wrapperWidth = r.wrapper.clientWidth, this.oldDisplayWidth = yr(e), this.force = i, this.dims = Nn(e), this.events = [];
      };
      Zi.prototype.signal = function(e, t) {
        Me(e, t) && this.events.push(arguments);
      }, Zi.prototype.finish = function() {
        for (var e = 0; e < this.events.length; e++)
          ve.apply(null, this.events[e]);
      };
      function Zu(e) {
        var t = e.display;
        !t.scrollbarsClipped && t.scroller.offsetWidth && (t.nativeBarWidth = t.scroller.offsetWidth - t.scroller.clientWidth, t.heightForcer.style.height = Qt(e) + "px", t.sizer.style.marginBottom = -t.nativeBarWidth + "px", t.sizer.style.borderRightWidth = Qt(e) + "px", t.scrollbarsClipped = !0);
      }
      function Qu(e) {
        if (e.hasFocus())
          return null;
        var t = We(G(e));
        if (!t || !De(e.display.lineDiv, t))
          return null;
        var i = { activeElt: t };
        if (window.getSelection) {
          var r = Te(e).getSelection();
          r.anchorNode && r.extend && De(e.display.lineDiv, r.anchorNode) && (i.anchorNode = r.anchorNode, i.anchorOffset = r.anchorOffset, i.focusNode = r.focusNode, i.focusOffset = r.focusOffset);
        }
        return i;
      }
      function Ju(e) {
        if (!(!e || !e.activeElt || e.activeElt == We(ze(e.activeElt))) && (e.activeElt.focus(), !/^(INPUT|TEXTAREA)$/.test(e.activeElt.nodeName) && e.anchorNode && De(document.body, e.anchorNode) && De(document.body, e.focusNode))) {
          var t = e.activeElt.ownerDocument, i = t.defaultView.getSelection(), r = t.createRange();
          r.setEnd(e.anchorNode, e.anchorOffset), r.collapse(!1), i.removeAllRanges(), i.addRange(r), i.extend(e.focusNode, e.focusOffset);
        }
      }
      function qn(e, t) {
        var i = e.display, r = e.doc;
        if (t.editorIsHidden)
          return ur(e), !1;
        if (!t.force && t.visible.from >= i.viewFrom && t.visible.to <= i.viewTo && (i.updateLineNumbers == null || i.updateLineNumbers >= i.viewTo) && i.renderedView == i.view && rl(e) == 0)
          return !1;
        dl(e) && (ur(e), t.dims = Nn(e));
        var n = r.first + r.size, a = Math.max(t.visible.from - e.options.viewportMargin, r.first), l = Math.min(n, t.visible.to + e.options.viewportMargin);
        i.viewFrom < a && a - i.viewFrom < 20 && (a = Math.max(r.first, i.viewFrom)), i.viewTo > l && i.viewTo - l < 20 && (l = Math.min(n, i.viewTo)), Vt && (a = Cn(e.doc, a), l = Ma(e.doc, l));
        var u = a != i.viewFrom || l != i.viewTo || i.lastWrapHeight != t.wrapperHeight || i.lastWrapWidth != t.wrapperWidth;
        Iu(e, a, l), i.viewOffset = er(be(e.doc, i.viewFrom)), e.display.mover.style.top = i.viewOffset + "px";
        var s = rl(e);
        if (!u && s == 0 && !t.force && i.renderedView == i.view && (i.updateLineNumbers == null || i.updateLineNumbers >= i.viewTo))
          return !1;
        var c = Qu(e);
        return s > 4 && (i.lineDiv.style.display = "none"), $u(e, i.updateLineNumbers, t.dims), s > 4 && (i.lineDiv.style.display = ""), i.renderedView = i.view, Ju(c), Ee(i.cursorDiv), Ee(i.selectionDiv), i.gutters.style.height = i.sizer.style.minHeight = 0, u && (i.lastWrapHeight = t.wrapperHeight, i.lastWrapWidth = t.wrapperWidth, pi(e, 400)), i.updateLineNumbers = null, !0;
      }
      function cl(e, t) {
        for (var i = t.viewport, r = !0; ; r = !1) {
          if (!r || !e.options.lineWrapping || t.oldDisplayWidth == yr(e)) {
            if (i && i.top != null && (i = { top: Math.min(e.doc.height + Fn(e.display) - An(e), i.top) }), t.visible = Xi(e.display, e.doc, i), t.visible.from >= e.display.viewFrom && t.visible.to <= e.display.viewTo)
              break;
          } else r && (t.visible = Xi(e.display, e.doc, i));
          if (!qn(e, t))
            break;
          Ki(e);
          var n = hi(e);
          si(e), _r(e, n), jn(e, n), t.force = !1;
        }
        t.signal(e, "update", e), (e.display.viewFrom != e.display.reportedViewFrom || e.display.viewTo != e.display.reportedViewTo) && (t.signal(e, "viewportChange", e, e.display.viewFrom, e.display.viewTo), e.display.reportedViewFrom = e.display.viewFrom, e.display.reportedViewTo = e.display.viewTo);
      }
      function Un(e, t) {
        var i = new Zi(e, t);
        if (qn(e, i)) {
          Ki(e), cl(e, i);
          var r = hi(e);
          si(e), _r(e, r), jn(e, r), i.finish();
        }
      }
      function $u(e, t, i) {
        var r = e.display, n = e.options.lineNumbers, a = r.lineDiv, l = a.firstChild;
        function u(U) {
          var Y = U.nextSibling;
          return re && j && e.display.currentWheelTarget == U ? U.style.display = "none" : U.parentNode.removeChild(U), Y;
        }
        for (var s = r.view, c = r.viewFrom, g = 0; g < s.length; g++) {
          var m = s[g];
          if (!m.hidden) if (!m.node || m.node.parentNode != a) {
            var L = Su(e, m, c, i);
            a.insertBefore(L, l);
          } else {
            for (; l != m.node; )
              l = u(l);
            var S = n && t != null && t <= c && m.lineNumber;
            m.changes && (Pe(m.changes, "gutter") > -1 && (S = !1), Ra(e, m, c, i)), S && (Ee(m.lineNumber), m.lineNumber.appendChild(document.createTextNode(gn(e.options, c)))), l = m.node.nextSibling;
          }
          c += m.size;
        }
        for (; l; )
          l = u(l);
      }
      function Gn(e) {
        var t = e.gutters.offsetWidth;
        e.sizer.style.marginLeft = t + "px", dt(e, "gutterChanged", e);
      }
      function jn(e, t) {
        e.display.sizer.style.minHeight = t.docHeight + "px", e.display.heightForcer.style.top = t.docHeight + "px", e.display.gutters.style.height = t.docHeight + e.display.barHeight + Qt(e) + "px";
      }
      function hl(e) {
        var t = e.display, i = t.view;
        if (!(!t.alignWidgets && (!t.gutters.firstChild || !e.options.fixedGutter))) {
          for (var r = On(t) - t.scroller.scrollLeft + e.doc.scrollLeft, n = t.gutters.offsetWidth, a = r + "px", l = 0; l < i.length; l++)
            if (!i[l].hidden) {
              e.options.fixedGutter && (i[l].gutter && (i[l].gutter.style.left = a), i[l].gutterBackground && (i[l].gutterBackground.style.left = a));
              var u = i[l].alignable;
              if (u)
                for (var s = 0; s < u.length; s++)
                  u[s].style.left = a;
            }
          e.options.fixedGutter && (t.gutters.style.left = r + n + "px");
        }
      }
      function dl(e) {
        if (!e.options.lineNumbers)
          return !1;
        var t = e.doc, i = gn(e.options, t.first + t.size - 1), r = e.display;
        if (i.length != r.lineNumChars) {
          var n = r.measure.appendChild(E(
            "div",
            [E("div", i)],
            "CodeMirror-linenumber CodeMirror-gutter-elt"
          )), a = n.firstChild.offsetWidth, l = n.offsetWidth - a;
          return r.lineGutter.style.width = "", r.lineNumInnerWidth = Math.max(a, r.lineGutter.offsetWidth - l) + 1, r.lineNumWidth = r.lineNumInnerWidth + l, r.lineNumChars = r.lineNumInnerWidth ? i.length : -1, r.lineGutter.style.width = r.lineNumWidth + "px", Gn(e.display), !0;
        }
        return !1;
      }
      function Kn(e, t) {
        for (var i = [], r = !1, n = 0; n < e.length; n++) {
          var a = e[n], l = null;
          if (typeof a != "string" && (l = a.style, a = a.className), a == "CodeMirror-linenumbers")
            if (t)
              r = !0;
            else
              continue;
          i.push({ className: a, style: l });
        }
        return t && !r && i.push({ className: "CodeMirror-linenumbers", style: null }), i;
      }
      function pl(e) {
        var t = e.gutters, i = e.gutterSpecs;
        Ee(t), e.lineGutter = null;
        for (var r = 0; r < i.length; ++r) {
          var n = i[r], a = n.className, l = n.style, u = t.appendChild(E("div", null, "CodeMirror-gutter " + a));
          l && (u.style.cssText = l), a == "CodeMirror-linenumbers" && (e.lineGutter = u, u.style.width = (e.lineNumWidth || 1) + "px");
        }
        t.style.display = i.length ? "" : "none", Gn(e);
      }
      function gi(e) {
        pl(e.display), Et(e), hl(e);
      }
      function Vu(e, t, i, r) {
        var n = this;
        this.input = i, n.scrollbarFiller = E("div", null, "CodeMirror-scrollbar-filler"), n.scrollbarFiller.setAttribute("cm-not-content", "true"), n.gutterFiller = E("div", null, "CodeMirror-gutter-filler"), n.gutterFiller.setAttribute("cm-not-content", "true"), n.lineDiv = ee("div", null, "CodeMirror-code"), n.selectionDiv = E("div", null, null, "position: relative; z-index: 1"), n.cursorDiv = E("div", null, "CodeMirror-cursors"), n.measure = E("div", null, "CodeMirror-measure"), n.lineMeasure = E("div", null, "CodeMirror-measure"), n.lineSpace = ee(
          "div",
          [n.measure, n.lineMeasure, n.selectionDiv, n.cursorDiv, n.lineDiv],
          null,
          "position: relative; outline: none"
        );
        var a = ee("div", [n.lineSpace], "CodeMirror-lines");
        n.mover = E("div", [a], null, "position: relative"), n.sizer = E("div", [n.mover], "CodeMirror-sizer"), n.sizerWidth = null, n.heightForcer = E("div", null, null, "position: absolute; height: " + _e + "px; width: 1px;"), n.gutters = E("div", null, "CodeMirror-gutters"), n.lineGutter = null, n.scroller = E("div", [n.sizer, n.heightForcer, n.gutters], "CodeMirror-scroll"), n.scroller.setAttribute("tabIndex", "-1"), n.wrapper = E("div", [n.scrollbarFiller, n.gutterFiller, n.scroller], "CodeMirror"), K && fe === 105 && (n.wrapper.style.clipPath = "inset(0px)"), n.wrapper.setAttribute("translate", "no"), T && P < 8 && (n.gutters.style.zIndex = -1, n.scroller.style.paddingRight = 0), !re && !(N && q) && (n.scroller.draggable = !0), e && (e.appendChild ? e.appendChild(n.wrapper) : e(n.wrapper)), n.viewFrom = n.viewTo = t.first, n.reportedViewFrom = n.reportedViewTo = t.first, n.view = [], n.renderedView = null, n.externalMeasured = null, n.viewOffset = 0, n.lastWrapHeight = n.lastWrapWidth = 0, n.updateLineNumbers = null, n.nativeBarWidth = n.barHeight = n.barWidth = 0, n.scrollbarsClipped = !1, n.lineNumWidth = n.lineNumInnerWidth = n.lineNumChars = null, n.alignWidgets = !1, n.cachedCharWidth = n.cachedTextHeight = n.cachedPaddingH = null, n.maxLine = null, n.maxLineLength = 0, n.maxLineChanged = !1, n.wheelDX = n.wheelDY = n.wheelStartX = n.wheelStartY = null, n.shift = !1, n.selForContextMenu = null, n.activeTouch = null, n.gutterSpecs = Kn(r.gutters, r.lineNumbers), pl(n), i.init(n);
      }
      var Qi = 0, rr = null;
      T ? rr = -0.53 : N ? rr = 15 : K ? rr = -0.7 : Se && (rr = -1 / 3);
      function gl(e) {
        var t = e.wheelDeltaX, i = e.wheelDeltaY;
        return t == null && e.detail && e.axis == e.HORIZONTAL_AXIS && (t = e.detail), i == null && e.detail && e.axis == e.VERTICAL_AXIS ? i = e.detail : i == null && (i = e.wheelDelta), { x: t, y: i };
      }
      function es(e) {
        var t = gl(e);
        return t.x *= rr, t.y *= rr, t;
      }
      function vl(e, t) {
        K && fe == 102 && (e.display.chromeScrollHack == null ? e.display.sizer.style.pointerEvents = "none" : clearTimeout(e.display.chromeScrollHack), e.display.chromeScrollHack = setTimeout(function() {
          e.display.chromeScrollHack = null, e.display.sizer.style.pointerEvents = "";
        }, 100));
        var i = gl(t), r = i.x, n = i.y, a = rr;
        t.deltaMode === 0 && (r = t.deltaX, n = t.deltaY, a = 1);
        var l = e.display, u = l.scroller, s = u.scrollWidth > u.clientWidth, c = u.scrollHeight > u.clientHeight;
        if (r && s || n && c) {
          if (n && j && re) {
            e: for (var g = t.target, m = l.view; g != u; g = g.parentNode)
              for (var L = 0; L < m.length; L++)
                if (m[L].node == g) {
                  e.display.currentWheelTarget = g;
                  break e;
                }
          }
          if (r && !N && !ie && a != null) {
            n && c && ci(e, Math.max(0, u.scrollTop + n * a)), wr(e, Math.max(0, u.scrollLeft + r * a)), (!n || n && c) && Ae(t), l.wheelStartX = null;
            return;
          }
          if (n && a != null) {
            var S = n * a, U = e.doc.scrollTop, Y = U + l.wrapper.clientHeight;
            S < 0 ? U = Math.max(0, U + S - 50) : Y = Math.min(e.doc.height, Y + S + 50), Un(e, { top: U, bottom: Y });
          }
          Qi < 20 && t.deltaMode !== 0 && (l.wheelStartX == null ? (l.wheelStartX = u.scrollLeft, l.wheelStartY = u.scrollTop, l.wheelDX = r, l.wheelDY = n, setTimeout(function() {
            if (l.wheelStartX != null) {
              var V = u.scrollLeft - l.wheelStartX, le = u.scrollTop - l.wheelStartY, he = le && l.wheelDY && le / l.wheelDY || V && l.wheelDX && V / l.wheelDX;
              l.wheelStartX = l.wheelStartY = null, he && (rr = (rr * Qi + he) / (Qi + 1), ++Qi);
            }
          }, 200)) : (l.wheelDX += r, l.wheelDY += n));
        }
      }
      var Pt = function(e, t) {
        this.ranges = e, this.primIndex = t;
      };
      Pt.prototype.primary = function() {
        return this.ranges[this.primIndex];
      }, Pt.prototype.equals = function(e) {
        if (e == this)
          return !0;
        if (e.primIndex != this.primIndex || e.ranges.length != this.ranges.length)
          return !1;
        for (var t = 0; t < this.ranges.length; t++) {
          var i = this.ranges[t], r = e.ranges[t];
          if (!vn(i.anchor, r.anchor) || !vn(i.head, r.head))
            return !1;
        }
        return !0;
      }, Pt.prototype.deepCopy = function() {
        for (var e = [], t = 0; t < this.ranges.length; t++)
          e[t] = new qe(mn(this.ranges[t].anchor), mn(this.ranges[t].head));
        return new Pt(e, this.primIndex);
      }, Pt.prototype.somethingSelected = function() {
        for (var e = 0; e < this.ranges.length; e++)
          if (!this.ranges[e].empty())
            return !0;
        return !1;
      }, Pt.prototype.contains = function(e, t) {
        t || (t = e);
        for (var i = 0; i < this.ranges.length; i++) {
          var r = this.ranges[i];
          if (Ne(t, r.from()) >= 0 && Ne(e, r.to()) <= 0)
            return i;
        }
        return -1;
      };
      var qe = function(e, t) {
        this.anchor = e, this.head = t;
      };
      qe.prototype.from = function() {
        return Ni(this.anchor, this.head);
      }, qe.prototype.to = function() {
        return Mi(this.anchor, this.head);
      }, qe.prototype.empty = function() {
        return this.head.line == this.anchor.line && this.head.ch == this.anchor.ch;
      };
      function jt(e, t, i) {
        var r = e && e.options.selectionsMayTouch, n = t[i];
        t.sort(function(L, S) {
          return Ne(L.from(), S.from());
        }), i = Pe(t, n);
        for (var a = 1; a < t.length; a++) {
          var l = t[a], u = t[a - 1], s = Ne(u.to(), l.from());
          if (r && !l.empty() ? s > 0 : s >= 0) {
            var c = Ni(u.from(), l.from()), g = Mi(u.to(), l.to()), m = u.empty() ? l.from() == l.head : u.from() == u.head;
            a <= i && --i, t.splice(--a, 2, new qe(m ? g : c, m ? c : g));
          }
        }
        return new Pt(t, i);
      }
      function sr(e, t) {
        return new Pt([new qe(e, t || e)], 0);
      }
      function fr(e) {
        return e.text ? $(
          e.from.line + e.text.length - 1,
          xe(e.text).length + (e.text.length == 1 ? e.from.ch : 0)
        ) : e.to;
      }
      function ml(e, t) {
        if (Ne(e, t.from) < 0)
          return e;
        if (Ne(e, t.to) <= 0)
          return fr(t);
        var i = e.line + t.text.length - (t.to.line - t.from.line) - 1, r = e.ch;
        return e.line == t.to.line && (r += fr(t).ch - t.to.ch), $(i, r);
      }
      function Xn(e, t) {
        for (var i = [], r = 0; r < e.sel.ranges.length; r++) {
          var n = e.sel.ranges[r];
          i.push(new qe(
            ml(n.anchor, t),
            ml(n.head, t)
          ));
        }
        return jt(e.cm, i, e.sel.primIndex);
      }
      function xl(e, t, i) {
        return e.line == t.line ? $(i.line, e.ch - t.ch + i.ch) : $(i.line + (e.line - t.line), e.ch);
      }
      function ts(e, t, i) {
        for (var r = [], n = $(e.first, 0), a = n, l = 0; l < t.length; l++) {
          var u = t[l], s = xl(u.from, n, a), c = xl(fr(u), n, a);
          if (n = u.to, a = c, i == "around") {
            var g = e.sel.ranges[l], m = Ne(g.head, g.anchor) < 0;
            r[l] = new qe(m ? c : s, m ? s : c);
          } else
            r[l] = new qe(s, s);
        }
        return new Pt(r, e.sel.primIndex);
      }
      function Yn(e) {
        e.doc.mode = Mr(e.options, e.doc.modeOption), vi(e);
      }
      function vi(e) {
        e.doc.iter(function(t) {
          t.stateAfter && (t.stateAfter = null), t.styles && (t.styles = null);
        }), e.doc.modeFrontier = e.doc.highlightFrontier = e.doc.first, pi(e, 100), e.state.modeGen++, e.curOp && Et(e);
      }
      function yl(e, t) {
        return t.from.ch == 0 && t.to.ch == 0 && xe(t.text) == "" && (!e.cm || e.cm.options.wholeLineUpdateBefore);
      }
      function Zn(e, t, i, r) {
        function n(he) {
          return i ? i[he] : null;
        }
        function a(he, oe, pe) {
          su(he, oe, pe, r), dt(he, "change", he, t);
        }
        function l(he, oe) {
          for (var pe = [], Fe = he; Fe < oe; ++Fe)
            pe.push(new Or(c[Fe], n(Fe), r));
          return pe;
        }
        var u = t.from, s = t.to, c = t.text, g = be(e, u.line), m = be(e, s.line), L = xe(c), S = n(c.length - 1), U = s.line - u.line;
        if (t.full)
          e.insert(0, l(0, c.length)), e.remove(c.length, e.size - c.length);
        else if (yl(e, t)) {
          var Y = l(0, c.length - 1);
          a(m, m.text, S), U && e.remove(u.line, U), Y.length && e.insert(u.line, Y);
        } else if (g == m)
          if (c.length == 1)
            a(g, g.text.slice(0, u.ch) + L + g.text.slice(s.ch), S);
          else {
            var V = l(1, c.length - 1);
            V.push(new Or(L + g.text.slice(s.ch), S, r)), a(g, g.text.slice(0, u.ch) + c[0], n(0)), e.insert(u.line + 1, V);
          }
        else if (c.length == 1)
          a(g, g.text.slice(0, u.ch) + c[0] + m.text.slice(s.ch), n(0)), e.remove(u.line + 1, U);
        else {
          a(g, g.text.slice(0, u.ch) + c[0], n(0)), a(m, L + m.text.slice(s.ch), S);
          var le = l(1, c.length - 1);
          U > 1 && e.remove(u.line + 1, U - 1), e.insert(u.line + 1, le);
        }
        dt(e, "change", e, t);
      }
      function cr(e, t, i) {
        function r(n, a, l) {
          if (n.linked)
            for (var u = 0; u < n.linked.length; ++u) {
              var s = n.linked[u];
              if (s.doc != a) {
                var c = l && s.sharedHist;
                i && !c || (t(s.doc, c), r(s.doc, n, c));
              }
            }
        }
        r(e, null, !0);
      }
      function Dl(e, t) {
        if (t.cm)
          throw new Error("This document is already in use.");
        e.doc = t, t.cm = e, In(e), Yn(e), bl(e), e.options.direction = t.direction, e.options.lineWrapping || kn(e), e.options.mode = t.modeOption, Et(e);
      }
      function bl(e) {
        (e.doc.direction == "rtl" ? rt : Le)(e.display.lineDiv, "CodeMirror-rtl");
      }
      function rs(e) {
        Ot(e, function() {
          bl(e), Et(e);
        });
      }
      function Ji(e) {
        this.done = [], this.undone = [], this.undoDepth = e ? e.undoDepth : 1 / 0, this.lastModTime = this.lastSelTime = 0, this.lastOp = this.lastSelOp = null, this.lastOrigin = this.lastSelOrigin = null, this.generation = this.maxGeneration = e ? e.maxGeneration : 1;
      }
      function Qn(e, t) {
        var i = { from: mn(t.from), to: fr(t), text: mr(e, t.from, t.to) };
        return kl(e, i, t.from.line, t.to.line + 1), cr(e, function(r) {
          return kl(r, i, t.from.line, t.to.line + 1);
        }, !0), i;
      }
      function Cl(e) {
        for (; e.length; ) {
          var t = xe(e);
          if (t.ranges)
            e.pop();
          else
            break;
        }
      }
      function is(e, t) {
        if (t)
          return Cl(e.done), xe(e.done);
        if (e.done.length && !xe(e.done).ranges)
          return xe(e.done);
        if (e.done.length > 1 && !e.done[e.done.length - 2].ranges)
          return e.done.pop(), xe(e.done);
      }
      function wl(e, t, i, r) {
        var n = e.history;
        n.undone.length = 0;
        var a = +/* @__PURE__ */ new Date(), l, u;
        if ((n.lastOp == r || n.lastOrigin == t.origin && t.origin && (t.origin.charAt(0) == "+" && n.lastModTime > a - (e.cm ? e.cm.options.historyEventDelay : 500) || t.origin.charAt(0) == "*")) && (l = is(n, n.lastOp == r)))
          u = xe(l.changes), Ne(t.from, t.to) == 0 && Ne(t.from, u.to) == 0 ? u.to = fr(t) : l.changes.push(Qn(e, t));
        else {
          var s = xe(n.done);
          for ((!s || !s.ranges) && $i(e.sel, n.done), l = {
            changes: [Qn(e, t)],
            generation: n.generation
          }, n.done.push(l); n.done.length > n.undoDepth; )
            n.done.shift(), n.done[0].ranges || n.done.shift();
        }
        n.done.push(i), n.generation = ++n.maxGeneration, n.lastModTime = n.lastSelTime = a, n.lastOp = n.lastSelOp = r, n.lastOrigin = n.lastSelOrigin = t.origin, u || ve(e, "historyAdded");
      }
      function ns(e, t, i, r) {
        var n = t.charAt(0);
        return n == "*" || n == "+" && i.ranges.length == r.ranges.length && i.somethingSelected() == r.somethingSelected() && /* @__PURE__ */ new Date() - e.history.lastSelTime <= (e.cm ? e.cm.options.historyEventDelay : 500);
      }
      function as(e, t, i, r) {
        var n = e.history, a = r && r.origin;
        i == n.lastSelOp || a && n.lastSelOrigin == a && (n.lastModTime == n.lastSelTime && n.lastOrigin == a || ns(e, a, xe(n.done), t)) ? n.done[n.done.length - 1] = t : $i(t, n.done), n.lastSelTime = +/* @__PURE__ */ new Date(), n.lastSelOrigin = a, n.lastSelOp = i, r && r.clearRedo !== !1 && Cl(n.undone);
      }
      function $i(e, t) {
        var i = xe(t);
        i && i.ranges && i.equals(e) || t.push(e);
      }
      function kl(e, t, i, r) {
        var n = t["spans_" + e.id], a = 0;
        e.iter(Math.max(e.first, i), Math.min(e.first + e.size, r), function(l) {
          l.markedSpans && ((n || (n = t["spans_" + e.id] = {}))[a] = l.markedSpans), ++a;
        });
      }
      function ls(e) {
        if (!e)
          return null;
        for (var t, i = 0; i < e.length; ++i)
          e[i].marker.explicitlyCleared ? t || (t = e.slice(0, i)) : t && t.push(e[i]);
        return t ? t.length ? t : null : e;
      }
      function os(e, t) {
        var i = t["spans_" + e.id];
        if (!i)
          return null;
        for (var r = [], n = 0; n < t.text.length; ++n)
          r.push(ls(i[n]));
        return r;
      }
      function Sl(e, t) {
        var i = os(e, t), r = Dn(e, t);
        if (!i)
          return r;
        if (!r)
          return i;
        for (var n = 0; n < i.length; ++n) {
          var a = i[n], l = r[n];
          if (a && l)
            e: for (var u = 0; u < l.length; ++u) {
              for (var s = l[u], c = 0; c < a.length; ++c)
                if (a[c].marker == s.marker)
                  continue e;
              a.push(s);
            }
          else l && (i[n] = l);
        }
        return i;
      }
      function qr(e, t, i) {
        for (var r = [], n = 0; n < e.length; ++n) {
          var a = e[n];
          if (a.ranges) {
            r.push(i ? Pt.prototype.deepCopy.call(a) : a);
            continue;
          }
          var l = a.changes, u = [];
          r.push({ changes: u });
          for (var s = 0; s < l.length; ++s) {
            var c = l[s], g = void 0;
            if (u.push({ from: c.from, to: c.to, text: c.text }), t)
              for (var m in c)
                (g = m.match(/^spans_(\d+)$/)) && Pe(t, Number(g[1])) > -1 && (xe(u)[m] = c[m], delete c[m]);
          }
        }
        return r;
      }
      function Jn(e, t, i, r) {
        if (r) {
          var n = e.anchor;
          if (i) {
            var a = Ne(t, n) < 0;
            a != Ne(i, n) < 0 ? (n = t, t = i) : a != Ne(t, i) < 0 && (t = i);
          }
          return new qe(n, t);
        } else
          return new qe(i || t, t);
      }
      function Vi(e, t, i, r, n) {
        n == null && (n = e.cm && (e.cm.display.shift || e.extend)), Ct(e, new Pt([Jn(e.sel.primary(), t, i, n)], 0), r);
      }
      function Fl(e, t, i) {
        for (var r = [], n = e.cm && (e.cm.display.shift || e.extend), a = 0; a < e.sel.ranges.length; a++)
          r[a] = Jn(e.sel.ranges[a], t[a], null, n);
        var l = jt(e.cm, r, e.sel.primIndex);
        Ct(e, l, i);
      }
      function $n(e, t, i, r) {
        var n = e.sel.ranges.slice(0);
        n[t] = i, Ct(e, jt(e.cm, n, e.sel.primIndex), r);
      }
      function Al(e, t, i, r) {
        Ct(e, sr(t, i), r);
      }
      function us(e, t, i) {
        var r = {
          ranges: t.ranges,
          update: function(n) {
            this.ranges = [];
            for (var a = 0; a < n.length; a++)
              this.ranges[a] = new qe(
                Oe(e, n[a].anchor),
                Oe(e, n[a].head)
              );
          },
          origin: i && i.origin
        };
        return ve(e, "beforeSelectionChange", e, r), e.cm && ve(e.cm, "beforeSelectionChange", e.cm, r), r.ranges != t.ranges ? jt(e.cm, r.ranges, r.ranges.length - 1) : t;
      }
      function El(e, t, i) {
        var r = e.history.done, n = xe(r);
        n && n.ranges ? (r[r.length - 1] = t, en(e, t, i)) : Ct(e, t, i);
      }
      function Ct(e, t, i) {
        en(e, t, i), as(e, e.sel, e.cm ? e.cm.curOp.id : NaN, i);
      }
      function en(e, t, i) {
        (Me(e, "beforeSelectionChange") || e.cm && Me(e.cm, "beforeSelectionChange")) && (t = us(e, t, i));
        var r = i && i.bias || (Ne(t.primary().head, e.sel.primary().head) < 0 ? -1 : 1);
        Ll(e, Bl(e, t, r, !0)), !(i && i.scroll === !1) && e.cm && e.cm.getOption("readOnly") != "nocursor" && Wr(e.cm);
      }
      function Ll(e, t) {
        t.equals(e.sel) || (e.sel = t, e.cm && (e.cm.curOp.updateInput = 1, e.cm.curOp.selectionChanged = !0, Be(e.cm)), dt(e, "cursorActivity", e));
      }
      function Tl(e) {
        Ll(e, Bl(e, e.sel, null, !1));
      }
      function Bl(e, t, i, r) {
        for (var n, a = 0; a < t.ranges.length; a++) {
          var l = t.ranges[a], u = t.ranges.length == e.sel.ranges.length && e.sel.ranges[a], s = tn(e, l.anchor, u && u.anchor, i, r), c = l.head == l.anchor ? s : tn(e, l.head, u && u.head, i, r);
          (n || s != l.anchor || c != l.head) && (n || (n = t.ranges.slice(0, a)), n[a] = new qe(s, c));
        }
        return n ? jt(e.cm, n, t.primIndex) : t;
      }
      function Ur(e, t, i, r, n) {
        var a = be(e, t.line);
        if (a.markedSpans)
          for (var l = 0; l < a.markedSpans.length; ++l) {
            var u = a.markedSpans[l], s = u.marker, c = "selectLeft" in s ? !s.selectLeft : s.inclusiveLeft, g = "selectRight" in s ? !s.selectRight : s.inclusiveRight;
            if ((u.from == null || (c ? u.from <= t.ch : u.from < t.ch)) && (u.to == null || (g ? u.to >= t.ch : u.to > t.ch))) {
              if (n && (ve(s, "beforeCursorEnter"), s.explicitlyCleared))
                if (a.markedSpans) {
                  --l;
                  continue;
                } else
                  break;
              if (!s.atomic)
                continue;
              if (i) {
                var m = s.find(r < 0 ? 1 : -1), L = void 0;
                if ((r < 0 ? g : c) && (m = Ml(e, m, -r, m && m.line == t.line ? a : null)), m && m.line == t.line && (L = Ne(m, i)) && (r < 0 ? L < 0 : L > 0))
                  return Ur(e, m, t, r, n);
              }
              var S = s.find(r < 0 ? -1 : 1);
              return (r < 0 ? c : g) && (S = Ml(e, S, r, S.line == t.line ? a : null)), S ? Ur(e, S, t, r, n) : null;
            }
          }
        return t;
      }
      function tn(e, t, i, r, n) {
        var a = r || 1, l = Ur(e, t, i, a, n) || !n && Ur(e, t, i, a, !0) || Ur(e, t, i, -a, n) || !n && Ur(e, t, i, -a, !0);
        return l || (e.cantEdit = !0, $(e.first, 0));
      }
      function Ml(e, t, i, r) {
        return i < 0 && t.ch == 0 ? t.line > e.first ? Oe(e, $(t.line - 1)) : null : i > 0 && t.ch == (r || be(e, t.line)).text.length ? t.line < e.first + e.size - 1 ? $(t.line + 1, 0) : null : new $(t.line, t.ch + i);
      }
      function Nl(e) {
        e.setSelection($(e.firstLine(), 0), $(e.lastLine()), at);
      }
      function Ol(e, t, i) {
        var r = {
          canceled: !1,
          from: t.from,
          to: t.to,
          text: t.text,
          origin: t.origin,
          cancel: function() {
            return r.canceled = !0;
          }
        };
        return i && (r.update = function(n, a, l, u) {
          n && (r.from = Oe(e, n)), a && (r.to = Oe(e, a)), l && (r.text = l), u !== void 0 && (r.origin = u);
        }), ve(e, "beforeChange", e, r), e.cm && ve(e.cm, "beforeChange", e.cm, r), r.canceled ? (e.cm && (e.cm.curOp.updateInput = 2), null) : { from: r.from, to: r.to, text: r.text, origin: r.origin };
      }
      function Gr(e, t, i) {
        if (e.cm) {
          if (!e.cm.curOp)
            return pt(e.cm, Gr)(e, t, i);
          if (e.cm.state.suppressEdits)
            return;
        }
        if (!((Me(e, "beforeChange") || e.cm && Me(e.cm, "beforeChange")) && (t = Ol(e, t, !0), !t))) {
          var r = Sa && !i && au(e, t.from, t.to);
          if (r)
            for (var n = r.length - 1; n >= 0; --n)
              Il(e, { from: r[n].from, to: r[n].to, text: n ? [""] : t.text, origin: t.origin });
          else
            Il(e, t);
        }
      }
      function Il(e, t) {
        if (!(t.text.length == 1 && t.text[0] == "" && Ne(t.from, t.to) == 0)) {
          var i = Xn(e, t);
          wl(e, t, i, e.cm ? e.cm.curOp.id : NaN), mi(e, t, i, Dn(e, t));
          var r = [];
          cr(e, function(n, a) {
            !a && Pe(r, n.history) == -1 && (zl(n.history, t), r.push(n.history)), mi(n, t, null, Dn(n, t));
          });
        }
      }
      function rn(e, t, i) {
        var r = e.cm && e.cm.state.suppressEdits;
        if (!(r && !i)) {
          for (var n = e.history, a, l = e.sel, u = t == "undo" ? n.done : n.undone, s = t == "undo" ? n.undone : n.done, c = 0; c < u.length && (a = u[c], !(i ? a.ranges && !a.equals(e.sel) : !a.ranges)); c++)
            ;
          if (c != u.length) {
            for (n.lastOrigin = n.lastSelOrigin = null; ; )
              if (a = u.pop(), a.ranges) {
                if ($i(a, s), i && !a.equals(e.sel)) {
                  Ct(e, a, { clearRedo: !1 });
                  return;
                }
                l = a;
              } else if (r) {
                u.push(a);
                return;
              } else
                break;
            var g = [];
            $i(l, s), s.push({ changes: g, generation: n.generation }), n.generation = a.generation || ++n.maxGeneration;
            for (var m = Me(e, "beforeChange") || e.cm && Me(e.cm, "beforeChange"), L = function(Y) {
              var V = a.changes[Y];
              if (V.origin = t, m && !Ol(e, V, !1))
                return u.length = 0, {};
              g.push(Qn(e, V));
              var le = Y ? Xn(e, V) : xe(u);
              mi(e, V, le, Sl(e, V)), !Y && e.cm && e.cm.scrollIntoView({ from: V.from, to: fr(V) });
              var he = [];
              cr(e, function(oe, pe) {
                !pe && Pe(he, oe.history) == -1 && (zl(oe.history, V), he.push(oe.history)), mi(oe, V, null, Sl(oe, V));
              });
            }, S = a.changes.length - 1; S >= 0; --S) {
              var U = L(S);
              if (U) return U.v;
            }
          }
        }
      }
      function Hl(e, t) {
        if (t != 0 && (e.first += t, e.sel = new Pt(ot(e.sel.ranges, function(n) {
          return new qe(
            $(n.anchor.line + t, n.anchor.ch),
            $(n.head.line + t, n.head.ch)
          );
        }), e.sel.primIndex), e.cm)) {
          Et(e.cm, e.first, e.first - t, t);
          for (var i = e.cm.display, r = i.viewFrom; r < i.viewTo; r++)
            or(e.cm, r, "gutter");
        }
      }
      function mi(e, t, i, r) {
        if (e.cm && !e.cm.curOp)
          return pt(e.cm, mi)(e, t, i, r);
        if (t.to.line < e.first) {
          Hl(e, t.text.length - 1 - (t.to.line - t.from.line));
          return;
        }
        if (!(t.from.line > e.lastLine())) {
          if (t.from.line < e.first) {
            var n = t.text.length - 1 - (e.first - t.from.line);
            Hl(e, n), t = {
              from: $(e.first, 0),
              to: $(t.to.line + n, t.to.ch),
              text: [xe(t.text)],
              origin: t.origin
            };
          }
          var a = e.lastLine();
          t.to.line > a && (t = {
            from: t.from,
            to: $(a, be(e, a).text.length),
            text: [t.text[0]],
            origin: t.origin
          }), t.removed = mr(e, t.from, t.to), i || (i = Xn(e, t)), e.cm ? ss(e.cm, t, r) : Zn(e, t, r), en(e, i, at), e.cantEdit && tn(e, $(e.firstLine(), 0)) && (e.cantEdit = !1);
        }
      }
      function ss(e, t, i) {
        var r = e.doc, n = e.display, a = t.from, l = t.to, u = !1, s = a.line;
        e.options.lineWrapping || (s = Ge(Ut(be(r, a.line))), r.iter(s, l.line + 1, function(S) {
          if (S == n.maxLine)
            return u = !0, !0;
        })), r.sel.contains(t.from, t.to) > -1 && Be(e), Zn(r, t, i, tl(e)), e.options.lineWrapping || (r.iter(s, a.line + t.text.length, function(S) {
          var U = zi(S);
          U > n.maxLineLength && (n.maxLine = S, n.maxLineLength = U, n.maxLineChanged = !0, u = !1);
        }), u && (e.curOp.updateMaxLine = !0)), $o(r, a.line), pi(e, 400);
        var c = t.text.length - (l.line - a.line) - 1;
        t.full ? Et(e) : a.line == l.line && t.text.length == 1 && !yl(e.doc, t) ? or(e, a.line, "text") : Et(e, a.line, l.line + 1, c);
        var g = Me(e, "changes"), m = Me(e, "change");
        if (m || g) {
          var L = {
            from: a,
            to: l,
            text: t.text,
            removed: t.removed,
            origin: t.origin
          };
          m && dt(e, "change", e, L), g && (e.curOp.changeObjs || (e.curOp.changeObjs = [])).push(L);
        }
        e.display.selForContextMenu = null;
      }
      function jr(e, t, i, r, n) {
        var a;
        r || (r = i), Ne(r, i) < 0 && (a = [r, i], i = a[0], r = a[1]), typeof t == "string" && (t = e.splitLines(t)), Gr(e, { from: i, to: r, text: t, origin: n });
      }
      function Rl(e, t, i, r) {
        i < e.line ? e.line += r : t < e.line && (e.line = t, e.ch = 0);
      }
      function Pl(e, t, i, r) {
        for (var n = 0; n < e.length; ++n) {
          var a = e[n], l = !0;
          if (a.ranges) {
            a.copied || (a = e[n] = a.deepCopy(), a.copied = !0);
            for (var u = 0; u < a.ranges.length; u++)
              Rl(a.ranges[u].anchor, t, i, r), Rl(a.ranges[u].head, t, i, r);
            continue;
          }
          for (var s = 0; s < a.changes.length; ++s) {
            var c = a.changes[s];
            if (i < c.from.line)
              c.from = $(c.from.line + r, c.from.ch), c.to = $(c.to.line + r, c.to.ch);
            else if (t <= c.to.line) {
              l = !1;
              break;
            }
          }
          l || (e.splice(0, n + 1), n = 0);
        }
      }
      function zl(e, t) {
        var i = t.from.line, r = t.to.line, n = t.text.length - (r - i) - 1;
        Pl(e.done, i, r, n), Pl(e.undone, i, r, n);
      }
      function xi(e, t, i, r) {
        var n = t, a = t;
        return typeof t == "number" ? a = be(e, va(e, t)) : n = Ge(t), n == null ? null : (r(a, n) && e.cm && or(e.cm, n, i), a);
      }
      function yi(e) {
        this.lines = e, this.parent = null;
        for (var t = 0, i = 0; i < e.length; ++i)
          e[i].parent = this, t += e[i].height;
        this.height = t;
      }
      yi.prototype = {
        chunkSize: function() {
          return this.lines.length;
        },
        // Remove the n lines at offset 'at'.
        removeInner: function(e, t) {
          for (var i = e, r = e + t; i < r; ++i) {
            var n = this.lines[i];
            this.height -= n.height, fu(n), dt(n, "delete");
          }
          this.lines.splice(e, t);
        },
        // Helper used to collapse a small branch into a single leaf.
        collapse: function(e) {
          e.push.apply(e, this.lines);
        },
        // Insert the given array of lines at offset 'at', count them as
        // having the given height.
        insertInner: function(e, t, i) {
          this.height += i, this.lines = this.lines.slice(0, e).concat(t).concat(this.lines.slice(e));
          for (var r = 0; r < t.length; ++r)
            t[r].parent = this;
        },
        // Used to iterate over a part of the tree.
        iterN: function(e, t, i) {
          for (var r = e + t; e < r; ++e)
            if (i(this.lines[e]))
              return !0;
        }
      };
      function Di(e) {
        this.children = e;
        for (var t = 0, i = 0, r = 0; r < e.length; ++r) {
          var n = e[r];
          t += n.chunkSize(), i += n.height, n.parent = this;
        }
        this.size = t, this.height = i, this.parent = null;
      }
      Di.prototype = {
        chunkSize: function() {
          return this.size;
        },
        removeInner: function(e, t) {
          this.size -= t;
          for (var i = 0; i < this.children.length; ++i) {
            var r = this.children[i], n = r.chunkSize();
            if (e < n) {
              var a = Math.min(t, n - e), l = r.height;
              if (r.removeInner(e, a), this.height -= l - r.height, n == a && (this.children.splice(i--, 1), r.parent = null), (t -= a) == 0)
                break;
              e = 0;
            } else
              e -= n;
          }
          if (this.size - t < 25 && (this.children.length > 1 || !(this.children[0] instanceof yi))) {
            var u = [];
            this.collapse(u), this.children = [new yi(u)], this.children[0].parent = this;
          }
        },
        collapse: function(e) {
          for (var t = 0; t < this.children.length; ++t)
            this.children[t].collapse(e);
        },
        insertInner: function(e, t, i) {
          this.size += t.length, this.height += i;
          for (var r = 0; r < this.children.length; ++r) {
            var n = this.children[r], a = n.chunkSize();
            if (e <= a) {
              if (n.insertInner(e, t, i), n.lines && n.lines.length > 50) {
                for (var l = n.lines.length % 25 + 25, u = l; u < n.lines.length; ) {
                  var s = new yi(n.lines.slice(u, u += 25));
                  n.height -= s.height, this.children.splice(++r, 0, s), s.parent = this;
                }
                n.lines = n.lines.slice(0, l), this.maybeSpill();
              }
              break;
            }
            e -= a;
          }
        },
        // When a node has grown, check whether it should be split.
        maybeSpill: function() {
          if (!(this.children.length <= 10)) {
            var e = this;
            do {
              var t = e.children.splice(e.children.length - 5, 5), i = new Di(t);
              if (e.parent) {
                e.size -= i.size, e.height -= i.height;
                var n = Pe(e.parent.children, e);
                e.parent.children.splice(n + 1, 0, i);
              } else {
                var r = new Di(e.children);
                r.parent = e, e.children = [r, i], e = r;
              }
              i.parent = e.parent;
            } while (e.children.length > 10);
            e.parent.maybeSpill();
          }
        },
        iterN: function(e, t, i) {
          for (var r = 0; r < this.children.length; ++r) {
            var n = this.children[r], a = n.chunkSize();
            if (e < a) {
              var l = Math.min(t, a - e);
              if (n.iterN(e, l, i))
                return !0;
              if ((t -= l) == 0)
                break;
              e = 0;
            } else
              e -= a;
          }
        }
      };
      var bi = function(e, t, i) {
        if (i)
          for (var r in i)
            i.hasOwnProperty(r) && (this[r] = i[r]);
        this.doc = e, this.node = t;
      };
      bi.prototype.clear = function() {
        var e = this.doc.cm, t = this.line.widgets, i = this.line, r = Ge(i);
        if (!(r == null || !t)) {
          for (var n = 0; n < t.length; ++n)
            t[n] == this && t.splice(n--, 1);
          t.length || (i.widgets = null);
          var a = oi(this);
          Yt(i, Math.max(0, i.height - a)), e && (Ot(e, function() {
            Wl(e, i, -a), or(e, r, "widget");
          }), dt(e, "lineWidgetCleared", e, this, r));
        }
      }, bi.prototype.changed = function() {
        var e = this, t = this.height, i = this.doc.cm, r = this.line;
        this.height = null;
        var n = oi(this) - t;
        n && (lr(this.doc, r) || Yt(r, r.height + n), i && Ot(i, function() {
          i.curOp.forceUpdate = !0, Wl(i, r, n), dt(i, "lineWidgetChanged", i, e, Ge(r));
        }));
      }, Ie(bi);
      function Wl(e, t, i) {
        er(t) < (e.curOp && e.curOp.scrollTop || e.doc.scrollTop) && _n(e, i);
      }
      function fs(e, t, i, r) {
        var n = new bi(e, i, r), a = e.cm;
        return a && n.noHScroll && (a.display.alignWidgets = !0), xi(e, t, "widget", function(l) {
          var u = l.widgets || (l.widgets = []);
          if (n.insertAt == null ? u.push(n) : u.splice(Math.min(u.length, Math.max(0, n.insertAt)), 0, n), n.line = l, a && !lr(e, l)) {
            var s = er(l) < e.scrollTop;
            Yt(l, l.height + oi(n)), s && _n(a, n.height), a.curOp.forceUpdate = !0;
          }
          return !0;
        }), a && dt(a, "lineWidgetAdded", a, n, typeof t == "number" ? t : Ge(t)), n;
      }
      var _l = 0, hr = function(e, t) {
        this.lines = [], this.type = t, this.doc = e, this.id = ++_l;
      };
      hr.prototype.clear = function() {
        if (!this.explicitlyCleared) {
          var e = this.doc.cm, t = e && !e.curOp;
          if (t && Sr(e), Me(this, "clear")) {
            var i = this.find();
            i && dt(this, "clear", i.from, i.to);
          }
          for (var r = null, n = null, a = 0; a < this.lines.length; ++a) {
            var l = this.lines[a], u = ni(l.markedSpans, this);
            e && !this.collapsed ? or(e, Ge(l), "text") : e && (u.to != null && (n = Ge(l)), u.from != null && (r = Ge(l))), l.markedSpans = tu(l.markedSpans, u), u.from == null && this.collapsed && !lr(this.doc, l) && e && Yt(l, Rr(e.display));
          }
          if (e && this.collapsed && !e.options.lineWrapping)
            for (var s = 0; s < this.lines.length; ++s) {
              var c = Ut(this.lines[s]), g = zi(c);
              g > e.display.maxLineLength && (e.display.maxLine = c, e.display.maxLineLength = g, e.display.maxLineChanged = !0);
            }
          r != null && e && this.collapsed && Et(e, r, n + 1), this.lines.length = 0, this.explicitlyCleared = !0, this.atomic && this.doc.cantEdit && (this.doc.cantEdit = !1, e && Tl(e.doc)), e && dt(e, "markerCleared", e, this, r, n), t && Fr(e), this.parent && this.parent.clear();
        }
      }, hr.prototype.find = function(e, t) {
        e == null && this.type == "bookmark" && (e = 1);
        for (var i, r, n = 0; n < this.lines.length; ++n) {
          var a = this.lines[n], l = ni(a.markedSpans, this);
          if (l.from != null && (i = $(t ? a : Ge(a), l.from), e == -1))
            return i;
          if (l.to != null && (r = $(t ? a : Ge(a), l.to), e == 1))
            return r;
        }
        return i && { from: i, to: r };
      }, hr.prototype.changed = function() {
        var e = this, t = this.find(-1, !0), i = this, r = this.doc.cm;
        !t || !r || Ot(r, function() {
          var n = t.line, a = Ge(t.line), l = En(r, a);
          if (l && (Xa(l), r.curOp.selectionChanged = r.curOp.forceUpdate = !0), r.curOp.updateMaxLine = !0, !lr(i.doc, n) && i.height != null) {
            var u = i.height;
            i.height = null;
            var s = oi(i) - u;
            s && Yt(n, n.height + s);
          }
          dt(r, "markerChanged", r, e);
        });
      }, hr.prototype.attachLine = function(e) {
        if (!this.lines.length && this.doc.cm) {
          var t = this.doc.cm.curOp;
          (!t.maybeHiddenMarkers || Pe(t.maybeHiddenMarkers, this) == -1) && (t.maybeUnhiddenMarkers || (t.maybeUnhiddenMarkers = [])).push(this);
        }
        this.lines.push(e);
      }, hr.prototype.detachLine = function(e) {
        if (this.lines.splice(Pe(this.lines, e), 1), !this.lines.length && this.doc.cm) {
          var t = this.doc.cm.curOp;
          (t.maybeHiddenMarkers || (t.maybeHiddenMarkers = [])).push(this);
        }
      }, Ie(hr);
      function Kr(e, t, i, r, n) {
        if (r && r.shared)
          return cs(e, t, i, r, n);
        if (e.cm && !e.cm.curOp)
          return pt(e.cm, Kr)(e, t, i, r, n);
        var a = new hr(e, n), l = Ne(t, i);
        if (r && $e(r, a, !1), l > 0 || l == 0 && a.clearWhenEmpty !== !1)
          return a;
        if (a.replacedWith && (a.collapsed = !0, a.widgetNode = ee("span", [a.replacedWith], "CodeMirror-widget"), r.handleMouseEvents || a.widgetNode.setAttribute("cm-ignore-events", "true"), r.insertLeft && (a.widgetNode.insertLeft = !0)), a.collapsed) {
          if (Ba(e, t.line, t, i, a) || t.line != i.line && Ba(e, i.line, t, i, a))
            throw new Error("Inserting collapsed marker partially overlapping an existing one");
          eu();
        }
        a.addToHistory && wl(e, { from: t, to: i, origin: "markText" }, e.sel, NaN);
        var u = t.line, s = e.cm, c;
        if (e.iter(u, i.line + 1, function(m) {
          s && a.collapsed && !s.options.lineWrapping && Ut(m) == s.display.maxLine && (c = !0), a.collapsed && u != t.line && Yt(m, 0), ru(m, new Ii(
            a,
            u == t.line ? t.ch : null,
            u == i.line ? i.ch : null
          ), e.cm && e.cm.curOp), ++u;
        }), a.collapsed && e.iter(t.line, i.line + 1, function(m) {
          lr(e, m) && Yt(m, 0);
        }), a.clearOnEnter && A(a, "beforeCursorEnter", function() {
          return a.clear();
        }), a.readOnly && (Vo(), (e.history.done.length || e.history.undone.length) && e.clearHistory()), a.collapsed && (a.id = ++_l, a.atomic = !0), s) {
          if (c && (s.curOp.updateMaxLine = !0), a.collapsed)
            Et(s, t.line, i.line + 1);
          else if (a.className || a.startStyle || a.endStyle || a.css || a.attributes || a.title)
            for (var g = t.line; g <= i.line; g++)
              or(s, g, "text");
          a.atomic && Tl(s.doc), dt(s, "markerAdded", s, a);
        }
        return a;
      }
      var Ci = function(e, t) {
        this.markers = e, this.primary = t;
        for (var i = 0; i < e.length; ++i)
          e[i].parent = this;
      };
      Ci.prototype.clear = function() {
        if (!this.explicitlyCleared) {
          this.explicitlyCleared = !0;
          for (var e = 0; e < this.markers.length; ++e)
            this.markers[e].clear();
          dt(this, "clear");
        }
      }, Ci.prototype.find = function(e, t) {
        return this.primary.find(e, t);
      }, Ie(Ci);
      function cs(e, t, i, r, n) {
        r = $e(r), r.shared = !1;
        var a = [Kr(e, t, i, r, n)], l = a[0], u = r.widgetNode;
        return cr(e, function(s) {
          u && (r.widgetNode = u.cloneNode(!0)), a.push(Kr(s, Oe(s, t), Oe(s, i), r, n));
          for (var c = 0; c < s.linked.length; ++c)
            if (s.linked[c].isParent)
              return;
          l = xe(a);
        }), new Ci(a, l);
      }
      function ql(e) {
        return e.findMarks($(e.first, 0), e.clipPos($(e.lastLine())), function(t) {
          return t.parent;
        });
      }
      function hs(e, t) {
        for (var i = 0; i < t.length; i++) {
          var r = t[i], n = r.find(), a = e.clipPos(n.from), l = e.clipPos(n.to);
          if (Ne(a, l)) {
            var u = Kr(e, a, l, r.primary, r.primary.type);
            r.markers.push(u), u.parent = r;
          }
        }
      }
      function ds(e) {
        for (var t = function(r) {
          var n = e[r], a = [n.primary.doc];
          cr(n.primary.doc, function(s) {
            return a.push(s);
          });
          for (var l = 0; l < n.markers.length; l++) {
            var u = n.markers[l];
            Pe(a, u.doc) == -1 && (u.parent = null, n.markers.splice(l--, 1));
          }
        }, i = 0; i < e.length; i++) t(i);
      }
      var ps = 0, Lt = function(e, t, i, r, n) {
        if (!(this instanceof Lt))
          return new Lt(e, t, i, r, n);
        i == null && (i = 0), Di.call(this, [new yi([new Or("", null)])]), this.first = i, this.scrollTop = this.scrollLeft = 0, this.cantEdit = !1, this.cleanGeneration = 1, this.modeFrontier = this.highlightFrontier = i;
        var a = $(i, 0);
        this.sel = sr(a), this.history = new Ji(null), this.id = ++ps, this.modeOption = t, this.lineSep = r, this.direction = n == "rtl" ? "rtl" : "ltr", this.extend = !1, typeof e == "string" && (e = this.splitLines(e)), Zn(this, { from: a, to: a, text: e }), Ct(this, sr(a), at);
      };
      Lt.prototype = O(Di.prototype, {
        constructor: Lt,
        // Iterate over the document. Supports two forms -- with only one
        // argument, it calls that for each line in the document. With
        // three, it iterates over the range given by the first two (with
        // the second being non-inclusive).
        iter: function(e, t, i) {
          i ? this.iterN(e - this.first, t - e, i) : this.iterN(this.first, this.first + this.size, e);
        },
        // Non-public interface for adding and removing lines.
        insert: function(e, t) {
          for (var i = 0, r = 0; r < t.length; ++r)
            i += t[r].height;
          this.insertInner(e - this.first, t, i);
        },
        remove: function(e, t) {
          this.removeInner(e - this.first, t);
        },
        // From here, the methods are part of the public interface. Most
        // are also available from CodeMirror (editor) instances.
        getValue: function(e) {
          var t = pn(this, this.first, this.first + this.size);
          return e === !1 ? t : t.join(e || this.lineSeparator());
        },
        setValue: gt(function(e) {
          var t = $(this.first, 0), i = this.first + this.size - 1;
          Gr(this, {
            from: t,
            to: $(i, be(this, i).text.length),
            text: this.splitLines(e),
            origin: "setValue",
            full: !0
          }, !0), this.cm && fi(this.cm, 0, 0), Ct(this, sr(t), at);
        }),
        replaceRange: function(e, t, i, r) {
          t = Oe(this, t), i = i ? Oe(this, i) : t, jr(this, e, t, i, r);
        },
        getRange: function(e, t, i) {
          var r = mr(this, Oe(this, e), Oe(this, t));
          return i === !1 ? r : i === "" ? r.join("") : r.join(i || this.lineSeparator());
        },
        getLine: function(e) {
          var t = this.getLineHandle(e);
          return t && t.text;
        },
        getLineHandle: function(e) {
          if (ri(this, e))
            return be(this, e);
        },
        getLineNumber: function(e) {
          return Ge(e);
        },
        getLineHandleVisualStart: function(e) {
          return typeof e == "number" && (e = be(this, e)), Ut(e);
        },
        lineCount: function() {
          return this.size;
        },
        firstLine: function() {
          return this.first;
        },
        lastLine: function() {
          return this.first + this.size - 1;
        },
        clipPos: function(e) {
          return Oe(this, e);
        },
        getCursor: function(e) {
          var t = this.sel.primary(), i;
          return e == null || e == "head" ? i = t.head : e == "anchor" ? i = t.anchor : e == "end" || e == "to" || e === !1 ? i = t.to() : i = t.from(), i;
        },
        listSelections: function() {
          return this.sel.ranges;
        },
        somethingSelected: function() {
          return this.sel.somethingSelected();
        },
        setCursor: gt(function(e, t, i) {
          Al(this, Oe(this, typeof e == "number" ? $(e, t || 0) : e), null, i);
        }),
        setSelection: gt(function(e, t, i) {
          Al(this, Oe(this, e), Oe(this, t || e), i);
        }),
        extendSelection: gt(function(e, t, i) {
          Vi(this, Oe(this, e), t && Oe(this, t), i);
        }),
        extendSelections: gt(function(e, t) {
          Fl(this, ma(this, e), t);
        }),
        extendSelectionsBy: gt(function(e, t) {
          var i = ot(this.sel.ranges, e);
          Fl(this, ma(this, i), t);
        }),
        setSelections: gt(function(e, t, i) {
          if (e.length) {
            for (var r = [], n = 0; n < e.length; n++)
              r[n] = new qe(
                Oe(this, e[n].anchor),
                Oe(this, e[n].head || e[n].anchor)
              );
            t == null && (t = Math.min(e.length - 1, this.sel.primIndex)), Ct(this, jt(this.cm, r, t), i);
          }
        }),
        addSelection: gt(function(e, t, i) {
          var r = this.sel.ranges.slice(0);
          r.push(new qe(Oe(this, e), Oe(this, t || e))), Ct(this, jt(this.cm, r, r.length - 1), i);
        }),
        getSelection: function(e) {
          for (var t = this.sel.ranges, i, r = 0; r < t.length; r++) {
            var n = mr(this, t[r].from(), t[r].to());
            i = i ? i.concat(n) : n;
          }
          return e === !1 ? i : i.join(e || this.lineSeparator());
        },
        getSelections: function(e) {
          for (var t = [], i = this.sel.ranges, r = 0; r < i.length; r++) {
            var n = mr(this, i[r].from(), i[r].to());
            e !== !1 && (n = n.join(e || this.lineSeparator())), t[r] = n;
          }
          return t;
        },
        replaceSelection: function(e, t, i) {
          for (var r = [], n = 0; n < this.sel.ranges.length; n++)
            r[n] = e;
          this.replaceSelections(r, t, i || "+input");
        },
        replaceSelections: gt(function(e, t, i) {
          for (var r = [], n = this.sel, a = 0; a < n.ranges.length; a++) {
            var l = n.ranges[a];
            r[a] = { from: l.from(), to: l.to(), text: this.splitLines(e[a]), origin: i };
          }
          for (var u = t && t != "end" && ts(this, r, t), s = r.length - 1; s >= 0; s--)
            Gr(this, r[s]);
          u ? El(this, u) : this.cm && Wr(this.cm);
        }),
        undo: gt(function() {
          rn(this, "undo");
        }),
        redo: gt(function() {
          rn(this, "redo");
        }),
        undoSelection: gt(function() {
          rn(this, "undo", !0);
        }),
        redoSelection: gt(function() {
          rn(this, "redo", !0);
        }),
        setExtending: function(e) {
          this.extend = e;
        },
        getExtending: function() {
          return this.extend;
        },
        historySize: function() {
          for (var e = this.history, t = 0, i = 0, r = 0; r < e.done.length; r++)
            e.done[r].ranges || ++t;
          for (var n = 0; n < e.undone.length; n++)
            e.undone[n].ranges || ++i;
          return { undo: t, redo: i };
        },
        clearHistory: function() {
          var e = this;
          this.history = new Ji(this.history), cr(this, function(t) {
            return t.history = e.history;
          }, !0);
        },
        markClean: function() {
          this.cleanGeneration = this.changeGeneration(!0);
        },
        changeGeneration: function(e) {
          return e && (this.history.lastOp = this.history.lastSelOp = this.history.lastOrigin = null), this.history.generation;
        },
        isClean: function(e) {
          return this.history.generation == (e || this.cleanGeneration);
        },
        getHistory: function() {
          return {
            done: qr(this.history.done),
            undone: qr(this.history.undone)
          };
        },
        setHistory: function(e) {
          var t = this.history = new Ji(this.history);
          t.done = qr(e.done.slice(0), null, !0), t.undone = qr(e.undone.slice(0), null, !0);
        },
        setGutterMarker: gt(function(e, t, i) {
          return xi(this, e, "gutter", function(r) {
            var n = r.gutterMarkers || (r.gutterMarkers = {});
            return n[t] = i, !i && h(n) && (r.gutterMarkers = null), !0;
          });
        }),
        clearGutter: gt(function(e) {
          var t = this;
          this.iter(function(i) {
            i.gutterMarkers && i.gutterMarkers[e] && xi(t, i, "gutter", function() {
              return i.gutterMarkers[e] = null, h(i.gutterMarkers) && (i.gutterMarkers = null), !0;
            });
          });
        }),
        lineInfo: function(e) {
          var t;
          if (typeof e == "number") {
            if (!ri(this, e) || (t = e, e = be(this, e), !e))
              return null;
          } else if (t = Ge(e), t == null)
            return null;
          return {
            line: t,
            handle: e,
            text: e.text,
            gutterMarkers: e.gutterMarkers,
            textClass: e.textClass,
            bgClass: e.bgClass,
            wrapClass: e.wrapClass,
            widgets: e.widgets
          };
        },
        addLineClass: gt(function(e, t, i) {
          return xi(this, e, t == "gutter" ? "gutter" : "class", function(r) {
            var n = t == "text" ? "textClass" : t == "background" ? "bgClass" : t == "gutter" ? "gutterClass" : "wrapClass";
            if (!r[n])
              r[n] = i;
            else {
              if (ae(i).test(r[n]))
                return !1;
              r[n] += " " + i;
            }
            return !0;
          });
        }),
        removeLineClass: gt(function(e, t, i) {
          return xi(this, e, t == "gutter" ? "gutter" : "class", function(r) {
            var n = t == "text" ? "textClass" : t == "background" ? "bgClass" : t == "gutter" ? "gutterClass" : "wrapClass", a = r[n];
            if (a)
              if (i == null)
                r[n] = null;
              else {
                var l = a.match(ae(i));
                if (!l)
                  return !1;
                var u = l.index + l[0].length;
                r[n] = a.slice(0, l.index) + (!l.index || u == a.length ? "" : " ") + a.slice(u) || null;
              }
            else return !1;
            return !0;
          });
        }),
        addLineWidget: gt(function(e, t, i) {
          return fs(this, e, t, i);
        }),
        removeLineWidget: function(e) {
          e.clear();
        },
        markText: function(e, t, i) {
          return Kr(this, Oe(this, e), Oe(this, t), i, i && i.type || "range");
        },
        setBookmark: function(e, t) {
          var i = {
            replacedWith: t && (t.nodeType == null ? t.widget : t),
            insertLeft: t && t.insertLeft,
            clearWhenEmpty: !1,
            shared: t && t.shared,
            handleMouseEvents: t && t.handleMouseEvents
          };
          return e = Oe(this, e), Kr(this, e, e, i, "bookmark");
        },
        findMarksAt: function(e) {
          e = Oe(this, e);
          var t = [], i = be(this, e.line).markedSpans;
          if (i)
            for (var r = 0; r < i.length; ++r) {
              var n = i[r];
              (n.from == null || n.from <= e.ch) && (n.to == null || n.to >= e.ch) && t.push(n.marker.parent || n.marker);
            }
          return t;
        },
        findMarks: function(e, t, i) {
          e = Oe(this, e), t = Oe(this, t);
          var r = [], n = e.line;
          return this.iter(e.line, t.line + 1, function(a) {
            var l = a.markedSpans;
            if (l)
              for (var u = 0; u < l.length; u++) {
                var s = l[u];
                !(s.to != null && n == e.line && e.ch >= s.to || s.from == null && n != e.line || s.from != null && n == t.line && s.from >= t.ch) && (!i || i(s.marker)) && r.push(s.marker.parent || s.marker);
              }
            ++n;
          }), r;
        },
        getAllMarks: function() {
          var e = [];
          return this.iter(function(t) {
            var i = t.markedSpans;
            if (i)
              for (var r = 0; r < i.length; ++r)
                i[r].from != null && e.push(i[r].marker);
          }), e;
        },
        posFromIndex: function(e) {
          var t, i = this.first, r = this.lineSeparator().length;
          return this.iter(function(n) {
            var a = n.text.length + r;
            if (a > e)
              return t = e, !0;
            e -= a, ++i;
          }), Oe(this, $(i, t));
        },
        indexFromPos: function(e) {
          e = Oe(this, e);
          var t = e.ch;
          if (e.line < this.first || e.ch < 0)
            return 0;
          var i = this.lineSeparator().length;
          return this.iter(this.first, e.line, function(r) {
            t += r.text.length + i;
          }), t;
        },
        copy: function(e) {
          var t = new Lt(
            pn(this, this.first, this.first + this.size),
            this.modeOption,
            this.first,
            this.lineSep,
            this.direction
          );
          return t.scrollTop = this.scrollTop, t.scrollLeft = this.scrollLeft, t.sel = this.sel, t.extend = !1, e && (t.history.undoDepth = this.history.undoDepth, t.setHistory(this.getHistory())), t;
        },
        linkedDoc: function(e) {
          e || (e = {});
          var t = this.first, i = this.first + this.size;
          e.from != null && e.from > t && (t = e.from), e.to != null && e.to < i && (i = e.to);
          var r = new Lt(pn(this, t, i), e.mode || this.modeOption, t, this.lineSep, this.direction);
          return e.sharedHist && (r.history = this.history), (this.linked || (this.linked = [])).push({ doc: r, sharedHist: e.sharedHist }), r.linked = [{ doc: this, isParent: !0, sharedHist: e.sharedHist }], hs(r, ql(this)), r;
        },
        unlinkDoc: function(e) {
          if (e instanceof et && (e = e.doc), this.linked)
            for (var t = 0; t < this.linked.length; ++t) {
              var i = this.linked[t];
              if (i.doc == e) {
                this.linked.splice(t, 1), e.unlinkDoc(this), ds(ql(this));
                break;
              }
            }
          if (e.history == this.history) {
            var r = [e.id];
            cr(e, function(n) {
              return r.push(n.id);
            }, !0), e.history = new Ji(null), e.history.done = qr(this.history.done, r), e.history.undone = qr(this.history.undone, r);
          }
        },
        iterLinkedDocs: function(e) {
          cr(this, e);
        },
        getMode: function() {
          return this.mode;
        },
        getEditor: function() {
          return this.cm;
        },
        splitLines: function(e) {
          return this.lineSep ? e.split(this.lineSep) : ti(e);
        },
        lineSeparator: function() {
          return this.lineSep || `
`;
        },
        setDirection: gt(function(e) {
          e != "rtl" && (e = "ltr"), e != this.direction && (this.direction = e, this.iter(function(t) {
            return t.order = null;
          }), this.cm && rs(this.cm));
        })
      }), Lt.prototype.eachLine = Lt.prototype.iter;
      var Ul = 0;
      function gs(e) {
        var t = this;
        if (Gl(t), !(te(t, e) || tr(t.display, e))) {
          Ae(e), T && (Ul = +/* @__PURE__ */ new Date());
          var i = br(t, e, !0), r = e.dataTransfer.files;
          if (!(!i || t.isReadOnly()))
            if (r && r.length && window.FileReader && window.File)
              for (var n = r.length, a = Array(n), l = 0, u = function() {
                ++l == n && pt(t, function() {
                  i = Oe(t.doc, i);
                  var S = {
                    from: i,
                    to: i,
                    text: t.doc.splitLines(
                      a.filter(function(U) {
                        return U != null;
                      }).join(t.doc.lineSeparator())
                    ),
                    origin: "paste"
                  };
                  Gr(t.doc, S), El(t.doc, sr(Oe(t.doc, i), Oe(t.doc, fr(S))));
                })();
              }, s = function(S, U) {
                if (t.options.allowDropFileTypes && Pe(t.options.allowDropFileTypes, S.type) == -1) {
                  u();
                  return;
                }
                var Y = new FileReader();
                Y.onerror = function() {
                  return u();
                }, Y.onload = function() {
                  var V = Y.result;
                  if (/[\x00-\x08\x0e-\x1f]{2}/.test(V)) {
                    u();
                    return;
                  }
                  a[U] = V, u();
                }, Y.readAsText(S);
              }, c = 0; c < r.length; c++)
                s(r[c], c);
            else {
              if (t.state.draggingText && t.doc.sel.contains(i) > -1) {
                t.state.draggingText(e), setTimeout(function() {
                  return t.display.input.focus();
                }, 20);
                return;
              }
              try {
                var g = e.dataTransfer.getData("Text");
                if (g) {
                  var m;
                  if (t.state.draggingText && !t.state.draggingText.copy && (m = t.listSelections()), en(t.doc, sr(i, i)), m)
                    for (var L = 0; L < m.length; ++L)
                      jr(t.doc, "", m[L].anchor, m[L].head, "drag");
                  t.replaceSelection(g, "around", "paste"), t.display.input.focus();
                }
              } catch {
              }
            }
        }
      }
      function vs(e, t) {
        if (T && (!e.state.draggingText || +/* @__PURE__ */ new Date() - Ul < 100)) {
          ut(t);
          return;
        }
        if (!(te(e, t) || tr(e.display, t)) && (t.dataTransfer.setData("Text", e.getSelection()), t.dataTransfer.effectAllowed = "copyMove", t.dataTransfer.setDragImage && !Se)) {
          var i = E("img", null, null, "position: fixed; left: 0; top: 0;");
          i.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", ie && (i.width = i.height = 1, e.display.wrapper.appendChild(i), i._top = i.offsetTop), t.dataTransfer.setDragImage(i, 0, 0), ie && i.parentNode.removeChild(i);
        }
      }
      function ms(e, t) {
        var i = br(e, t);
        if (i) {
          var r = document.createDocumentFragment();
          Hn(e, i, r), e.display.dragCursor || (e.display.dragCursor = E("div", null, "CodeMirror-cursors CodeMirror-dragcursors"), e.display.lineSpace.insertBefore(e.display.dragCursor, e.display.cursorDiv)), He(e.display.dragCursor, r);
        }
      }
      function Gl(e) {
        e.display.dragCursor && (e.display.lineSpace.removeChild(e.display.dragCursor), e.display.dragCursor = null);
      }
      function jl(e) {
        if (document.getElementsByClassName) {
          for (var t = document.getElementsByClassName("CodeMirror"), i = [], r = 0; r < t.length; r++) {
            var n = t[r].CodeMirror;
            n && i.push(n);
          }
          i.length && i[0].operation(function() {
            for (var a = 0; a < i.length; a++)
              e(i[a]);
          });
        }
      }
      var Kl = !1;
      function xs() {
        Kl || (ys(), Kl = !0);
      }
      function ys() {
        var e;
        A(window, "resize", function() {
          e == null && (e = setTimeout(function() {
            e = null, jl(Ds);
          }, 100));
        }), A(window, "blur", function() {
          return jl(zr);
        });
      }
      function Ds(e) {
        var t = e.display;
        t.cachedCharWidth = t.cachedTextHeight = t.cachedPaddingH = null, t.scrollbarsClipped = !1, e.setSize();
      }
      for (var dr = {
        3: "Pause",
        8: "Backspace",
        9: "Tab",
        13: "Enter",
        16: "Shift",
        17: "Ctrl",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Esc",
        32: "Space",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "Left",
        38: "Up",
        39: "Right",
        40: "Down",
        44: "PrintScrn",
        45: "Insert",
        46: "Delete",
        59: ";",
        61: "=",
        91: "Mod",
        92: "Mod",
        93: "Mod",
        106: "*",
        107: "=",
        109: "-",
        110: ".",
        111: "/",
        145: "ScrollLock",
        173: "-",
        186: ";",
        187: "=",
        188: ",",
        189: "-",
        190: ".",
        191: "/",
        192: "`",
        219: "[",
        220: "\\",
        221: "]",
        222: "'",
        224: "Mod",
        63232: "Up",
        63233: "Down",
        63234: "Left",
        63235: "Right",
        63272: "Delete",
        63273: "Home",
        63275: "End",
        63276: "PageUp",
        63277: "PageDown",
        63302: "Insert"
      }, wi = 0; wi < 10; wi++)
        dr[wi + 48] = dr[wi + 96] = String(wi);
      for (var nn = 65; nn <= 90; nn++)
        dr[nn] = String.fromCharCode(nn);
      for (var ki = 1; ki <= 12; ki++)
        dr[ki + 111] = dr[ki + 63235] = "F" + ki;
      var ir = {};
      ir.basic = {
        Left: "goCharLeft",
        Right: "goCharRight",
        Up: "goLineUp",
        Down: "goLineDown",
        End: "goLineEnd",
        Home: "goLineStartSmart",
        PageUp: "goPageUp",
        PageDown: "goPageDown",
        Delete: "delCharAfter",
        Backspace: "delCharBefore",
        "Shift-Backspace": "delCharBefore",
        Tab: "defaultTab",
        "Shift-Tab": "indentAuto",
        Enter: "newlineAndIndent",
        Insert: "toggleOverwrite",
        Esc: "singleSelection"
      }, ir.pcDefault = {
        "Ctrl-A": "selectAll",
        "Ctrl-D": "deleteLine",
        "Ctrl-Z": "undo",
        "Shift-Ctrl-Z": "redo",
        "Ctrl-Y": "redo",
        "Ctrl-Home": "goDocStart",
        "Ctrl-End": "goDocEnd",
        "Ctrl-Up": "goLineUp",
        "Ctrl-Down": "goLineDown",
        "Ctrl-Left": "goGroupLeft",
        "Ctrl-Right": "goGroupRight",
        "Alt-Left": "goLineStart",
        "Alt-Right": "goLineEnd",
        "Ctrl-Backspace": "delGroupBefore",
        "Ctrl-Delete": "delGroupAfter",
        "Ctrl-S": "save",
        "Ctrl-F": "find",
        "Ctrl-G": "findNext",
        "Shift-Ctrl-G": "findPrev",
        "Shift-Ctrl-F": "replace",
        "Shift-Ctrl-R": "replaceAll",
        "Ctrl-[": "indentLess",
        "Ctrl-]": "indentMore",
        "Ctrl-U": "undoSelection",
        "Shift-Ctrl-U": "redoSelection",
        "Alt-U": "redoSelection",
        fallthrough: "basic"
      }, ir.emacsy = {
        "Ctrl-F": "goCharRight",
        "Ctrl-B": "goCharLeft",
        "Ctrl-P": "goLineUp",
        "Ctrl-N": "goLineDown",
        "Ctrl-A": "goLineStart",
        "Ctrl-E": "goLineEnd",
        "Ctrl-V": "goPageDown",
        "Shift-Ctrl-V": "goPageUp",
        "Ctrl-D": "delCharAfter",
        "Ctrl-H": "delCharBefore",
        "Alt-Backspace": "delWordBefore",
        "Ctrl-K": "killLine",
        "Ctrl-T": "transposeChars",
        "Ctrl-O": "openLine"
      }, ir.macDefault = {
        "Cmd-A": "selectAll",
        "Cmd-D": "deleteLine",
        "Cmd-Z": "undo",
        "Shift-Cmd-Z": "redo",
        "Cmd-Y": "redo",
        "Cmd-Home": "goDocStart",
        "Cmd-Up": "goDocStart",
        "Cmd-End": "goDocEnd",
        "Cmd-Down": "goDocEnd",
        "Alt-Left": "goGroupLeft",
        "Alt-Right": "goGroupRight",
        "Cmd-Left": "goLineLeft",
        "Cmd-Right": "goLineRight",
        "Alt-Backspace": "delGroupBefore",
        "Ctrl-Alt-Backspace": "delGroupAfter",
        "Alt-Delete": "delGroupAfter",
        "Cmd-S": "save",
        "Cmd-F": "find",
        "Cmd-G": "findNext",
        "Shift-Cmd-G": "findPrev",
        "Cmd-Alt-F": "replace",
        "Shift-Cmd-Alt-F": "replaceAll",
        "Cmd-[": "indentLess",
        "Cmd-]": "indentMore",
        "Cmd-Backspace": "delWrappedLineLeft",
        "Cmd-Delete": "delWrappedLineRight",
        "Cmd-U": "undoSelection",
        "Shift-Cmd-U": "redoSelection",
        "Ctrl-Up": "goDocStart",
        "Ctrl-Down": "goDocEnd",
        fallthrough: ["basic", "emacsy"]
      }, ir.default = j ? ir.macDefault : ir.pcDefault;
      function bs(e) {
        var t = e.split(/-(?!$)/);
        e = t[t.length - 1];
        for (var i, r, n, a, l = 0; l < t.length - 1; l++) {
          var u = t[l];
          if (/^(cmd|meta|m)$/i.test(u))
            a = !0;
          else if (/^a(lt)?$/i.test(u))
            i = !0;
          else if (/^(c|ctrl|control)$/i.test(u))
            r = !0;
          else if (/^s(hift)?$/i.test(u))
            n = !0;
          else
            throw new Error("Unrecognized modifier name: " + u);
        }
        return i && (e = "Alt-" + e), r && (e = "Ctrl-" + e), a && (e = "Cmd-" + e), n && (e = "Shift-" + e), e;
      }
      function Cs(e) {
        var t = {};
        for (var i in e)
          if (e.hasOwnProperty(i)) {
            var r = e[i];
            if (/^(name|fallthrough|(de|at)tach)$/.test(i))
              continue;
            if (r == "...") {
              delete e[i];
              continue;
            }
            for (var n = ot(i.split(" "), bs), a = 0; a < n.length; a++) {
              var l = void 0, u = void 0;
              a == n.length - 1 ? (u = n.join(" "), l = r) : (u = n.slice(0, a + 1).join(" "), l = "...");
              var s = t[u];
              if (!s)
                t[u] = l;
              else if (s != l)
                throw new Error("Inconsistent bindings for " + u);
            }
            delete e[i];
          }
        for (var c in t)
          e[c] = t[c];
        return e;
      }
      function Xr(e, t, i, r) {
        t = an(t);
        var n = t.call ? t.call(e, r) : t[e];
        if (n === !1)
          return "nothing";
        if (n === "...")
          return "multi";
        if (n != null && i(n))
          return "handled";
        if (t.fallthrough) {
          if (Object.prototype.toString.call(t.fallthrough) != "[object Array]")
            return Xr(e, t.fallthrough, i, r);
          for (var a = 0; a < t.fallthrough.length; a++) {
            var l = Xr(e, t.fallthrough[a], i, r);
            if (l)
              return l;
          }
        }
      }
      function Xl(e) {
        var t = typeof e == "string" ? e : dr[e.keyCode];
        return t == "Ctrl" || t == "Alt" || t == "Shift" || t == "Mod";
      }
      function Yl(e, t, i) {
        var r = e;
        return t.altKey && r != "Alt" && (e = "Alt-" + e), (me ? t.metaKey : t.ctrlKey) && r != "Ctrl" && (e = "Ctrl-" + e), (me ? t.ctrlKey : t.metaKey) && r != "Mod" && (e = "Cmd-" + e), !i && t.shiftKey && r != "Shift" && (e = "Shift-" + e), e;
      }
      function Zl(e, t) {
        if (ie && e.keyCode == 34 && e.char)
          return !1;
        var i = dr[e.keyCode];
        return i == null || e.altGraphKey ? !1 : (e.keyCode == 3 && e.code && (i = e.code), Yl(i, e, t));
      }
      function an(e) {
        return typeof e == "string" ? ir[e] : e;
      }
      function Yr(e, t) {
        for (var i = e.doc.sel.ranges, r = [], n = 0; n < i.length; n++) {
          for (var a = t(i[n]); r.length && Ne(a.from, xe(r).to) <= 0; ) {
            var l = r.pop();
            if (Ne(l.from, a.from) < 0) {
              a.from = l.from;
              break;
            }
          }
          r.push(a);
        }
        Ot(e, function() {
          for (var u = r.length - 1; u >= 0; u--)
            jr(e.doc, "", r[u].from, r[u].to, "+delete");
          Wr(e);
        });
      }
      function Vn(e, t, i) {
        var r = f(e.text, t + i, i);
        return r < 0 || r > e.text.length ? null : r;
      }
      function ea(e, t, i) {
        var r = Vn(e, t.ch, i);
        return r == null ? null : new $(t.line, r, i < 0 ? "after" : "before");
      }
      function ta(e, t, i, r, n) {
        if (e) {
          t.doc.direction == "rtl" && (n = -n);
          var a = y(i, t.doc.direction);
          if (a) {
            var l = n < 0 ? xe(a) : a[0], u = n < 0 == (l.level == 1), s = u ? "after" : "before", c;
            if (l.level > 0 || t.doc.direction == "rtl") {
              var g = Hr(t, i);
              c = n < 0 ? i.text.length - 1 : 0;
              var m = Jt(t, g, c).top;
              c = v(function(L) {
                return Jt(t, g, L).top == m;
              }, n < 0 == (l.level == 1) ? l.from : l.to - 1, c), s == "before" && (c = Vn(i, c, 1));
            } else
              c = n < 0 ? l.to : l.from;
            return new $(r, c, s);
          }
        }
        return new $(r, n < 0 ? i.text.length : 0, n < 0 ? "before" : "after");
      }
      function ws(e, t, i, r) {
        var n = y(t, e.doc.direction);
        if (!n)
          return ea(t, i, r);
        i.ch >= t.text.length ? (i.ch = t.text.length, i.sticky = "before") : i.ch <= 0 && (i.ch = 0, i.sticky = "after");
        var a = M(n, i.ch, i.sticky), l = n[a];
        if (e.doc.direction == "ltr" && l.level % 2 == 0 && (r > 0 ? l.to > i.ch : l.from < i.ch))
          return ea(t, i, r);
        var u = function(le, he) {
          return Vn(t, le instanceof $ ? le.ch : le, he);
        }, s, c = function(le) {
          return e.options.lineWrapping ? (s = s || Hr(e, t), el(e, t, s, le)) : { begin: 0, end: t.text.length };
        }, g = c(i.sticky == "before" ? u(i, -1) : i.ch);
        if (e.doc.direction == "rtl" || l.level == 1) {
          var m = l.level == 1 == r < 0, L = u(i, m ? 1 : -1);
          if (L != null && (m ? L <= l.to && L <= g.end : L >= l.from && L >= g.begin)) {
            var S = m ? "before" : "after";
            return new $(i.line, L, S);
          }
        }
        var U = function(le, he, oe) {
          for (var pe = function(Qe, vt) {
            return vt ? new $(i.line, u(Qe, 1), "before") : new $(i.line, Qe, "after");
          }; le >= 0 && le < n.length; le += he) {
            var Fe = n[le], we = he > 0 == (Fe.level != 1), Re = we ? oe.begin : u(oe.end, -1);
            if (Fe.from <= Re && Re < Fe.to || (Re = we ? Fe.from : u(Fe.to, -1), oe.begin <= Re && Re < oe.end))
              return pe(Re, we);
          }
        }, Y = U(a + r, r, g);
        if (Y)
          return Y;
        var V = r > 0 ? g.end : u(g.begin, -1);
        return V != null && !(r > 0 && V == t.text.length) && (Y = U(r > 0 ? 0 : n.length - 1, r, c(V)), Y) ? Y : null;
      }
      var Si = {
        selectAll: Nl,
        singleSelection: function(e) {
          return e.setSelection(e.getCursor("anchor"), e.getCursor("head"), at);
        },
        killLine: function(e) {
          return Yr(e, function(t) {
            if (t.empty()) {
              var i = be(e.doc, t.head.line).text.length;
              return t.head.ch == i && t.head.line < e.lastLine() ? { from: t.head, to: $(t.head.line + 1, 0) } : { from: t.head, to: $(t.head.line, i) };
            } else
              return { from: t.from(), to: t.to() };
          });
        },
        deleteLine: function(e) {
          return Yr(e, function(t) {
            return {
              from: $(t.from().line, 0),
              to: Oe(e.doc, $(t.to().line + 1, 0))
            };
          });
        },
        delLineLeft: function(e) {
          return Yr(e, function(t) {
            return {
              from: $(t.from().line, 0),
              to: t.from()
            };
          });
        },
        delWrappedLineLeft: function(e) {
          return Yr(e, function(t) {
            var i = e.charCoords(t.head, "div").top + 5, r = e.coordsChar({ left: 0, top: i }, "div");
            return { from: r, to: t.from() };
          });
        },
        delWrappedLineRight: function(e) {
          return Yr(e, function(t) {
            var i = e.charCoords(t.head, "div").top + 5, r = e.coordsChar({ left: e.display.lineDiv.offsetWidth + 100, top: i }, "div");
            return { from: t.from(), to: r };
          });
        },
        undo: function(e) {
          return e.undo();
        },
        redo: function(e) {
          return e.redo();
        },
        undoSelection: function(e) {
          return e.undoSelection();
        },
        redoSelection: function(e) {
          return e.redoSelection();
        },
        goDocStart: function(e) {
          return e.extendSelection($(e.firstLine(), 0));
        },
        goDocEnd: function(e) {
          return e.extendSelection($(e.lastLine()));
        },
        goLineStart: function(e) {
          return e.extendSelectionsBy(
            function(t) {
              return Ql(e, t.head.line);
            },
            { origin: "+move", bias: 1 }
          );
        },
        goLineStartSmart: function(e) {
          return e.extendSelectionsBy(
            function(t) {
              return Jl(e, t.head);
            },
            { origin: "+move", bias: 1 }
          );
        },
        goLineEnd: function(e) {
          return e.extendSelectionsBy(
            function(t) {
              return ks(e, t.head.line);
            },
            { origin: "+move", bias: -1 }
          );
        },
        goLineRight: function(e) {
          return e.extendSelectionsBy(function(t) {
            var i = e.cursorCoords(t.head, "div").top + 5;
            return e.coordsChar({ left: e.display.lineDiv.offsetWidth + 100, top: i }, "div");
          }, Dt);
        },
        goLineLeft: function(e) {
          return e.extendSelectionsBy(function(t) {
            var i = e.cursorCoords(t.head, "div").top + 5;
            return e.coordsChar({ left: 0, top: i }, "div");
          }, Dt);
        },
        goLineLeftSmart: function(e) {
          return e.extendSelectionsBy(function(t) {
            var i = e.cursorCoords(t.head, "div").top + 5, r = e.coordsChar({ left: 0, top: i }, "div");
            return r.ch < e.getLine(r.line).search(/\S/) ? Jl(e, t.head) : r;
          }, Dt);
        },
        goLineUp: function(e) {
          return e.moveV(-1, "line");
        },
        goLineDown: function(e) {
          return e.moveV(1, "line");
        },
        goPageUp: function(e) {
          return e.moveV(-1, "page");
        },
        goPageDown: function(e) {
          return e.moveV(1, "page");
        },
        goCharLeft: function(e) {
          return e.moveH(-1, "char");
        },
        goCharRight: function(e) {
          return e.moveH(1, "char");
        },
        goColumnLeft: function(e) {
          return e.moveH(-1, "column");
        },
        goColumnRight: function(e) {
          return e.moveH(1, "column");
        },
        goWordLeft: function(e) {
          return e.moveH(-1, "word");
        },
        goGroupRight: function(e) {
          return e.moveH(1, "group");
        },
        goGroupLeft: function(e) {
          return e.moveH(-1, "group");
        },
        goWordRight: function(e) {
          return e.moveH(1, "word");
        },
        delCharBefore: function(e) {
          return e.deleteH(-1, "codepoint");
        },
        delCharAfter: function(e) {
          return e.deleteH(1, "char");
        },
        delWordBefore: function(e) {
          return e.deleteH(-1, "word");
        },
        delWordAfter: function(e) {
          return e.deleteH(1, "word");
        },
        delGroupBefore: function(e) {
          return e.deleteH(-1, "group");
        },
        delGroupAfter: function(e) {
          return e.deleteH(1, "group");
        },
        indentAuto: function(e) {
          return e.indentSelection("smart");
        },
        indentMore: function(e) {
          return e.indentSelection("add");
        },
        indentLess: function(e) {
          return e.indentSelection("subtract");
        },
        insertTab: function(e) {
          return e.replaceSelection("	");
        },
        insertSoftTab: function(e) {
          for (var t = [], i = e.listSelections(), r = e.options.tabSize, n = 0; n < i.length; n++) {
            var a = i[n].from(), l = Ke(e.getLine(a.line), a.ch, r);
            t.push(Ht(r - l % r));
          }
          e.replaceSelections(t);
        },
        defaultTab: function(e) {
          e.somethingSelected() ? e.indentSelection("add") : e.execCommand("insertTab");
        },
        // Swap the two chars left and right of each selection's head.
        // Move cursor behind the two swapped characters afterwards.
        //
        // Doesn't consider line feeds a character.
        // Doesn't scan more than one line above to find a character.
        // Doesn't do anything on an empty line.
        // Doesn't do anything with non-empty selections.
        transposeChars: function(e) {
          return Ot(e, function() {
            for (var t = e.listSelections(), i = [], r = 0; r < t.length; r++)
              if (t[r].empty()) {
                var n = t[r].head, a = be(e.doc, n.line).text;
                if (a) {
                  if (n.ch == a.length && (n = new $(n.line, n.ch - 1)), n.ch > 0)
                    n = new $(n.line, n.ch + 1), e.replaceRange(
                      a.charAt(n.ch - 1) + a.charAt(n.ch - 2),
                      $(n.line, n.ch - 2),
                      n,
                      "+transpose"
                    );
                  else if (n.line > e.doc.first) {
                    var l = be(e.doc, n.line - 1).text;
                    l && (n = new $(n.line, 1), e.replaceRange(
                      a.charAt(0) + e.doc.lineSeparator() + l.charAt(l.length - 1),
                      $(n.line - 1, l.length - 1),
                      n,
                      "+transpose"
                    ));
                  }
                }
                i.push(new qe(n, n));
              }
            e.setSelections(i);
          });
        },
        newlineAndIndent: function(e) {
          return Ot(e, function() {
            for (var t = e.listSelections(), i = t.length - 1; i >= 0; i--)
              e.replaceRange(e.doc.lineSeparator(), t[i].anchor, t[i].head, "+input");
            t = e.listSelections();
            for (var r = 0; r < t.length; r++)
              e.indentLine(t[r].from().line, null, !0);
            Wr(e);
          });
        },
        openLine: function(e) {
          return e.replaceSelection(`
`, "start");
        },
        toggleOverwrite: function(e) {
          return e.toggleOverwrite();
        }
      };
      function Ql(e, t) {
        var i = be(e.doc, t), r = Ut(i);
        return r != i && (t = Ge(r)), ta(!0, e, r, t, 1);
      }
      function ks(e, t) {
        var i = be(e.doc, t), r = ou(i);
        return r != i && (t = Ge(r)), ta(!0, e, i, t, -1);
      }
      function Jl(e, t) {
        var i = Ql(e, t.line), r = be(e.doc, i.line), n = y(r, e.doc.direction);
        if (!n || n[0].level == 0) {
          var a = Math.max(i.ch, r.text.search(/\S/)), l = t.line == i.line && t.ch <= a && t.ch;
          return $(i.line, l ? 0 : a, i.sticky);
        }
        return i;
      }
      function ln(e, t, i) {
        if (typeof t == "string" && (t = Si[t], !t))
          return !1;
        e.display.input.ensurePolled();
        var r = e.display.shift, n = !1;
        try {
          e.isReadOnly() && (e.state.suppressEdits = !0), i && (e.display.shift = !1), n = t(e) != Ve;
        } finally {
          e.display.shift = r, e.state.suppressEdits = !1;
        }
        return n;
      }
      function Ss(e, t, i) {
        for (var r = 0; r < e.state.keyMaps.length; r++) {
          var n = Xr(t, e.state.keyMaps[r], i, e);
          if (n)
            return n;
        }
        return e.options.extraKeys && Xr(t, e.options.extraKeys, i, e) || Xr(t, e.options.keyMap, i, e);
      }
      var Fs = new Ye();
      function Fi(e, t, i, r) {
        var n = e.state.keySeq;
        if (n) {
          if (Xl(t))
            return "handled";
          if (/\'$/.test(t) ? e.state.keySeq = null : Fs.set(50, function() {
            e.state.keySeq == n && (e.state.keySeq = null, e.display.input.reset());
          }), $l(e, n + " " + t, i, r))
            return !0;
        }
        return $l(e, t, i, r);
      }
      function $l(e, t, i, r) {
        var n = Ss(e, t, r);
        return n == "multi" && (e.state.keySeq = t), n == "handled" && dt(e, "keyHandled", e, t, i), (n == "handled" || n == "multi") && (Ae(i), Rn(e)), !!n;
      }
      function Vl(e, t) {
        var i = Zl(t, !0);
        return i ? t.shiftKey && !e.state.keySeq ? Fi(e, "Shift-" + i, t, function(r) {
          return ln(e, r, !0);
        }) || Fi(e, i, t, function(r) {
          if (typeof r == "string" ? /^go[A-Z]/.test(r) : r.motion)
            return ln(e, r);
        }) : Fi(e, i, t, function(r) {
          return ln(e, r);
        }) : !1;
      }
      function As(e, t, i) {
        return Fi(e, "'" + i + "'", t, function(r) {
          return ln(e, r, !0);
        });
      }
      var ra = null;
      function eo(e) {
        var t = this;
        if (!(e.target && e.target != t.display.input.getField()) && (t.curOp.focus = We(G(t)), !te(t, e))) {
          T && P < 11 && e.keyCode == 27 && (e.returnValue = !1);
          var i = e.keyCode;
          t.display.shift = i == 16 || e.shiftKey;
          var r = Vl(t, e);
          ie && (ra = r ? i : null, !r && i == 88 && !xt && (j ? e.metaKey : e.ctrlKey) && t.replaceSelection("", null, "cut")), N && !j && !r && i == 46 && e.shiftKey && !e.ctrlKey && document.execCommand && document.execCommand("cut"), i == 18 && !/\bCodeMirror-crosshair\b/.test(t.display.lineDiv.className) && Es(t);
        }
      }
      function Es(e) {
        var t = e.display.lineDiv;
        rt(t, "CodeMirror-crosshair");
        function i(r) {
          (r.keyCode == 18 || !r.altKey) && (Le(t, "CodeMirror-crosshair"), ge(document, "keyup", i), ge(document, "mouseover", i));
        }
        A(document, "keyup", i), A(document, "mouseover", i);
      }
      function to(e) {
        e.keyCode == 16 && (this.doc.sel.shift = !1), te(this, e);
      }
      function ro(e) {
        var t = this;
        if (!(e.target && e.target != t.display.input.getField()) && !(tr(t.display, e) || te(t, e) || e.ctrlKey && !e.altKey || j && e.metaKey)) {
          var i = e.keyCode, r = e.charCode;
          if (ie && i == ra) {
            ra = null, Ae(e);
            return;
          }
          if (!(ie && (!e.which || e.which < 10) && Vl(t, e))) {
            var n = String.fromCharCode(r ?? i);
            n != "\b" && (As(t, e, n) || t.display.input.onKeyPress(e));
          }
        }
      }
      var Ls = 400, ia = function(e, t, i) {
        this.time = e, this.pos = t, this.button = i;
      };
      ia.prototype.compare = function(e, t, i) {
        return this.time + Ls > e && Ne(t, this.pos) == 0 && i == this.button;
      };
      var Ai, Ei;
      function Ts(e, t) {
        var i = +/* @__PURE__ */ new Date();
        return Ei && Ei.compare(i, e, t) ? (Ai = Ei = null, "triple") : Ai && Ai.compare(i, e, t) ? (Ei = new ia(i, e, t), Ai = null, "double") : (Ai = new ia(i, e, t), Ei = null, "single");
      }
      function io(e) {
        var t = this, i = t.display;
        if (!(te(t, e) || i.activeTouch && i.input.supportsTouch())) {
          if (i.input.ensurePolled(), i.shift = e.shiftKey, tr(i, e)) {
            re || (i.scroller.draggable = !1, setTimeout(function() {
              return i.scroller.draggable = !0;
            }, 100));
            return;
          }
          if (!na(t, e)) {
            var r = br(t, e), n = bt(e), a = r ? Ts(r, n) : "single";
            Te(t).focus(), n == 1 && t.state.selectingText && t.state.selectingText(e), !(r && Bs(t, n, r, a, e)) && (n == 1 ? r ? Ns(t, r, a, e) : kt(e) == i.scroller && Ae(e) : n == 2 ? (r && Vi(t.doc, r), setTimeout(function() {
              return i.input.focus();
            }, 20)) : n == 3 && (Ue ? t.display.input.onContextMenu(e) : Pn(t)));
          }
        }
      }
      function Bs(e, t, i, r, n) {
        var a = "Click";
        return r == "double" ? a = "Double" + a : r == "triple" && (a = "Triple" + a), a = (t == 1 ? "Left" : t == 2 ? "Middle" : "Right") + a, Fi(e, Yl(a, n), n, function(l) {
          if (typeof l == "string" && (l = Si[l]), !l)
            return !1;
          var u = !1;
          try {
            e.isReadOnly() && (e.state.suppressEdits = !0), u = l(e, i) != Ve;
          } finally {
            e.state.suppressEdits = !1;
          }
          return u;
        });
      }
      function Ms(e, t, i) {
        var r = e.getOption("configureMouse"), n = r ? r(e, t, i) : {};
        if (n.unit == null) {
          var a = ue ? i.shiftKey && i.metaKey : i.altKey;
          n.unit = a ? "rectangle" : t == "single" ? "char" : t == "double" ? "word" : "line";
        }
        return (n.extend == null || e.doc.extend) && (n.extend = e.doc.extend || i.shiftKey), n.addNew == null && (n.addNew = j ? i.metaKey : i.ctrlKey), n.moveOnDrag == null && (n.moveOnDrag = !(j ? i.altKey : i.ctrlKey)), n;
      }
      function Ns(e, t, i, r) {
        T ? setTimeout(Je(nl, e), 0) : e.curOp.focus = We(G(e));
        var n = Ms(e, i, r), a = e.doc.sel, l;
        e.options.dragDrop && Lr && !e.isReadOnly() && i == "single" && (l = a.contains(t)) > -1 && (Ne((l = a.ranges[l]).from(), t) < 0 || t.xRel > 0) && (Ne(l.to(), t) > 0 || t.xRel < 0) ? Os(e, r, t, n) : Is(e, r, t, n);
      }
      function Os(e, t, i, r) {
        var n = e.display, a = !1, l = pt(e, function(c) {
          re && (n.scroller.draggable = !1), e.state.draggingText = !1, e.state.delayingBlurEvent && (e.hasFocus() ? e.state.delayingBlurEvent = !1 : Pn(e)), ge(n.wrapper.ownerDocument, "mouseup", l), ge(n.wrapper.ownerDocument, "mousemove", u), ge(n.scroller, "dragstart", s), ge(n.scroller, "drop", l), a || (Ae(c), r.addNew || Vi(e.doc, i, null, null, r.extend), re && !Se || T && P == 9 ? setTimeout(function() {
            n.wrapper.ownerDocument.body.focus({ preventScroll: !0 }), n.input.focus();
          }, 20) : n.input.focus());
        }), u = function(c) {
          a = a || Math.abs(t.clientX - c.clientX) + Math.abs(t.clientY - c.clientY) >= 10;
        }, s = function() {
          return a = !0;
        };
        re && (n.scroller.draggable = !0), e.state.draggingText = l, l.copy = !r.moveOnDrag, A(n.wrapper.ownerDocument, "mouseup", l), A(n.wrapper.ownerDocument, "mousemove", u), A(n.scroller, "dragstart", s), A(n.scroller, "drop", l), e.state.delayingBlurEvent = !0, setTimeout(function() {
          return n.input.focus();
        }, 20), n.scroller.dragDrop && n.scroller.dragDrop();
      }
      function no(e, t, i) {
        if (i == "char")
          return new qe(t, t);
        if (i == "word")
          return e.findWordAt(t);
        if (i == "line")
          return new qe($(t.line, 0), Oe(e.doc, $(t.line + 1, 0)));
        var r = i(e, t);
        return new qe(r.from, r.to);
      }
      function Is(e, t, i, r) {
        T && Pn(e);
        var n = e.display, a = e.doc;
        Ae(t);
        var l, u, s = a.sel, c = s.ranges;
        if (r.addNew && !r.extend ? (u = a.sel.contains(i), u > -1 ? l = c[u] : l = new qe(i, i)) : (l = a.sel.primary(), u = a.sel.primIndex), r.unit == "rectangle")
          r.addNew || (l = new qe(i, i)), i = br(e, t, !0, !0), u = -1;
        else {
          var g = no(e, i, r.unit);
          r.extend ? l = Jn(l, g.anchor, g.head, r.extend) : l = g;
        }
        r.addNew ? u == -1 ? (u = c.length, Ct(
          a,
          jt(e, c.concat([l]), u),
          { scroll: !1, origin: "*mouse" }
        )) : c.length > 1 && c[u].empty() && r.unit == "char" && !r.extend ? (Ct(
          a,
          jt(e, c.slice(0, u).concat(c.slice(u + 1)), 0),
          { scroll: !1, origin: "*mouse" }
        ), s = a.sel) : $n(a, u, l, Ce) : (u = 0, Ct(a, new Pt([l], 0), Ce), s = a.sel);
        var m = i;
        function L(oe) {
          if (Ne(m, oe) != 0)
            if (m = oe, r.unit == "rectangle") {
              for (var pe = [], Fe = e.options.tabSize, we = Ke(be(a, i.line).text, i.ch, Fe), Re = Ke(be(a, oe.line).text, oe.ch, Fe), Qe = Math.min(we, Re), vt = Math.max(we, Re), tt = Math.min(i.line, oe.line), It = Math.min(e.lastLine(), Math.max(i.line, oe.line)); tt <= It; tt++) {
                var Tt = be(a, tt).text, ft = At(Tt, Qe, Fe);
                Qe == vt ? pe.push(new qe($(tt, ft), $(tt, ft))) : Tt.length > ft && pe.push(new qe($(tt, ft), $(tt, At(Tt, vt, Fe))));
              }
              pe.length || pe.push(new qe(i, i)), Ct(
                a,
                jt(e, s.ranges.slice(0, u).concat(pe), u),
                { origin: "*mouse", scroll: !1 }
              ), e.scrollIntoView(oe);
            } else {
              var Bt = l, yt = no(e, oe, r.unit), ht = Bt.anchor, ct;
              Ne(yt.anchor, ht) > 0 ? (ct = yt.head, ht = Ni(Bt.from(), yt.anchor)) : (ct = yt.anchor, ht = Mi(Bt.to(), yt.head));
              var nt = s.ranges.slice(0);
              nt[u] = Hs(e, new qe(Oe(a, ht), ct)), Ct(a, jt(e, nt, u), Ce);
            }
        }
        var S = n.wrapper.getBoundingClientRect(), U = 0;
        function Y(oe) {
          var pe = ++U, Fe = br(e, oe, !0, r.unit == "rectangle");
          if (Fe)
            if (Ne(Fe, m) != 0) {
              e.curOp.focus = We(G(e)), L(Fe);
              var we = Xi(n, a);
              (Fe.line >= we.to || Fe.line < we.from) && setTimeout(pt(e, function() {
                U == pe && Y(oe);
              }), 150);
            } else {
              var Re = oe.clientY < S.top ? -20 : oe.clientY > S.bottom ? 20 : 0;
              Re && setTimeout(pt(e, function() {
                U == pe && (n.scroller.scrollTop += Re, Y(oe));
              }), 50);
            }
        }
        function V(oe) {
          e.state.selectingText = !1, U = 1 / 0, oe && (Ae(oe), n.input.focus()), ge(n.wrapper.ownerDocument, "mousemove", le), ge(n.wrapper.ownerDocument, "mouseup", he), a.history.lastSelOrigin = null;
        }
        var le = pt(e, function(oe) {
          oe.buttons === 0 || !bt(oe) ? V(oe) : Y(oe);
        }), he = pt(e, V);
        e.state.selectingText = he, A(n.wrapper.ownerDocument, "mousemove", le), A(n.wrapper.ownerDocument, "mouseup", he);
      }
      function Hs(e, t) {
        var i = t.anchor, r = t.head, n = be(e.doc, i.line);
        if (Ne(i, r) == 0 && i.sticky == r.sticky)
          return t;
        var a = y(n);
        if (!a)
          return t;
        var l = M(a, i.ch, i.sticky), u = a[l];
        if (u.from != i.ch && u.to != i.ch)
          return t;
        var s = l + (u.from == i.ch == (u.level != 1) ? 0 : 1);
        if (s == 0 || s == a.length)
          return t;
        var c;
        if (r.line != i.line)
          c = (r.line - i.line) * (e.doc.direction == "ltr" ? 1 : -1) > 0;
        else {
          var g = M(a, r.ch, r.sticky), m = g - l || (r.ch - i.ch) * (u.level == 1 ? -1 : 1);
          g == s - 1 || g == s ? c = m < 0 : c = m > 0;
        }
        var L = a[s + (c ? -1 : 0)], S = c == (L.level == 1), U = S ? L.from : L.to, Y = S ? "after" : "before";
        return i.ch == U && i.sticky == Y ? t : new qe(new $(i.line, U, Y), r);
      }
      function ao(e, t, i, r) {
        var n, a;
        if (t.touches)
          n = t.touches[0].clientX, a = t.touches[0].clientY;
        else
          try {
            n = t.clientX, a = t.clientY;
          } catch {
            return !1;
          }
        if (n >= Math.floor(e.display.gutters.getBoundingClientRect().right))
          return !1;
        r && Ae(t);
        var l = e.display, u = l.lineDiv.getBoundingClientRect();
        if (a > u.bottom || !Me(e, i))
          return Ze(t);
        a -= u.top - l.viewOffset;
        for (var s = 0; s < e.display.gutterSpecs.length; ++s) {
          var c = l.gutters.childNodes[s];
          if (c && c.getBoundingClientRect().right >= n) {
            var g = xr(e.doc, a), m = e.display.gutterSpecs[s];
            return ve(e, i, e, g, m.className, t), Ze(t);
          }
        }
      }
      function na(e, t) {
        return ao(e, t, "gutterClick", !0);
      }
      function lo(e, t) {
        tr(e.display, t) || Rs(e, t) || te(e, t, "contextmenu") || Ue || e.display.input.onContextMenu(t);
      }
      function Rs(e, t) {
        return Me(e, "gutterContextMenu") ? ao(e, t, "gutterContextMenu", !1) : !1;
      }
      function oo(e) {
        e.display.wrapper.className = e.display.wrapper.className.replace(/\s*cm-s-\S+/g, "") + e.options.theme.replace(/(^|\s)\s*/g, " cm-s-"), ui(e);
      }
      var Zr = { toString: function() {
        return "CodeMirror.Init";
      } }, uo = {}, on = {};
      function Ps(e) {
        var t = e.optionHandlers;
        function i(r, n, a, l) {
          e.defaults[r] = n, a && (t[r] = l ? function(u, s, c) {
            c != Zr && a(u, s, c);
          } : a);
        }
        e.defineOption = i, e.Init = Zr, i("value", "", function(r, n) {
          return r.setValue(n);
        }, !0), i("mode", null, function(r, n) {
          r.doc.modeOption = n, Yn(r);
        }, !0), i("indentUnit", 2, Yn, !0), i("indentWithTabs", !1), i("smartIndent", !0), i("tabSize", 4, function(r) {
          vi(r), ui(r), Et(r);
        }, !0), i("lineSeparator", null, function(r, n) {
          if (r.doc.lineSep = n, !!n) {
            var a = [], l = r.doc.first;
            r.doc.iter(function(s) {
              for (var c = 0; ; ) {
                var g = s.text.indexOf(n, c);
                if (g == -1)
                  break;
                c = g + n.length, a.push($(l, g));
              }
              l++;
            });
            for (var u = a.length - 1; u >= 0; u--)
              jr(r.doc, n, a[u], $(a[u].line, a[u].ch + n.length));
          }
        }), i("specialChars", /[\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b\u200e\u200f\u2028\u2029\u202d\u202e\u2066\u2067\u2069\ufeff\ufff9-\ufffc]/g, function(r, n, a) {
          r.state.specialChars = new RegExp(n.source + (n.test("	") ? "" : "|	"), "g"), a != Zr && r.refresh();
        }), i("specialCharPlaceholder", du, function(r) {
          return r.refresh();
        }, !0), i("electricChars", !0), i("inputStyle", q ? "contenteditable" : "textarea", function() {
          throw new Error("inputStyle can not (yet) be changed in a running editor");
        }, !0), i("spellcheck", !1, function(r, n) {
          return r.getInputField().spellcheck = n;
        }, !0), i("autocorrect", !1, function(r, n) {
          return r.getInputField().autocorrect = n;
        }, !0), i("autocapitalize", !1, function(r, n) {
          return r.getInputField().autocapitalize = n;
        }, !0), i("rtlMoveVisually", !Z), i("wholeLineUpdateBefore", !0), i("theme", "default", function(r) {
          oo(r), gi(r);
        }, !0), i("keyMap", "default", function(r, n, a) {
          var l = an(n), u = a != Zr && an(a);
          u && u.detach && u.detach(r, l), l.attach && l.attach(r, u || null);
        }), i("extraKeys", null), i("configureMouse", null), i("lineWrapping", !1, Ws, !0), i("gutters", [], function(r, n) {
          r.display.gutterSpecs = Kn(n, r.options.lineNumbers), gi(r);
        }, !0), i("fixedGutter", !0, function(r, n) {
          r.display.gutters.style.left = n ? On(r.display) + "px" : "0", r.refresh();
        }, !0), i("coverGutterNextToScrollbar", !1, function(r) {
          return _r(r);
        }, !0), i("scrollbarStyle", "native", function(r) {
          fl(r), _r(r), r.display.scrollbars.setScrollTop(r.doc.scrollTop), r.display.scrollbars.setScrollLeft(r.doc.scrollLeft);
        }, !0), i("lineNumbers", !1, function(r, n) {
          r.display.gutterSpecs = Kn(r.options.gutters, n), gi(r);
        }, !0), i("firstLineNumber", 1, gi, !0), i("lineNumberFormatter", function(r) {
          return r;
        }, gi, !0), i("showCursorWhenSelecting", !1, si, !0), i("resetSelectionOnContextMenu", !0), i("lineWiseCopyCut", !0), i("pasteLinesPerSelection", !0), i("selectionsMayTouch", !1), i("readOnly", !1, function(r, n) {
          n == "nocursor" && (zr(r), r.display.input.blur()), r.display.input.readOnlyChanged(n);
        }), i("screenReaderLabel", null, function(r, n) {
          n = n === "" ? null : n, r.display.input.screenReaderLabelChanged(n);
        }), i("disableInput", !1, function(r, n) {
          n || r.display.input.reset();
        }, !0), i("dragDrop", !0, zs), i("allowDropFileTypes", null), i("cursorBlinkRate", 530), i("cursorScrollMargin", 0), i("cursorHeight", 1, si, !0), i("singleCursorHeightPerLine", !0, si, !0), i("workTime", 100), i("workDelay", 100), i("flattenSpans", !0, vi, !0), i("addModeClass", !1, vi, !0), i("pollInterval", 100), i("undoDepth", 200, function(r, n) {
          return r.doc.history.undoDepth = n;
        }), i("historyEventDelay", 1250), i("viewportMargin", 10, function(r) {
          return r.refresh();
        }, !0), i("maxHighlightLength", 1e4, vi, !0), i("moveInputWithCursor", !0, function(r, n) {
          n || r.display.input.resetPosition();
        }), i("tabindex", null, function(r, n) {
          return r.display.input.getField().tabIndex = n || "";
        }), i("autofocus", null), i("direction", "ltr", function(r, n) {
          return r.doc.setDirection(n);
        }, !0), i("phrases", null);
      }
      function zs(e, t, i) {
        var r = i && i != Zr;
        if (!t != !r) {
          var n = e.display.dragFunctions, a = t ? A : ge;
          a(e.display.scroller, "dragstart", n.start), a(e.display.scroller, "dragenter", n.enter), a(e.display.scroller, "dragover", n.over), a(e.display.scroller, "dragleave", n.leave), a(e.display.scroller, "drop", n.drop);
        }
      }
      function Ws(e) {
        e.options.lineWrapping ? (rt(e.display.wrapper, "CodeMirror-wrap"), e.display.sizer.style.minWidth = "", e.display.sizerWidth = null) : (Le(e.display.wrapper, "CodeMirror-wrap"), kn(e)), In(e), Et(e), ui(e), setTimeout(function() {
          return _r(e);
        }, 100);
      }
      function et(e, t) {
        var i = this;
        if (!(this instanceof et))
          return new et(e, t);
        this.options = t = t ? $e(t) : {}, $e(uo, t, !1);
        var r = t.value;
        typeof r == "string" ? r = new Lt(r, t.mode, null, t.lineSeparator, t.direction) : t.mode && (r.modeOption = t.mode), this.doc = r;
        var n = new et.inputStyles[t.inputStyle](this), a = this.display = new Vu(e, r, n, t);
        a.wrapper.CodeMirror = this, oo(this), t.lineWrapping && (this.display.wrapper.className += " CodeMirror-wrap"), fl(this), this.state = {
          keyMaps: [],
          // stores maps added by addKeyMap
          overlays: [],
          // highlighting overlays, as added by addOverlay
          modeGen: 0,
          // bumped when mode/overlay changes, used to invalidate highlighting info
          overwrite: !1,
          delayingBlurEvent: !1,
          focused: !1,
          suppressEdits: !1,
          // used to disable editing during key handlers when in readOnly mode
          pasteIncoming: -1,
          cutIncoming: -1,
          // help recognize paste/cut edits in input.poll
          selectingText: !1,
          draggingText: !1,
          highlight: new Ye(),
          // stores highlight worker timeout
          keySeq: null,
          // Unfinished key sequence
          specialChars: null
        }, t.autofocus && !q && a.input.focus(), T && P < 11 && setTimeout(function() {
          return i.display.input.reset(!0);
        }, 20), _s(this), xs(), Sr(this), this.curOp.forceUpdate = !0, Dl(this, r), t.autofocus && !q || this.hasFocus() ? setTimeout(function() {
          i.hasFocus() && !i.state.focused && zn(i);
        }, 20) : zr(this);
        for (var l in on)
          on.hasOwnProperty(l) && on[l](this, t[l], Zr);
        dl(this), t.finishInit && t.finishInit(this);
        for (var u = 0; u < aa.length; ++u)
          aa[u](this);
        Fr(this), re && t.lineWrapping && getComputedStyle(a.lineDiv).textRendering == "optimizelegibility" && (a.lineDiv.style.textRendering = "auto");
      }
      et.defaults = uo, et.optionHandlers = on;
      function _s(e) {
        var t = e.display;
        A(t.scroller, "mousedown", pt(e, io)), T && P < 11 ? A(t.scroller, "dblclick", pt(e, function(s) {
          if (!te(e, s)) {
            var c = br(e, s);
            if (!(!c || na(e, s) || tr(e.display, s))) {
              Ae(s);
              var g = e.findWordAt(c);
              Vi(e.doc, g.anchor, g.head);
            }
          }
        })) : A(t.scroller, "dblclick", function(s) {
          return te(e, s) || Ae(s);
        }), A(t.scroller, "contextmenu", function(s) {
          return lo(e, s);
        }), A(t.input.getField(), "contextmenu", function(s) {
          t.scroller.contains(s.target) || lo(e, s);
        });
        var i, r = { end: 0 };
        function n() {
          t.activeTouch && (i = setTimeout(function() {
            return t.activeTouch = null;
          }, 1e3), r = t.activeTouch, r.end = +/* @__PURE__ */ new Date());
        }
        function a(s) {
          if (s.touches.length != 1)
            return !1;
          var c = s.touches[0];
          return c.radiusX <= 1 && c.radiusY <= 1;
        }
        function l(s, c) {
          if (c.left == null)
            return !0;
          var g = c.left - s.left, m = c.top - s.top;
          return g * g + m * m > 400;
        }
        A(t.scroller, "touchstart", function(s) {
          if (!te(e, s) && !a(s) && !na(e, s)) {
            t.input.ensurePolled(), clearTimeout(i);
            var c = +/* @__PURE__ */ new Date();
            t.activeTouch = {
              start: c,
              moved: !1,
              prev: c - r.end <= 300 ? r : null
            }, s.touches.length == 1 && (t.activeTouch.left = s.touches[0].pageX, t.activeTouch.top = s.touches[0].pageY);
          }
        }), A(t.scroller, "touchmove", function() {
          t.activeTouch && (t.activeTouch.moved = !0);
        }), A(t.scroller, "touchend", function(s) {
          var c = t.activeTouch;
          if (c && !tr(t, s) && c.left != null && !c.moved && /* @__PURE__ */ new Date() - c.start < 300) {
            var g = e.coordsChar(t.activeTouch, "page"), m;
            !c.prev || l(c, c.prev) ? m = new qe(g, g) : !c.prev.prev || l(c, c.prev.prev) ? m = e.findWordAt(g) : m = new qe($(g.line, 0), Oe(e.doc, $(g.line + 1, 0))), e.setSelection(m.anchor, m.head), e.focus(), Ae(s);
          }
          n();
        }), A(t.scroller, "touchcancel", n), A(t.scroller, "scroll", function() {
          t.scroller.clientHeight && (ci(e, t.scroller.scrollTop), wr(e, t.scroller.scrollLeft, !0), ve(e, "scroll", e));
        }), A(t.scroller, "mousewheel", function(s) {
          return vl(e, s);
        }), A(t.scroller, "DOMMouseScroll", function(s) {
          return vl(e, s);
        }), A(t.wrapper, "scroll", function() {
          return t.wrapper.scrollTop = t.wrapper.scrollLeft = 0;
        }), t.dragFunctions = {
          enter: function(s) {
            te(e, s) || ut(s);
          },
          over: function(s) {
            te(e, s) || (ms(e, s), ut(s));
          },
          start: function(s) {
            return vs(e, s);
          },
          drop: pt(e, gs),
          leave: function(s) {
            te(e, s) || Gl(e);
          }
        };
        var u = t.input.getField();
        A(u, "keyup", function(s) {
          return to.call(e, s);
        }), A(u, "keydown", pt(e, eo)), A(u, "keypress", pt(e, ro)), A(u, "focus", function(s) {
          return zn(e, s);
        }), A(u, "blur", function(s) {
          return zr(e, s);
        });
      }
      var aa = [];
      et.defineInitHook = function(e) {
        return aa.push(e);
      };
      function Li(e, t, i, r) {
        var n = e.doc, a;
        i == null && (i = "add"), i == "smart" && (n.mode.indent ? a = ii(e, t).state : i = "prev");
        var l = e.options.tabSize, u = be(n, t), s = Ke(u.text, null, l);
        u.stateAfter && (u.stateAfter = null);
        var c = u.text.match(/^\s*/)[0], g;
        if (!r && !/\S/.test(u.text))
          g = 0, i = "not";
        else if (i == "smart" && (g = n.mode.indent(a, u.text.slice(c.length), u.text), g == Ve || g > 150)) {
          if (!r)
            return;
          i = "prev";
        }
        i == "prev" ? t > n.first ? g = Ke(be(n, t - 1).text, null, l) : g = 0 : i == "add" ? g = s + e.options.indentUnit : i == "subtract" ? g = s - e.options.indentUnit : typeof i == "number" && (g = s + i), g = Math.max(0, g);
        var m = "", L = 0;
        if (e.options.indentWithTabs)
          for (var S = Math.floor(g / l); S; --S)
            L += l, m += "	";
        if (L < g && (m += Ht(g - L)), m != c)
          return jr(n, m, $(t, 0), $(t, c.length), "+input"), u.stateAfter = null, !0;
        for (var U = 0; U < n.sel.ranges.length; U++) {
          var Y = n.sel.ranges[U];
          if (Y.head.line == t && Y.head.ch < c.length) {
            var V = $(t, c.length);
            $n(n, U, new qe(V, V));
            break;
          }
        }
      }
      var Kt = null;
      function un(e) {
        Kt = e;
      }
      function la(e, t, i, r, n) {
        var a = e.doc;
        e.display.shift = !1, r || (r = a.sel);
        var l = +/* @__PURE__ */ new Date() - 200, u = n == "paste" || e.state.pasteIncoming > l, s = ti(t), c = null;
        if (u && r.ranges.length > 1)
          if (Kt && Kt.text.join(`
`) == t) {
            if (r.ranges.length % Kt.text.length == 0) {
              c = [];
              for (var g = 0; g < Kt.text.length; g++)
                c.push(a.splitLines(Kt.text[g]));
            }
          } else s.length == r.ranges.length && e.options.pasteLinesPerSelection && (c = ot(s, function(le) {
            return [le];
          }));
        for (var m = e.curOp.updateInput, L = r.ranges.length - 1; L >= 0; L--) {
          var S = r.ranges[L], U = S.from(), Y = S.to();
          S.empty() && (i && i > 0 ? U = $(U.line, U.ch - i) : e.state.overwrite && !u ? Y = $(Y.line, Math.min(be(a, Y.line).text.length, Y.ch + xe(s).length)) : u && Kt && Kt.lineWise && Kt.text.join(`
`) == s.join(`
`) && (U = Y = $(U.line, 0)));
          var V = {
            from: U,
            to: Y,
            text: c ? c[L % c.length] : s,
            origin: n || (u ? "paste" : e.state.cutIncoming > l ? "cut" : "+input")
          };
          Gr(e.doc, V), dt(e, "inputRead", e, V);
        }
        t && !u && fo(e, t), Wr(e), e.curOp.updateInput < 2 && (e.curOp.updateInput = m), e.curOp.typing = !0, e.state.pasteIncoming = e.state.cutIncoming = -1;
      }
      function so(e, t) {
        var i = e.clipboardData && e.clipboardData.getData("Text");
        if (i)
          return e.preventDefault(), !t.isReadOnly() && !t.options.disableInput && t.hasFocus() && Ot(t, function() {
            return la(t, i, 0, null, "paste");
          }), !0;
      }
      function fo(e, t) {
        if (!(!e.options.electricChars || !e.options.smartIndent))
          for (var i = e.doc.sel, r = i.ranges.length - 1; r >= 0; r--) {
            var n = i.ranges[r];
            if (!(n.head.ch > 100 || r && i.ranges[r - 1].head.line == n.head.line)) {
              var a = e.getModeAt(n.head), l = !1;
              if (a.electricChars) {
                for (var u = 0; u < a.electricChars.length; u++)
                  if (t.indexOf(a.electricChars.charAt(u)) > -1) {
                    l = Li(e, n.head.line, "smart");
                    break;
                  }
              } else a.electricInput && a.electricInput.test(be(e.doc, n.head.line).text.slice(0, n.head.ch)) && (l = Li(e, n.head.line, "smart"));
              l && dt(e, "electricInput", e, n.head.line);
            }
          }
      }
      function co(e) {
        for (var t = [], i = [], r = 0; r < e.doc.sel.ranges.length; r++) {
          var n = e.doc.sel.ranges[r].head.line, a = { anchor: $(n, 0), head: $(n + 1, 0) };
          i.push(a), t.push(e.getRange(a.anchor, a.head));
        }
        return { text: t, ranges: i };
      }
      function oa(e, t, i, r) {
        e.setAttribute("autocorrect", i ? "on" : "off"), e.setAttribute("autocapitalize", r ? "on" : "off"), e.setAttribute("spellcheck", !!t);
      }
      function ho() {
        var e = E("textarea", null, null, "position: absolute; bottom: -1em; padding: 0; width: 1px; height: 1em; min-height: 1em; outline: none"), t = E("div", [e], null, "overflow: hidden; position: relative; width: 3px; height: 0px;");
        return re ? e.style.width = "1000px" : e.setAttribute("wrap", "off"), _ && (e.style.border = "1px solid black"), t;
      }
      function qs(e) {
        var t = e.optionHandlers, i = e.helpers = {};
        e.prototype = {
          constructor: e,
          focus: function() {
            Te(this).focus(), this.display.input.focus();
          },
          setOption: function(r, n) {
            var a = this.options, l = a[r];
            a[r] == n && r != "mode" || (a[r] = n, t.hasOwnProperty(r) && pt(this, t[r])(this, n, l), ve(this, "optionChange", this, r));
          },
          getOption: function(r) {
            return this.options[r];
          },
          getDoc: function() {
            return this.doc;
          },
          addKeyMap: function(r, n) {
            this.state.keyMaps[n ? "push" : "unshift"](an(r));
          },
          removeKeyMap: function(r) {
            for (var n = this.state.keyMaps, a = 0; a < n.length; ++a)
              if (n[a] == r || n[a].name == r)
                return n.splice(a, 1), !0;
          },
          addOverlay: St(function(r, n) {
            var a = r.token ? r : e.getMode(this.options, r);
            if (a.startState)
              throw new Error("Overlays may not be stateful.");
            Wt(
              this.state.overlays,
              {
                mode: a,
                modeSpec: r,
                opaque: n && n.opaque,
                priority: n && n.priority || 0
              },
              function(l) {
                return l.priority;
              }
            ), this.state.modeGen++, Et(this);
          }),
          removeOverlay: St(function(r) {
            for (var n = this.state.overlays, a = 0; a < n.length; ++a) {
              var l = n[a].modeSpec;
              if (l == r || typeof r == "string" && l.name == r) {
                n.splice(a, 1), this.state.modeGen++, Et(this);
                return;
              }
            }
          }),
          indentLine: St(function(r, n, a) {
            typeof n != "string" && typeof n != "number" && (n == null ? n = this.options.smartIndent ? "smart" : "prev" : n = n ? "add" : "subtract"), ri(this.doc, r) && Li(this, r, n, a);
          }),
          indentSelection: St(function(r) {
            for (var n = this.doc.sel.ranges, a = -1, l = 0; l < n.length; l++) {
              var u = n[l];
              if (u.empty())
                u.head.line > a && (Li(this, u.head.line, r, !0), a = u.head.line, l == this.doc.sel.primIndex && Wr(this));
              else {
                var s = u.from(), c = u.to(), g = Math.max(a, s.line);
                a = Math.min(this.lastLine(), c.line - (c.ch ? 0 : 1)) + 1;
                for (var m = g; m < a; ++m)
                  Li(this, m, r);
                var L = this.doc.sel.ranges;
                s.ch == 0 && n.length == L.length && L[l].from().ch > 0 && $n(this.doc, l, new qe(s, L[l].to()), at);
              }
            }
          }),
          // Fetch the parser token for a given character. Useful for hacks
          // that want to inspect the mode state (say, for completion).
          getTokenAt: function(r, n) {
            return Ca(this, r, n);
          },
          getLineTokens: function(r, n) {
            return Ca(this, $(r), n, !0);
          },
          getTokenTypeAt: function(r) {
            r = Oe(this.doc, r);
            var n = ya(this, be(this.doc, r.line)), a = 0, l = (n.length - 1) / 2, u = r.ch, s;
            if (u == 0)
              s = n[2];
            else
              for (; ; ) {
                var c = a + l >> 1;
                if ((c ? n[c * 2 - 1] : 0) >= u)
                  l = c;
                else if (n[c * 2 + 1] < u)
                  a = c + 1;
                else {
                  s = n[c * 2 + 2];
                  break;
                }
              }
            var g = s ? s.indexOf("overlay ") : -1;
            return g < 0 ? s : g == 0 ? null : s.slice(0, g - 1);
          },
          getModeAt: function(r) {
            var n = this.doc.mode;
            return n.innerMode ? e.innerMode(n, this.getTokenAt(r).state).mode : n;
          },
          getHelper: function(r, n) {
            return this.getHelpers(r, n)[0];
          },
          getHelpers: function(r, n) {
            var a = [];
            if (!i.hasOwnProperty(n))
              return a;
            var l = i[n], u = this.getModeAt(r);
            if (typeof u[n] == "string")
              l[u[n]] && a.push(l[u[n]]);
            else if (u[n])
              for (var s = 0; s < u[n].length; s++) {
                var c = l[u[n][s]];
                c && a.push(c);
              }
            else u.helperType && l[u.helperType] ? a.push(l[u.helperType]) : l[u.name] && a.push(l[u.name]);
            for (var g = 0; g < l._global.length; g++) {
              var m = l._global[g];
              m.pred(u, this) && Pe(a, m.val) == -1 && a.push(m.val);
            }
            return a;
          },
          getStateAfter: function(r, n) {
            var a = this.doc;
            return r = va(a, r ?? a.first + a.size - 1), ii(this, r + 1, n).state;
          },
          cursorCoords: function(r, n) {
            var a, l = this.doc.sel.primary();
            return r == null ? a = l.head : typeof r == "object" ? a = Oe(this.doc, r) : a = r ? l.from() : l.to(), Gt(this, a, n || "page");
          },
          charCoords: function(r, n) {
            return Ui(this, Oe(this.doc, r), n || "page");
          },
          coordsChar: function(r, n) {
            return r = Ja(this, r, n || "page"), Bn(this, r.left, r.top);
          },
          lineAtHeight: function(r, n) {
            return r = Ja(this, { top: r, left: 0 }, n || "page").top, xr(this.doc, r + this.display.viewOffset);
          },
          heightAtLine: function(r, n, a) {
            var l = !1, u;
            if (typeof r == "number") {
              var s = this.doc.first + this.doc.size - 1;
              r < this.doc.first ? r = this.doc.first : r > s && (r = s, l = !0), u = be(this.doc, r);
            } else
              u = r;
            return qi(this, u, { top: 0, left: 0 }, n || "page", a || l).top + (l ? this.doc.height - er(u) : 0);
          },
          defaultTextHeight: function() {
            return Rr(this.display);
          },
          defaultCharWidth: function() {
            return Pr(this.display);
          },
          getViewport: function() {
            return { from: this.display.viewFrom, to: this.display.viewTo };
          },
          addWidget: function(r, n, a, l, u) {
            var s = this.display;
            r = Gt(this, Oe(this.doc, r));
            var c = r.bottom, g = r.left;
            if (n.style.position = "absolute", n.setAttribute("cm-ignore-events", "true"), this.display.input.setUneditable(n), s.sizer.appendChild(n), l == "over")
              c = r.top;
            else if (l == "above" || l == "near") {
              var m = Math.max(s.wrapper.clientHeight, this.doc.height), L = Math.max(s.sizer.clientWidth, s.lineSpace.clientWidth);
              (l == "above" || r.bottom + n.offsetHeight > m) && r.top > n.offsetHeight ? c = r.top - n.offsetHeight : r.bottom + n.offsetHeight <= m && (c = r.bottom), g + n.offsetWidth > L && (g = L - n.offsetWidth);
            }
            n.style.top = c + "px", n.style.left = n.style.right = "", u == "right" ? (g = s.sizer.clientWidth - n.offsetWidth, n.style.right = "0px") : (u == "left" ? g = 0 : u == "middle" && (g = (s.sizer.clientWidth - n.offsetWidth) / 2), n.style.left = g + "px"), a && zu(this, { left: g, top: c, right: g + n.offsetWidth, bottom: c + n.offsetHeight });
          },
          triggerOnKeyDown: St(eo),
          triggerOnKeyPress: St(ro),
          triggerOnKeyUp: to,
          triggerOnMouseDown: St(io),
          execCommand: function(r) {
            if (Si.hasOwnProperty(r))
              return Si[r].call(null, this);
          },
          triggerElectric: St(function(r) {
            fo(this, r);
          }),
          findPosH: function(r, n, a, l) {
            var u = 1;
            n < 0 && (u = -1, n = -n);
            for (var s = Oe(this.doc, r), c = 0; c < n && (s = ua(this.doc, s, u, a, l), !s.hitSide); ++c)
              ;
            return s;
          },
          moveH: St(function(r, n) {
            var a = this;
            this.extendSelectionsBy(function(l) {
              return a.display.shift || a.doc.extend || l.empty() ? ua(a.doc, l.head, r, n, a.options.rtlMoveVisually) : r < 0 ? l.from() : l.to();
            }, Dt);
          }),
          deleteH: St(function(r, n) {
            var a = this.doc.sel, l = this.doc;
            a.somethingSelected() ? l.replaceSelection("", null, "+delete") : Yr(this, function(u) {
              var s = ua(l, u.head, r, n, !1);
              return r < 0 ? { from: s, to: u.head } : { from: u.head, to: s };
            });
          }),
          findPosV: function(r, n, a, l) {
            var u = 1, s = l;
            n < 0 && (u = -1, n = -n);
            for (var c = Oe(this.doc, r), g = 0; g < n; ++g) {
              var m = Gt(this, c, "div");
              if (s == null ? s = m.left : m.left = s, c = po(this, m, u, a), c.hitSide)
                break;
            }
            return c;
          },
          moveV: St(function(r, n) {
            var a = this, l = this.doc, u = [], s = !this.display.shift && !l.extend && l.sel.somethingSelected();
            if (l.extendSelectionsBy(function(g) {
              if (s)
                return r < 0 ? g.from() : g.to();
              var m = Gt(a, g.head, "div");
              g.goalColumn != null && (m.left = g.goalColumn), u.push(m.left);
              var L = po(a, m, r, n);
              return n == "page" && g == l.sel.primary() && _n(a, Ui(a, L, "div").top - m.top), L;
            }, Dt), u.length)
              for (var c = 0; c < l.sel.ranges.length; c++)
                l.sel.ranges[c].goalColumn = u[c];
          }),
          // Find the word at the given position (as returned by coordsChar).
          findWordAt: function(r) {
            var n = this.doc, a = be(n, r.line).text, l = r.ch, u = r.ch;
            if (a) {
              var s = this.getHelper(r, "wordChars");
              (r.sticky == "before" || u == a.length) && l ? --l : ++u;
              for (var c = a.charAt(l), g = d(c, s) ? function(m) {
                return d(m, s);
              } : /\s/.test(c) ? function(m) {
                return /\s/.test(m);
              } : function(m) {
                return !/\s/.test(m) && !d(m);
              }; l > 0 && g(a.charAt(l - 1)); )
                --l;
              for (; u < a.length && g(a.charAt(u)); )
                ++u;
            }
            return new qe($(r.line, l), $(r.line, u));
          },
          toggleOverwrite: function(r) {
            r != null && r == this.state.overwrite || ((this.state.overwrite = !this.state.overwrite) ? rt(this.display.cursorDiv, "CodeMirror-overwrite") : Le(this.display.cursorDiv, "CodeMirror-overwrite"), ve(this, "overwriteToggle", this, this.state.overwrite));
          },
          hasFocus: function() {
            return this.display.input.getField() == We(G(this));
          },
          isReadOnly: function() {
            return !!(this.options.readOnly || this.doc.cantEdit);
          },
          scrollTo: St(function(r, n) {
            fi(this, r, n);
          }),
          getScrollInfo: function() {
            var r = this.display.scroller;
            return {
              left: r.scrollLeft,
              top: r.scrollTop,
              height: r.scrollHeight - Qt(this) - this.display.barHeight,
              width: r.scrollWidth - Qt(this) - this.display.barWidth,
              clientHeight: An(this),
              clientWidth: yr(this)
            };
          },
          scrollIntoView: St(function(r, n) {
            r == null ? (r = { from: this.doc.sel.primary().head, to: null }, n == null && (n = this.options.cursorScrollMargin)) : typeof r == "number" ? r = { from: $(r, 0), to: null } : r.from == null && (r = { from: r, to: null }), r.to || (r.to = r.from), r.margin = n || 0, r.from.line != null ? Wu(this, r) : ll(this, r.from, r.to, r.margin);
          }),
          setSize: St(function(r, n) {
            var a = this, l = function(s) {
              return typeof s == "number" || /^\d+$/.test(String(s)) ? s + "px" : s;
            };
            r != null && (this.display.wrapper.style.width = l(r)), n != null && (this.display.wrapper.style.height = l(n)), this.options.lineWrapping && Ya(this);
            var u = this.display.viewFrom;
            this.doc.iter(u, this.display.viewTo, function(s) {
              if (s.widgets) {
                for (var c = 0; c < s.widgets.length; c++)
                  if (s.widgets[c].noHScroll) {
                    or(a, u, "widget");
                    break;
                  }
              }
              ++u;
            }), this.curOp.forceUpdate = !0, ve(this, "refresh", this);
          }),
          operation: function(r) {
            return Ot(this, r);
          },
          startOperation: function() {
            return Sr(this);
          },
          endOperation: function() {
            return Fr(this);
          },
          refresh: St(function() {
            var r = this.display.cachedTextHeight;
            Et(this), this.curOp.forceUpdate = !0, ui(this), fi(this, this.doc.scrollLeft, this.doc.scrollTop), Gn(this.display), (r == null || Math.abs(r - Rr(this.display)) > 0.5 || this.options.lineWrapping) && In(this), ve(this, "refresh", this);
          }),
          swapDoc: St(function(r) {
            var n = this.doc;
            return n.cm = null, this.state.selectingText && this.state.selectingText(), Dl(this, r), ui(this), this.display.input.reset(), fi(this, r.scrollLeft, r.scrollTop), this.curOp.forceScroll = !0, dt(this, "swapDoc", this, n), n;
          }),
          phrase: function(r) {
            var n = this.options.phrases;
            return n && Object.prototype.hasOwnProperty.call(n, r) ? n[r] : r;
          },
          getInputField: function() {
            return this.display.input.getField();
          },
          getWrapperElement: function() {
            return this.display.wrapper;
          },
          getScrollerElement: function() {
            return this.display.scroller;
          },
          getGutterElement: function() {
            return this.display.gutters;
          }
        }, Ie(e), e.registerHelper = function(r, n, a) {
          i.hasOwnProperty(r) || (i[r] = e[r] = { _global: [] }), i[r][n] = a;
        }, e.registerGlobalHelper = function(r, n, a, l) {
          e.registerHelper(r, n, l), i[r]._global.push({ pred: a, val: l });
        };
      }
      function ua(e, t, i, r, n) {
        var a = t, l = i, u = be(e, t.line), s = n && e.direction == "rtl" ? -i : i;
        function c() {
          var he = t.line + s;
          return he < e.first || he >= e.first + e.size ? !1 : (t = new $(he, t.ch, t.sticky), u = be(e, he));
        }
        function g(he) {
          var oe;
          if (r == "codepoint") {
            var pe = u.text.charCodeAt(t.ch + (i > 0 ? 0 : -1));
            if (isNaN(pe))
              oe = null;
            else {
              var Fe = i > 0 ? pe >= 55296 && pe < 56320 : pe >= 56320 && pe < 57343;
              oe = new $(t.line, Math.max(0, Math.min(u.text.length, t.ch + i * (Fe ? 2 : 1))), -i);
            }
          } else n ? oe = ws(e.cm, u, t, i) : oe = ea(u, t, i);
          if (oe == null)
            if (!he && c())
              t = ta(n, e.cm, u, t.line, s);
            else
              return !1;
          else
            t = oe;
          return !0;
        }
        if (r == "char" || r == "codepoint")
          g();
        else if (r == "column")
          g(!0);
        else if (r == "word" || r == "group")
          for (var m = null, L = r == "group", S = e.cm && e.cm.getHelper(t, "wordChars"), U = !0; !(i < 0 && !g(!U)); U = !1) {
            var Y = u.text.charAt(t.ch) || `
`, V = d(Y, S) ? "w" : L && Y == `
` ? "n" : !L || /\s/.test(Y) ? null : "p";
            if (L && !U && !V && (V = "s"), m && m != V) {
              i < 0 && (i = 1, g(), t.sticky = "after");
              break;
            }
            if (V && (m = V), i > 0 && !g(!U))
              break;
          }
        var le = tn(e, t, a, l, !0);
        return vn(a, le) && (le.hitSide = !0), le;
      }
      function po(e, t, i, r) {
        var n = e.doc, a = t.left, l;
        if (r == "page") {
          var u = Math.min(e.display.wrapper.clientHeight, Te(e).innerHeight || n(e).documentElement.clientHeight), s = Math.max(u - 0.5 * Rr(e.display), 3);
          l = (i > 0 ? t.bottom : t.top) + i * s;
        } else r == "line" && (l = i > 0 ? t.bottom + 3 : t.top - 3);
        for (var c; c = Bn(e, a, l), !!c.outside; ) {
          if (i < 0 ? l <= 0 : l >= n.height) {
            c.hitSide = !0;
            break;
          }
          l += i * 5;
        }
        return c;
      }
      var je = function(e) {
        this.cm = e, this.lastAnchorNode = this.lastAnchorOffset = this.lastFocusNode = this.lastFocusOffset = null, this.polling = new Ye(), this.composing = null, this.gracePeriod = !1, this.readDOMTimeout = null;
      };
      je.prototype.init = function(e) {
        var t = this, i = this, r = i.cm, n = i.div = e.lineDiv;
        n.contentEditable = !0, oa(n, r.options.spellcheck, r.options.autocorrect, r.options.autocapitalize);
        function a(u) {
          for (var s = u.target; s; s = s.parentNode) {
            if (s == n)
              return !0;
            if (/\bCodeMirror-(?:line)?widget\b/.test(s.className))
              break;
          }
          return !1;
        }
        A(n, "paste", function(u) {
          !a(u) || te(r, u) || so(u, r) || P <= 11 && setTimeout(pt(r, function() {
            return t.updateFromDOM();
          }), 20);
        }), A(n, "compositionstart", function(u) {
          t.composing = { data: u.data, done: !1 };
        }), A(n, "compositionupdate", function(u) {
          t.composing || (t.composing = { data: u.data, done: !1 });
        }), A(n, "compositionend", function(u) {
          t.composing && (u.data != t.composing.data && t.readFromDOMSoon(), t.composing.done = !0);
        }), A(n, "touchstart", function() {
          return i.forceCompositionEnd();
        }), A(n, "input", function() {
          t.composing || t.readFromDOMSoon();
        });
        function l(u) {
          if (!(!a(u) || te(r, u))) {
            if (r.somethingSelected())
              un({ lineWise: !1, text: r.getSelections() }), u.type == "cut" && r.replaceSelection("", null, "cut");
            else if (r.options.lineWiseCopyCut) {
              var s = co(r);
              un({ lineWise: !0, text: s.text }), u.type == "cut" && r.operation(function() {
                r.setSelections(s.ranges, 0, at), r.replaceSelection("", null, "cut");
              });
            } else
              return;
            if (u.clipboardData) {
              u.clipboardData.clearData();
              var c = Kt.text.join(`
`);
              if (u.clipboardData.setData("Text", c), u.clipboardData.getData("Text") == c) {
                u.preventDefault();
                return;
              }
            }
            var g = ho(), m = g.firstChild;
            oa(m), r.display.lineSpace.insertBefore(g, r.display.lineSpace.firstChild), m.value = Kt.text.join(`
`);
            var L = We(ze(n));
            D(m), setTimeout(function() {
              r.display.lineSpace.removeChild(g), L.focus(), L == n && i.showPrimarySelection();
            }, 50);
          }
        }
        A(n, "copy", l), A(n, "cut", l);
      }, je.prototype.screenReaderLabelChanged = function(e) {
        e ? this.div.setAttribute("aria-label", e) : this.div.removeAttribute("aria-label");
      }, je.prototype.prepareSelection = function() {
        var e = il(this.cm, !1);
        return e.focus = We(ze(this.div)) == this.div, e;
      }, je.prototype.showSelection = function(e, t) {
        !e || !this.cm.display.view.length || ((e.focus || t) && this.showPrimarySelection(), this.showMultipleSelections(e));
      }, je.prototype.getSelection = function() {
        return this.cm.display.wrapper.ownerDocument.getSelection();
      }, je.prototype.showPrimarySelection = function() {
        var e = this.getSelection(), t = this.cm, i = t.doc.sel.primary(), r = i.from(), n = i.to();
        if (t.display.viewTo == t.display.viewFrom || r.line >= t.display.viewTo || n.line < t.display.viewFrom) {
          e.removeAllRanges();
          return;
        }
        var a = sn(t, e.anchorNode, e.anchorOffset), l = sn(t, e.focusNode, e.focusOffset);
        if (!(a && !a.bad && l && !l.bad && Ne(Ni(a, l), r) == 0 && Ne(Mi(a, l), n) == 0)) {
          var u = t.display.view, s = r.line >= t.display.viewFrom && go(t, r) || { node: u[0].measure.map[2], offset: 0 }, c = n.line < t.display.viewTo && go(t, n);
          if (!c) {
            var g = u[u.length - 1].measure, m = g.maps ? g.maps[g.maps.length - 1] : g.map;
            c = { node: m[m.length - 1], offset: m[m.length - 2] - m[m.length - 3] };
          }
          if (!s || !c) {
            e.removeAllRanges();
            return;
          }
          var L = e.rangeCount && e.getRangeAt(0), S;
          try {
            S = J(s.node, s.offset, c.offset, c.node);
          } catch {
          }
          S && (!N && t.state.focused ? (e.collapse(s.node, s.offset), S.collapsed || (e.removeAllRanges(), e.addRange(S))) : (e.removeAllRanges(), e.addRange(S)), L && e.anchorNode == null ? e.addRange(L) : N && this.startGracePeriod()), this.rememberSelection();
        }
      }, je.prototype.startGracePeriod = function() {
        var e = this;
        clearTimeout(this.gracePeriod), this.gracePeriod = setTimeout(function() {
          e.gracePeriod = !1, e.selectionChanged() && e.cm.operation(function() {
            return e.cm.curOp.selectionChanged = !0;
          });
        }, 20);
      }, je.prototype.showMultipleSelections = function(e) {
        He(this.cm.display.cursorDiv, e.cursors), He(this.cm.display.selectionDiv, e.selection);
      }, je.prototype.rememberSelection = function() {
        var e = this.getSelection();
        this.lastAnchorNode = e.anchorNode, this.lastAnchorOffset = e.anchorOffset, this.lastFocusNode = e.focusNode, this.lastFocusOffset = e.focusOffset;
      }, je.prototype.selectionInEditor = function() {
        var e = this.getSelection();
        if (!e.rangeCount)
          return !1;
        var t = e.getRangeAt(0).commonAncestorContainer;
        return De(this.div, t);
      }, je.prototype.focus = function() {
        this.cm.options.readOnly != "nocursor" && ((!this.selectionInEditor() || We(ze(this.div)) != this.div) && this.showSelection(this.prepareSelection(), !0), this.div.focus());
      }, je.prototype.blur = function() {
        this.div.blur();
      }, je.prototype.getField = function() {
        return this.div;
      }, je.prototype.supportsTouch = function() {
        return !0;
      }, je.prototype.receivedFocus = function() {
        var e = this, t = this;
        this.selectionInEditor() ? setTimeout(function() {
          return e.pollSelection();
        }, 20) : Ot(this.cm, function() {
          return t.cm.curOp.selectionChanged = !0;
        });
        function i() {
          t.cm.state.focused && (t.pollSelection(), t.polling.set(t.cm.options.pollInterval, i));
        }
        this.polling.set(this.cm.options.pollInterval, i);
      }, je.prototype.selectionChanged = function() {
        var e = this.getSelection();
        return e.anchorNode != this.lastAnchorNode || e.anchorOffset != this.lastAnchorOffset || e.focusNode != this.lastFocusNode || e.focusOffset != this.lastFocusOffset;
      }, je.prototype.pollSelection = function() {
        if (!(this.readDOMTimeout != null || this.gracePeriod || !this.selectionChanged())) {
          var e = this.getSelection(), t = this.cm;
          if (X && K && this.cm.display.gutterSpecs.length && Us(e.anchorNode)) {
            this.cm.triggerOnKeyDown({ type: "keydown", keyCode: 8, preventDefault: Math.abs }), this.blur(), this.focus();
            return;
          }
          if (!this.composing) {
            this.rememberSelection();
            var i = sn(t, e.anchorNode, e.anchorOffset), r = sn(t, e.focusNode, e.focusOffset);
            i && r && Ot(t, function() {
              Ct(t.doc, sr(i, r), at), (i.bad || r.bad) && (t.curOp.selectionChanged = !0);
            });
          }
        }
      }, je.prototype.pollContent = function() {
        this.readDOMTimeout != null && (clearTimeout(this.readDOMTimeout), this.readDOMTimeout = null);
        var e = this.cm, t = e.display, i = e.doc.sel.primary(), r = i.from(), n = i.to();
        if (r.ch == 0 && r.line > e.firstLine() && (r = $(r.line - 1, be(e.doc, r.line - 1).length)), n.ch == be(e.doc, n.line).text.length && n.line < e.lastLine() && (n = $(n.line + 1, 0)), r.line < t.viewFrom || n.line > t.viewTo - 1)
          return !1;
        var a, l, u;
        r.line == t.viewFrom || (a = Cr(e, r.line)) == 0 ? (l = Ge(t.view[0].line), u = t.view[0].node) : (l = Ge(t.view[a].line), u = t.view[a - 1].node.nextSibling);
        var s = Cr(e, n.line), c, g;
        if (s == t.view.length - 1 ? (c = t.viewTo - 1, g = t.lineDiv.lastChild) : (c = Ge(t.view[s + 1].line) - 1, g = t.view[s + 1].node.previousSibling), !u)
          return !1;
        for (var m = e.doc.splitLines(Gs(e, u, g, l, c)), L = mr(e.doc, $(l, 0), $(c, be(e.doc, c).text.length)); m.length > 1 && L.length > 1; )
          if (xe(m) == xe(L))
            m.pop(), L.pop(), c--;
          else if (m[0] == L[0])
            m.shift(), L.shift(), l++;
          else
            break;
        for (var S = 0, U = 0, Y = m[0], V = L[0], le = Math.min(Y.length, V.length); S < le && Y.charCodeAt(S) == V.charCodeAt(S); )
          ++S;
        for (var he = xe(m), oe = xe(L), pe = Math.min(
          he.length - (m.length == 1 ? S : 0),
          oe.length - (L.length == 1 ? S : 0)
        ); U < pe && he.charCodeAt(he.length - U - 1) == oe.charCodeAt(oe.length - U - 1); )
          ++U;
        if (m.length == 1 && L.length == 1 && l == r.line)
          for (; S && S > r.ch && he.charCodeAt(he.length - U - 1) == oe.charCodeAt(oe.length - U - 1); )
            S--, U++;
        m[m.length - 1] = he.slice(0, he.length - U).replace(/^\u200b+/, ""), m[0] = m[0].slice(S).replace(/\u200b+$/, "");
        var Fe = $(l, S), we = $(c, L.length ? xe(L).length - U : 0);
        if (m.length > 1 || m[0] || Ne(Fe, we))
          return jr(e.doc, m, Fe, we, "+input"), !0;
      }, je.prototype.ensurePolled = function() {
        this.forceCompositionEnd();
      }, je.prototype.reset = function() {
        this.forceCompositionEnd();
      }, je.prototype.forceCompositionEnd = function() {
        this.composing && (clearTimeout(this.readDOMTimeout), this.composing = null, this.updateFromDOM(), this.div.blur(), this.div.focus());
      }, je.prototype.readFromDOMSoon = function() {
        var e = this;
        this.readDOMTimeout == null && (this.readDOMTimeout = setTimeout(function() {
          if (e.readDOMTimeout = null, e.composing)
            if (e.composing.done)
              e.composing = null;
            else
              return;
          e.updateFromDOM();
        }, 80));
      }, je.prototype.updateFromDOM = function() {
        var e = this;
        (this.cm.isReadOnly() || !this.pollContent()) && Ot(this.cm, function() {
          return Et(e.cm);
        });
      }, je.prototype.setUneditable = function(e) {
        e.contentEditable = "false";
      }, je.prototype.onKeyPress = function(e) {
        e.charCode == 0 || this.composing || (e.preventDefault(), this.cm.isReadOnly() || pt(this.cm, la)(this.cm, String.fromCharCode(e.charCode == null ? e.keyCode : e.charCode), 0));
      }, je.prototype.readOnlyChanged = function(e) {
        this.div.contentEditable = String(e != "nocursor");
      }, je.prototype.onContextMenu = function() {
      }, je.prototype.resetPosition = function() {
      }, je.prototype.needsContentAttribute = !0;
      function go(e, t) {
        var i = En(e, t.line);
        if (!i || i.hidden)
          return null;
        var r = be(e.doc, t.line), n = Ua(i, r, t.line), a = y(r, e.doc.direction), l = "left";
        if (a) {
          var u = M(a, t.ch);
          l = u % 2 ? "right" : "left";
        }
        var s = Ka(n.map, t.ch, l);
        return s.offset = s.collapse == "right" ? s.end : s.start, s;
      }
      function Us(e) {
        for (var t = e; t; t = t.parentNode)
          if (/CodeMirror-gutter-wrapper/.test(t.className))
            return !0;
        return !1;
      }
      function Qr(e, t) {
        return t && (e.bad = !0), e;
      }
      function Gs(e, t, i, r, n) {
        var a = "", l = !1, u = e.doc.lineSeparator(), s = !1;
        function c(S) {
          return function(U) {
            return U.id == S;
          };
        }
        function g() {
          l && (a += u, s && (a += u), l = s = !1);
        }
        function m(S) {
          S && (g(), a += S);
        }
        function L(S) {
          if (S.nodeType == 1) {
            var U = S.getAttribute("cm-text");
            if (U) {
              m(U);
              return;
            }
            var Y = S.getAttribute("cm-marker"), V;
            if (Y) {
              var le = e.findMarks($(r, 0), $(n + 1, 0), c(+Y));
              le.length && (V = le[0].find(0)) && m(mr(e.doc, V.from, V.to).join(u));
              return;
            }
            if (S.getAttribute("contenteditable") == "false")
              return;
            var he = /^(pre|div|p|li|table|br)$/i.test(S.nodeName);
            if (!/^br$/i.test(S.nodeName) && S.textContent.length == 0)
              return;
            he && g();
            for (var oe = 0; oe < S.childNodes.length; oe++)
              L(S.childNodes[oe]);
            /^(pre|p)$/i.test(S.nodeName) && (s = !0), he && (l = !0);
          } else S.nodeType == 3 && m(S.nodeValue.replace(/\u200b/g, "").replace(/\u00a0/g, " "));
        }
        for (; L(t), t != i; )
          t = t.nextSibling, s = !1;
        return a;
      }
      function sn(e, t, i) {
        var r;
        if (t == e.display.lineDiv) {
          if (r = e.display.lineDiv.childNodes[i], !r)
            return Qr(e.clipPos($(e.display.viewTo - 1)), !0);
          t = null, i = 0;
        } else
          for (r = t; ; r = r.parentNode) {
            if (!r || r == e.display.lineDiv)
              return null;
            if (r.parentNode && r.parentNode == e.display.lineDiv)
              break;
          }
        for (var n = 0; n < e.display.view.length; n++) {
          var a = e.display.view[n];
          if (a.node == r)
            return js(a, t, i);
        }
      }
      function js(e, t, i) {
        var r = e.text.firstChild, n = !1;
        if (!t || !De(r, t))
          return Qr($(Ge(e.line), 0), !0);
        if (t == r && (n = !0, t = r.childNodes[i], i = 0, !t)) {
          var a = e.rest ? xe(e.rest) : e.line;
          return Qr($(Ge(a), a.text.length), n);
        }
        var l = t.nodeType == 3 ? t : null, u = t;
        for (!l && t.childNodes.length == 1 && t.firstChild.nodeType == 3 && (l = t.firstChild, i && (i = l.nodeValue.length)); u.parentNode != r; )
          u = u.parentNode;
        var s = e.measure, c = s.maps;
        function g(V, le, he) {
          for (var oe = -1; oe < (c ? c.length : 0); oe++)
            for (var pe = oe < 0 ? s.map : c[oe], Fe = 0; Fe < pe.length; Fe += 3) {
              var we = pe[Fe + 2];
              if (we == V || we == le) {
                var Re = Ge(oe < 0 ? e.line : e.rest[oe]), Qe = pe[Fe] + he;
                return (he < 0 || we != V) && (Qe = pe[Fe + (he ? 1 : 0)]), $(Re, Qe);
              }
            }
        }
        var m = g(l, u, i);
        if (m)
          return Qr(m, n);
        for (var L = u.nextSibling, S = l ? l.nodeValue.length - i : 0; L; L = L.nextSibling) {
          if (m = g(L, L.firstChild, 0), m)
            return Qr($(m.line, m.ch - S), n);
          S += L.textContent.length;
        }
        for (var U = u.previousSibling, Y = i; U; U = U.previousSibling) {
          if (m = g(U, U.firstChild, -1), m)
            return Qr($(m.line, m.ch + Y), n);
          Y += U.textContent.length;
        }
      }
      var lt = function(e) {
        this.cm = e, this.prevInput = "", this.pollingFast = !1, this.polling = new Ye(), this.hasSelection = !1, this.composing = null, this.resetting = !1;
      };
      lt.prototype.init = function(e) {
        var t = this, i = this, r = this.cm;
        this.createField(e);
        var n = this.textarea;
        e.wrapper.insertBefore(this.wrapper, e.wrapper.firstChild), _ && (n.style.width = "0px"), A(n, "input", function() {
          T && P >= 9 && t.hasSelection && (t.hasSelection = null), i.poll();
        }), A(n, "paste", function(l) {
          te(r, l) || so(l, r) || (r.state.pasteIncoming = +/* @__PURE__ */ new Date(), i.fastPoll());
        });
        function a(l) {
          if (!te(r, l)) {
            if (r.somethingSelected())
              un({ lineWise: !1, text: r.getSelections() });
            else if (r.options.lineWiseCopyCut) {
              var u = co(r);
              un({ lineWise: !0, text: u.text }), l.type == "cut" ? r.setSelections(u.ranges, null, at) : (i.prevInput = "", n.value = u.text.join(`
`), D(n));
            } else
              return;
            l.type == "cut" && (r.state.cutIncoming = +/* @__PURE__ */ new Date());
          }
        }
        A(n, "cut", a), A(n, "copy", a), A(e.scroller, "paste", function(l) {
          if (!(tr(e, l) || te(r, l))) {
            if (!n.dispatchEvent) {
              r.state.pasteIncoming = +/* @__PURE__ */ new Date(), i.focus();
              return;
            }
            var u = new Event("paste");
            u.clipboardData = l.clipboardData, n.dispatchEvent(u);
          }
        }), A(e.lineSpace, "selectstart", function(l) {
          tr(e, l) || Ae(l);
        }), A(n, "compositionstart", function() {
          var l = r.getCursor("from");
          i.composing && i.composing.range.clear(), i.composing = {
            start: l,
            range: r.markText(l, r.getCursor("to"), { className: "CodeMirror-composing" })
          };
        }), A(n, "compositionend", function() {
          i.composing && (i.poll(), i.composing.range.clear(), i.composing = null);
        });
      }, lt.prototype.createField = function(e) {
        this.wrapper = ho(), this.textarea = this.wrapper.firstChild;
        var t = this.cm.options;
        oa(this.textarea, t.spellcheck, t.autocorrect, t.autocapitalize);
      }, lt.prototype.screenReaderLabelChanged = function(e) {
        e ? this.textarea.setAttribute("aria-label", e) : this.textarea.removeAttribute("aria-label");
      }, lt.prototype.prepareSelection = function() {
        var e = this.cm, t = e.display, i = e.doc, r = il(e);
        if (e.options.moveInputWithCursor) {
          var n = Gt(e, i.sel.primary().head, "div"), a = t.wrapper.getBoundingClientRect(), l = t.lineDiv.getBoundingClientRect();
          r.teTop = Math.max(0, Math.min(
            t.wrapper.clientHeight - 10,
            n.top + l.top - a.top
          )), r.teLeft = Math.max(0, Math.min(
            t.wrapper.clientWidth - 10,
            n.left + l.left - a.left
          ));
        }
        return r;
      }, lt.prototype.showSelection = function(e) {
        var t = this.cm, i = t.display;
        He(i.cursorDiv, e.cursors), He(i.selectionDiv, e.selection), e.teTop != null && (this.wrapper.style.top = e.teTop + "px", this.wrapper.style.left = e.teLeft + "px");
      }, lt.prototype.reset = function(e) {
        if (!(this.contextMenuPending || this.composing && e)) {
          var t = this.cm;
          if (this.resetting = !0, t.somethingSelected()) {
            this.prevInput = "";
            var i = t.getSelection();
            this.textarea.value = i, t.state.focused && D(this.textarea), T && P >= 9 && (this.hasSelection = i);
          } else e || (this.prevInput = this.textarea.value = "", T && P >= 9 && (this.hasSelection = null));
          this.resetting = !1;
        }
      }, lt.prototype.getField = function() {
        return this.textarea;
      }, lt.prototype.supportsTouch = function() {
        return !1;
      }, lt.prototype.focus = function() {
        if (this.cm.options.readOnly != "nocursor" && (!q || We(ze(this.textarea)) != this.textarea))
          try {
            this.textarea.focus();
          } catch {
          }
      }, lt.prototype.blur = function() {
        this.textarea.blur();
      }, lt.prototype.resetPosition = function() {
        this.wrapper.style.top = this.wrapper.style.left = 0;
      }, lt.prototype.receivedFocus = function() {
        this.slowPoll();
      }, lt.prototype.slowPoll = function() {
        var e = this;
        this.pollingFast || this.polling.set(this.cm.options.pollInterval, function() {
          e.poll(), e.cm.state.focused && e.slowPoll();
        });
      }, lt.prototype.fastPoll = function() {
        var e = !1, t = this;
        t.pollingFast = !0;
        function i() {
          var r = t.poll();
          !r && !e ? (e = !0, t.polling.set(60, i)) : (t.pollingFast = !1, t.slowPoll());
        }
        t.polling.set(20, i);
      }, lt.prototype.poll = function() {
        var e = this, t = this.cm, i = this.textarea, r = this.prevInput;
        if (this.contextMenuPending || this.resetting || !t.state.focused || hn(i) && !r && !this.composing || t.isReadOnly() || t.options.disableInput || t.state.keySeq)
          return !1;
        var n = i.value;
        if (n == r && !t.somethingSelected())
          return !1;
        if (T && P >= 9 && this.hasSelection === n || j && /[\uf700-\uf7ff]/.test(n))
          return t.display.input.reset(), !1;
        if (t.doc.sel == t.display.selForContextMenu) {
          var a = n.charCodeAt(0);
          if (a == 8203 && !r && (r = "​"), a == 8666)
            return this.reset(), this.cm.execCommand("undo");
        }
        for (var l = 0, u = Math.min(r.length, n.length); l < u && r.charCodeAt(l) == n.charCodeAt(l); )
          ++l;
        return Ot(t, function() {
          la(
            t,
            n.slice(l),
            r.length - l,
            null,
            e.composing ? "*compose" : null
          ), n.length > 1e3 || n.indexOf(`
`) > -1 ? i.value = e.prevInput = "" : e.prevInput = n, e.composing && (e.composing.range.clear(), e.composing.range = t.markText(
            e.composing.start,
            t.getCursor("to"),
            { className: "CodeMirror-composing" }
          ));
        }), !0;
      }, lt.prototype.ensurePolled = function() {
        this.pollingFast && this.poll() && (this.pollingFast = !1);
      }, lt.prototype.onKeyPress = function() {
        T && P >= 9 && (this.hasSelection = null), this.fastPoll();
      }, lt.prototype.onContextMenu = function(e) {
        var t = this, i = t.cm, r = i.display, n = t.textarea;
        t.contextMenuPending && t.contextMenuPending();
        var a = br(i, e), l = r.scroller.scrollTop;
        if (!a || ie)
          return;
        var u = i.options.resetSelectionOnContextMenu;
        u && i.doc.sel.contains(a) == -1 && pt(i, Ct)(i.doc, sr(a), at);
        var s = n.style.cssText, c = t.wrapper.style.cssText, g = t.wrapper.offsetParent.getBoundingClientRect();
        t.wrapper.style.cssText = "position: static", n.style.cssText = `position: absolute; width: 30px; height: 30px;
      top: ` + (e.clientY - g.top - 5) + "px; left: " + (e.clientX - g.left - 5) + `px;
      z-index: 1000; background: ` + (T ? "rgba(255, 255, 255, .05)" : "transparent") + `;
      outline: none; border-width: 0; outline: none; overflow: hidden; opacity: .05; filter: alpha(opacity=5);`;
        var m;
        re && (m = n.ownerDocument.defaultView.scrollY), r.input.focus(), re && n.ownerDocument.defaultView.scrollTo(null, m), r.input.reset(), i.somethingSelected() || (n.value = t.prevInput = " "), t.contextMenuPending = S, r.selForContextMenu = i.doc.sel, clearTimeout(r.detectingSelectAll);
        function L() {
          if (n.selectionStart != null) {
            var Y = i.somethingSelected(), V = "​" + (Y ? n.value : "");
            n.value = "⇚", n.value = V, t.prevInput = Y ? "" : "​", n.selectionStart = 1, n.selectionEnd = V.length, r.selForContextMenu = i.doc.sel;
          }
        }
        function S() {
          if (t.contextMenuPending == S && (t.contextMenuPending = !1, t.wrapper.style.cssText = c, n.style.cssText = s, T && P < 9 && r.scrollbars.setScrollTop(r.scroller.scrollTop = l), n.selectionStart != null)) {
            (!T || T && P < 9) && L();
            var Y = 0, V = function() {
              r.selForContextMenu == i.doc.sel && n.selectionStart == 0 && n.selectionEnd > 0 && t.prevInput == "​" ? pt(i, Nl)(i) : Y++ < 10 ? r.detectingSelectAll = setTimeout(V, 500) : (r.selForContextMenu = null, r.input.reset());
            };
            r.detectingSelectAll = setTimeout(V, 200);
          }
        }
        if (T && P >= 9 && L(), Ue) {
          ut(e);
          var U = function() {
            ge(window, "mouseup", U), setTimeout(S, 20);
          };
          A(window, "mouseup", U);
        } else
          setTimeout(S, 50);
      }, lt.prototype.readOnlyChanged = function(e) {
        e || this.reset(), this.textarea.disabled = e == "nocursor", this.textarea.readOnly = !!e;
      }, lt.prototype.setUneditable = function() {
      }, lt.prototype.needsContentAttribute = !1;
      function Ks(e, t) {
        if (t = t ? $e(t) : {}, t.value = e.value, !t.tabindex && e.tabIndex && (t.tabindex = e.tabIndex), !t.placeholder && e.placeholder && (t.placeholder = e.placeholder), t.autofocus == null) {
          var i = We(ze(e));
          t.autofocus = i == e || e.getAttribute("autofocus") != null && i == document.body;
        }
        function r() {
          e.value = u.getValue();
        }
        var n;
        if (e.form && (A(e.form, "submit", r), !t.leaveSubmitMethodAlone)) {
          var a = e.form;
          n = a.submit;
          try {
            var l = a.submit = function() {
              r(), a.submit = n, a.submit(), a.submit = l;
            };
          } catch {
          }
        }
        t.finishInit = function(s) {
          s.save = r, s.getTextArea = function() {
            return e;
          }, s.toTextArea = function() {
            s.toTextArea = isNaN, r(), e.parentNode.removeChild(s.getWrapperElement()), e.style.display = "", e.form && (ge(e.form, "submit", r), !t.leaveSubmitMethodAlone && typeof e.form.submit == "function" && (e.form.submit = n));
          };
        }, e.style.display = "none";
        var u = et(
          function(s) {
            return e.parentNode.insertBefore(s, e.nextSibling);
          },
          t
        );
        return u;
      }
      function Xs(e) {
        e.off = ge, e.on = A, e.wheelEventPixels = es, e.Doc = Lt, e.splitLines = ti, e.countColumn = Ke, e.findColumn = At, e.isWordChar = F, e.Pass = Ve, e.signal = ve, e.Line = Or, e.changeEnd = fr, e.scrollbarModel = sl, e.Pos = $, e.cmpPos = Ne, e.modes = Rt, e.mimeModes = Nt, e.resolveMode = Br, e.getMode = Mr, e.modeExtensions = Nr, e.extendMode = Zo, e.copyState = vr, e.startState = ga, e.innerMode = dn, e.commands = Si, e.keyMap = ir, e.keyName = Zl, e.isModifierKey = Xl, e.lookupKey = Xr, e.normalizeKeyMap = Cs, e.StringStream = st, e.SharedTextMarker = Ci, e.TextMarker = hr, e.LineWidget = bi, e.e_preventDefault = Ae, e.e_stopPropagation = Xe, e.e_stop = ut, e.addClass = rt, e.contains = De, e.rmClass = Le, e.keyNames = dr;
      }
      Ps(et), qs(et);
      var Ys = "iter insert remove copy getEditor constructor".split(" ");
      for (var fn in Lt.prototype)
        Lt.prototype.hasOwnProperty(fn) && Pe(Ys, fn) < 0 && (et.prototype[fn] = /* @__PURE__ */ (function(e) {
          return function() {
            return e.apply(this.doc, arguments);
          };
        })(Lt.prototype[fn]));
      return Ie(Lt), et.inputStyles = { textarea: lt, contenteditable: je }, et.defineMode = function(e) {
        !et.defaults.mode && e != "null" && (et.defaults.mode = e), gr.apply(this, arguments);
      }, et.defineMIME = Bi, et.defineMode("null", function() {
        return { token: function(e) {
          return e.skipToEnd();
        } };
      }), et.defineMIME("text/plain", "null"), et.defineExtension = function(e, t) {
        et.prototype[e] = t;
      }, et.defineDocExtension = function(e, t) {
        Lt.prototype[e] = t;
      }, et.fromTextArea = Ks, Xs(et), et.version = "5.65.21", et;
    }));
  })(cn)), cn.exports;
}
var mo = { exports: {} }, xo;
function Vs() {
  return xo || (xo = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      var W = /^(\s*)(>[> ]*|[*+-] \[[x ]\]\s|[*+-]\s|(\d+)([.)]))(\s*)/, N = /^(\s*)(>[> ]*|[*+-] \[[x ]\]|[*+-]|(\d+)[.)])(\s*)$/, I = /[*+-]\s/;
      k.commands.newlineAndIndentContinueMarkdownList = function(z) {
        if (z.getOption("disableInput")) return k.Pass;
        for (var T = z.listSelections(), P = [], re = 0; re < T.length; re++) {
          var Q = T[re].head, K = z.getStateAfter(Q.line), fe = k.innerMode(z.getMode(), K);
          if (fe.mode.name !== "markdown" && fe.mode.helperType !== "markdown") {
            z.execCommand("newlineAndIndent");
            return;
          } else
            K = fe.state;
          var ie = K.list !== !1, Se = K.quote !== 0, de = z.getLine(Q.line), ce = W.exec(de), _ = /^\s*$/.test(de.slice(0, Q.ch));
          if (!T[re].empty() || !ie && !Se || !ce || _) {
            z.execCommand("newlineAndIndent");
            return;
          }
          if (N.test(de)) {
            var X = Se && />\s*$/.test(de), q = !/>\s*$/.test(de);
            (X || q) && z.replaceRange("", {
              line: Q.line,
              ch: 0
            }, {
              line: Q.line,
              ch: Q.ch + 1
            }), P[re] = `
`;
          } else {
            var j = ce[1], ue = ce[5], Z = !(I.test(ce[2]) || ce[2].indexOf(">") >= 0), se = Z ? parseInt(ce[3], 10) + 1 + ce[4] : ce[2].replace("x", " ");
            P[re] = `
` + j + se + ue, Z && H(z, Q);
          }
        }
        z.replaceSelections(P);
      };
      function H(z, T) {
        var P = T.line, re = 0, Q = 0, K = W.exec(z.getLine(P)), fe = K[1];
        do {
          re += 1;
          var ie = P + re, Se = z.getLine(ie), de = W.exec(Se);
          if (de) {
            var ce = de[1], _ = parseInt(K[3], 10) + re - Q, X = parseInt(de[3], 10), q = X;
            if (fe === ce && !isNaN(X))
              _ === X && (q = X + 1), _ > X && (q = _ + 1), z.replaceRange(
                Se.replace(W, ce + q + de[4] + de[5]),
                {
                  line: ie,
                  ch: 0
                },
                {
                  line: ie,
                  ch: Se.length
                }
              );
            else {
              if (fe.length > ce.length || fe.length < ce.length && re === 1) return;
              Q += 1;
            }
          }
        } while (de);
      }
    });
  })()), mo.exports;
}
var yo = {}, Do;
function ef() {
  if (Do) return yo;
  Do = 1;
  var ke = zt();
  return ke.commands.tabAndIndentMarkdownList = function(ye) {
    var k = ye.listSelections(), W = k[0].head, N = ye.getStateAfter(W.line), I = N.list !== !1;
    if (I) {
      ye.execCommand("indentMore");
      return;
    }
    if (ye.options.indentWithTabs)
      ye.execCommand("insertTab");
    else {
      var H = Array(ye.options.tabSize + 1).join(" ");
      ye.replaceSelection(H);
    }
  }, ke.commands.shiftTabAndUnindentMarkdownList = function(ye) {
    var k = ye.listSelections(), W = k[0].head, N = ye.getStateAfter(W.line), I = N.list !== !1;
    if (I) {
      ye.execCommand("indentLess");
      return;
    }
    if (ye.options.indentWithTabs)
      ye.execCommand("insertTab");
    else {
      var H = Array(ye.options.tabSize + 1).join(" ");
      ye.replaceSelection(H);
    }
  }, yo;
}
var bo = { exports: {} }, Co;
function tf() {
  return Co || (Co = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.defineOption("fullScreen", !1, function(I, H, z) {
        z == k.Init && (z = !1), !z != !H && (H ? W(I) : N(I));
      });
      function W(I) {
        var H = I.getWrapperElement();
        I.state.fullScreenRestore = {
          scrollTop: window.pageYOffset,
          scrollLeft: window.pageXOffset,
          width: H.style.width,
          height: H.style.height
        }, H.style.width = "", H.style.height = "auto", H.className += " CodeMirror-fullscreen", document.documentElement.style.overflow = "hidden", I.refresh();
      }
      function N(I) {
        var H = I.getWrapperElement();
        H.className = H.className.replace(/\s*CodeMirror-fullscreen\b/, ""), document.documentElement.style.overflow = "";
        var z = I.state.fullScreenRestore;
        H.style.width = z.width, H.style.height = z.height, window.scrollTo(z.scrollLeft, z.scrollTop), I.refresh();
      }
    });
  })()), bo.exports;
}
var wo = { exports: {} }, ko = { exports: {} }, So;
function jo() {
  return So || (So = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      var W = {
        autoSelfClosers: {
          area: !0,
          base: !0,
          br: !0,
          col: !0,
          command: !0,
          embed: !0,
          frame: !0,
          hr: !0,
          img: !0,
          input: !0,
          keygen: !0,
          link: !0,
          meta: !0,
          param: !0,
          source: !0,
          track: !0,
          wbr: !0,
          menuitem: !0
        },
        implicitlyClosed: {
          dd: !0,
          li: !0,
          optgroup: !0,
          option: !0,
          p: !0,
          rp: !0,
          rt: !0,
          tbody: !0,
          td: !0,
          tfoot: !0,
          th: !0,
          tr: !0
        },
        contextGrabbers: {
          dd: { dd: !0, dt: !0 },
          dt: { dd: !0, dt: !0 },
          li: { li: !0 },
          option: { option: !0, optgroup: !0 },
          optgroup: { optgroup: !0 },
          p: {
            address: !0,
            article: !0,
            aside: !0,
            blockquote: !0,
            dir: !0,
            div: !0,
            dl: !0,
            fieldset: !0,
            footer: !0,
            form: !0,
            h1: !0,
            h2: !0,
            h3: !0,
            h4: !0,
            h5: !0,
            h6: !0,
            header: !0,
            hgroup: !0,
            hr: !0,
            menu: !0,
            nav: !0,
            ol: !0,
            p: !0,
            pre: !0,
            section: !0,
            table: !0,
            ul: !0
          },
          rp: { rp: !0, rt: !0 },
          rt: { rp: !0, rt: !0 },
          tbody: { tbody: !0, tfoot: !0 },
          td: { td: !0, th: !0 },
          tfoot: { tbody: !0 },
          th: { td: !0, th: !0 },
          thead: { tbody: !0, tfoot: !0 },
          tr: { tr: !0 }
        },
        doNotIndent: { pre: !0 },
        allowUnquoted: !0,
        allowMissing: !0,
        caseFold: !0
      }, N = {
        autoSelfClosers: {},
        implicitlyClosed: {},
        contextGrabbers: {},
        doNotIndent: {},
        allowUnquoted: !1,
        allowMissing: !1,
        allowMissingTagName: !1,
        caseFold: !1
      };
      k.defineMode("xml", function(I, H) {
        var z = I.indentUnit, T = {}, P = H.htmlMode ? W : N;
        for (var re in P) T[re] = P[re];
        for (var re in H) T[re] = H[re];
        var Q, K;
        function fe(E, ee) {
          function J(rt) {
            return ee.tokenize = rt, rt(E, ee);
          }
          var De = E.next();
          if (De == "<")
            return E.eat("!") ? E.eat("[") ? E.match("CDATA[") ? J(de("atom", "]]>")) : null : E.match("--") ? J(de("comment", "-->")) : E.match("DOCTYPE", !0, !0) ? (E.eatWhile(/[\w\._\-]/), J(ce(1))) : null : E.eat("?") ? (E.eatWhile(/[\w\._\-]/), ee.tokenize = de("meta", "?>"), "meta") : (Q = E.eat("/") ? "closeTag" : "openTag", ee.tokenize = ie, "tag bracket");
          if (De == "&") {
            var We;
            return E.eat("#") ? E.eat("x") ? We = E.eatWhile(/[a-fA-F\d]/) && E.eat(";") : We = E.eatWhile(/[\d]/) && E.eat(";") : We = E.eatWhile(/[\w\.\-:]/) && E.eat(";"), We ? "atom" : "error";
          } else
            return E.eatWhile(/[^&<]/), null;
        }
        fe.isInText = !0;
        function ie(E, ee) {
          var J = E.next();
          if (J == ">" || J == "/" && E.eat(">"))
            return ee.tokenize = fe, Q = J == ">" ? "endTag" : "selfcloseTag", "tag bracket";
          if (J == "=")
            return Q = "equals", null;
          if (J == "<") {
            ee.tokenize = fe, ee.state = ue, ee.tagName = ee.tagStart = null;
            var De = ee.tokenize(E, ee);
            return De ? De + " tag error" : "tag error";
          } else return /[\'\"]/.test(J) ? (ee.tokenize = Se(J), ee.stringStartCol = E.column(), ee.tokenize(E, ee)) : (E.match(/^[^\s\u00a0=<>\"\']*[^\s\u00a0=<>\"\'\/]/), "word");
        }
        function Se(E) {
          var ee = function(J, De) {
            for (; !J.eol(); )
              if (J.next() == E) {
                De.tokenize = ie;
                break;
              }
            return "string";
          };
          return ee.isInAttribute = !0, ee;
        }
        function de(E, ee) {
          return function(J, De) {
            for (; !J.eol(); ) {
              if (J.match(ee)) {
                De.tokenize = fe;
                break;
              }
              J.next();
            }
            return E;
          };
        }
        function ce(E) {
          return function(ee, J) {
            for (var De; (De = ee.next()) != null; ) {
              if (De == "<")
                return J.tokenize = ce(E + 1), J.tokenize(ee, J);
              if (De == ">")
                if (E == 1) {
                  J.tokenize = fe;
                  break;
                } else
                  return J.tokenize = ce(E - 1), J.tokenize(ee, J);
            }
            return "meta";
          };
        }
        function _(E) {
          return E && E.toLowerCase();
        }
        function X(E, ee, J) {
          this.prev = E.context, this.tagName = ee || "", this.indent = E.indented, this.startOfLine = J, (T.doNotIndent.hasOwnProperty(ee) || E.context && E.context.noIndent) && (this.noIndent = !0);
        }
        function q(E) {
          E.context && (E.context = E.context.prev);
        }
        function j(E, ee) {
          for (var J; ; ) {
            if (!E.context || (J = E.context.tagName, !T.contextGrabbers.hasOwnProperty(_(J)) || !T.contextGrabbers[_(J)].hasOwnProperty(_(ee))))
              return;
            q(E);
          }
        }
        function ue(E, ee, J) {
          return E == "openTag" ? (J.tagStart = ee.column(), Z) : E == "closeTag" ? se : ue;
        }
        function Z(E, ee, J) {
          return E == "word" ? (J.tagName = ee.current(), K = "tag", ae) : T.allowMissingTagName && E == "endTag" ? (K = "tag bracket", ae(E, ee, J)) : (K = "error", Z);
        }
        function se(E, ee, J) {
          if (E == "word") {
            var De = ee.current();
            return J.context && J.context.tagName != De && T.implicitlyClosed.hasOwnProperty(_(J.context.tagName)) && q(J), J.context && J.context.tagName == De || T.matchClosing === !1 ? (K = "tag", me) : (K = "tag error", Ue);
          } else return T.allowMissingTagName && E == "endTag" ? (K = "tag bracket", me(E, ee, J)) : (K = "error", Ue);
        }
        function me(E, ee, J) {
          return E != "endTag" ? (K = "error", me) : (q(J), ue);
        }
        function Ue(E, ee, J) {
          return K = "error", me(E, ee, J);
        }
        function ae(E, ee, J) {
          if (E == "word")
            return K = "attribute", Le;
          if (E == "endTag" || E == "selfcloseTag") {
            var De = J.tagName, We = J.tagStart;
            return J.tagName = J.tagStart = null, E == "selfcloseTag" || T.autoSelfClosers.hasOwnProperty(_(De)) ? j(J, De) : (j(J, De), J.context = new X(J, De, We == J.indented)), ue;
          }
          return K = "error", ae;
        }
        function Le(E, ee, J) {
          return E == "equals" ? Ee : (T.allowMissing || (K = "error"), ae(E, ee, J));
        }
        function Ee(E, ee, J) {
          return E == "string" ? He : E == "word" && T.allowUnquoted ? (K = "string", ae) : (K = "error", ae(E, ee, J));
        }
        function He(E, ee, J) {
          return E == "string" ? He : ae(E, ee, J);
        }
        return {
          startState: function(E) {
            var ee = {
              tokenize: fe,
              state: ue,
              indented: E || 0,
              tagName: null,
              tagStart: null,
              context: null
            };
            return E != null && (ee.baseIndent = E), ee;
          },
          token: function(E, ee) {
            if (!ee.tagName && E.sol() && (ee.indented = E.indentation()), E.eatSpace()) return null;
            Q = null;
            var J = ee.tokenize(E, ee);
            return (J || Q) && J != "comment" && (K = null, ee.state = ee.state(Q || J, E, ee), K && (J = K == "error" ? J + " error" : K)), J;
          },
          indent: function(E, ee, J) {
            var De = E.context;
            if (E.tokenize.isInAttribute)
              return E.tagStart == E.indented ? E.stringStartCol + 1 : E.indented + z;
            if (De && De.noIndent) return k.Pass;
            if (E.tokenize != ie && E.tokenize != fe)
              return J ? J.match(/^(\s*)/)[0].length : 0;
            if (E.tagName)
              return T.multilineTagIndentPastTag !== !1 ? E.tagStart + E.tagName.length + 2 : E.tagStart + z * (T.multilineTagIndentFactor || 1);
            if (T.alignCDATA && /<!\[CDATA\[/.test(ee)) return 0;
            var We = ee && /^<(\/)?([\w_:\.-]*)/.exec(ee);
            if (We && We[1])
              for (; De; )
                if (De.tagName == We[2]) {
                  De = De.prev;
                  break;
                } else if (T.implicitlyClosed.hasOwnProperty(_(De.tagName)))
                  De = De.prev;
                else
                  break;
            else if (We)
              for (; De; ) {
                var rt = T.contextGrabbers[_(De.tagName)];
                if (rt && rt.hasOwnProperty(_(We[2])))
                  De = De.prev;
                else
                  break;
              }
            for (; De && De.prev && !De.startOfLine; )
              De = De.prev;
            return De ? De.indent + z : E.baseIndent || 0;
          },
          electricInput: /<\/[\s\w:]+>$/,
          blockCommentStart: "<!--",
          blockCommentEnd: "-->",
          configuration: T.htmlMode ? "html" : "xml",
          helperType: T.htmlMode ? "html" : "xml",
          skipAttribute: function(E) {
            E.state == Ee && (E.state = ae);
          },
          xmlCurrentTag: function(E) {
            return E.tagName ? { name: E.tagName, close: E.type == "closeTag" } : null;
          },
          xmlCurrentContext: function(E) {
            for (var ee = [], J = E.context; J; J = J.prev)
              ee.push(J.tagName);
            return ee.reverse();
          }
        };
      }), k.defineMIME("text/xml", "xml"), k.defineMIME("application/xml", "xml"), k.mimeModes.hasOwnProperty("text/html") || k.defineMIME("text/html", { name: "xml", htmlMode: !0 });
    });
  })()), ko.exports;
}
var Fo = { exports: {} }, Ao;
function rf() {
  return Ao || (Ao = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.modeInfo = [
        { name: "APL", mime: "text/apl", mode: "apl", ext: ["dyalog", "apl"] },
        { name: "PGP", mimes: ["application/pgp", "application/pgp-encrypted", "application/pgp-keys", "application/pgp-signature"], mode: "asciiarmor", ext: ["asc", "pgp", "sig"] },
        { name: "ASN.1", mime: "text/x-ttcn-asn", mode: "asn.1", ext: ["asn", "asn1"] },
        { name: "Asterisk", mime: "text/x-asterisk", mode: "asterisk", file: /^extensions\.conf$/i },
        { name: "Brainfuck", mime: "text/x-brainfuck", mode: "brainfuck", ext: ["b", "bf"] },
        { name: "C", mime: "text/x-csrc", mode: "clike", ext: ["c", "h", "ino"] },
        { name: "C++", mime: "text/x-c++src", mode: "clike", ext: ["cpp", "c++", "cc", "cxx", "hpp", "h++", "hh", "hxx"], alias: ["cpp"] },
        { name: "Cobol", mime: "text/x-cobol", mode: "cobol", ext: ["cob", "cpy", "cbl"] },
        { name: "C#", mime: "text/x-csharp", mode: "clike", ext: ["cs"], alias: ["csharp", "cs"] },
        { name: "Clojure", mime: "text/x-clojure", mode: "clojure", ext: ["clj", "cljc", "cljx"] },
        { name: "ClojureScript", mime: "text/x-clojurescript", mode: "clojure", ext: ["cljs"] },
        { name: "Closure Stylesheets (GSS)", mime: "text/x-gss", mode: "css", ext: ["gss"] },
        { name: "CMake", mime: "text/x-cmake", mode: "cmake", ext: ["cmake", "cmake.in"], file: /^CMakeLists\.txt$/ },
        { name: "CoffeeScript", mimes: ["application/vnd.coffeescript", "text/coffeescript", "text/x-coffeescript"], mode: "coffeescript", ext: ["coffee"], alias: ["coffee", "coffee-script"] },
        { name: "Common Lisp", mime: "text/x-common-lisp", mode: "commonlisp", ext: ["cl", "lisp", "el"], alias: ["lisp"] },
        { name: "Cypher", mime: "application/x-cypher-query", mode: "cypher", ext: ["cyp", "cypher"] },
        { name: "Cython", mime: "text/x-cython", mode: "python", ext: ["pyx", "pxd", "pxi"] },
        { name: "Crystal", mime: "text/x-crystal", mode: "crystal", ext: ["cr"] },
        { name: "CSS", mime: "text/css", mode: "css", ext: ["css"] },
        { name: "CQL", mime: "text/x-cassandra", mode: "sql", ext: ["cql"] },
        { name: "D", mime: "text/x-d", mode: "d", ext: ["d"] },
        { name: "Dart", mimes: ["application/dart", "text/x-dart"], mode: "dart", ext: ["dart"] },
        { name: "diff", mime: "text/x-diff", mode: "diff", ext: ["diff", "patch"] },
        { name: "Django", mime: "text/x-django", mode: "django" },
        { name: "Dockerfile", mime: "text/x-dockerfile", mode: "dockerfile", file: /^Dockerfile$/ },
        { name: "DTD", mime: "application/xml-dtd", mode: "dtd", ext: ["dtd"] },
        { name: "Dylan", mime: "text/x-dylan", mode: "dylan", ext: ["dylan", "dyl", "intr"] },
        { name: "EBNF", mime: "text/x-ebnf", mode: "ebnf" },
        { name: "ECL", mime: "text/x-ecl", mode: "ecl", ext: ["ecl"] },
        { name: "edn", mime: "application/edn", mode: "clojure", ext: ["edn"] },
        { name: "Eiffel", mime: "text/x-eiffel", mode: "eiffel", ext: ["e"] },
        { name: "Elm", mime: "text/x-elm", mode: "elm", ext: ["elm"] },
        { name: "Embedded JavaScript", mime: "application/x-ejs", mode: "htmlembedded", ext: ["ejs"] },
        { name: "Embedded Ruby", mime: "application/x-erb", mode: "htmlembedded", ext: ["erb"] },
        { name: "Erlang", mime: "text/x-erlang", mode: "erlang", ext: ["erl"] },
        { name: "Esper", mime: "text/x-esper", mode: "sql" },
        { name: "Factor", mime: "text/x-factor", mode: "factor", ext: ["factor"] },
        { name: "FCL", mime: "text/x-fcl", mode: "fcl" },
        { name: "Forth", mime: "text/x-forth", mode: "forth", ext: ["forth", "fth", "4th"] },
        { name: "Fortran", mime: "text/x-fortran", mode: "fortran", ext: ["f", "for", "f77", "f90", "f95"] },
        { name: "F#", mime: "text/x-fsharp", mode: "mllike", ext: ["fs"], alias: ["fsharp"] },
        { name: "Gas", mime: "text/x-gas", mode: "gas", ext: ["s"] },
        { name: "Gherkin", mime: "text/x-feature", mode: "gherkin", ext: ["feature"] },
        { name: "GitHub Flavored Markdown", mime: "text/x-gfm", mode: "gfm", file: /^(readme|contributing|history)\.md$/i },
        { name: "Go", mime: "text/x-go", mode: "go", ext: ["go"] },
        { name: "Groovy", mime: "text/x-groovy", mode: "groovy", ext: ["groovy", "gradle"], file: /^Jenkinsfile$/ },
        { name: "HAML", mime: "text/x-haml", mode: "haml", ext: ["haml"] },
        { name: "Haskell", mime: "text/x-haskell", mode: "haskell", ext: ["hs"] },
        { name: "Haskell (Literate)", mime: "text/x-literate-haskell", mode: "haskell-literate", ext: ["lhs"] },
        { name: "Haxe", mime: "text/x-haxe", mode: "haxe", ext: ["hx"] },
        { name: "HXML", mime: "text/x-hxml", mode: "haxe", ext: ["hxml"] },
        { name: "ASP.NET", mime: "application/x-aspx", mode: "htmlembedded", ext: ["aspx"], alias: ["asp", "aspx"] },
        { name: "HTML", mime: "text/html", mode: "htmlmixed", ext: ["html", "htm", "handlebars", "hbs"], alias: ["xhtml"] },
        { name: "HTTP", mime: "message/http", mode: "http" },
        { name: "IDL", mime: "text/x-idl", mode: "idl", ext: ["pro"] },
        { name: "Pug", mime: "text/x-pug", mode: "pug", ext: ["jade", "pug"], alias: ["jade"] },
        { name: "Java", mime: "text/x-java", mode: "clike", ext: ["java"] },
        { name: "Java Server Pages", mime: "application/x-jsp", mode: "htmlembedded", ext: ["jsp"], alias: ["jsp"] },
        {
          name: "JavaScript",
          mimes: ["text/javascript", "text/ecmascript", "application/javascript", "application/x-javascript", "application/ecmascript"],
          mode: "javascript",
          ext: ["js"],
          alias: ["ecmascript", "js", "node"]
        },
        { name: "JSON", mimes: ["application/json", "application/x-json"], mode: "javascript", ext: ["json", "map"], alias: ["json5"] },
        { name: "JSON-LD", mime: "application/ld+json", mode: "javascript", ext: ["jsonld"], alias: ["jsonld"] },
        { name: "JSX", mime: "text/jsx", mode: "jsx", ext: ["jsx"] },
        { name: "Jinja2", mime: "text/jinja2", mode: "jinja2", ext: ["j2", "jinja", "jinja2"] },
        { name: "Julia", mime: "text/x-julia", mode: "julia", ext: ["jl"], alias: ["jl"] },
        { name: "Kotlin", mime: "text/x-kotlin", mode: "clike", ext: ["kt"] },
        { name: "LESS", mime: "text/x-less", mode: "css", ext: ["less"] },
        { name: "LiveScript", mime: "text/x-livescript", mode: "livescript", ext: ["ls"], alias: ["ls"] },
        { name: "Lua", mime: "text/x-lua", mode: "lua", ext: ["lua"] },
        { name: "Markdown", mime: "text/x-markdown", mode: "markdown", ext: ["markdown", "md", "mkd"] },
        { name: "mIRC", mime: "text/mirc", mode: "mirc" },
        { name: "MariaDB SQL", mime: "text/x-mariadb", mode: "sql" },
        { name: "Mathematica", mime: "text/x-mathematica", mode: "mathematica", ext: ["m", "nb", "wl", "wls"] },
        { name: "Modelica", mime: "text/x-modelica", mode: "modelica", ext: ["mo"] },
        { name: "MUMPS", mime: "text/x-mumps", mode: "mumps", ext: ["mps"] },
        { name: "MS SQL", mime: "text/x-mssql", mode: "sql" },
        { name: "mbox", mime: "application/mbox", mode: "mbox", ext: ["mbox"] },
        { name: "MySQL", mime: "text/x-mysql", mode: "sql" },
        { name: "Nginx", mime: "text/x-nginx-conf", mode: "nginx", file: /nginx.*\.conf$/i },
        { name: "NSIS", mime: "text/x-nsis", mode: "nsis", ext: ["nsh", "nsi"] },
        {
          name: "NTriples",
          mimes: ["application/n-triples", "application/n-quads", "text/n-triples"],
          mode: "ntriples",
          ext: ["nt", "nq"]
        },
        { name: "Objective-C", mime: "text/x-objectivec", mode: "clike", ext: ["m"], alias: ["objective-c", "objc"] },
        { name: "Objective-C++", mime: "text/x-objectivec++", mode: "clike", ext: ["mm"], alias: ["objective-c++", "objc++"] },
        { name: "OCaml", mime: "text/x-ocaml", mode: "mllike", ext: ["ml", "mli", "mll", "mly"] },
        { name: "Octave", mime: "text/x-octave", mode: "octave", ext: ["m"] },
        { name: "Oz", mime: "text/x-oz", mode: "oz", ext: ["oz"] },
        { name: "Pascal", mime: "text/x-pascal", mode: "pascal", ext: ["p", "pas"] },
        { name: "PEG.js", mime: "null", mode: "pegjs", ext: ["jsonld"] },
        { name: "Perl", mime: "text/x-perl", mode: "perl", ext: ["pl", "pm"] },
        { name: "PHP", mimes: ["text/x-php", "application/x-httpd-php", "application/x-httpd-php-open"], mode: "php", ext: ["php", "php3", "php4", "php5", "php7", "phtml"] },
        { name: "Pig", mime: "text/x-pig", mode: "pig", ext: ["pig"] },
        { name: "Plain Text", mime: "text/plain", mode: "null", ext: ["txt", "text", "conf", "def", "list", "log"] },
        { name: "PLSQL", mime: "text/x-plsql", mode: "sql", ext: ["pls"] },
        { name: "PostgreSQL", mime: "text/x-pgsql", mode: "sql" },
        { name: "PowerShell", mime: "application/x-powershell", mode: "powershell", ext: ["ps1", "psd1", "psm1"] },
        { name: "Properties files", mime: "text/x-properties", mode: "properties", ext: ["properties", "ini", "in"], alias: ["ini", "properties"] },
        { name: "ProtoBuf", mime: "text/x-protobuf", mode: "protobuf", ext: ["proto"] },
        { name: "Python", mime: "text/x-python", mode: "python", ext: ["BUILD", "bzl", "py", "pyw"], file: /^(BUCK|BUILD)$/ },
        { name: "Puppet", mime: "text/x-puppet", mode: "puppet", ext: ["pp"] },
        { name: "Q", mime: "text/x-q", mode: "q", ext: ["q"] },
        { name: "R", mime: "text/x-rsrc", mode: "r", ext: ["r", "R"], alias: ["rscript"] },
        { name: "reStructuredText", mime: "text/x-rst", mode: "rst", ext: ["rst"], alias: ["rst"] },
        { name: "RPM Changes", mime: "text/x-rpm-changes", mode: "rpm" },
        { name: "RPM Spec", mime: "text/x-rpm-spec", mode: "rpm", ext: ["spec"] },
        { name: "Ruby", mime: "text/x-ruby", mode: "ruby", ext: ["rb"], alias: ["jruby", "macruby", "rake", "rb", "rbx"] },
        { name: "Rust", mime: "text/x-rustsrc", mode: "rust", ext: ["rs"] },
        { name: "SAS", mime: "text/x-sas", mode: "sas", ext: ["sas"] },
        { name: "Sass", mime: "text/x-sass", mode: "sass", ext: ["sass"] },
        { name: "Scala", mime: "text/x-scala", mode: "clike", ext: ["scala"] },
        { name: "Scheme", mime: "text/x-scheme", mode: "scheme", ext: ["scm", "ss"] },
        { name: "SCSS", mime: "text/x-scss", mode: "css", ext: ["scss"] },
        { name: "Shell", mimes: ["text/x-sh", "application/x-sh"], mode: "shell", ext: ["sh", "ksh", "bash"], alias: ["bash", "sh", "zsh"], file: /^PKGBUILD$/ },
        { name: "Sieve", mime: "application/sieve", mode: "sieve", ext: ["siv", "sieve"] },
        { name: "Slim", mimes: ["text/x-slim", "application/x-slim"], mode: "slim", ext: ["slim"] },
        { name: "Smalltalk", mime: "text/x-stsrc", mode: "smalltalk", ext: ["st"] },
        { name: "Smarty", mime: "text/x-smarty", mode: "smarty", ext: ["tpl"] },
        { name: "Solr", mime: "text/x-solr", mode: "solr" },
        { name: "SML", mime: "text/x-sml", mode: "mllike", ext: ["sml", "sig", "fun", "smackspec"] },
        { name: "Soy", mime: "text/x-soy", mode: "soy", ext: ["soy"], alias: ["closure template"] },
        { name: "SPARQL", mime: "application/sparql-query", mode: "sparql", ext: ["rq", "sparql"], alias: ["sparul"] },
        { name: "Spreadsheet", mime: "text/x-spreadsheet", mode: "spreadsheet", alias: ["excel", "formula"] },
        { name: "SQL", mime: "text/x-sql", mode: "sql", ext: ["sql"] },
        { name: "SQLite", mime: "text/x-sqlite", mode: "sql" },
        { name: "Squirrel", mime: "text/x-squirrel", mode: "clike", ext: ["nut"] },
        { name: "Stylus", mime: "text/x-styl", mode: "stylus", ext: ["styl"] },
        { name: "Swift", mime: "text/x-swift", mode: "swift", ext: ["swift"] },
        { name: "sTeX", mime: "text/x-stex", mode: "stex" },
        { name: "LaTeX", mime: "text/x-latex", mode: "stex", ext: ["text", "ltx", "tex"], alias: ["tex"] },
        { name: "SystemVerilog", mime: "text/x-systemverilog", mode: "verilog", ext: ["v", "sv", "svh"] },
        { name: "Tcl", mime: "text/x-tcl", mode: "tcl", ext: ["tcl"] },
        { name: "Textile", mime: "text/x-textile", mode: "textile", ext: ["textile"] },
        { name: "TiddlyWiki", mime: "text/x-tiddlywiki", mode: "tiddlywiki" },
        { name: "Tiki wiki", mime: "text/tiki", mode: "tiki" },
        { name: "TOML", mime: "text/x-toml", mode: "toml", ext: ["toml"] },
        { name: "Tornado", mime: "text/x-tornado", mode: "tornado" },
        { name: "troff", mime: "text/troff", mode: "troff", ext: ["1", "2", "3", "4", "5", "6", "7", "8", "9"] },
        { name: "TTCN", mime: "text/x-ttcn", mode: "ttcn", ext: ["ttcn", "ttcn3", "ttcnpp"] },
        { name: "TTCN_CFG", mime: "text/x-ttcn-cfg", mode: "ttcn-cfg", ext: ["cfg"] },
        { name: "Turtle", mime: "text/turtle", mode: "turtle", ext: ["ttl"] },
        { name: "TypeScript", mime: "application/typescript", mode: "javascript", ext: ["ts"], alias: ["ts"] },
        { name: "TypeScript-JSX", mime: "text/typescript-jsx", mode: "jsx", ext: ["tsx"], alias: ["tsx"] },
        { name: "Twig", mime: "text/x-twig", mode: "twig" },
        { name: "Web IDL", mime: "text/x-webidl", mode: "webidl", ext: ["webidl"] },
        { name: "VB.NET", mime: "text/x-vb", mode: "vb", ext: ["vb"] },
        { name: "VBScript", mime: "text/vbscript", mode: "vbscript", ext: ["vbs"] },
        { name: "Velocity", mime: "text/velocity", mode: "velocity", ext: ["vtl"] },
        { name: "Verilog", mime: "text/x-verilog", mode: "verilog", ext: ["v"] },
        { name: "VHDL", mime: "text/x-vhdl", mode: "vhdl", ext: ["vhd", "vhdl"] },
        { name: "Vue.js Component", mimes: ["script/x-vue", "text/x-vue"], mode: "vue", ext: ["vue"] },
        { name: "XML", mimes: ["application/xml", "text/xml"], mode: "xml", ext: ["xml", "xsl", "xsd", "svg"], alias: ["rss", "wsdl", "xsd"] },
        { name: "XQuery", mime: "application/xquery", mode: "xquery", ext: ["xy", "xquery"] },
        { name: "Yacas", mime: "text/x-yacas", mode: "yacas", ext: ["ys"] },
        { name: "YAML", mimes: ["text/x-yaml", "text/yaml"], mode: "yaml", ext: ["yaml", "yml"], alias: ["yml"] },
        { name: "Z80", mime: "text/x-z80", mode: "z80", ext: ["z80"] },
        { name: "mscgen", mime: "text/x-mscgen", mode: "mscgen", ext: ["mscgen", "mscin", "msc"] },
        { name: "xu", mime: "text/x-xu", mode: "mscgen", ext: ["xu"] },
        { name: "msgenny", mime: "text/x-msgenny", mode: "mscgen", ext: ["msgenny"] },
        { name: "WebAssembly", mime: "text/webassembly", mode: "wast", ext: ["wat", "wast"] }
      ];
      for (var W = 0; W < k.modeInfo.length; W++) {
        var N = k.modeInfo[W];
        N.mimes && (N.mime = N.mimes[0]);
      }
      k.findModeByMIME = function(I) {
        I = I.toLowerCase();
        for (var H = 0; H < k.modeInfo.length; H++) {
          var z = k.modeInfo[H];
          if (z.mime == I) return z;
          if (z.mimes) {
            for (var T = 0; T < z.mimes.length; T++)
              if (z.mimes[T] == I) return z;
          }
        }
        if (/\+xml$/.test(I)) return k.findModeByMIME("application/xml");
        if (/\+json$/.test(I)) return k.findModeByMIME("application/json");
      }, k.findModeByExtension = function(I) {
        I = I.toLowerCase();
        for (var H = 0; H < k.modeInfo.length; H++) {
          var z = k.modeInfo[H];
          if (z.ext) {
            for (var T = 0; T < z.ext.length; T++)
              if (z.ext[T] == I) return z;
          }
        }
      }, k.findModeByFileName = function(I) {
        for (var H = 0; H < k.modeInfo.length; H++) {
          var z = k.modeInfo[H];
          if (z.file && z.file.test(I)) return z;
        }
        var T = I.lastIndexOf("."), P = T > -1 && I.substring(T + 1, I.length);
        if (P) return k.findModeByExtension(P);
      }, k.findModeByName = function(I) {
        I = I.toLowerCase();
        for (var H = 0; H < k.modeInfo.length; H++) {
          var z = k.modeInfo[H];
          if (z.name.toLowerCase() == I) return z;
          if (z.alias) {
            for (var T = 0; T < z.alias.length; T++)
              if (z.alias[T].toLowerCase() == I) return z;
          }
        }
      };
    });
  })()), Fo.exports;
}
var Eo;
function Ko() {
  return Eo || (Eo = 1, (function(ke, ye) {
    (function(k) {
      k(zt(), jo(), rf());
    })(function(k) {
      k.defineMode("markdown", function(W, N) {
        var I = k.getMode(W, "text/html"), H = I.name == "null";
        function z(D) {
          if (k.findModeByName) {
            var p = k.findModeByName(D);
            p && (D = p.mime || p.mimes[0]);
          }
          var G = k.getMode(W, D);
          return G.name == "null" ? null : G;
        }
        N.highlightFormatting === void 0 && (N.highlightFormatting = !1), N.maxBlockquoteDepth === void 0 && (N.maxBlockquoteDepth = 0), N.taskLists === void 0 && (N.taskLists = !1), N.strikethrough === void 0 && (N.strikethrough = !1), N.emoji === void 0 && (N.emoji = !1), N.fencedCodeBlockHighlighting === void 0 && (N.fencedCodeBlockHighlighting = !0), N.fencedCodeBlockDefaultMode === void 0 && (N.fencedCodeBlockDefaultMode = "text/plain"), N.xml === void 0 && (N.xml = !0), N.tokenTypeOverrides === void 0 && (N.tokenTypeOverrides = {});
        var T = {
          header: "header",
          code: "comment",
          quote: "quote",
          list1: "variable-2",
          list2: "variable-3",
          list3: "keyword",
          hr: "hr",
          image: "image",
          imageAltText: "image-alt-text",
          imageMarker: "image-marker",
          formatting: "formatting",
          linkInline: "link",
          linkEmail: "link",
          linkText: "link",
          linkHref: "string",
          em: "em",
          strong: "strong",
          strikethrough: "strikethrough",
          emoji: "builtin"
        };
        for (var P in T)
          T.hasOwnProperty(P) && N.tokenTypeOverrides[P] && (T[P] = N.tokenTypeOverrides[P]);
        var re = /^([*\-_])(?:\s*\1){2,}\s*$/, Q = /^(?:[*\-+]|^[0-9]+([.)]))\s+/, K = /^\[(x| )\](?=\s)/i, fe = N.allowAtxHeaderWithoutSpace ? /^(#+)/ : /^(#+)(?: |$)/, ie = /^ {0,3}(?:\={1,}|-{2,})\s*$/, Se = /^[^#!\[\]*_\\<>` "'(~:]+/, de = /^(~~~+|```+)[ \t]*([\w\/+#-]*)[^\n`]*$/, ce = /^\s*\[[^\]]+?\]:.*$/, _ = /[!"#$%&'()*+,\-.\/:;<=>?@\[\\\]^_`{|}~\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u0AF0\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166D\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E42\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC9\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9]|\uD805[\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDF3C-\uDF3E]|\uD809[\uDC70-\uDC74]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]/, X = "    ";
        function q(D, p, G) {
          return p.f = p.inline = G, G(D, p);
        }
        function j(D, p, G) {
          return p.f = p.block = G, G(D, p);
        }
        function ue(D) {
          return !D || !/\S/.test(D.string);
        }
        function Z(D) {
          if (D.linkTitle = !1, D.linkHref = !1, D.linkText = !1, D.em = !1, D.strong = !1, D.strikethrough = !1, D.quote = 0, D.indentedCode = !1, D.f == me) {
            var p = H;
            if (!p) {
              var G = k.innerMode(I, D.htmlState);
              p = G.mode.name == "xml" && G.state.tagStart === null && !G.state.context && G.state.tokenize.isInText;
            }
            p && (D.f = Ee, D.block = se, D.htmlState = null);
          }
          return D.trailingSpace = 0, D.trailingSpaceNewLine = !1, D.prevLine = D.thisLine, D.thisLine = { stream: null }, null;
        }
        function se(D, p) {
          var G = D.column() === p.indentation, ze = ue(p.prevLine.stream), Te = p.indentedCode, Je = p.prevLine.hr, $e = p.list !== !1, Ke = (p.listStack[p.listStack.length - 1] || 0) + 3;
          p.indentedCode = !1;
          var Ye = p.indentation;
          if (p.indentationDiff === null && (p.indentationDiff = p.indentation, $e)) {
            for (p.list = null; Ye < p.listStack[p.listStack.length - 1]; )
              p.listStack.pop(), p.listStack.length ? p.indentation = p.listStack[p.listStack.length - 1] : p.list = !1;
            p.list !== !1 && (p.indentationDiff = Ye - p.listStack[p.listStack.length - 1]);
          }
          var Pe = !ze && !Je && !p.prevLine.header && (!$e || !Te) && !p.prevLine.fencedCodeEnd, _e = (p.list === !1 || Je || ze) && p.indentation <= Ke && D.match(re), Ve = null;
          if (p.indentationDiff >= 4 && (Te || p.prevLine.fencedCodeEnd || p.prevLine.header || ze))
            return D.skipToEnd(), p.indentedCode = !0, T.code;
          if (D.eatSpace())
            return null;
          if (G && p.indentation <= Ke && (Ve = D.match(fe)) && Ve[1].length <= 6)
            return p.quote = 0, p.header = Ve[1].length, p.thisLine.header = !0, N.highlightFormatting && (p.formatting = "header"), p.f = p.inline, ae(p);
          if (p.indentation <= Ke && D.eat(">"))
            return p.quote = G ? 1 : p.quote + 1, N.highlightFormatting && (p.formatting = "quote"), D.eatSpace(), ae(p);
          if (!_e && !p.setext && G && p.indentation <= Ke && (Ve = D.match(Q))) {
            var at = Ve[1] ? "ol" : "ul";
            return p.indentation = Ye + D.current().length, p.list = !0, p.quote = 0, p.listStack.push(p.indentation), p.em = !1, p.strong = !1, p.code = !1, p.strikethrough = !1, N.taskLists && D.match(K, !1) && (p.taskList = !0), p.f = p.inline, N.highlightFormatting && (p.formatting = ["list", "list-" + at]), ae(p);
          } else {
            if (G && p.indentation <= Ke && (Ve = D.match(de, !0)))
              return p.quote = 0, p.fencedEndRE = new RegExp(Ve[1] + "+ *$"), p.localMode = N.fencedCodeBlockHighlighting && z(Ve[2] || N.fencedCodeBlockDefaultMode), p.localMode && (p.localState = k.startState(p.localMode)), p.f = p.block = Ue, N.highlightFormatting && (p.formatting = "code-block"), p.code = -1, ae(p);
            if (
              // if setext set, indicates line after ---/===
              p.setext || // line before ---/===
              (!Pe || !$e) && !p.quote && p.list === !1 && !p.code && !_e && !ce.test(D.string) && (Ve = D.lookAhead(1)) && (Ve = Ve.match(ie))
            )
              return p.setext ? (p.header = p.setext, p.setext = 0, D.skipToEnd(), N.highlightFormatting && (p.formatting = "header")) : (p.header = Ve[0].charAt(0) == "=" ? 1 : 2, p.setext = p.header), p.thisLine.header = !0, p.f = p.inline, ae(p);
            if (_e)
              return D.skipToEnd(), p.hr = !0, p.thisLine.hr = !0, T.hr;
            if (D.peek() === "[")
              return q(D, p, De);
          }
          return q(D, p, p.inline);
        }
        function me(D, p) {
          var G = I.token(D, p.htmlState);
          if (!H) {
            var ze = k.innerMode(I, p.htmlState);
            (ze.mode.name == "xml" && ze.state.tagStart === null && !ze.state.context && ze.state.tokenize.isInText || p.md_inside && D.current().indexOf(">") > -1) && (p.f = Ee, p.block = se, p.htmlState = null);
          }
          return G;
        }
        function Ue(D, p) {
          var G = p.listStack[p.listStack.length - 1] || 0, ze = p.indentation < G, Te = G + 3;
          if (p.fencedEndRE && p.indentation <= Te && (ze || D.match(p.fencedEndRE))) {
            N.highlightFormatting && (p.formatting = "code-block");
            var Je;
            return ze || (Je = ae(p)), p.localMode = p.localState = null, p.block = se, p.f = Ee, p.fencedEndRE = null, p.code = 0, p.thisLine.fencedCodeEnd = !0, ze ? j(D, p, p.block) : Je;
          } else return p.localMode ? p.localMode.token(D, p.localState) : (D.skipToEnd(), T.code);
        }
        function ae(D) {
          var p = [];
          if (D.formatting) {
            p.push(T.formatting), typeof D.formatting == "string" && (D.formatting = [D.formatting]);
            for (var G = 0; G < D.formatting.length; G++)
              p.push(T.formatting + "-" + D.formatting[G]), D.formatting[G] === "header" && p.push(T.formatting + "-" + D.formatting[G] + "-" + D.header), D.formatting[G] === "quote" && (!N.maxBlockquoteDepth || N.maxBlockquoteDepth >= D.quote ? p.push(T.formatting + "-" + D.formatting[G] + "-" + D.quote) : p.push("error"));
          }
          if (D.taskOpen)
            return p.push("meta"), p.length ? p.join(" ") : null;
          if (D.taskClosed)
            return p.push("property"), p.length ? p.join(" ") : null;
          if (D.linkHref ? p.push(T.linkHref, "url") : (D.strong && p.push(T.strong), D.em && p.push(T.em), D.strikethrough && p.push(T.strikethrough), D.emoji && p.push(T.emoji), D.linkText && p.push(T.linkText), D.code && p.push(T.code), D.image && p.push(T.image), D.imageAltText && p.push(T.imageAltText, "link"), D.imageMarker && p.push(T.imageMarker)), D.header && p.push(T.header, T.header + "-" + D.header), D.quote && (p.push(T.quote), !N.maxBlockquoteDepth || N.maxBlockquoteDepth >= D.quote ? p.push(T.quote + "-" + D.quote) : p.push(T.quote + "-" + N.maxBlockquoteDepth)), D.list !== !1) {
            var ze = (D.listStack.length - 1) % 3;
            ze ? ze === 1 ? p.push(T.list2) : p.push(T.list3) : p.push(T.list1);
          }
          return D.trailingSpaceNewLine ? p.push("trailing-space-new-line") : D.trailingSpace && p.push("trailing-space-" + (D.trailingSpace % 2 ? "a" : "b")), p.length ? p.join(" ") : null;
        }
        function Le(D, p) {
          if (D.match(Se, !0))
            return ae(p);
        }
        function Ee(D, p) {
          var G = p.text(D, p);
          if (typeof G < "u")
            return G;
          if (p.list)
            return p.list = null, ae(p);
          if (p.taskList) {
            var ze = D.match(K, !0)[1] === " ";
            return ze ? p.taskOpen = !0 : p.taskClosed = !0, N.highlightFormatting && (p.formatting = "task"), p.taskList = !1, ae(p);
          }
          if (p.taskOpen = !1, p.taskClosed = !1, p.header && D.match(/^#+$/, !0))
            return N.highlightFormatting && (p.formatting = "header"), ae(p);
          var Te = D.next();
          if (p.linkTitle) {
            p.linkTitle = !1;
            var Je = Te;
            Te === "(" && (Je = ")"), Je = (Je + "").replace(/([.?*+^\[\]\\(){}|-])/g, "\\$1");
            var $e = "^\\s*(?:[^" + Je + "\\\\]+|\\\\\\\\|\\\\.)" + Je;
            if (D.match(new RegExp($e), !0))
              return T.linkHref;
          }
          if (Te === "`") {
            var Ke = p.formatting;
            N.highlightFormatting && (p.formatting = "code"), D.eatWhile("`");
            var Ye = D.current().length;
            if (p.code == 0 && (!p.quote || Ye == 1))
              return p.code = Ye, ae(p);
            if (Ye == p.code) {
              var Pe = ae(p);
              return p.code = 0, Pe;
            } else
              return p.formatting = Ke, ae(p);
          } else if (p.code)
            return ae(p);
          if (Te === "\\" && (D.next(), N.highlightFormatting)) {
            var _e = ae(p), Ve = T.formatting + "-escape";
            return _e ? _e + " " + Ve : Ve;
          }
          if (Te === "!" && D.match(/\[[^\]]*\] ?(?:\(|\[)/, !1))
            return p.imageMarker = !0, p.image = !0, N.highlightFormatting && (p.formatting = "image"), ae(p);
          if (Te === "[" && p.imageMarker && D.match(/[^\]]*\](\(.*?\)| ?\[.*?\])/, !1))
            return p.imageMarker = !1, p.imageAltText = !0, N.highlightFormatting && (p.formatting = "image"), ae(p);
          if (Te === "]" && p.imageAltText) {
            N.highlightFormatting && (p.formatting = "image");
            var _e = ae(p);
            return p.imageAltText = !1, p.image = !1, p.inline = p.f = E, _e;
          }
          if (Te === "[" && !p.image)
            return p.linkText && D.match(/^.*?\]/) || (p.linkText = !0, N.highlightFormatting && (p.formatting = "link")), ae(p);
          if (Te === "]" && p.linkText) {
            N.highlightFormatting && (p.formatting = "link");
            var _e = ae(p);
            return p.linkText = !1, p.inline = p.f = D.match(/\(.*?\)| ?\[.*?\]/, !1) ? E : Ee, _e;
          }
          if (Te === "<" && D.match(/^(https?|ftps?):\/\/(?:[^\\>]|\\.)+>/, !1)) {
            p.f = p.inline = He, N.highlightFormatting && (p.formatting = "link");
            var _e = ae(p);
            return _e ? _e += " " : _e = "", _e + T.linkInline;
          }
          if (Te === "<" && D.match(/^[^> \\]+@(?:[^\\>]|\\.)+>/, !1)) {
            p.f = p.inline = He, N.highlightFormatting && (p.formatting = "link");
            var _e = ae(p);
            return _e ? _e += " " : _e = "", _e + T.linkEmail;
          }
          if (N.xml && Te === "<" && D.match(/^(!--|\?|!\[CDATA\[|[a-z][a-z0-9-]*(?:\s+[a-z_:.\-]+(?:\s*=\s*[^>]+)?)*\s*(?:>|$))/i, !1)) {
            var at = D.string.indexOf(">", D.pos);
            if (at != -1) {
              var Ce = D.string.substring(D.start, at);
              /markdown\s*=\s*('|"){0,1}1('|"){0,1}/.test(Ce) && (p.md_inside = !0);
            }
            return D.backUp(1), p.htmlState = k.startState(I), j(D, p, me);
          }
          if (N.xml && Te === "<" && D.match(/^\/\w*?>/))
            return p.md_inside = !1, "tag";
          if (Te === "*" || Te === "_") {
            for (var Dt = 1, At = D.pos == 1 ? " " : D.string.charAt(D.pos - 2); Dt < 3 && D.eat(Te); ) Dt++;
            var it = D.peek() || " ", Ht = !/\s/.test(it) && (!_.test(it) || /\s/.test(At) || _.test(At)), xe = !/\s/.test(At) && (!_.test(At) || /\s/.test(it) || _.test(it)), ot = null, Wt = null;
            if (Dt % 2 && (!p.em && Ht && (Te === "*" || !xe || _.test(At)) ? ot = !0 : p.em == Te && xe && (Te === "*" || !Ht || _.test(it)) && (ot = !1)), Dt > 1 && (!p.strong && Ht && (Te === "*" || !xe || _.test(At)) ? Wt = !0 : p.strong == Te && xe && (Te === "*" || !Ht || _.test(it)) && (Wt = !1)), Wt != null || ot != null) {
              N.highlightFormatting && (p.formatting = ot == null ? "strong" : Wt == null ? "em" : "strong em"), ot === !0 && (p.em = Te), Wt === !0 && (p.strong = Te);
              var Pe = ae(p);
              return ot === !1 && (p.em = !1), Wt === !1 && (p.strong = !1), Pe;
            }
          } else if (Te === " " && (D.eat("*") || D.eat("_"))) {
            if (D.peek() === " ")
              return ae(p);
            D.backUp(1);
          }
          if (N.strikethrough) {
            if (Te === "~" && D.eatWhile(Te)) {
              if (p.strikethrough) {
                N.highlightFormatting && (p.formatting = "strikethrough");
                var Pe = ae(p);
                return p.strikethrough = !1, Pe;
              } else if (D.match(/^[^\s]/, !1))
                return p.strikethrough = !0, N.highlightFormatting && (p.formatting = "strikethrough"), ae(p);
            } else if (Te === " " && D.match("~~", !0)) {
              if (D.peek() === " ")
                return ae(p);
              D.backUp(2);
            }
          }
          if (N.emoji && Te === ":" && D.match(/^(?:[a-z_\d+][a-z_\d+-]*|\-[a-z_\d+][a-z_\d+-]*):/)) {
            p.emoji = !0, N.highlightFormatting && (p.formatting = "emoji");
            var ar = ae(p);
            return p.emoji = !1, ar;
          }
          return Te === " " && (D.match(/^ +$/, !1) ? p.trailingSpace++ : p.trailingSpace && (p.trailingSpaceNewLine = !0)), ae(p);
        }
        function He(D, p) {
          var G = D.next();
          if (G === ">") {
            p.f = p.inline = Ee, N.highlightFormatting && (p.formatting = "link");
            var ze = ae(p);
            return ze ? ze += " " : ze = "", ze + T.linkInline;
          }
          return D.match(/^[^>]+/, !0), T.linkInline;
        }
        function E(D, p) {
          if (D.eatSpace())
            return null;
          var G = D.next();
          return G === "(" || G === "[" ? (p.f = p.inline = J(G === "(" ? ")" : "]"), N.highlightFormatting && (p.formatting = "link-string"), p.linkHref = !0, ae(p)) : "error";
        }
        var ee = {
          ")": /^(?:[^\\\(\)]|\\.|\((?:[^\\\(\)]|\\.)*\))*?(?=\))/,
          "]": /^(?:[^\\\[\]]|\\.|\[(?:[^\\\[\]]|\\.)*\])*?(?=\])/
        };
        function J(D) {
          return function(p, G) {
            var ze = p.next();
            if (ze === D) {
              G.f = G.inline = Ee, N.highlightFormatting && (G.formatting = "link-string");
              var Te = ae(G);
              return G.linkHref = !1, Te;
            }
            return p.match(ee[D]), G.linkHref = !0, ae(G);
          };
        }
        function De(D, p) {
          return D.match(/^([^\]\\]|\\.)*\]:/, !1) ? (p.f = We, D.next(), N.highlightFormatting && (p.formatting = "link"), p.linkText = !0, ae(p)) : q(D, p, Ee);
        }
        function We(D, p) {
          if (D.match("]:", !0)) {
            p.f = p.inline = rt, N.highlightFormatting && (p.formatting = "link");
            var G = ae(p);
            return p.linkText = !1, G;
          }
          return D.match(/^([^\]\\]|\\.)+/, !0), T.linkText;
        }
        function rt(D, p) {
          return D.eatSpace() ? null : (D.match(/^[^\s]+/, !0), D.peek() === void 0 ? p.linkTitle = !0 : D.match(/^(?:\s+(?:"(?:[^"\\]|\\.)+"|'(?:[^'\\]|\\.)+'|\((?:[^)\\]|\\.)+\)))?/, !0), p.f = p.inline = Ee, T.linkHref + " url");
        }
        var _t = {
          startState: function() {
            return {
              f: se,
              prevLine: { stream: null },
              thisLine: { stream: null },
              block: se,
              htmlState: null,
              indentation: 0,
              inline: Ee,
              text: Le,
              formatting: !1,
              linkText: !1,
              linkHref: !1,
              linkTitle: !1,
              code: 0,
              em: !1,
              strong: !1,
              header: 0,
              setext: 0,
              hr: !1,
              taskList: !1,
              list: !1,
              listStack: [],
              quote: 0,
              trailingSpace: 0,
              trailingSpaceNewLine: !1,
              strikethrough: !1,
              emoji: !1,
              fencedEndRE: null
            };
          },
          copyState: function(D) {
            return {
              f: D.f,
              prevLine: D.prevLine,
              thisLine: D.thisLine,
              block: D.block,
              htmlState: D.htmlState && k.copyState(I, D.htmlState),
              indentation: D.indentation,
              localMode: D.localMode,
              localState: D.localMode ? k.copyState(D.localMode, D.localState) : null,
              inline: D.inline,
              text: D.text,
              formatting: !1,
              linkText: D.linkText,
              linkTitle: D.linkTitle,
              linkHref: D.linkHref,
              code: D.code,
              em: D.em,
              strong: D.strong,
              strikethrough: D.strikethrough,
              emoji: D.emoji,
              header: D.header,
              setext: D.setext,
              hr: D.hr,
              taskList: D.taskList,
              list: D.list,
              listStack: D.listStack.slice(0),
              quote: D.quote,
              indentedCode: D.indentedCode,
              trailingSpace: D.trailingSpace,
              trailingSpaceNewLine: D.trailingSpaceNewLine,
              md_inside: D.md_inside,
              fencedEndRE: D.fencedEndRE
            };
          },
          token: function(D, p) {
            if (p.formatting = !1, D != p.thisLine.stream) {
              if (p.header = 0, p.hr = !1, D.match(/^\s*$/, !0))
                return Z(p), null;
              if (p.prevLine = p.thisLine, p.thisLine = { stream: D }, p.taskList = !1, p.trailingSpace = 0, p.trailingSpaceNewLine = !1, !p.localState && (p.f = p.block, p.f != me)) {
                var G = D.match(/^\s*/, !0)[0].replace(/\t/g, X).length;
                if (p.indentation = G, p.indentationDiff = null, G > 0) return null;
              }
            }
            return p.f(D, p);
          },
          innerMode: function(D) {
            return D.block == me ? { state: D.htmlState, mode: I } : D.localState ? { state: D.localState, mode: D.localMode } : { state: D, mode: _t };
          },
          indent: function(D, p, G) {
            return D.block == me && I.indent ? I.indent(D.htmlState, p, G) : D.localState && D.localMode.indent ? D.localMode.indent(D.localState, p, G) : k.Pass;
          },
          blankLine: Z,
          getType: ae,
          blockCommentStart: "<!--",
          blockCommentEnd: "-->",
          closeBrackets: "()[]{}''\"\"``",
          fold: "markdown"
        };
        return _t;
      }, "xml"), k.defineMIME("text/markdown", "markdown"), k.defineMIME("text/x-markdown", "markdown");
    });
  })()), wo.exports;
}
var Lo = { exports: {} }, To;
function Xo() {
  return To || (To = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.overlayMode = function(W, N, I) {
        return {
          startState: function() {
            return {
              base: k.startState(W),
              overlay: k.startState(N),
              basePos: 0,
              baseCur: null,
              overlayPos: 0,
              overlayCur: null,
              streamSeen: null
            };
          },
          copyState: function(H) {
            return {
              base: k.copyState(W, H.base),
              overlay: k.copyState(N, H.overlay),
              basePos: H.basePos,
              baseCur: null,
              overlayPos: H.overlayPos,
              overlayCur: null
            };
          },
          token: function(H, z) {
            return (H != z.streamSeen || Math.min(z.basePos, z.overlayPos) < H.start) && (z.streamSeen = H, z.basePos = z.overlayPos = H.start), H.start == z.basePos && (z.baseCur = W.token(H, z.base), z.basePos = H.pos), H.start == z.overlayPos && (H.pos = H.start, z.overlayCur = N.token(H, z.overlay), z.overlayPos = H.pos), H.pos = Math.min(z.basePos, z.overlayPos), z.overlayCur == null ? z.baseCur : z.baseCur != null && z.overlay.combineTokens || I && z.overlay.combineTokens == null ? z.baseCur + " " + z.overlayCur : z.overlayCur;
          },
          indent: W.indent && function(H, z, T) {
            return W.indent(H.base, z, T);
          },
          electricChars: W.electricChars,
          innerMode: function(H) {
            return { state: H.base, mode: W };
          },
          blankLine: function(H) {
            var z, T;
            return W.blankLine && (z = W.blankLine(H.base)), N.blankLine && (T = N.blankLine(H.overlay)), T == null ? z : I && z != null ? z + " " + T : T;
          }
        };
      };
    });
  })()), Lo.exports;
}
var Bo = { exports: {} }, Mo;
function nf() {
  return Mo || (Mo = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.defineOption("placeholder", "", function(P, re, Q) {
        var K = Q && Q != k.Init;
        if (re && !K)
          P.on("blur", H), P.on("change", z), P.on("swapDoc", z), k.on(P.getInputField(), "compositionupdate", P.state.placeholderCompose = function() {
            I(P);
          }), z(P);
        else if (!re && K) {
          P.off("blur", H), P.off("change", z), P.off("swapDoc", z), k.off(P.getInputField(), "compositionupdate", P.state.placeholderCompose), W(P);
          var fe = P.getWrapperElement();
          fe.className = fe.className.replace(" CodeMirror-empty", "");
        }
        re && !P.hasFocus() && H(P);
      });
      function W(P) {
        P.state.placeholder && (P.state.placeholder.parentNode.removeChild(P.state.placeholder), P.state.placeholder = null);
      }
      function N(P) {
        W(P);
        var re = P.state.placeholder = document.createElement("pre");
        re.style.cssText = "height: 0; overflow: visible", re.style.direction = P.getOption("direction"), re.className = "CodeMirror-placeholder CodeMirror-line-like";
        var Q = P.getOption("placeholder");
        typeof Q == "string" && (Q = document.createTextNode(Q)), re.appendChild(Q), P.display.lineSpace.insertBefore(re, P.display.lineSpace.firstChild);
      }
      function I(P) {
        setTimeout(function() {
          var re = !1;
          if (P.lineCount() == 1) {
            var Q = P.getInputField();
            re = Q.nodeName == "TEXTAREA" ? !P.getLine(0).length : !/[^\u200b]/.test(Q.querySelector(".CodeMirror-line").textContent);
          }
          re ? N(P) : W(P);
        }, 20);
      }
      function H(P) {
        T(P) && N(P);
      }
      function z(P) {
        var re = P.getWrapperElement(), Q = T(P);
        re.className = re.className.replace(" CodeMirror-empty", "") + (Q ? " CodeMirror-empty" : ""), Q ? N(P) : W(P);
      }
      function T(P) {
        return P.lineCount() === 1 && P.getLine(0) === "";
      }
    });
  })()), Bo.exports;
}
var No = { exports: {} }, Oo;
function af() {
  return Oo || (Oo = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.defineOption("autoRefresh", !1, function(I, H) {
        I.state.autoRefresh && (N(I, I.state.autoRefresh), I.state.autoRefresh = null), H && I.display.wrapper.offsetHeight == 0 && W(I, I.state.autoRefresh = { delay: H.delay || 250 });
      });
      function W(I, H) {
        function z() {
          I.display.wrapper.offsetHeight ? (N(I, H), I.display.lastWrapHeight != I.display.wrapper.clientHeight && I.refresh()) : H.timeout = setTimeout(z, H.delay);
        }
        H.timeout = setTimeout(z, H.delay), H.hurry = function() {
          clearTimeout(H.timeout), H.timeout = setTimeout(z, 50);
        }, k.on(window, "mouseup", H.hurry), k.on(window, "keyup", H.hurry);
      }
      function N(I, H) {
        clearTimeout(H.timeout), k.off(window, "mouseup", H.hurry), k.off(window, "keyup", H.hurry);
      }
    });
  })()), No.exports;
}
var Io = { exports: {} }, Ho;
function lf() {
  return Ho || (Ho = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      k.defineOption("styleSelectedText", !1, function(K, fe, ie) {
        var Se = ie && ie != k.Init;
        fe && !Se ? (K.state.markedSelection = [], K.state.markedSelectionStyle = typeof fe == "string" ? fe : "CodeMirror-selectedtext", re(K), K.on("cursorActivity", W), K.on("change", N)) : !fe && Se && (K.off("cursorActivity", W), K.off("change", N), P(K), K.state.markedSelection = K.state.markedSelectionStyle = null);
      });
      function W(K) {
        K.state.markedSelection && K.operation(function() {
          Q(K);
        });
      }
      function N(K) {
        K.state.markedSelection && K.state.markedSelection.length && K.operation(function() {
          P(K);
        });
      }
      var I = 8, H = k.Pos, z = k.cmpPos;
      function T(K, fe, ie, Se) {
        if (z(fe, ie) != 0)
          for (var de = K.state.markedSelection, ce = K.state.markedSelectionStyle, _ = fe.line; ; ) {
            var X = _ == fe.line ? fe : H(_, 0), q = _ + I, j = q >= ie.line, ue = j ? ie : H(q, 0), Z = K.markText(X, ue, { className: ce });
            if (Se == null ? de.push(Z) : de.splice(Se++, 0, Z), j) break;
            _ = q;
          }
      }
      function P(K) {
        for (var fe = K.state.markedSelection, ie = 0; ie < fe.length; ++ie) fe[ie].clear();
        fe.length = 0;
      }
      function re(K) {
        P(K);
        for (var fe = K.listSelections(), ie = 0; ie < fe.length; ie++)
          T(K, fe[ie].from(), fe[ie].to());
      }
      function Q(K) {
        if (!K.somethingSelected()) return P(K);
        if (K.listSelections().length > 1) return re(K);
        var fe = K.getCursor("start"), ie = K.getCursor("end"), Se = K.state.markedSelection;
        if (!Se.length) return T(K, fe, ie);
        var de = Se[0].find(), ce = Se[Se.length - 1].find();
        if (!de || !ce || ie.line - fe.line <= I || z(fe, ce.to) >= 0 || z(ie, de.from) <= 0)
          return re(K);
        for (; z(fe, de.from) > 0; )
          Se.shift().clear(), de = Se[0].find();
        for (z(fe, de.from) < 0 && (de.to.line - fe.line < I ? (Se.shift().clear(), T(K, fe, de.to, 0)) : T(K, fe, de.from, 0)); z(ie, ce.to) < 0; )
          Se.pop().clear(), ce = Se[Se.length - 1].find();
        z(ie, ce.to) > 0 && (ie.line - ce.from.line < I ? (Se.pop().clear(), T(K, ce.from, ie)) : T(K, ce.to, ie));
      }
    });
  })()), Io.exports;
}
var Ro = { exports: {} }, Po;
function of() {
  return Po || (Po = 1, (function(ke, ye) {
    (function(k) {
      k(zt());
    })(function(k) {
      var W = k.Pos;
      function N(_) {
        var X = _.flags;
        return X ?? (_.ignoreCase ? "i" : "") + (_.global ? "g" : "") + (_.multiline ? "m" : "");
      }
      function I(_, X) {
        for (var q = N(_), j = q, ue = 0; ue < X.length; ue++) j.indexOf(X.charAt(ue)) == -1 && (j += X.charAt(ue));
        return q == j ? _ : new RegExp(_.source, j);
      }
      function H(_) {
        return /\\s|\\n|\n|\\W|\\D|\[\^/.test(_.source);
      }
      function z(_, X, q) {
        X = I(X, "g");
        for (var j = q.line, ue = q.ch, Z = _.lastLine(); j <= Z; j++, ue = 0) {
          X.lastIndex = ue;
          var se = _.getLine(j), me = X.exec(se);
          if (me)
            return {
              from: W(j, me.index),
              to: W(j, me.index + me[0].length),
              match: me
            };
        }
      }
      function T(_, X, q) {
        if (!H(X)) return z(_, X, q);
        X = I(X, "gm");
        for (var j, ue = 1, Z = q.line, se = _.lastLine(); Z <= se; ) {
          for (var me = 0; me < ue && !(Z > se); me++) {
            var Ue = _.getLine(Z++);
            j = j == null ? Ue : j + `
` + Ue;
          }
          ue = ue * 2, X.lastIndex = q.ch;
          var ae = X.exec(j);
          if (ae) {
            var Le = j.slice(0, ae.index).split(`
`), Ee = ae[0].split(`
`), He = q.line + Le.length - 1, E = Le[Le.length - 1].length;
            return {
              from: W(He, E),
              to: W(
                He + Ee.length - 1,
                Ee.length == 1 ? E + Ee[0].length : Ee[Ee.length - 1].length
              ),
              match: ae
            };
          }
        }
      }
      function P(_, X, q) {
        for (var j, ue = 0; ue <= _.length; ) {
          X.lastIndex = ue;
          var Z = X.exec(_);
          if (!Z) break;
          var se = Z.index + Z[0].length;
          if (se > _.length - q) break;
          (!j || se > j.index + j[0].length) && (j = Z), ue = Z.index + 1;
        }
        return j;
      }
      function re(_, X, q) {
        X = I(X, "g");
        for (var j = q.line, ue = q.ch, Z = _.firstLine(); j >= Z; j--, ue = -1) {
          var se = _.getLine(j), me = P(se, X, ue < 0 ? 0 : se.length - ue);
          if (me)
            return {
              from: W(j, me.index),
              to: W(j, me.index + me[0].length),
              match: me
            };
        }
      }
      function Q(_, X, q) {
        if (!H(X)) return re(_, X, q);
        X = I(X, "gm");
        for (var j, ue = 1, Z = _.getLine(q.line).length - q.ch, se = q.line, me = _.firstLine(); se >= me; ) {
          for (var Ue = 0; Ue < ue && se >= me; Ue++) {
            var ae = _.getLine(se--);
            j = j == null ? ae : ae + `
` + j;
          }
          ue *= 2;
          var Le = P(j, X, Z);
          if (Le) {
            var Ee = j.slice(0, Le.index).split(`
`), He = Le[0].split(`
`), E = se + Ee.length, ee = Ee[Ee.length - 1].length;
            return {
              from: W(E, ee),
              to: W(
                E + He.length - 1,
                He.length == 1 ? ee + He[0].length : He[He.length - 1].length
              ),
              match: Le
            };
          }
        }
      }
      var K, fe;
      String.prototype.normalize ? (K = function(_) {
        return _.normalize("NFD").toLowerCase();
      }, fe = function(_) {
        return _.normalize("NFD");
      }) : (K = function(_) {
        return _.toLowerCase();
      }, fe = function(_) {
        return _;
      });
      function ie(_, X, q, j) {
        if (_.length == X.length) return q;
        for (var ue = 0, Z = q + Math.max(0, _.length - X.length); ; ) {
          if (ue == Z) return ue;
          var se = ue + Z >> 1, me = j(_.slice(0, se)).length;
          if (me == q) return se;
          me > q ? Z = se : ue = se + 1;
        }
      }
      function Se(_, X, q, j) {
        if (!X.length) return null;
        var ue = j ? K : fe, Z = ue(X).split(/\r|\n\r?/);
        e: for (var se = q.line, me = q.ch, Ue = _.lastLine() + 1 - Z.length; se <= Ue; se++, me = 0) {
          var ae = _.getLine(se).slice(me), Le = ue(ae);
          if (Z.length == 1) {
            var Ee = Le.indexOf(Z[0]);
            if (Ee == -1) continue e;
            var q = ie(ae, Le, Ee, ue) + me;
            return {
              from: W(se, ie(ae, Le, Ee, ue) + me),
              to: W(se, ie(ae, Le, Ee + Z[0].length, ue) + me)
            };
          } else {
            var He = Le.length - Z[0].length;
            if (Le.slice(He) != Z[0]) continue e;
            for (var E = 1; E < Z.length - 1; E++)
              if (ue(_.getLine(se + E)) != Z[E]) continue e;
            var ee = _.getLine(se + Z.length - 1), J = ue(ee), De = Z[Z.length - 1];
            if (J.slice(0, De.length) != De) continue e;
            return {
              from: W(se, ie(ae, Le, He, ue) + me),
              to: W(se + Z.length - 1, ie(ee, J, De.length, ue))
            };
          }
        }
      }
      function de(_, X, q, j) {
        if (!X.length) return null;
        var ue = j ? K : fe, Z = ue(X).split(/\r|\n\r?/);
        e: for (var se = q.line, me = q.ch, Ue = _.firstLine() - 1 + Z.length; se >= Ue; se--, me = -1) {
          var ae = _.getLine(se);
          me > -1 && (ae = ae.slice(0, me));
          var Le = ue(ae);
          if (Z.length == 1) {
            var Ee = Le.lastIndexOf(Z[0]);
            if (Ee == -1) continue e;
            return {
              from: W(se, ie(ae, Le, Ee, ue)),
              to: W(se, ie(ae, Le, Ee + Z[0].length, ue))
            };
          } else {
            var He = Z[Z.length - 1];
            if (Le.slice(0, He.length) != He) continue e;
            for (var E = 1, q = se - Z.length + 1; E < Z.length - 1; E++)
              if (ue(_.getLine(q + E)) != Z[E]) continue e;
            var ee = _.getLine(se + 1 - Z.length), J = ue(ee);
            if (J.slice(J.length - Z[0].length) != Z[0]) continue e;
            return {
              from: W(se + 1 - Z.length, ie(ee, J, ee.length - Z[0].length, ue)),
              to: W(se, ie(ae, Le, He.length, ue))
            };
          }
        }
      }
      function ce(_, X, q, j) {
        this.atOccurrence = !1, this.afterEmptyMatch = !1, this.doc = _, q = q ? _.clipPos(q) : W(0, 0), this.pos = { from: q, to: q };
        var ue;
        typeof j == "object" ? ue = j.caseFold : (ue = j, j = null), typeof X == "string" ? (ue == null && (ue = !1), this.matches = function(Z, se) {
          return (Z ? de : Se)(_, X, se, ue);
        }) : (X = I(X, "gm"), !j || j.multiline !== !1 ? this.matches = function(Z, se) {
          return (Z ? Q : T)(_, X, se);
        } : this.matches = function(Z, se) {
          return (Z ? re : z)(_, X, se);
        });
      }
      ce.prototype = {
        findNext: function() {
          return this.find(!1);
        },
        findPrevious: function() {
          return this.find(!0);
        },
        find: function(_) {
          var X = this.doc.clipPos(_ ? this.pos.from : this.pos.to);
          if (this.afterEmptyMatch && this.atOccurrence && (X = W(X.line, X.ch), _ ? (X.ch--, X.ch < 0 && (X.line--, X.ch = (this.doc.getLine(X.line) || "").length)) : (X.ch++, X.ch > (this.doc.getLine(X.line) || "").length && (X.ch = 0, X.line++)), k.cmpPos(X, this.doc.clipPos(X)) != 0))
            return this.atOccurrence = !1;
          var q = this.matches(_, X);
          if (this.afterEmptyMatch = q && k.cmpPos(q.from, q.to) == 0, q)
            return this.pos = q, this.atOccurrence = !0, this.pos.match || !0;
          var j = W(_ ? this.doc.firstLine() : this.doc.lastLine() + 1, 0);
          return this.pos = { from: j, to: j }, this.atOccurrence = !1;
        },
        from: function() {
          if (this.atOccurrence) return this.pos.from;
        },
        to: function() {
          if (this.atOccurrence) return this.pos.to;
        },
        replace: function(_, X) {
          if (this.atOccurrence) {
            var q = k.splitLines(_);
            this.doc.replaceRange(q, this.pos.from, this.pos.to, X), this.pos.to = W(
              this.pos.from.line + q.length - 1,
              q[q.length - 1].length + (q.length == 1 ? this.pos.from.ch : 0)
            );
          }
        }
      }, k.defineExtension("getSearchCursor", function(_, X, q) {
        return new ce(this.doc, _, X, q);
      }), k.defineDocExtension("getSearchCursor", function(_, X, q) {
        return new ce(this, _, X, q);
      }), k.defineExtension("selectMatches", function(_, X) {
        for (var q = [], j = this.getSearchCursor(_, this.getCursor("from"), X); j.findNext() && !(k.cmpPos(j.to(), this.getCursor("to")) > 0); )
          q.push({ anchor: j.from(), head: j.to() });
        q.length && this.setSelections(q, 0);
      });
    });
  })()), Ro.exports;
}
var zo = { exports: {} }, Wo;
function uf() {
  return Wo || (Wo = 1, (function(ke, ye) {
    (function(k) {
      k(zt(), Ko(), Xo());
    })(function(k) {
      var W = /^((?:(?:aaas?|about|acap|adiumxtra|af[ps]|aim|apt|attachment|aw|beshare|bitcoin|bolo|callto|cap|chrome(?:-extension)?|cid|coap|com-eventbrite-attendee|content|crid|cvs|data|dav|dict|dlna-(?:playcontainer|playsingle)|dns|doi|dtn|dvb|ed2k|facetime|feed|file|finger|fish|ftp|geo|gg|git|gizmoproject|go|gopher|gtalk|h323|hcp|https?|iax|icap|icon|im|imap|info|ipn|ipp|irc[6s]?|iris(?:\.beep|\.lwz|\.xpc|\.xpcs)?|itms|jar|javascript|jms|keyparc|lastfm|ldaps?|magnet|mailto|maps|market|message|mid|mms|ms-help|msnim|msrps?|mtqp|mumble|mupdate|mvn|news|nfs|nih?|nntp|notes|oid|opaquelocktoken|palm|paparazzi|platform|pop|pres|proxy|psyc|query|res(?:ource)?|rmi|rsync|rtmp|rtsp|secondlife|service|session|sftp|sgn|shttp|sieve|sips?|skype|sm[bs]|snmp|soap\.beeps?|soldat|spotify|ssh|steam|svn|tag|teamspeak|tel(?:net)?|tftp|things|thismessage|tip|tn3270|tv|udp|unreal|urn|ut2004|vemmi|ventrilo|view-source|webcal|wss?|wtai|wyciwyg|xcon(?:-userid)?|xfire|xmlrpc\.beeps?|xmpp|xri|ymsgr|z39\.50[rs]?):(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]|\([^\s()<>]*\))+(?:\([^\s()<>]*\)|[^\s`*!()\[\]{};:'".,<>?«»“”‘’]))/i;
      k.defineMode("gfm", function(N, I) {
        var H = 0;
        function z(Q) {
          return Q.code = !1, null;
        }
        var T = {
          startState: function() {
            return {
              code: !1,
              codeBlock: !1,
              ateSpace: !1
            };
          },
          copyState: function(Q) {
            return {
              code: Q.code,
              codeBlock: Q.codeBlock,
              ateSpace: Q.ateSpace
            };
          },
          token: function(Q, K) {
            if (K.combineTokens = null, K.codeBlock)
              return Q.match(/^```+/) ? (K.codeBlock = !1, null) : (Q.skipToEnd(), null);
            if (Q.sol() && (K.code = !1), Q.sol() && Q.match(/^```+/))
              return Q.skipToEnd(), K.codeBlock = !0, null;
            if (Q.peek() === "`") {
              Q.next();
              var fe = Q.pos;
              Q.eatWhile("`");
              var ie = 1 + Q.pos - fe;
              return K.code ? ie === H && (K.code = !1) : (H = ie, K.code = !0), null;
            } else if (K.code)
              return Q.next(), null;
            if (Q.eatSpace())
              return K.ateSpace = !0, null;
            if ((Q.sol() || K.ateSpace) && (K.ateSpace = !1, I.gitHubSpice !== !1)) {
              if (Q.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+@)?(?=.{0,6}\d)(?:[a-f0-9]{7,40}\b)/))
                return K.combineTokens = !0, "link";
              if (Q.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+)?#[0-9]+\b/))
                return K.combineTokens = !0, "link";
            }
            return Q.match(W) && Q.string.slice(Q.start - 2, Q.start) != "](" && (Q.start == 0 || /\W/.test(Q.string.charAt(Q.start - 1))) ? (K.combineTokens = !0, "link") : (Q.next(), null);
          },
          blankLine: z
        }, P = {
          taskLists: !0,
          strikethrough: !0,
          emoji: !0
        };
        for (var re in I)
          P[re] = I[re];
        return P.name = "markdown", k.overlayMode(k.getMode(N, P), T);
      }, "markdown"), k.defineMIME("text/x-gfm", "gfm");
    });
  })()), zo.exports;
}
function sf(ke) {
  throw new Error('Could not dynamically require "' + ke + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var ca = { exports: {} }, _o;
function ff() {
  return _o || (_o = 1, (function(ke) {
    var ye;
    (function() {
      ye = function(k, W, N, I) {
        I = I || {}, this.dictionary = null, this.rules = {}, this.dictionaryTable = {}, this.compoundRules = [], this.compoundRuleCodes = {}, this.replacementTable = [], this.flags = I.flags || {}, this.memoized = {}, this.loaded = !1;
        var H = this, z, T, P, re, Q;
        if (k)
          if (H.dictionary = k, W && N)
            de();
          else if (typeof window < "u" && (window.chrome && window.chrome.runtime || window.browser && window.browser.runtime)) {
            var K = window.chrome && window.chrome.runtime ? window.chrome.runtime : window.browser.runtime;
            I.dictionaryPath ? z = I.dictionaryPath : z = "typo/dictionaries", W || fe(K.getURL(z + "/" + k + "/" + k + ".aff"), ie), N || fe(K.getURL(z + "/" + k + "/" + k + ".dic"), Se);
          } else
            I.dictionaryPath ? z = I.dictionaryPath : typeof __dirname < "u" ? z = __dirname + "/dictionaries" : z = "./dictionaries", W || fe(z + "/" + k + "/" + k + ".aff", ie), N || fe(z + "/" + k + "/" + k + ".dic", Se);
        function fe(ce, _) {
          var X = H._readFile(ce, null, I?.asyncLoad);
          I?.asyncLoad ? X.then(function(q) {
            _(q);
          }) : _(X);
        }
        function ie(ce) {
          W = ce, N && de();
        }
        function Se(ce) {
          N = ce, W && de();
        }
        function de() {
          for (H.rules = H._parseAFF(W), H.compoundRuleCodes = {}, T = 0, re = H.compoundRules.length; T < re; T++) {
            var ce = H.compoundRules[T];
            for (P = 0, Q = ce.length; P < Q; P++)
              H.compoundRuleCodes[ce[P]] = [];
          }
          "ONLYINCOMPOUND" in H.flags && (H.compoundRuleCodes[H.flags.ONLYINCOMPOUND] = []), H.dictionaryTable = H._parseDIC(N);
          for (T in H.compoundRuleCodes)
            H.compoundRuleCodes[T].length === 0 && delete H.compoundRuleCodes[T];
          for (T = 0, re = H.compoundRules.length; T < re; T++) {
            var _ = H.compoundRules[T], X = "";
            for (P = 0, Q = _.length; P < Q; P++) {
              var q = _[P];
              q in H.compoundRuleCodes ? X += "(" + H.compoundRuleCodes[q].join("|") + ")" : X += q;
            }
            H.compoundRules[T] = new RegExp("^" + X + "$", "i");
          }
          H.loaded = !0, I?.asyncLoad && I?.loadedCallback && I.loadedCallback(H);
        }
        return this;
      }, ye.prototype = {
        /**
         * Loads a Typo instance from a hash of all of the Typo properties.
         *
         * @param {object} obj A hash of Typo properties, probably gotten from a JSON.parse(JSON.stringify(typo_instance)).
         */
        load: function(k) {
          for (var W in k)
            k.hasOwnProperty(W) && (this[W] = k[W]);
          return this;
        },
        /**
         * Read the contents of a file.
         *
         * @param {string} path The path (relative) to the file.
         * @param {string} [charset="ISO8859-1"] The expected charset of the file
         * @param {boolean} async If true, the file will be read asynchronously. For node.js this does nothing, all
         *        files are read synchronously.
         * @returns {string} The file data if async is false, otherwise a promise object. If running node.js, the data is
         *          always returned.
         */
        _readFile: function(k, W, N) {
          var I;
          if (W = W || "utf8", typeof XMLHttpRequest < "u") {
            var H = new XMLHttpRequest();
            if (H.open("GET", k, !!N), (I = H.overrideMimeType) === null || I === void 0 || I.call(H, "text/plain; charset=" + W), N) {
              var z = new Promise(function(P, re) {
                H.onload = function() {
                  H.status === 200 ? P(H.responseText) : re(H.statusText);
                }, H.onerror = function() {
                  re(H.statusText);
                };
              });
              return H.send(null), z;
            } else
              return H.send(null), H.responseText;
          } else if (typeof sf < "u") {
            var T = Zs;
            try {
              if (T.existsSync(k))
                return T.readFileSync(k, W);
              console.log("Path " + k + " does not exist.");
            } catch (P) {
              console.log(P);
            }
            return "";
          }
          return "";
        },
        /**
         * Parse the rules out from a .aff file.
         *
         * @param {string} data The contents of the affix file.
         * @returns object The rules from the file.
         */
        _parseAFF: function(k) {
          var W = {}, N, I, H, z, T, P, re, Q, K = k.split(/\r?\n/);
          for (T = 0, re = K.length; T < re; T++)
            if (N = this._removeAffixComments(K[T]), N = N.trim(), !!N) {
              var fe = N.split(/\s+/), ie = fe[0];
              if (ie === "PFX" || ie === "SFX") {
                var Se = fe[1], de = fe[2];
                H = parseInt(fe[3], 10);
                var ce = [];
                for (P = T + 1, Q = T + 1 + H; P < Q; P++) {
                  I = K[P], z = I.split(/\s+/);
                  var _ = z[2], X = z[3].split("/"), q = X[0];
                  q === "0" && (q = "");
                  var j = this.parseRuleCodes(X[1]), ue = z[4], Z = {
                    add: q
                  };
                  j.length > 0 && (Z.continuationClasses = j), ue !== "." && (ie === "SFX" ? Z.match = new RegExp(ue + "$") : Z.match = new RegExp("^" + ue)), _ != "0" && (ie === "SFX" ? Z.remove = new RegExp(_ + "$") : Z.remove = _), ce.push(Z);
                }
                W[Se] = { type: ie, combineable: de === "Y", entries: ce }, T += H;
              } else if (ie === "COMPOUNDRULE") {
                for (H = parseInt(fe[1], 10), P = T + 1, Q = T + 1 + H; P < Q; P++)
                  N = K[P], z = N.split(/\s+/), this.compoundRules.push(z[1]);
                T += H;
              } else ie === "REP" ? (z = N.split(/\s+/), z.length === 3 && this.replacementTable.push([z[1], z[2]])) : this.flags[ie] = fe[1];
            }
          return W;
        },
        /**
         * Removes comments.
         *
         * @param {string} data A line from an affix file.
         * @return {string} The cleaned-up line.
         */
        _removeAffixComments: function(k) {
          return k.match(/^\s*#/) ? "" : k;
        },
        /**
         * Parses the words out from the .dic file.
         *
         * @param {string} data The data from the dictionary file.
         * @returns HashMap The lookup table containing all of the words and
         *                 word forms from the dictionary.
         */
        _parseDIC: function(k) {
          k = this._removeDicComments(k);
          var W = k.split(/\r?\n/), N = {};
          function I(Le, Ee) {
            N.hasOwnProperty(Le) || (N[Le] = null), Ee.length > 0 && (N[Le] === null && (N[Le] = []), N[Le].push(Ee));
          }
          for (var H = 1, z = W.length; H < z; H++) {
            var T = W[H];
            if (T) {
              var P = T.replace(/\s.*$/, ""), re = P.split("/", 2), Q = re[0];
              if (re.length > 1) {
                var K = this.parseRuleCodes(re[1]);
                (!("NEEDAFFIX" in this.flags) || K.indexOf(this.flags.NEEDAFFIX) === -1) && I(Q, K);
                for (var fe = 0, ie = K.length; fe < ie; fe++) {
                  var Se = K[fe], de = this.rules[Se];
                  if (de)
                    for (var ce = this._applyRule(Q, de), _ = 0, X = ce.length; _ < X; _++) {
                      var q = ce[_];
                      if (I(q, []), de.combineable)
                        for (var j = fe + 1; j < ie; j++) {
                          var ue = K[j], Z = this.rules[ue];
                          if (Z && Z.combineable && de.type != Z.type)
                            for (var se = this._applyRule(q, Z), me = 0, Ue = se.length; me < Ue; me++) {
                              var ae = se[me];
                              I(ae, []);
                            }
                        }
                    }
                  Se in this.compoundRuleCodes && this.compoundRuleCodes[Se].push(Q);
                }
              } else
                I(Q.trim(), []);
            }
          }
          return N;
        },
        /**
         * Removes comment lines and then cleans up blank lines and trailing whitespace.
         *
         * @param {string} data The data from a .dic file.
         * @return {string} The cleaned-up data.
         */
        _removeDicComments: function(k) {
          return k = k.replace(/^\t.*$/mg, ""), k;
        },
        parseRuleCodes: function(k) {
          if (k)
            if ("FLAG" in this.flags)
              if (this.flags.FLAG === "long") {
                for (var W = [], N = 0, I = k.length; N < I; N += 2)
                  W.push(k.substr(N, 2));
                return W;
              } else return this.flags.FLAG === "num" ? k.split(",") : this.flags.FLAG === "UTF-8" ? Array.from(k) : k.split("");
            else return k.split("");
          else return [];
        },
        /**
         * Applies an affix rule to a word.
         *
         * @param {string} word The base word.
         * @param {Object} rule The affix rule.
         * @returns {string[]} The new words generated by the rule.
         */
        _applyRule: function(k, W) {
          for (var N = W.entries, I = [], H = 0, z = N.length; H < z; H++) {
            var T = N[H];
            if (!T.match || k.match(T.match)) {
              var P = k;
              if (T.remove && (P = P.replace(T.remove, "")), W.type === "SFX" ? P = P + T.add : P = T.add + P, I.push(P), "continuationClasses" in T)
                for (var re = 0, Q = T.continuationClasses.length; re < Q; re++) {
                  var K = this.rules[T.continuationClasses[re]];
                  K && (I = I.concat(this._applyRule(P, K)));
                }
            }
          }
          return I;
        },
        /**
         * Checks whether a word or a capitalization variant exists in the current dictionary.
         * The word is trimmed and several variations of capitalizations are checked.
         * If you want to check a word without any changes made to it, call checkExact()
         *
         * @see http://blog.stevenlevithan.com/archives/faster-trim-javascript re:trimming function
         *
         * @param {string} aWord The word to check.
         * @returns {boolean}
         */
        check: function(k) {
          if (!this.loaded)
            throw "Dictionary not loaded.";
          if (!k)
            return !1;
          var W = k.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
          if (this.checkExact(W))
            return !0;
          if (W.toUpperCase() === W) {
            var N = W[0] + W.substring(1).toLowerCase();
            if (this.hasFlag(N, "KEEPCASE"))
              return !1;
            if (this.checkExact(N) || this.checkExact(W.toLowerCase()))
              return !0;
          }
          var I = W[0].toLowerCase() + W.substring(1);
          if (I !== W) {
            if (this.hasFlag(I, "KEEPCASE"))
              return !1;
            if (this.checkExact(I))
              return !0;
          }
          return !1;
        },
        /**
         * Checks whether a word exists in the current dictionary.
         *
         * @param {string} word The word to check.
         * @returns {boolean}
         */
        checkExact: function(k) {
          if (!this.loaded)
            throw "Dictionary not loaded.";
          var W = this.dictionaryTable[k], N, I;
          if (typeof W > "u") {
            if ("COMPOUNDMIN" in this.flags && k.length >= this.flags.COMPOUNDMIN) {
              for (N = 0, I = this.compoundRules.length; N < I; N++)
                if (k.match(this.compoundRules[N]))
                  return !0;
            }
          } else {
            if (W === null)
              return !0;
            if (typeof W == "object") {
              for (N = 0, I = W.length; N < I; N++)
                if (!this.hasFlag(k, "ONLYINCOMPOUND", W[N]))
                  return !0;
            }
          }
          return !1;
        },
        /**
         * Looks up whether a given word is flagged with a given flag.
         *
         * @param {string} word The word in question.
         * @param {string} flag The flag in question.
         * @return {boolean}
         */
        hasFlag: function(k, W, N) {
          if (!this.loaded)
            throw "Dictionary not loaded.";
          return !!(W in this.flags && (typeof N > "u" && (N = Array.prototype.concat.apply([], this.dictionaryTable[k])), N && N.indexOf(this.flags[W]) !== -1));
        },
        /**
         * Returns a list of suggestions for a misspelled word.
         *
         * @see http://www.norvig.com/spell-correct.html for the basis of this suggestor.
         * This suggestor is primitive, but it works.
         *
         * @param {string} word The misspelling.
         * @param {number} [limit=5] The maximum number of suggestions to return.
         * @returns {string[]} The array of suggestions.
         */
        alphabet: "",
        suggest: function(k, W) {
          if (!this.loaded)
            throw "Dictionary not loaded.";
          if (W = W || 5, this.memoized.hasOwnProperty(k)) {
            var N = this.memoized[k].limit;
            if (W <= N || this.memoized[k].suggestions.length < N)
              return this.memoized[k].suggestions.slice(0, W);
          }
          if (this.check(k))
            return [];
          for (var I = 0, H = this.replacementTable.length; I < H; I++) {
            var z = this.replacementTable[I];
            if (k.indexOf(z[0]) !== -1) {
              var T = k.replace(z[0], z[1]);
              if (this.check(T))
                return [T];
            }
          }
          if (!this.alphabet) {
            this.alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", "TRY" in this.flags && (this.alphabet += this.flags.TRY), "WORDCHARS" in this.flags && (this.alphabet += this.flags.WORDCHARS);
            var P = this.alphabet.split("");
            P.sort();
            for (var re = {}, I = 0; I < P.length; I++)
              re[P[I]] = !0;
            this.alphabet = "";
            for (var I in re)
              this.alphabet += I;
          }
          var Q = this;
          function K(ie, Se) {
            var de = {}, ce, _, X, q, j = Q.alphabet.length;
            for (var ue in ie)
              for (ce = 0, X = ue.length + 1; ce < X; ce++) {
                var Z = [ue.substring(0, ce), ue.substring(ce)];
                if (Z[1] && (q = Z[0] + Z[1].substring(1), (!Se || Q.check(q)) && (q in de ? de[q] += 1 : de[q] = 1)), Z[1].length > 1 && Z[1][1] !== Z[1][0] && (q = Z[0] + Z[1][1] + Z[1][0] + Z[1].substring(2), (!Se || Q.check(q)) && (q in de ? de[q] += 1 : de[q] = 1)), Z[1]) {
                  var se = Z[1].substring(0, 1).toUpperCase() === Z[1].substring(0, 1) ? "uppercase" : "lowercase";
                  for (_ = 0; _ < j; _++) {
                    var me = Q.alphabet[_];
                    se === "uppercase" && (me = me.toUpperCase()), me != Z[1].substring(0, 1) && (q = Z[0] + me + Z[1].substring(1), (!Se || Q.check(q)) && (q in de ? de[q] += 1 : de[q] = 1));
                  }
                }
                if (Z[1])
                  for (_ = 0; _ < j; _++) {
                    var se = Z[0].substring(-1).toUpperCase() === Z[0].substring(-1) && Z[1].substring(0, 1).toUpperCase() === Z[1].substring(0, 1) ? "uppercase" : "lowercase", me = Q.alphabet[_];
                    se === "uppercase" && (me = me.toUpperCase()), q = Z[0] + me + Z[1], (!Se || Q.check(q)) && (q in de ? de[q] += 1 : de[q] = 1);
                  }
              }
            return de;
          }
          function fe(ie) {
            var Se, de = K((Se = {}, Se[ie] = !0, Se)), ce = K(de, !0), _ = ce;
            for (var X in de)
              Q.check(X) && (X in _ ? _[X] += de[X] : _[X] = de[X]);
            var q, j = [];
            for (q in _)
              _.hasOwnProperty(q) && (Q.hasFlag(q, "PRIORITYSUGGEST") && (_[q] += 1e3), j.push([q, _[q]]));
            function ue(Ue, ae) {
              var Le = Ue[1], Ee = ae[1];
              return Le < Ee ? -1 : Le > Ee ? 1 : ae[0].localeCompare(Ue[0]);
            }
            j.sort(ue).reverse();
            var Z = [], se = "lowercase";
            ie.toUpperCase() === ie ? se = "uppercase" : ie.substr(0, 1).toUpperCase() + ie.substr(1).toLowerCase() === ie && (se = "capitalized");
            var me = W;
            for (q = 0; q < Math.min(me, j.length); q++)
              se === "uppercase" ? j[q][0] = j[q][0].toUpperCase() : se === "capitalized" && (j[q][0] = j[q][0].substr(0, 1).toUpperCase() + j[q][0].substr(1)), !Q.hasFlag(j[q][0], "NOSUGGEST") && Z.indexOf(j[q][0]) === -1 ? Z.push(j[q][0]) : me++;
            return Z;
          }
          return this.memoized[k] = {
            suggestions: fe(k),
            limit: W
          }, this.memoized[k].suggestions;
        }
      };
    })(), ke.exports = ye;
  })(ca)), ca.exports;
}
var ha, qo;
function cf() {
  if (qo) return ha;
  qo = 1;
  var ke = ff();
  function ye(k) {
    if (k = k || {}, typeof k.codeMirrorInstance != "function" || typeof k.codeMirrorInstance.defineMode != "function") {
      console.log("CodeMirror Spell Checker: You must provide an instance of CodeMirror via the option `codeMirrorInstance`");
      return;
    }
    String.prototype.includes || (String.prototype.includes = function() {
      return String.prototype.indexOf.apply(this, arguments) !== -1;
    }), k.codeMirrorInstance.defineMode("spell-checker", function(W) {
      if (!ye.aff_loading) {
        ye.aff_loading = !0;
        var N = new XMLHttpRequest();
        N.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.aff", !0), N.onload = function() {
          N.readyState === 4 && N.status === 200 && (ye.aff_data = N.responseText, ye.num_loaded++, ye.num_loaded == 2 && (ye.typo = new ke("en_US", ye.aff_data, ye.dic_data, {
            platform: "any"
          })));
        }, N.send(null);
      }
      if (!ye.dic_loading) {
        ye.dic_loading = !0;
        var I = new XMLHttpRequest();
        I.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.dic", !0), I.onload = function() {
          I.readyState === 4 && I.status === 200 && (ye.dic_data = I.responseText, ye.num_loaded++, ye.num_loaded == 2 && (ye.typo = new ke("en_US", ye.aff_data, ye.dic_data, {
            platform: "any"
          })));
        }, I.send(null);
      }
      var H = '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~ ', z = {
        token: function(P) {
          var re = P.peek(), Q = "";
          if (H.includes(re))
            return P.next(), null;
          for (; (re = P.peek()) != null && !H.includes(re); )
            Q += re, P.next();
          return ye.typo && !ye.typo.check(Q) ? "spell-error" : null;
        }
      }, T = k.codeMirrorInstance.getMode(
        W,
        W.backdrop || "text/plain"
      );
      return k.codeMirrorInstance.overlayMode(T, z, !0);
    });
  }
  return ye.num_loaded = 0, ye.aff_loading = !1, ye.dic_loading = !1, ye.aff_data = "", ye.dic_data = "", ye.typo, ha = ye, ha;
}
var da = {}, Uo;
function hf() {
  return Uo || (Uo = 1, (function(ke) {
    function ye(O, R) {
      for (var F = 0; F < R.length; F++) {
        var d = R[F];
        d.enumerable = d.enumerable || !1, d.configurable = !0, "value" in d && (d.writable = !0), Object.defineProperty(O, T(d.key), d);
      }
    }
    function k(O, R, F) {
      return F && ye(O, F), Object.defineProperty(O, "prototype", {
        writable: !1
      }), O;
    }
    function W() {
      return W = Object.assign ? Object.assign.bind() : function(O) {
        for (var R = 1; R < arguments.length; R++) {
          var F = arguments[R];
          for (var d in F)
            Object.prototype.hasOwnProperty.call(F, d) && (O[d] = F[d]);
        }
        return O;
      }, W.apply(this, arguments);
    }
    function N(O, R) {
      if (O) {
        if (typeof O == "string") return I(O, R);
        var F = Object.prototype.toString.call(O).slice(8, -1);
        if (F === "Object" && O.constructor && (F = O.constructor.name), F === "Map" || F === "Set") return Array.from(O);
        if (F === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(F)) return I(O, R);
      }
    }
    function I(O, R) {
      (R == null || R > O.length) && (R = O.length);
      for (var F = 0, d = new Array(R); F < R; F++) d[F] = O[F];
      return d;
    }
    function H(O, R) {
      var F = typeof Symbol < "u" && O[Symbol.iterator] || O["@@iterator"];
      if (F) return (F = F.call(O)).next.bind(F);
      if (Array.isArray(O) || (F = N(O)) || R) {
        F && (O = F);
        var d = 0;
        return function() {
          return d >= O.length ? {
            done: !0
          } : {
            done: !1,
            value: O[d++]
          };
        };
      }
      throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
    }
    function z(O, R) {
      if (typeof O != "object" || O === null) return O;
      var F = O[Symbol.toPrimitive];
      if (F !== void 0) {
        var d = F.call(O, R);
        if (typeof d != "object") return d;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return String(O);
    }
    function T(O) {
      var R = z(O, "string");
      return typeof R == "symbol" ? R : String(R);
    }
    function P() {
      return {
        async: !1,
        baseUrl: null,
        breaks: !1,
        extensions: null,
        gfm: !0,
        headerIds: !0,
        headerPrefix: "",
        highlight: null,
        hooks: null,
        langPrefix: "language-",
        mangle: !0,
        pedantic: !1,
        renderer: null,
        sanitize: !1,
        sanitizer: null,
        silent: !1,
        smartypants: !1,
        tokenizer: null,
        walkTokens: null,
        xhtml: !1
      };
    }
    ke.defaults = P();
    function re(O) {
      ke.defaults = O;
    }
    var Q = /[&<>"']/, K = new RegExp(Q.source, "g"), fe = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, ie = new RegExp(fe.source, "g"), Se = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }, de = function(R) {
      return Se[R];
    };
    function ce(O, R) {
      if (R) {
        if (Q.test(O))
          return O.replace(K, de);
      } else if (fe.test(O))
        return O.replace(ie, de);
      return O;
    }
    var _ = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
    function X(O) {
      return O.replace(_, function(R, F) {
        return F = F.toLowerCase(), F === "colon" ? ":" : F.charAt(0) === "#" ? F.charAt(1) === "x" ? String.fromCharCode(parseInt(F.substring(2), 16)) : String.fromCharCode(+F.substring(1)) : "";
      });
    }
    var q = /(^|[^\[])\^/g;
    function j(O, R) {
      O = typeof O == "string" ? O : O.source, R = R || "";
      var F = {
        replace: function(h, C) {
          return C = C.source || C, C = C.replace(q, "$1"), O = O.replace(h, C), F;
        },
        getRegex: function() {
          return new RegExp(O, R);
        }
      };
      return F;
    }
    var ue = /[^\w:]/g, Z = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;
    function se(O, R, F) {
      if (O) {
        var d;
        try {
          d = decodeURIComponent(X(F)).replace(ue, "").toLowerCase();
        } catch {
          return null;
        }
        if (d.indexOf("javascript:") === 0 || d.indexOf("vbscript:") === 0 || d.indexOf("data:") === 0)
          return null;
      }
      R && !Z.test(F) && (F = Ee(R, F));
      try {
        F = encodeURI(F).replace(/%25/g, "%");
      } catch {
        return null;
      }
      return F;
    }
    var me = {}, Ue = /^[^:]+:\/*[^/]*$/, ae = /^([^:]+:)[\s\S]*$/, Le = /^([^:]+:\/*[^/]*)[\s\S]*$/;
    function Ee(O, R) {
      me[" " + O] || (Ue.test(O) ? me[" " + O] = O + "/" : me[" " + O] = ee(O, "/", !0)), O = me[" " + O];
      var F = O.indexOf(":") === -1;
      return R.substring(0, 2) === "//" ? F ? R : O.replace(ae, "$1") + R : R.charAt(0) === "/" ? F ? R : O.replace(Le, "$1") + R : O + R;
    }
    var He = {
      exec: function() {
      }
    };
    function E(O, R) {
      var F = O.replace(/\|/g, function(C, o, f) {
        for (var v = !1, x = o; --x >= 0 && f[x] === "\\"; )
          v = !v;
        return v ? "|" : " |";
      }), d = F.split(/ \|/), h = 0;
      if (d[0].trim() || d.shift(), d.length > 0 && !d[d.length - 1].trim() && d.pop(), d.length > R)
        d.splice(R);
      else
        for (; d.length < R; )
          d.push("");
      for (; h < d.length; h++)
        d[h] = d[h].trim().replace(/\\\|/g, "|");
      return d;
    }
    function ee(O, R, F) {
      var d = O.length;
      if (d === 0)
        return "";
      for (var h = 0; h < d; ) {
        var C = O.charAt(d - h - 1);
        if (C === R && !F)
          h++;
        else if (C !== R && F)
          h++;
        else
          break;
      }
      return O.slice(0, d - h);
    }
    function J(O, R) {
      if (O.indexOf(R[1]) === -1)
        return -1;
      for (var F = O.length, d = 0, h = 0; h < F; h++)
        if (O[h] === "\\")
          h++;
        else if (O[h] === R[0])
          d++;
        else if (O[h] === R[1] && (d--, d < 0))
          return h;
      return -1;
    }
    function De(O) {
      O && O.sanitize && !O.silent && console.warn("marked(): sanitize and sanitizer parameters are deprecated since version 0.7.0, should not be used and will be removed in the future. Read more here: https://marked.js.org/#/USING_ADVANCED.md#options");
    }
    function We(O, R) {
      if (R < 1)
        return "";
      for (var F = ""; R > 1; )
        R & 1 && (F += O), R >>= 1, O += O;
      return F + O;
    }
    function rt(O, R, F, d) {
      var h = R.href, C = R.title ? ce(R.title) : null, o = O[1].replace(/\\([\[\]])/g, "$1");
      if (O[0].charAt(0) !== "!") {
        d.state.inLink = !0;
        var f = {
          type: "link",
          raw: F,
          href: h,
          title: C,
          text: o,
          tokens: d.inlineTokens(o)
        };
        return d.state.inLink = !1, f;
      }
      return {
        type: "image",
        raw: F,
        href: h,
        title: C,
        text: ce(o)
      };
    }
    function _t(O, R) {
      var F = O.match(/^(\s+)(?:```)/);
      if (F === null)
        return R;
      var d = F[1];
      return R.split(`
`).map(function(h) {
        var C = h.match(/^\s+/);
        if (C === null)
          return h;
        var o = C[0];
        return o.length >= d.length ? h.slice(d.length) : h;
      }).join(`
`);
    }
    var D = /* @__PURE__ */ (function() {
      function O(F) {
        this.options = F || ke.defaults;
      }
      var R = O.prototype;
      return R.space = function(d) {
        var h = this.rules.block.newline.exec(d);
        if (h && h[0].length > 0)
          return {
            type: "space",
            raw: h[0]
          };
      }, R.code = function(d) {
        var h = this.rules.block.code.exec(d);
        if (h) {
          var C = h[0].replace(/^ {1,4}/gm, "");
          return {
            type: "code",
            raw: h[0],
            codeBlockStyle: "indented",
            text: this.options.pedantic ? C : ee(C, `
`)
          };
        }
      }, R.fences = function(d) {
        var h = this.rules.block.fences.exec(d);
        if (h) {
          var C = h[0], o = _t(C, h[3] || "");
          return {
            type: "code",
            raw: C,
            lang: h[2] ? h[2].trim().replace(this.rules.inline._escapes, "$1") : h[2],
            text: o
          };
        }
      }, R.heading = function(d) {
        var h = this.rules.block.heading.exec(d);
        if (h) {
          var C = h[2].trim();
          if (/#$/.test(C)) {
            var o = ee(C, "#");
            (this.options.pedantic || !o || / $/.test(o)) && (C = o.trim());
          }
          return {
            type: "heading",
            raw: h[0],
            depth: h[1].length,
            text: C,
            tokens: this.lexer.inline(C)
          };
        }
      }, R.hr = function(d) {
        var h = this.rules.block.hr.exec(d);
        if (h)
          return {
            type: "hr",
            raw: h[0]
          };
      }, R.blockquote = function(d) {
        var h = this.rules.block.blockquote.exec(d);
        if (h) {
          var C = h[0].replace(/^ *>[ \t]?/gm, ""), o = this.lexer.state.top;
          this.lexer.state.top = !0;
          var f = this.lexer.blockTokens(C);
          return this.lexer.state.top = o, {
            type: "blockquote",
            raw: h[0],
            tokens: f,
            text: C
          };
        }
      }, R.list = function(d) {
        var h = this.rules.block.list.exec(d);
        if (h) {
          var C, o, f, v, x, b, M, w, y, B, A, ne, ge = h[1].trim(), ve = ge.length > 1, te = {
            type: "list",
            raw: "",
            ordered: ve,
            start: ve ? +ge.slice(0, -1) : "",
            loose: !1,
            items: []
          };
          ge = ve ? "\\d{1,9}\\" + ge.slice(-1) : "\\" + ge, this.options.pedantic && (ge = ve ? ge : "[*+-]");
          for (var Be = new RegExp("^( {0,3}" + ge + ")((?:[	 ][^\\n]*)?(?:\\n|$))"); d && (ne = !1, !(!(h = Be.exec(d)) || this.rules.block.hr.test(d))); ) {
            if (C = h[0], d = d.substring(C.length), w = h[2].split(`
`, 1)[0].replace(/^\t+/, function(bt) {
              return " ".repeat(3 * bt.length);
            }), y = d.split(`
`, 1)[0], this.options.pedantic ? (v = 2, A = w.trimLeft()) : (v = h[2].search(/[^ ]/), v = v > 4 ? 1 : v, A = w.slice(v), v += h[1].length), b = !1, !w && /^ *$/.test(y) && (C += y + `
`, d = d.substring(y.length + 1), ne = !0), !ne)
              for (var Me = new RegExp("^ {0," + Math.min(3, v - 1) + "}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))"), Ie = new RegExp("^ {0," + Math.min(3, v - 1) + "}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)"), Ae = new RegExp("^ {0," + Math.min(3, v - 1) + "}(?:```|~~~)"), Xe = new RegExp("^ {0," + Math.min(3, v - 1) + "}#"); d && (B = d.split(`
`, 1)[0], y = B, this.options.pedantic && (y = y.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), !(Ae.test(y) || Xe.test(y) || Me.test(y) || Ie.test(d))); ) {
                if (y.search(/[^ ]/) >= v || !y.trim())
                  A += `
` + y.slice(v);
                else {
                  if (b || w.search(/[^ ]/) >= 4 || Ae.test(w) || Xe.test(w) || Ie.test(w))
                    break;
                  A += `
` + y;
                }
                !b && !y.trim() && (b = !0), C += B + `
`, d = d.substring(B.length + 1), w = y.slice(v);
              }
            te.loose || (M ? te.loose = !0 : /\n *\n *$/.test(C) && (M = !0)), this.options.gfm && (o = /^\[[ xX]\] /.exec(A), o && (f = o[0] !== "[ ] ", A = A.replace(/^\[[ xX]\] +/, ""))), te.items.push({
              type: "list_item",
              raw: C,
              task: !!o,
              checked: f,
              loose: !1,
              text: A
            }), te.raw += C;
          }
          te.items[te.items.length - 1].raw = C.trimRight(), te.items[te.items.length - 1].text = A.trimRight(), te.raw = te.raw.trimRight();
          var Ze = te.items.length;
          for (x = 0; x < Ze; x++)
            if (this.lexer.state.top = !1, te.items[x].tokens = this.lexer.blockTokens(te.items[x].text, []), !te.loose) {
              var ut = te.items[x].tokens.filter(function(bt) {
                return bt.type === "space";
              }), kt = ut.length > 0 && ut.some(function(bt) {
                return /\n.*\n/.test(bt.raw);
              });
              te.loose = kt;
            }
          if (te.loose)
            for (x = 0; x < Ze; x++)
              te.items[x].loose = !0;
          return te;
        }
      }, R.html = function(d) {
        var h = this.rules.block.html.exec(d);
        if (h) {
          var C = {
            type: "html",
            raw: h[0],
            pre: !this.options.sanitizer && (h[1] === "pre" || h[1] === "script" || h[1] === "style"),
            text: h[0]
          };
          if (this.options.sanitize) {
            var o = this.options.sanitizer ? this.options.sanitizer(h[0]) : ce(h[0]);
            C.type = "paragraph", C.text = o, C.tokens = this.lexer.inline(o);
          }
          return C;
        }
      }, R.def = function(d) {
        var h = this.rules.block.def.exec(d);
        if (h) {
          var C = h[1].toLowerCase().replace(/\s+/g, " "), o = h[2] ? h[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline._escapes, "$1") : "", f = h[3] ? h[3].substring(1, h[3].length - 1).replace(this.rules.inline._escapes, "$1") : h[3];
          return {
            type: "def",
            tag: C,
            raw: h[0],
            href: o,
            title: f
          };
        }
      }, R.table = function(d) {
        var h = this.rules.block.table.exec(d);
        if (h) {
          var C = {
            type: "table",
            header: E(h[1]).map(function(M) {
              return {
                text: M
              };
            }),
            align: h[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
            rows: h[3] && h[3].trim() ? h[3].replace(/\n[ \t]*$/, "").split(`
`) : []
          };
          if (C.header.length === C.align.length) {
            C.raw = h[0];
            var o = C.align.length, f, v, x, b;
            for (f = 0; f < o; f++)
              /^ *-+: *$/.test(C.align[f]) ? C.align[f] = "right" : /^ *:-+: *$/.test(C.align[f]) ? C.align[f] = "center" : /^ *:-+ *$/.test(C.align[f]) ? C.align[f] = "left" : C.align[f] = null;
            for (o = C.rows.length, f = 0; f < o; f++)
              C.rows[f] = E(C.rows[f], C.header.length).map(function(M) {
                return {
                  text: M
                };
              });
            for (o = C.header.length, v = 0; v < o; v++)
              C.header[v].tokens = this.lexer.inline(C.header[v].text);
            for (o = C.rows.length, v = 0; v < o; v++)
              for (b = C.rows[v], x = 0; x < b.length; x++)
                b[x].tokens = this.lexer.inline(b[x].text);
            return C;
          }
        }
      }, R.lheading = function(d) {
        var h = this.rules.block.lheading.exec(d);
        if (h)
          return {
            type: "heading",
            raw: h[0],
            depth: h[2].charAt(0) === "=" ? 1 : 2,
            text: h[1],
            tokens: this.lexer.inline(h[1])
          };
      }, R.paragraph = function(d) {
        var h = this.rules.block.paragraph.exec(d);
        if (h) {
          var C = h[1].charAt(h[1].length - 1) === `
` ? h[1].slice(0, -1) : h[1];
          return {
            type: "paragraph",
            raw: h[0],
            text: C,
            tokens: this.lexer.inline(C)
          };
        }
      }, R.text = function(d) {
        var h = this.rules.block.text.exec(d);
        if (h)
          return {
            type: "text",
            raw: h[0],
            text: h[0],
            tokens: this.lexer.inline(h[0])
          };
      }, R.escape = function(d) {
        var h = this.rules.inline.escape.exec(d);
        if (h)
          return {
            type: "escape",
            raw: h[0],
            text: ce(h[1])
          };
      }, R.tag = function(d) {
        var h = this.rules.inline.tag.exec(d);
        if (h)
          return !this.lexer.state.inLink && /^<a /i.test(h[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(h[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(h[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(h[0]) && (this.lexer.state.inRawBlock = !1), {
            type: this.options.sanitize ? "text" : "html",
            raw: h[0],
            inLink: this.lexer.state.inLink,
            inRawBlock: this.lexer.state.inRawBlock,
            text: this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(h[0]) : ce(h[0]) : h[0]
          };
      }, R.link = function(d) {
        var h = this.rules.inline.link.exec(d);
        if (h) {
          var C = h[2].trim();
          if (!this.options.pedantic && /^</.test(C)) {
            if (!/>$/.test(C))
              return;
            var o = ee(C.slice(0, -1), "\\");
            if ((C.length - o.length) % 2 === 0)
              return;
          } else {
            var f = J(h[2], "()");
            if (f > -1) {
              var v = h[0].indexOf("!") === 0 ? 5 : 4, x = v + h[1].length + f;
              h[2] = h[2].substring(0, f), h[0] = h[0].substring(0, x).trim(), h[3] = "";
            }
          }
          var b = h[2], M = "";
          if (this.options.pedantic) {
            var w = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(b);
            w && (b = w[1], M = w[3]);
          } else
            M = h[3] ? h[3].slice(1, -1) : "";
          return b = b.trim(), /^</.test(b) && (this.options.pedantic && !/>$/.test(C) ? b = b.slice(1) : b = b.slice(1, -1)), rt(h, {
            href: b && b.replace(this.rules.inline._escapes, "$1"),
            title: M && M.replace(this.rules.inline._escapes, "$1")
          }, h[0], this.lexer);
        }
      }, R.reflink = function(d, h) {
        var C;
        if ((C = this.rules.inline.reflink.exec(d)) || (C = this.rules.inline.nolink.exec(d))) {
          var o = (C[2] || C[1]).replace(/\s+/g, " ");
          if (o = h[o.toLowerCase()], !o) {
            var f = C[0].charAt(0);
            return {
              type: "text",
              raw: f,
              text: f
            };
          }
          return rt(C, o, C[0], this.lexer);
        }
      }, R.emStrong = function(d, h, C) {
        C === void 0 && (C = "");
        var o = this.rules.inline.emStrong.lDelim.exec(d);
        if (o && !(o[3] && C.match(/(?:[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD07-\uDD33\uDD40-\uDD78\uDD8A\uDD8B\uDE80-\uDE9C\uDEA0-\uDED0\uDEE1-\uDEFB\uDF00-\uDF23\uDF2D-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC58-\uDC76\uDC79-\uDC9E\uDCA7-\uDCAF\uDCE0-\uDCF2\uDCF4\uDCF5\uDCFB-\uDD1B\uDD20-\uDD39\uDD80-\uDDB7\uDDBC-\uDDCF\uDDD2-\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE40-\uDE48\uDE60-\uDE7E\uDE80-\uDE9F\uDEC0-\uDEC7\uDEC9-\uDEE4\uDEEB-\uDEEF\uDF00-\uDF35\uDF40-\uDF55\uDF58-\uDF72\uDF78-\uDF91\uDFA9-\uDFAF]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDCFA-\uDD23\uDD30-\uDD39\uDE60-\uDE7E\uDE80-\uDEA9\uDEB0\uDEB1\uDF00-\uDF27\uDF30-\uDF45\uDF51-\uDF54\uDF70-\uDF81\uDFB0-\uDFCB\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC52-\uDC6F\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD03-\uDD26\uDD36-\uDD3F\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDD0-\uDDDA\uDDDC\uDDE1-\uDDF4\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDEF0-\uDEF9\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC50-\uDC59\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE50-\uDE59\uDE80-\uDEAA\uDEB8\uDEC0-\uDEC9\uDF00-\uDF1A\uDF30-\uDF3B\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCF2\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDD50-\uDD59\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC50-\uDC6C\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD50-\uDD59\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDDA0-\uDDA9\uDEE0-\uDEF2\uDFB0\uDFC0-\uDFD4]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD81C-\uD820\uD822\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872\uD874-\uD879\uD880-\uD883][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDE70-\uDEBE\uDEC0-\uDEC9\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF50-\uDF59\uDF5B-\uDF61\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDE40-\uDE96\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3]|\uD821[\uDC00-\uDFF7]|\uD823[\uDC00-\uDCD5\uDD00-\uDD08]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD50-\uDD52\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD834[\uDEE0-\uDEF3\uDF60-\uDF78]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD837[\uDF00-\uDF1E]|\uD838[\uDD00-\uDD2C\uDD37-\uDD3D\uDD40-\uDD49\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB\uDEF0-\uDEF9]|\uD839[\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDCC7-\uDCCF\uDD00-\uDD43\uDD4B\uDD50-\uDD59]|\uD83B[\uDC71-\uDCAB\uDCAD-\uDCAF\uDCB1-\uDCB4\uDD01-\uDD2D\uDD2F-\uDD3D\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD83C[\uDD00-\uDD0C]|\uD83E[\uDFF0-\uDFF9]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF38\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A])/))) {
          var f = o[1] || o[2] || "";
          if (!f || f && (C === "" || this.rules.inline.punctuation.exec(C))) {
            var v = o[0].length - 1, x, b, M = v, w = 0, y = o[0][0] === "*" ? this.rules.inline.emStrong.rDelimAst : this.rules.inline.emStrong.rDelimUnd;
            for (y.lastIndex = 0, h = h.slice(-1 * d.length + v); (o = y.exec(h)) != null; )
              if (x = o[1] || o[2] || o[3] || o[4] || o[5] || o[6], !!x) {
                if (b = x.length, o[3] || o[4]) {
                  M += b;
                  continue;
                } else if ((o[5] || o[6]) && v % 3 && !((v + b) % 3)) {
                  w += b;
                  continue;
                }
                if (M -= b, !(M > 0)) {
                  b = Math.min(b, b + M + w);
                  var B = d.slice(0, v + o.index + (o[0].length - x.length) + b);
                  if (Math.min(v, b) % 2) {
                    var A = B.slice(1, -1);
                    return {
                      type: "em",
                      raw: B,
                      text: A,
                      tokens: this.lexer.inlineTokens(A)
                    };
                  }
                  var ne = B.slice(2, -2);
                  return {
                    type: "strong",
                    raw: B,
                    text: ne,
                    tokens: this.lexer.inlineTokens(ne)
                  };
                }
              }
          }
        }
      }, R.codespan = function(d) {
        var h = this.rules.inline.code.exec(d);
        if (h) {
          var C = h[2].replace(/\n/g, " "), o = /[^ ]/.test(C), f = /^ /.test(C) && / $/.test(C);
          return o && f && (C = C.substring(1, C.length - 1)), C = ce(C, !0), {
            type: "codespan",
            raw: h[0],
            text: C
          };
        }
      }, R.br = function(d) {
        var h = this.rules.inline.br.exec(d);
        if (h)
          return {
            type: "br",
            raw: h[0]
          };
      }, R.del = function(d) {
        var h = this.rules.inline.del.exec(d);
        if (h)
          return {
            type: "del",
            raw: h[0],
            text: h[2],
            tokens: this.lexer.inlineTokens(h[2])
          };
      }, R.autolink = function(d, h) {
        var C = this.rules.inline.autolink.exec(d);
        if (C) {
          var o, f;
          return C[2] === "@" ? (o = ce(this.options.mangle ? h(C[1]) : C[1]), f = "mailto:" + o) : (o = ce(C[1]), f = o), {
            type: "link",
            raw: C[0],
            text: o,
            href: f,
            tokens: [{
              type: "text",
              raw: o,
              text: o
            }]
          };
        }
      }, R.url = function(d, h) {
        var C;
        if (C = this.rules.inline.url.exec(d)) {
          var o, f;
          if (C[2] === "@")
            o = ce(this.options.mangle ? h(C[0]) : C[0]), f = "mailto:" + o;
          else {
            var v;
            do
              v = C[0], C[0] = this.rules.inline._backpedal.exec(C[0])[0];
            while (v !== C[0]);
            o = ce(C[0]), C[1] === "www." ? f = "http://" + C[0] : f = C[0];
          }
          return {
            type: "link",
            raw: C[0],
            text: o,
            href: f,
            tokens: [{
              type: "text",
              raw: o,
              text: o
            }]
          };
        }
      }, R.inlineText = function(d, h) {
        var C = this.rules.inline.text.exec(d);
        if (C) {
          var o;
          return this.lexer.state.inRawBlock ? o = this.options.sanitize ? this.options.sanitizer ? this.options.sanitizer(C[0]) : ce(C[0]) : C[0] : o = ce(this.options.smartypants ? h(C[0]) : C[0]), {
            type: "text",
            raw: C[0],
            text: o
          };
        }
      }, O;
    })(), p = {
      newline: /^(?: *(?:\n|$))+/,
      code: /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/,
      fences: /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,
      hr: /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,
      heading: /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,
      blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
      list: /^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/,
      html: "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))",
      def: /^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/,
      table: He,
      lheading: /^((?:.|\n(?!\n))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
      // regex template, placeholders will be replaced according to different paragraph
      // interruption rules of commonmark and the original markdown spec:
      _paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/,
      text: /^[^\n]+/
    };
    p._label = /(?!\s*\])(?:\\.|[^\[\]\\])+/, p._title = /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/, p.def = j(p.def).replace("label", p._label).replace("title", p._title).getRegex(), p.bullet = /(?:[*+-]|\d{1,9}[.)])/, p.listItemStart = j(/^( *)(bull) */).replace("bull", p.bullet).getRegex(), p.list = j(p.list).replace(/bull/g, p.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def", "\\n+(?=" + p.def.source + ")").getRegex(), p._tag = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", p._comment = /<!--(?!-?>)[\s\S]*?(?:-->|$)/, p.html = j(p.html, "i").replace("comment", p._comment).replace("tag", p._tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), p.paragraph = j(p._paragraph).replace("hr", p.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", p._tag).getRegex(), p.blockquote = j(p.blockquote).replace("paragraph", p.paragraph).getRegex(), p.normal = W({}, p), p.gfm = W({}, p.normal, {
      table: "^ *([^\\n ].*\\|.*)\\n {0,3}(?:\\| *)?(:?-+:? *(?:\\| *:?-+:? *)*)(?:\\| *)?(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
      // Cells
    }), p.gfm.table = j(p.gfm.table).replace("hr", p.hr).replace("heading", " {0,3}#{1,6} ").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", p._tag).getRegex(), p.gfm.paragraph = j(p._paragraph).replace("hr", p.hr).replace("heading", " {0,3}#{1,6} ").replace("|lheading", "").replace("table", p.gfm.table).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", p._tag).getRegex(), p.pedantic = W({}, p.normal, {
      html: j(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", p._comment).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
      def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
      heading: /^(#{1,6})(.*)(?:\n+|$)/,
      fences: He,
      // fences not supported
      lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
      paragraph: j(p.normal._paragraph).replace("hr", p.hr).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", p.lheading).replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").getRegex()
    });
    var G = {
      escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
      autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
      url: He,
      tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
      // CDATA section
      link: /^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/,
      reflink: /^!?\[(label)\]\[(ref)\]/,
      nolink: /^!?\[(ref)\](?:\[\])?/,
      reflinkSearch: "reflink|nolink(?!\\()",
      emStrong: {
        lDelim: /^(?:\*+(?:([punct_])|[^\s*]))|^_+(?:([punct*])|([^\s_]))/,
        //        (1) and (2) can only be a Right Delimiter. (3) and (4) can only be Left.  (5) and (6) can be either Left or Right.
        //          () Skip orphan inside strong                                      () Consume to delim     (1) #***                (2) a***#, a***                             (3) #***a, ***a                 (4) ***#              (5) #***#                 (6) a***a
        rDelimAst: /^(?:[^_*\\]|\\.)*?\_\_(?:[^_*\\]|\\.)*?\*(?:[^_*\\]|\\.)*?(?=\_\_)|(?:[^*\\]|\\.)+(?=[^*])|[punct_](\*+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\*+)(?=[punct_\s]|$)|[punct_\s](\*+)(?=[^punct*_\s])|[\s](\*+)(?=[punct_])|[punct_](\*+)(?=[punct_])|(?:[^punct*_\s\\]|\\.)(\*+)(?=[^punct*_\s])/,
        rDelimUnd: /^(?:[^_*\\]|\\.)*?\*\*(?:[^_*\\]|\\.)*?\_(?:[^_*\\]|\\.)*?(?=\*\*)|(?:[^_\\]|\\.)+(?=[^_])|[punct*](\_+)(?=[\s]|$)|(?:[^punct*_\s\\]|\\.)(\_+)(?=[punct*\s]|$)|[punct*\s](\_+)(?=[^punct*_\s])|[\s](\_+)(?=[punct*])|[punct*](\_+)(?=[punct*])/
        // ^- Not allowed for _
      },
      code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
      br: /^( {2,}|\\)\n(?!\s*$)/,
      del: He,
      text: /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,
      punctuation: /^([\spunctuation])/
    };
    G._punctuation = "!\"#$%&'()+\\-.,/:;<=>?@\\[\\]`^{|}~", G.punctuation = j(G.punctuation).replace(/punctuation/g, G._punctuation).getRegex(), G.blockSkip = /\[[^\]]*?\]\([^\)]*?\)|`[^`]*?`|<[^>]*?>/g, G.escapedEmSt = /(?:^|[^\\])(?:\\\\)*\\[*_]/g, G._comment = j(p._comment).replace("(?:-->|$)", "-->").getRegex(), G.emStrong.lDelim = j(G.emStrong.lDelim).replace(/punct/g, G._punctuation).getRegex(), G.emStrong.rDelimAst = j(G.emStrong.rDelimAst, "g").replace(/punct/g, G._punctuation).getRegex(), G.emStrong.rDelimUnd = j(G.emStrong.rDelimUnd, "g").replace(/punct/g, G._punctuation).getRegex(), G._escapes = /\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g, G._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/, G._email = /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/, G.autolink = j(G.autolink).replace("scheme", G._scheme).replace("email", G._email).getRegex(), G._attribute = /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/, G.tag = j(G.tag).replace("comment", G._comment).replace("attribute", G._attribute).getRegex(), G._label = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, G._href = /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/, G._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/, G.link = j(G.link).replace("label", G._label).replace("href", G._href).replace("title", G._title).getRegex(), G.reflink = j(G.reflink).replace("label", G._label).replace("ref", p._label).getRegex(), G.nolink = j(G.nolink).replace("ref", p._label).getRegex(), G.reflinkSearch = j(G.reflinkSearch, "g").replace("reflink", G.reflink).replace("nolink", G.nolink).getRegex(), G.normal = W({}, G), G.pedantic = W({}, G.normal, {
      strong: {
        start: /^__|\*\*/,
        middle: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
        endAst: /\*\*(?!\*)/g,
        endUnd: /__(?!_)/g
      },
      em: {
        start: /^_|\*/,
        middle: /^()\*(?=\S)([\s\S]*?\S)\*(?!\*)|^_(?=\S)([\s\S]*?\S)_(?!_)/,
        endAst: /\*(?!\*)/g,
        endUnd: /_(?!_)/g
      },
      link: j(/^!?\[(label)\]\((.*?)\)/).replace("label", G._label).getRegex(),
      reflink: j(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", G._label).getRegex()
    }), G.gfm = W({}, G.normal, {
      escape: j(G.escape).replace("])", "~|])").getRegex(),
      _extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
      url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
      _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
      del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
      text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
    }), G.gfm.url = j(G.gfm.url, "i").replace("email", G.gfm._extended_email).getRegex(), G.breaks = W({}, G.gfm, {
      br: j(G.br).replace("{2,}", "*").getRegex(),
      text: j(G.gfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
    });
    function ze(O) {
      return O.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1‘").replace(/'/g, "’").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1“").replace(/"/g, "”").replace(/\.{3}/g, "…");
    }
    function Te(O) {
      var R = "", F, d, h = O.length;
      for (F = 0; F < h; F++)
        d = O.charCodeAt(F), Math.random() > 0.5 && (d = "x" + d.toString(16)), R += "&#" + d + ";";
      return R;
    }
    var Je = /* @__PURE__ */ (function() {
      function O(F) {
        this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = F || ke.defaults, this.options.tokenizer = this.options.tokenizer || new D(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
          inLink: !1,
          inRawBlock: !1,
          top: !0
        };
        var d = {
          block: p.normal,
          inline: G.normal
        };
        this.options.pedantic ? (d.block = p.pedantic, d.inline = G.pedantic) : this.options.gfm && (d.block = p.gfm, this.options.breaks ? d.inline = G.breaks : d.inline = G.gfm), this.tokenizer.rules = d;
      }
      O.lex = function(d, h) {
        var C = new O(h);
        return C.lex(d);
      }, O.lexInline = function(d, h) {
        var C = new O(h);
        return C.inlineTokens(d);
      };
      var R = O.prototype;
      return R.lex = function(d) {
        d = d.replace(/\r\n|\r/g, `
`), this.blockTokens(d, this.tokens);
        for (var h; h = this.inlineQueue.shift(); )
          this.inlineTokens(h.src, h.tokens);
        return this.tokens;
      }, R.blockTokens = function(d, h) {
        var C = this;
        h === void 0 && (h = []), this.options.pedantic ? d = d.replace(/\t/g, "    ").replace(/^ +$/gm, "") : d = d.replace(/^( *)(\t+)/gm, function(M, w, y) {
          return w + "    ".repeat(y.length);
        });
        for (var o, f, v, x; d; )
          if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some(function(M) {
            return (o = M.call({
              lexer: C
            }, d, h)) ? (d = d.substring(o.raw.length), h.push(o), !0) : !1;
          }))) {
            if (o = this.tokenizer.space(d)) {
              d = d.substring(o.raw.length), o.raw.length === 1 && h.length > 0 ? h[h.length - 1].raw += `
` : h.push(o);
              continue;
            }
            if (o = this.tokenizer.code(d)) {
              d = d.substring(o.raw.length), f = h[h.length - 1], f && (f.type === "paragraph" || f.type === "text") ? (f.raw += `
` + o.raw, f.text += `
` + o.text, this.inlineQueue[this.inlineQueue.length - 1].src = f.text) : h.push(o);
              continue;
            }
            if (o = this.tokenizer.fences(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.heading(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.hr(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.blockquote(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.list(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.html(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.def(d)) {
              d = d.substring(o.raw.length), f = h[h.length - 1], f && (f.type === "paragraph" || f.type === "text") ? (f.raw += `
` + o.raw, f.text += `
` + o.raw, this.inlineQueue[this.inlineQueue.length - 1].src = f.text) : this.tokens.links[o.tag] || (this.tokens.links[o.tag] = {
                href: o.href,
                title: o.title
              });
              continue;
            }
            if (o = this.tokenizer.table(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.lheading(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (v = d, this.options.extensions && this.options.extensions.startBlock && (function() {
              var M = 1 / 0, w = d.slice(1), y = void 0;
              C.options.extensions.startBlock.forEach(function(B) {
                y = B.call({
                  lexer: this
                }, w), typeof y == "number" && y >= 0 && (M = Math.min(M, y));
              }), M < 1 / 0 && M >= 0 && (v = d.substring(0, M + 1));
            })(), this.state.top && (o = this.tokenizer.paragraph(v))) {
              f = h[h.length - 1], x && f.type === "paragraph" ? (f.raw += `
` + o.raw, f.text += `
` + o.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = f.text) : h.push(o), x = v.length !== d.length, d = d.substring(o.raw.length);
              continue;
            }
            if (o = this.tokenizer.text(d)) {
              d = d.substring(o.raw.length), f = h[h.length - 1], f && f.type === "text" ? (f.raw += `
` + o.raw, f.text += `
` + o.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = f.text) : h.push(o);
              continue;
            }
            if (d) {
              var b = "Infinite loop on byte: " + d.charCodeAt(0);
              if (this.options.silent) {
                console.error(b);
                break;
              } else
                throw new Error(b);
            }
          }
        return this.state.top = !0, h;
      }, R.inline = function(d, h) {
        return h === void 0 && (h = []), this.inlineQueue.push({
          src: d,
          tokens: h
        }), h;
      }, R.inlineTokens = function(d, h) {
        var C = this;
        h === void 0 && (h = []);
        var o, f, v, x = d, b, M, w;
        if (this.tokens.links) {
          var y = Object.keys(this.tokens.links);
          if (y.length > 0)
            for (; (b = this.tokenizer.rules.inline.reflinkSearch.exec(x)) != null; )
              y.includes(b[0].slice(b[0].lastIndexOf("[") + 1, -1)) && (x = x.slice(0, b.index) + "[" + We("a", b[0].length - 2) + "]" + x.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
        }
        for (; (b = this.tokenizer.rules.inline.blockSkip.exec(x)) != null; )
          x = x.slice(0, b.index) + "[" + We("a", b[0].length - 2) + "]" + x.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
        for (; (b = this.tokenizer.rules.inline.escapedEmSt.exec(x)) != null; )
          x = x.slice(0, b.index + b[0].length - 2) + "++" + x.slice(this.tokenizer.rules.inline.escapedEmSt.lastIndex), this.tokenizer.rules.inline.escapedEmSt.lastIndex--;
        for (; d; )
          if (M || (w = ""), M = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some(function(A) {
            return (o = A.call({
              lexer: C
            }, d, h)) ? (d = d.substring(o.raw.length), h.push(o), !0) : !1;
          }))) {
            if (o = this.tokenizer.escape(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.tag(d)) {
              d = d.substring(o.raw.length), f = h[h.length - 1], f && o.type === "text" && f.type === "text" ? (f.raw += o.raw, f.text += o.text) : h.push(o);
              continue;
            }
            if (o = this.tokenizer.link(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.reflink(d, this.tokens.links)) {
              d = d.substring(o.raw.length), f = h[h.length - 1], f && o.type === "text" && f.type === "text" ? (f.raw += o.raw, f.text += o.text) : h.push(o);
              continue;
            }
            if (o = this.tokenizer.emStrong(d, x, w)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.codespan(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.br(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.del(d)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (o = this.tokenizer.autolink(d, Te)) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (!this.state.inLink && (o = this.tokenizer.url(d, Te))) {
              d = d.substring(o.raw.length), h.push(o);
              continue;
            }
            if (v = d, this.options.extensions && this.options.extensions.startInline && (function() {
              var A = 1 / 0, ne = d.slice(1), ge = void 0;
              C.options.extensions.startInline.forEach(function(ve) {
                ge = ve.call({
                  lexer: this
                }, ne), typeof ge == "number" && ge >= 0 && (A = Math.min(A, ge));
              }), A < 1 / 0 && A >= 0 && (v = d.substring(0, A + 1));
            })(), o = this.tokenizer.inlineText(v, ze)) {
              d = d.substring(o.raw.length), o.raw.slice(-1) !== "_" && (w = o.raw.slice(-1)), M = !0, f = h[h.length - 1], f && f.type === "text" ? (f.raw += o.raw, f.text += o.text) : h.push(o);
              continue;
            }
            if (d) {
              var B = "Infinite loop on byte: " + d.charCodeAt(0);
              if (this.options.silent) {
                console.error(B);
                break;
              } else
                throw new Error(B);
            }
          }
        return h;
      }, k(O, null, [{
        key: "rules",
        get: function() {
          return {
            block: p,
            inline: G
          };
        }
      }]), O;
    })(), $e = /* @__PURE__ */ (function() {
      function O(F) {
        this.options = F || ke.defaults;
      }
      var R = O.prototype;
      return R.code = function(d, h, C) {
        var o = (h || "").match(/\S*/)[0];
        if (this.options.highlight) {
          var f = this.options.highlight(d, o);
          f != null && f !== d && (C = !0, d = f);
        }
        return d = d.replace(/\n$/, "") + `
`, o ? '<pre><code class="' + this.options.langPrefix + ce(o) + '">' + (C ? d : ce(d, !0)) + `</code></pre>
` : "<pre><code>" + (C ? d : ce(d, !0)) + `</code></pre>
`;
      }, R.blockquote = function(d) {
        return `<blockquote>
` + d + `</blockquote>
`;
      }, R.html = function(d) {
        return d;
      }, R.heading = function(d, h, C, o) {
        if (this.options.headerIds) {
          var f = this.options.headerPrefix + o.slug(C);
          return "<h" + h + ' id="' + f + '">' + d + "</h" + h + `>
`;
        }
        return "<h" + h + ">" + d + "</h" + h + `>
`;
      }, R.hr = function() {
        return this.options.xhtml ? `<hr/>
` : `<hr>
`;
      }, R.list = function(d, h, C) {
        var o = h ? "ol" : "ul", f = h && C !== 1 ? ' start="' + C + '"' : "";
        return "<" + o + f + `>
` + d + "</" + o + `>
`;
      }, R.listitem = function(d) {
        return "<li>" + d + `</li>
`;
      }, R.checkbox = function(d) {
        return "<input " + (d ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> ";
      }, R.paragraph = function(d) {
        return "<p>" + d + `</p>
`;
      }, R.table = function(d, h) {
        return h && (h = "<tbody>" + h + "</tbody>"), `<table>
<thead>
` + d + `</thead>
` + h + `</table>
`;
      }, R.tablerow = function(d) {
        return `<tr>
` + d + `</tr>
`;
      }, R.tablecell = function(d, h) {
        var C = h.header ? "th" : "td", o = h.align ? "<" + C + ' align="' + h.align + '">' : "<" + C + ">";
        return o + d + ("</" + C + `>
`);
      }, R.strong = function(d) {
        return "<strong>" + d + "</strong>";
      }, R.em = function(d) {
        return "<em>" + d + "</em>";
      }, R.codespan = function(d) {
        return "<code>" + d + "</code>";
      }, R.br = function() {
        return this.options.xhtml ? "<br/>" : "<br>";
      }, R.del = function(d) {
        return "<del>" + d + "</del>";
      }, R.link = function(d, h, C) {
        if (d = se(this.options.sanitize, this.options.baseUrl, d), d === null)
          return C;
        var o = '<a href="' + d + '"';
        return h && (o += ' title="' + h + '"'), o += ">" + C + "</a>", o;
      }, R.image = function(d, h, C) {
        if (d = se(this.options.sanitize, this.options.baseUrl, d), d === null)
          return C;
        var o = '<img src="' + d + '" alt="' + C + '"';
        return h && (o += ' title="' + h + '"'), o += this.options.xhtml ? "/>" : ">", o;
      }, R.text = function(d) {
        return d;
      }, O;
    })(), Ke = /* @__PURE__ */ (function() {
      function O() {
      }
      var R = O.prototype;
      return R.strong = function(d) {
        return d;
      }, R.em = function(d) {
        return d;
      }, R.codespan = function(d) {
        return d;
      }, R.del = function(d) {
        return d;
      }, R.html = function(d) {
        return d;
      }, R.text = function(d) {
        return d;
      }, R.link = function(d, h, C) {
        return "" + C;
      }, R.image = function(d, h, C) {
        return "" + C;
      }, R.br = function() {
        return "";
      }, O;
    })(), Ye = /* @__PURE__ */ (function() {
      function O() {
        this.seen = {};
      }
      var R = O.prototype;
      return R.serialize = function(d) {
        return d.toLowerCase().trim().replace(/<[!\/a-z].*?>/ig, "").replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-");
      }, R.getNextSafeSlug = function(d, h) {
        var C = d, o = 0;
        if (this.seen.hasOwnProperty(C)) {
          o = this.seen[d];
          do
            o++, C = d + "-" + o;
          while (this.seen.hasOwnProperty(C));
        }
        return h || (this.seen[d] = o, this.seen[C] = 0), C;
      }, R.slug = function(d, h) {
        h === void 0 && (h = {});
        var C = this.serialize(d);
        return this.getNextSafeSlug(C, h.dryrun);
      }, O;
    })(), Pe = /* @__PURE__ */ (function() {
      function O(F) {
        this.options = F || ke.defaults, this.options.renderer = this.options.renderer || new $e(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new Ke(), this.slugger = new Ye();
      }
      O.parse = function(d, h) {
        var C = new O(h);
        return C.parse(d);
      }, O.parseInline = function(d, h) {
        var C = new O(h);
        return C.parseInline(d);
      };
      var R = O.prototype;
      return R.parse = function(d, h) {
        h === void 0 && (h = !0);
        var C = "", o, f, v, x, b, M, w, y, B, A, ne, ge, ve, te, Be, Me, Ie, Ae, Xe, Ze = d.length;
        for (o = 0; o < Ze; o++) {
          if (A = d[o], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[A.type] && (Xe = this.options.extensions.renderers[A.type].call({
            parser: this
          }, A), Xe !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(A.type))) {
            C += Xe || "";
            continue;
          }
          switch (A.type) {
            case "space":
              continue;
            case "hr": {
              C += this.renderer.hr();
              continue;
            }
            case "heading": {
              C += this.renderer.heading(this.parseInline(A.tokens), A.depth, X(this.parseInline(A.tokens, this.textRenderer)), this.slugger);
              continue;
            }
            case "code": {
              C += this.renderer.code(A.text, A.lang, A.escaped);
              continue;
            }
            case "table": {
              for (y = "", w = "", x = A.header.length, f = 0; f < x; f++)
                w += this.renderer.tablecell(this.parseInline(A.header[f].tokens), {
                  header: !0,
                  align: A.align[f]
                });
              for (y += this.renderer.tablerow(w), B = "", x = A.rows.length, f = 0; f < x; f++) {
                for (M = A.rows[f], w = "", b = M.length, v = 0; v < b; v++)
                  w += this.renderer.tablecell(this.parseInline(M[v].tokens), {
                    header: !1,
                    align: A.align[v]
                  });
                B += this.renderer.tablerow(w);
              }
              C += this.renderer.table(y, B);
              continue;
            }
            case "blockquote": {
              B = this.parse(A.tokens), C += this.renderer.blockquote(B);
              continue;
            }
            case "list": {
              for (ne = A.ordered, ge = A.start, ve = A.loose, x = A.items.length, B = "", f = 0; f < x; f++)
                Be = A.items[f], Me = Be.checked, Ie = Be.task, te = "", Be.task && (Ae = this.renderer.checkbox(Me), ve ? Be.tokens.length > 0 && Be.tokens[0].type === "paragraph" ? (Be.tokens[0].text = Ae + " " + Be.tokens[0].text, Be.tokens[0].tokens && Be.tokens[0].tokens.length > 0 && Be.tokens[0].tokens[0].type === "text" && (Be.tokens[0].tokens[0].text = Ae + " " + Be.tokens[0].tokens[0].text)) : Be.tokens.unshift({
                  type: "text",
                  text: Ae
                }) : te += Ae), te += this.parse(Be.tokens, ve), B += this.renderer.listitem(te, Ie, Me);
              C += this.renderer.list(B, ne, ge);
              continue;
            }
            case "html": {
              C += this.renderer.html(A.text);
              continue;
            }
            case "paragraph": {
              C += this.renderer.paragraph(this.parseInline(A.tokens));
              continue;
            }
            case "text": {
              for (B = A.tokens ? this.parseInline(A.tokens) : A.text; o + 1 < Ze && d[o + 1].type === "text"; )
                A = d[++o], B += `
` + (A.tokens ? this.parseInline(A.tokens) : A.text);
              C += h ? this.renderer.paragraph(B) : B;
              continue;
            }
            default: {
              var ut = 'Token with "' + A.type + '" type was not found.';
              if (this.options.silent) {
                console.error(ut);
                return;
              } else
                throw new Error(ut);
            }
          }
        }
        return C;
      }, R.parseInline = function(d, h) {
        h = h || this.renderer;
        var C = "", o, f, v, x = d.length;
        for (o = 0; o < x; o++) {
          if (f = d[o], this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[f.type] && (v = this.options.extensions.renderers[f.type].call({
            parser: this
          }, f), v !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(f.type))) {
            C += v || "";
            continue;
          }
          switch (f.type) {
            case "escape": {
              C += h.text(f.text);
              break;
            }
            case "html": {
              C += h.html(f.text);
              break;
            }
            case "link": {
              C += h.link(f.href, f.title, this.parseInline(f.tokens, h));
              break;
            }
            case "image": {
              C += h.image(f.href, f.title, f.text);
              break;
            }
            case "strong": {
              C += h.strong(this.parseInline(f.tokens, h));
              break;
            }
            case "em": {
              C += h.em(this.parseInline(f.tokens, h));
              break;
            }
            case "codespan": {
              C += h.codespan(f.text);
              break;
            }
            case "br": {
              C += h.br();
              break;
            }
            case "del": {
              C += h.del(this.parseInline(f.tokens, h));
              break;
            }
            case "text": {
              C += h.text(f.text);
              break;
            }
            default: {
              var b = 'Token with "' + f.type + '" type was not found.';
              if (this.options.silent) {
                console.error(b);
                return;
              } else
                throw new Error(b);
            }
          }
        }
        return C;
      }, O;
    })(), _e = /* @__PURE__ */ (function() {
      function O(F) {
        this.options = F || ke.defaults;
      }
      var R = O.prototype;
      return R.preprocess = function(d) {
        return d;
      }, R.postprocess = function(d) {
        return d;
      }, O;
    })();
    _e.passThroughHooks = /* @__PURE__ */ new Set(["preprocess", "postprocess"]);
    function Ve(O, R, F) {
      return function(d) {
        if (d.message += `
Please report this to https://github.com/markedjs/marked.`, O) {
          var h = "<p>An error occurred:</p><pre>" + ce(d.message + "", !0) + "</pre>";
          if (R)
            return Promise.resolve(h);
          if (F) {
            F(null, h);
            return;
          }
          return h;
        }
        if (R)
          return Promise.reject(d);
        if (F) {
          F(d);
          return;
        }
        throw d;
      };
    }
    function at(O, R) {
      return function(F, d, h) {
        typeof d == "function" && (h = d, d = null);
        var C = W({}, d);
        d = W({}, Ce.defaults, C);
        var o = Ve(d.silent, d.async, h);
        if (typeof F > "u" || F === null)
          return o(new Error("marked(): input parameter is undefined or null"));
        if (typeof F != "string")
          return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(F) + ", string expected"));
        if (De(d), d.hooks && (d.hooks.options = d), h) {
          var f = d.highlight, v;
          try {
            d.hooks && (F = d.hooks.preprocess(F)), v = O(F, d);
          } catch (y) {
            return o(y);
          }
          var x = function(B) {
            var A;
            if (!B)
              try {
                d.walkTokens && Ce.walkTokens(v, d.walkTokens), A = R(v, d), d.hooks && (A = d.hooks.postprocess(A));
              } catch (ne) {
                B = ne;
              }
            return d.highlight = f, B ? o(B) : h(null, A);
          };
          if (!f || f.length < 3 || (delete d.highlight, !v.length)) return x();
          var b = 0;
          Ce.walkTokens(v, function(y) {
            y.type === "code" && (b++, setTimeout(function() {
              f(y.text, y.lang, function(B, A) {
                if (B)
                  return x(B);
                A != null && A !== y.text && (y.text = A, y.escaped = !0), b--, b === 0 && x();
              });
            }, 0));
          }), b === 0 && x();
          return;
        }
        if (d.async)
          return Promise.resolve(d.hooks ? d.hooks.preprocess(F) : F).then(function(y) {
            return O(y, d);
          }).then(function(y) {
            return d.walkTokens ? Promise.all(Ce.walkTokens(y, d.walkTokens)).then(function() {
              return y;
            }) : y;
          }).then(function(y) {
            return R(y, d);
          }).then(function(y) {
            return d.hooks ? d.hooks.postprocess(y) : y;
          }).catch(o);
        try {
          d.hooks && (F = d.hooks.preprocess(F));
          var M = O(F, d);
          d.walkTokens && Ce.walkTokens(M, d.walkTokens);
          var w = R(M, d);
          return d.hooks && (w = d.hooks.postprocess(w)), w;
        } catch (y) {
          return o(y);
        }
      };
    }
    function Ce(O, R, F) {
      return at(Je.lex, Pe.parse)(O, R, F);
    }
    Ce.options = Ce.setOptions = function(O) {
      return Ce.defaults = W({}, Ce.defaults, O), re(Ce.defaults), Ce;
    }, Ce.getDefaults = P, Ce.defaults = ke.defaults, Ce.use = function() {
      for (var O = Ce.defaults.extensions || {
        renderers: {},
        childTokens: {}
      }, R = arguments.length, F = new Array(R), d = 0; d < R; d++)
        F[d] = arguments[d];
      F.forEach(function(h) {
        var C = W({}, h);
        if (C.async = Ce.defaults.async || C.async || !1, h.extensions && (h.extensions.forEach(function(f) {
          if (!f.name)
            throw new Error("extension name required");
          if (f.renderer) {
            var v = O.renderers[f.name];
            v ? O.renderers[f.name] = function() {
              for (var x = arguments.length, b = new Array(x), M = 0; M < x; M++)
                b[M] = arguments[M];
              var w = f.renderer.apply(this, b);
              return w === !1 && (w = v.apply(this, b)), w;
            } : O.renderers[f.name] = f.renderer;
          }
          if (f.tokenizer) {
            if (!f.level || f.level !== "block" && f.level !== "inline")
              throw new Error("extension level must be 'block' or 'inline'");
            O[f.level] ? O[f.level].unshift(f.tokenizer) : O[f.level] = [f.tokenizer], f.start && (f.level === "block" ? O.startBlock ? O.startBlock.push(f.start) : O.startBlock = [f.start] : f.level === "inline" && (O.startInline ? O.startInline.push(f.start) : O.startInline = [f.start]));
          }
          f.childTokens && (O.childTokens[f.name] = f.childTokens);
        }), C.extensions = O), h.renderer && (function() {
          var f = Ce.defaults.renderer || new $e(), v = function(M) {
            var w = f[M];
            f[M] = function() {
              for (var y = arguments.length, B = new Array(y), A = 0; A < y; A++)
                B[A] = arguments[A];
              var ne = h.renderer[M].apply(f, B);
              return ne === !1 && (ne = w.apply(f, B)), ne;
            };
          };
          for (var x in h.renderer)
            v(x);
          C.renderer = f;
        })(), h.tokenizer && (function() {
          var f = Ce.defaults.tokenizer || new D(), v = function(M) {
            var w = f[M];
            f[M] = function() {
              for (var y = arguments.length, B = new Array(y), A = 0; A < y; A++)
                B[A] = arguments[A];
              var ne = h.tokenizer[M].apply(f, B);
              return ne === !1 && (ne = w.apply(f, B)), ne;
            };
          };
          for (var x in h.tokenizer)
            v(x);
          C.tokenizer = f;
        })(), h.hooks && (function() {
          var f = Ce.defaults.hooks || new _e(), v = function(M) {
            var w = f[M];
            _e.passThroughHooks.has(M) ? f[M] = function(y) {
              if (Ce.defaults.async)
                return Promise.resolve(h.hooks[M].call(f, y)).then(function(A) {
                  return w.call(f, A);
                });
              var B = h.hooks[M].call(f, y);
              return w.call(f, B);
            } : f[M] = function() {
              for (var y = arguments.length, B = new Array(y), A = 0; A < y; A++)
                B[A] = arguments[A];
              var ne = h.hooks[M].apply(f, B);
              return ne === !1 && (ne = w.apply(f, B)), ne;
            };
          };
          for (var x in h.hooks)
            v(x);
          C.hooks = f;
        })(), h.walkTokens) {
          var o = Ce.defaults.walkTokens;
          C.walkTokens = function(f) {
            var v = [];
            return v.push(h.walkTokens.call(this, f)), o && (v = v.concat(o.call(this, f))), v;
          };
        }
        Ce.setOptions(C);
      });
    }, Ce.walkTokens = function(O, R) {
      for (var F = [], d = function() {
        var f = C.value;
        switch (F = F.concat(R.call(Ce, f)), f.type) {
          case "table": {
            for (var v = H(f.header), x; !(x = v()).done; ) {
              var b = x.value;
              F = F.concat(Ce.walkTokens(b.tokens, R));
            }
            for (var M = H(f.rows), w; !(w = M()).done; )
              for (var y = w.value, B = H(y), A; !(A = B()).done; ) {
                var ne = A.value;
                F = F.concat(Ce.walkTokens(ne.tokens, R));
              }
            break;
          }
          case "list": {
            F = F.concat(Ce.walkTokens(f.items, R));
            break;
          }
          default:
            Ce.defaults.extensions && Ce.defaults.extensions.childTokens && Ce.defaults.extensions.childTokens[f.type] ? Ce.defaults.extensions.childTokens[f.type].forEach(function(ge) {
              F = F.concat(Ce.walkTokens(f[ge], R));
            }) : f.tokens && (F = F.concat(Ce.walkTokens(f.tokens, R)));
        }
      }, h = H(O), C; !(C = h()).done; )
        d();
      return F;
    }, Ce.parseInline = at(Je.lexInline, Pe.parseInline), Ce.Parser = Pe, Ce.parser = Pe.parse, Ce.Renderer = $e, Ce.TextRenderer = Ke, Ce.Lexer = Je, Ce.lexer = Je.lex, Ce.Tokenizer = D, Ce.Slugger = Ye, Ce.Hooks = _e, Ce.parse = Ce;
    var Dt = Ce.options, At = Ce.setOptions, it = Ce.use, Ht = Ce.walkTokens, xe = Ce.parseInline, ot = Ce, Wt = Pe.parse, ar = Je.lex;
    ke.Hooks = _e, ke.Lexer = Je, ke.Parser = Pe, ke.Renderer = $e, ke.Slugger = Ye, ke.TextRenderer = Ke, ke.Tokenizer = D, ke.getDefaults = P, ke.lexer = ar, ke.marked = Ce, ke.options = Dt, ke.parse = ot, ke.parseInline = xe, ke.parser = Wt, ke.setOptions = At, ke.use = it, ke.walkTokens = Ht;
  })(da)), da;
}
var pa, Go;
function df() {
  if (Go) return pa;
  Go = 1;
  var ke = zt();
  Vs(), ef(), tf(), Ko(), Xo(), nf(), af(), lf(), of(), uf(), jo();
  var ye = cf(), k = hf().marked, W = /Mac/.test(navigator.platform), N = new RegExp(/(<a.*?https?:\/\/.*?[^a]>)+?/g), I = {
    toggleBold: X,
    toggleItalic: q,
    drawLink: We,
    toggleHeadingSmaller: se,
    toggleHeadingBigger: me,
    drawImage: rt,
    toggleBlockquote: Z,
    toggleOrderedList: J,
    toggleUnorderedList: ee,
    toggleCodeBlock: ue,
    togglePreview: Ke,
    toggleStrikethrough: j,
    toggleHeading1: Ue,
    toggleHeading2: ae,
    toggleHeading3: Le,
    toggleHeading4: Ee,
    toggleHeading5: He,
    toggleHeading6: E,
    cleanBlock: De,
    drawTable: G,
    drawHorizontalRule: ze,
    undo: Te,
    redo: Je,
    toggleSideBySide: $e,
    toggleFullScreen: _
  }, H = {
    toggleBold: "Cmd-B",
    toggleItalic: "Cmd-I",
    drawLink: "Cmd-K",
    toggleHeadingSmaller: "Cmd-H",
    toggleHeadingBigger: "Shift-Cmd-H",
    toggleHeading1: "Ctrl+Alt+1",
    toggleHeading2: "Ctrl+Alt+2",
    toggleHeading3: "Ctrl+Alt+3",
    toggleHeading4: "Ctrl+Alt+4",
    toggleHeading5: "Ctrl+Alt+5",
    toggleHeading6: "Ctrl+Alt+6",
    cleanBlock: "Cmd-E",
    drawImage: "Cmd-Alt-I",
    toggleBlockquote: "Cmd-'",
    toggleOrderedList: "Cmd-Alt-L",
    toggleUnorderedList: "Cmd-L",
    toggleCodeBlock: "Cmd-Alt-C",
    togglePreview: "Cmd-P",
    toggleSideBySide: "F9",
    toggleFullScreen: "F11"
  }, z = function(o) {
    for (var f in I)
      if (I[f] === o)
        return f;
    return null;
  }, T = function() {
    var o = !1;
    return (function(f) {
      (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(f) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i.test(f.substr(0, 4))) && (o = !0);
    })(navigator.userAgent || navigator.vendor || window.opera), o;
  };
  function P(o) {
    for (var f; (f = N.exec(o)) !== null; ) {
      var v = f[0];
      if (v.indexOf("target=") === -1) {
        var x = v.replace(/>$/, ' target="_blank">');
        o = o.replace(v, x);
      }
    }
    return o;
  }
  function re(o) {
    for (var f = new DOMParser(), v = f.parseFromString(o, "text/html"), x = v.getElementsByTagName("li"), b = 0; b < x.length; b++)
      for (var M = x[b], w = 0; w < M.children.length; w++) {
        var y = M.children[w];
        y instanceof HTMLInputElement && y.type === "checkbox" && (M.style.marginLeft = "-1.5em", M.style.listStyleType = "none");
      }
    return v.documentElement.innerHTML;
  }
  function Q(o) {
    return W ? o = o.replace("Ctrl", "Cmd") : o = o.replace("Cmd", "Ctrl"), o;
  }
  function K(o, f, v, x) {
    var b = fe(o, !1, f, v, "button", x);
    b.classList.add("easymde-dropdown"), b.onclick = function() {
      b.focus();
    };
    var M = document.createElement("div");
    M.className = "easymde-dropdown-content";
    for (var w = 0; w < o.children.length; w++) {
      var y = o.children[w], B;
      typeof y == "string" && y in ot ? B = fe(ot[y], !0, f, v, "button", x) : B = fe(y, !0, f, v, "button", x), B.addEventListener("click", function(A) {
        A.stopPropagation();
      }, !1), M.appendChild(B);
    }
    return b.appendChild(M), b;
  }
  function fe(o, f, v, x, b, M) {
    o = o || {};
    var w = document.createElement(b);
    if (o.attributes)
      for (var y in o.attributes)
        Object.prototype.hasOwnProperty.call(o.attributes, y) && w.setAttribute(y, o.attributes[y]);
    var B = M.options.toolbarButtonClassPrefix ? M.options.toolbarButtonClassPrefix + "-" : "";
    w.className = B + o.name, w.setAttribute("type", b), v = v ?? !0, o.text && (w.innerText = o.text), o.name && o.name in x && (I[o.name] = o.action), o.title && v && (w.title = Se(o.title, o.action, x), W && (w.title = w.title.replace("Ctrl", "⌘"), w.title = w.title.replace("Alt", "⌥"))), o.title && w.setAttribute("aria-label", o.title), o.noDisable && w.classList.add("no-disable"), o.noMobile && w.classList.add("no-mobile");
    var A = [];
    typeof o.className < "u" && (A = o.className.split(" "));
    for (var ne = [], ge = 0; ge < A.length; ge++) {
      var ve = A[ge];
      ve.match(/^fa([srlb]|(-[\w-]*)|$)/) ? ne.push(ve) : w.classList.add(ve);
    }
    if (w.tabIndex = -1, ne.length > 0) {
      for (var te = document.createElement("i"), Be = 0; Be < ne.length; Be++) {
        var Me = ne[Be];
        te.classList.add(Me);
      }
      w.appendChild(te);
    }
    return typeof o.icon < "u" && (w.innerHTML = o.icon), o.action && f && (typeof o.action == "function" ? w.onclick = function(Ie) {
      Ie.preventDefault(), o.action(M);
    } : typeof o.action == "string" && (w.onclick = function(Ie) {
      Ie.preventDefault(), window.open(o.action, "_blank");
    })), w;
  }
  function ie() {
    var o = document.createElement("i");
    return o.className = "separator", o.innerHTML = "|", o;
  }
  function Se(o, f, v) {
    var x, b = o;
    return f && (x = z(f), v[x] && (b += " (" + Q(v[x]) + ")")), b;
  }
  function de(o, f) {
    f = f || o.getCursor("start");
    var v = o.getTokenAt(f);
    if (!v.type) return {};
    for (var x = v.type.split(" "), b = {}, M, w, y = 0; y < x.length; y++)
      M = x[y], M === "strong" ? b.bold = !0 : M === "variable-2" ? (w = o.getLine(f.line), /^\s*\d+\.\s/.test(w) ? b["ordered-list"] = !0 : b["unordered-list"] = !0) : M === "atom" ? b.quote = !0 : M === "em" ? b.italic = !0 : M === "quote" ? b.quote = !0 : M === "strikethrough" ? b.strikethrough = !0 : M === "comment" ? b.code = !0 : M === "link" && !b.image ? b.link = !0 : M === "image" ? b.image = !0 : M.match(/^header(-[1-6])?$/) && (b[M.replace("header", "heading")] = !0);
    return b;
  }
  var ce = "";
  function _(o) {
    var f = o.codemirror;
    f.setOption("fullScreen", !f.getOption("fullScreen")), f.getOption("fullScreen") ? (ce = document.body.style.overflow, document.body.style.overflow = "hidden") : document.body.style.overflow = ce;
    var v = f.getWrapperElement(), x = v.nextSibling;
    if (x.classList.contains("editor-preview-active-side"))
      if (o.options.sideBySideFullscreen === !1) {
        var b = v.parentNode;
        f.getOption("fullScreen") ? b.classList.remove("sided--no-fullscreen") : b.classList.add("sided--no-fullscreen");
      } else
        $e(o);
    if (o.options.onToggleFullScreen && o.options.onToggleFullScreen(f.getOption("fullScreen") || !1), typeof o.options.maxHeight < "u" && (f.getOption("fullScreen") ? (f.getScrollerElement().style.removeProperty("height"), x.style.removeProperty("height")) : (f.getScrollerElement().style.height = o.options.maxHeight, o.setPreviewMaxHeight())), o.toolbar_div.classList.toggle("fullscreen"), o.toolbarElements && o.toolbarElements.fullscreen) {
      var M = o.toolbarElements.fullscreen;
      M.classList.toggle("active");
    }
  }
  function X(o) {
    at(o, "bold", o.options.blockStyles.bold);
  }
  function q(o) {
    at(o, "italic", o.options.blockStyles.italic);
  }
  function j(o) {
    at(o, "strikethrough", "~~");
  }
  function ue(o) {
    var f = o.options.blockStyles.code;
    function v(xt) {
      if (typeof xt != "object")
        throw "fencing_line() takes a 'line' object (not a line number, or line text).  Got: " + typeof xt + ": " + xt;
      return xt.styles && xt.styles[2] && xt.styles[2].indexOf("formatting-code-block") !== -1;
    }
    function x(xt) {
      return xt.state.base.base || xt.state.base;
    }
    function b(xt, Xt, qt, Rt, Nt) {
      qt = qt || xt.getLineHandle(Xt), Rt = Rt || xt.getTokenAt({
        line: Xt,
        ch: 1
      }), Nt = Nt || !!qt.text && xt.getTokenAt({
        line: Xt,
        ch: qt.text.length - 1
      });
      var gr = Rt.type ? Rt.type.split(" ") : [];
      return Nt && x(Nt).indentedCode ? "indented" : gr.indexOf("comment") === -1 ? !1 : x(Rt).fencedChars || x(Nt).fencedChars || v(qt) ? "fenced" : "single";
    }
    function M(xt, Xt, qt, Rt) {
      var Nt = Xt.line + 1, gr = qt.line + 1, Bi = Xt.line !== qt.line, Br = Rt + `
`, Mr = `
` + Rt;
      Bi && gr++, Bi && qt.ch === 0 && (Mr = Rt + `
`, gr--), Ye(xt, !1, [Br, Mr]), xt.setSelection({
        line: Nt,
        ch: 0
      }, {
        line: gr,
        ch: 0
      });
    }
    var w = o.codemirror, y = w.getCursor("start"), B = w.getCursor("end"), A = w.getTokenAt({
      line: y.line,
      ch: y.ch || 1
    }), ne = w.getLineHandle(y.line), ge = b(w, y.line, ne, A), ve, te, Be;
    if (ge === "single") {
      var Me = ne.text.slice(0, y.ch).replace("`", ""), Ie = ne.text.slice(y.ch).replace("`", "");
      w.replaceRange(Me + Ie, {
        line: y.line,
        ch: 0
      }, {
        line: y.line,
        ch: 99999999999999
      }), y.ch--, y !== B && B.ch--, w.setSelection(y, B), w.focus();
    } else if (ge === "fenced")
      if (y.line !== B.line || y.ch !== B.ch) {
        for (ve = y.line; ve >= 0 && (ne = w.getLineHandle(ve), !v(ne)); ve--)
          ;
        var Ae = w.getTokenAt({
          line: ve,
          ch: 1
        }), Xe = x(Ae).fencedChars, Ze, ut, kt, bt;
        v(w.getLineHandle(y.line)) ? (Ze = "", ut = y.line) : v(w.getLineHandle(y.line - 1)) ? (Ze = "", ut = y.line - 1) : (Ze = Xe + `
`, ut = y.line), v(w.getLineHandle(B.line)) ? (kt = "", bt = B.line, B.ch === 0 && (bt += 1)) : B.ch !== 0 && v(w.getLineHandle(B.line + 1)) ? (kt = "", bt = B.line + 1) : (kt = Xe + `
`, bt = B.line + 1), B.ch === 0 && (bt -= 1), w.operation(function() {
          w.replaceRange(kt, {
            line: bt,
            ch: 0
          }, {
            line: bt + (kt ? 0 : 1),
            ch: 0
          }), w.replaceRange(Ze, {
            line: ut,
            ch: 0
          }, {
            line: ut + (Ze ? 0 : 1),
            ch: 0
          });
        }), w.setSelection({
          line: ut + (Ze ? 1 : 0),
          ch: 0
        }, {
          line: bt + (Ze ? 1 : -1),
          ch: 0
        }), w.focus();
      } else {
        var Lr = y.line;
        if (v(w.getLineHandle(y.line)) && (b(w, y.line + 1) === "fenced" ? (ve = y.line, Lr = y.line + 1) : (te = y.line, Lr = y.line - 1)), ve === void 0)
          for (ve = Lr; ve >= 0 && (ne = w.getLineHandle(ve), !v(ne)); ve--)
            ;
        if (te === void 0)
          for (Be = w.lineCount(), te = Lr; te < Be && (ne = w.getLineHandle(te), !v(ne)); te++)
            ;
        w.operation(function() {
          w.replaceRange("", {
            line: ve,
            ch: 0
          }, {
            line: ve + 1,
            ch: 0
          }), w.replaceRange("", {
            line: te - 1,
            ch: 0
          }, {
            line: te,
            ch: 0
          });
        }), w.focus();
      }
    else if (ge === "indented") {
      if (y.line !== B.line || y.ch !== B.ch)
        ve = y.line, te = B.line, B.ch === 0 && te--;
      else {
        for (ve = y.line; ve >= 0; ve--)
          if (ne = w.getLineHandle(ve), !ne.text.match(/^\s*$/) && b(w, ve, ne) !== "indented") {
            ve += 1;
            break;
          }
        for (Be = w.lineCount(), te = y.line; te < Be; te++)
          if (ne = w.getLineHandle(te), !ne.text.match(/^\s*$/) && b(w, te, ne) !== "indented") {
            te -= 1;
            break;
          }
      }
      var Tr = w.getLineHandle(te + 1), Ti = Tr && w.getTokenAt({
        line: te + 1,
        ch: Tr.text.length - 1
      }), Vr = Ti && x(Ti).indentedCode;
      Vr && w.replaceRange(`
`, {
        line: te + 1,
        ch: 0
      });
      for (var ei = ve; ei <= te; ei++)
        w.indentLine(ei, "subtract");
      w.focus();
    } else {
      var ti = y.line === B.line && y.ch === B.ch && y.ch === 0, hn = y.line !== B.line;
      ti || hn ? M(w, y, B, f) : Ye(w, !1, ["`", "`"]);
    }
  }
  function Z(o) {
    _e(o.codemirror, "quote");
  }
  function se(o) {
    Pe(o.codemirror, "smaller");
  }
  function me(o) {
    Pe(o.codemirror, "bigger");
  }
  function Ue(o) {
    Pe(o.codemirror, void 0, 1);
  }
  function ae(o) {
    Pe(o.codemirror, void 0, 2);
  }
  function Le(o) {
    Pe(o.codemirror, void 0, 3);
  }
  function Ee(o) {
    Pe(o.codemirror, void 0, 4);
  }
  function He(o) {
    Pe(o.codemirror, void 0, 5);
  }
  function E(o) {
    Pe(o.codemirror, void 0, 6);
  }
  function ee(o) {
    var f = o.codemirror, v = "*";
    ["-", "+", "*"].includes(o.options.unorderedListStyle) && (v = o.options.unorderedListStyle), _e(f, "unordered-list", v);
  }
  function J(o) {
    _e(o.codemirror, "ordered-list");
  }
  function De(o) {
    Ce(o.codemirror);
  }
  function We(o) {
    var f = o.options, v = "https://";
    if (f.promptURLs) {
      var x = prompt(f.promptTexts.link, v);
      if (!x)
        return !1;
      v = _t(x);
    }
    Ve(o, "link", f.insertTexts.link, v);
  }
  function rt(o) {
    var f = o.options, v = "https://";
    if (f.promptURLs) {
      var x = prompt(f.promptTexts.image, v);
      if (!x)
        return !1;
      v = _t(x);
    }
    Ve(o, "image", f.insertTexts.image, v);
  }
  function _t(o) {
    return encodeURI(o).replace(/([\\()])/g, "\\$1");
  }
  function D(o) {
    o.openBrowseFileWindow();
  }
  function p(o, f) {
    var v = o.codemirror, x = de(v), b = o.options, M = f.substr(f.lastIndexOf("/") + 1), w = M.substring(M.lastIndexOf(".") + 1).replace(/\?.*$/, "").toLowerCase();
    if (["png", "jpg", "jpeg", "gif", "svg", "apng", "avif", "webp"].includes(w))
      Ye(v, x.image, b.insertTexts.uploadedImage, f);
    else {
      var y = b.insertTexts.link;
      y[0] = "[" + M, Ye(v, x.link, y, f);
    }
    o.updateStatusBar("upload-image", o.options.imageTexts.sbOnUploaded.replace("#image_name#", M)), setTimeout(function() {
      o.updateStatusBar("upload-image", o.options.imageTexts.sbInit);
    }, 1e3);
  }
  function G(o) {
    var f = o.codemirror, v = de(f), x = o.options;
    Ye(f, v.table, x.insertTexts.table);
  }
  function ze(o) {
    var f = o.codemirror, v = de(f), x = o.options;
    Ye(f, v.image, x.insertTexts.horizontalRule);
  }
  function Te(o) {
    var f = o.codemirror;
    f.undo(), f.focus();
  }
  function Je(o) {
    var f = o.codemirror;
    f.redo(), f.focus();
  }
  function $e(o) {
    var f = o.codemirror, v = f.getWrapperElement(), x = v.nextSibling, b = o.toolbarElements && o.toolbarElements["side-by-side"], M = !1, w = v.parentNode;
    x.classList.contains("editor-preview-active-side") ? (o.options.sideBySideFullscreen === !1 && w.classList.remove("sided--no-fullscreen"), x.classList.remove("editor-preview-active-side"), b && b.classList.remove("active"), v.classList.remove("CodeMirror-sided")) : (setTimeout(function() {
      f.getOption("fullScreen") || (o.options.sideBySideFullscreen === !1 ? w.classList.add("sided--no-fullscreen") : _(o)), x.classList.add("editor-preview-active-side");
    }, 1), b && b.classList.add("active"), v.classList.add("CodeMirror-sided"), M = !0);
    var y = v.lastChild;
    if (y.classList.contains("editor-preview-active")) {
      y.classList.remove("editor-preview-active");
      var B = o.toolbarElements.preview, A = o.toolbar_div;
      B.classList.remove("active"), A.classList.remove("disabled-for-preview");
    }
    var ne = function() {
      var ve = o.options.previewRender(o.value(), x);
      ve != null && (x.innerHTML = ve);
    };
    if (f.sideBySideRenderingFunction || (f.sideBySideRenderingFunction = ne), M) {
      var ge = o.options.previewRender(o.value(), x);
      ge != null && (x.innerHTML = ge), f.on("update", f.sideBySideRenderingFunction);
    } else
      f.off("update", f.sideBySideRenderingFunction);
    f.refresh();
  }
  function Ke(o) {
    var f = o.codemirror, v = f.getWrapperElement(), x = o.toolbar_div, b = o.options.toolbar ? o.toolbarElements.preview : !1, M = v.lastChild, w = f.getWrapperElement().nextSibling;
    if (w.classList.contains("editor-preview-active-side") && $e(o), !M || !M.classList.contains("editor-preview-full")) {
      if (M = document.createElement("div"), M.className = "editor-preview-full", o.options.previewClass)
        if (Array.isArray(o.options.previewClass))
          for (var y = 0; y < o.options.previewClass.length; y++)
            M.classList.add(o.options.previewClass[y]);
        else typeof o.options.previewClass == "string" && M.classList.add(o.options.previewClass);
      v.appendChild(M);
    }
    M.classList.contains("editor-preview-active") ? (M.classList.remove("editor-preview-active"), b && (b.classList.remove("active"), x.classList.remove("disabled-for-preview"))) : (setTimeout(function() {
      M.classList.add("editor-preview-active");
    }, 1), b && (b.classList.add("active"), x.classList.add("disabled-for-preview")));
    var B = o.options.previewRender(o.value(), M);
    B !== null && (M.innerHTML = B);
  }
  function Ye(o, f, v, x) {
    if (!o.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
      var b, M = v[0], w = v[1], y = {}, B = {};
      Object.assign(y, o.getCursor("start")), Object.assign(B, o.getCursor("end")), x && (M = M.replace("#url#", x), w = w.replace("#url#", x)), f ? (b = o.getLine(y.line), M = b.slice(0, y.ch), w = b.slice(y.ch), o.replaceRange(M + w, {
        line: y.line,
        ch: 0
      })) : (b = o.getSelection(), o.replaceSelection(M + b + w), y.ch += M.length, y !== B && (B.ch += M.length)), o.setSelection(y, B), o.focus();
    }
  }
  function Pe(o, f, v) {
    if (!o.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
      for (var x = o.getCursor("start"), b = o.getCursor("end"), M = x.line; M <= b.line; M++)
        (function(w) {
          var y = o.getLine(w), B = y.search(/[^#]/);
          f !== void 0 ? B <= 0 ? f == "bigger" ? y = "###### " + y : y = "# " + y : B == 6 && f == "smaller" ? y = y.substr(7) : B == 1 && f == "bigger" ? y = y.substr(2) : f == "bigger" ? y = y.substr(1) : y = "#" + y : B <= 0 ? y = "#".repeat(v) + " " + y : B == v ? y = y.substr(B + 1) : y = "#".repeat(v) + " " + y.substr(B + 1), o.replaceRange(y, {
            line: w,
            ch: 0
          }, {
            line: w,
            ch: 99999999999999
          });
        })(M);
      o.focus();
    }
  }
  function _e(o, f, v) {
    if (!o.getWrapperElement().lastChild.classList.contains("editor-preview-active")) {
      for (var x = /^(\s*)(\*|-|\+|\d*\.)(\s+)/, b = /^\s*/, M = de(o), w = o.getCursor("start"), y = o.getCursor("end"), B = {
        quote: /^(\s*)>\s+/,
        "unordered-list": x,
        "ordered-list": x
      }, A = function(Be, Me) {
        var Ie = {
          quote: ">",
          "unordered-list": v,
          "ordered-list": "%%i."
        };
        return Ie[Be].replace("%%i", Me);
      }, ne = function(Be, Me) {
        var Ie = {
          quote: ">",
          "unordered-list": "\\" + v,
          "ordered-list": "\\d+."
        }, Ae = new RegExp(Ie[Be]);
        return Me && Ae.test(Me);
      }, ge = function(Be, Me, Ie) {
        var Ae = x.exec(Me), Xe = A(Be, ve);
        return Ae !== null ? (ne(Be, Ae[2]) && (Xe = ""), Me = Ae[1] + Xe + Ae[3] + Me.replace(b, "").replace(B[Be], "$1")) : Ie == !1 && (Me = Xe + " " + Me), Me;
      }, ve = 1, te = w.line; te <= y.line; te++)
        (function(Be) {
          var Me = o.getLine(Be);
          M[f] ? Me = Me.replace(B[f], "$1") : (f == "unordered-list" && (Me = ge("ordered-list", Me, !0)), Me = ge(f, Me, !1), ve += 1), o.replaceRange(Me, {
            line: Be,
            ch: 0
          }, {
            line: Be,
            ch: 99999999999999
          });
        })(te);
      o.focus();
    }
  }
  function Ve(o, f, v, x) {
    if (!(!o.codemirror || o.isPreviewActive())) {
      var b = o.codemirror, M = de(b), w = M[f];
      if (!w) {
        Ye(b, w, v, x);
        return;
      }
      var y = b.getCursor("start"), B = b.getCursor("end"), A = b.getLine(y.line), ne = A.slice(0, y.ch), ge = A.slice(y.ch);
      f == "link" ? ne = ne.replace(/(.*)[^!]\[/, "$1") : f == "image" && (ne = ne.replace(/(.*)!\[$/, "$1")), ge = ge.replace(/]\(.*?\)/, ""), b.replaceRange(ne + ge, {
        line: y.line,
        ch: 0
      }, {
        line: y.line,
        ch: 99999999999999
      }), y.ch -= v[0].length, y !== B && (B.ch -= v[0].length), b.setSelection(y, B), b.focus();
    }
  }
  function at(o, f, v, x) {
    if (!(!o.codemirror || o.isPreviewActive())) {
      x = typeof x > "u" ? v : x;
      var b = o.codemirror, M = de(b), w, y = v, B = x, A = b.getCursor("start"), ne = b.getCursor("end");
      M[f] ? (w = b.getLine(A.line), y = w.slice(0, A.ch), B = w.slice(A.ch), f == "bold" ? (y = y.replace(/(\*\*|__)(?![\s\S]*(\*\*|__))/, ""), B = B.replace(/(\*\*|__)/, "")) : f == "italic" ? (y = y.replace(/(\*|_)(?![\s\S]*(\*|_))/, ""), B = B.replace(/(\*|_)/, "")) : f == "strikethrough" && (y = y.replace(/(\*\*|~~)(?![\s\S]*(\*\*|~~))/, ""), B = B.replace(/(\*\*|~~)/, "")), b.replaceRange(y + B, {
        line: A.line,
        ch: 0
      }, {
        line: A.line,
        ch: 99999999999999
      }), f == "bold" || f == "strikethrough" ? (A.ch -= 2, A !== ne && (ne.ch -= 2)) : f == "italic" && (A.ch -= 1, A !== ne && (ne.ch -= 1))) : (w = b.getSelection(), f == "bold" ? (w = w.split("**").join(""), w = w.split("__").join("")) : f == "italic" ? (w = w.split("*").join(""), w = w.split("_").join("")) : f == "strikethrough" && (w = w.split("~~").join("")), b.replaceSelection(y + w + B), A.ch += v.length, ne.ch = A.ch + w.length), b.setSelection(A, ne), b.focus();
    }
  }
  function Ce(o) {
    if (!o.getWrapperElement().lastChild.classList.contains("editor-preview-active"))
      for (var f = o.getCursor("start"), v = o.getCursor("end"), x, b = f.line; b <= v.line; b++)
        x = o.getLine(b), x = x.replace(/^[ ]*([# ]+|\*|-|[> ]+|[0-9]+(.|\)))[ ]*/, ""), o.replaceRange(x, {
          line: b,
          ch: 0
        }, {
          line: b,
          ch: 99999999999999
        });
  }
  function Dt(o, f) {
    if (Math.abs(o) < 1024)
      return "" + o + f[0];
    var v = 0;
    do
      o /= 1024, ++v;
    while (Math.abs(o) >= 1024 && v < f.length);
    return "" + o.toFixed(1) + f[v];
  }
  function At(o, f) {
    for (var v in f)
      Object.prototype.hasOwnProperty.call(f, v) && (f[v] instanceof Array ? o[v] = f[v].concat(o[v] instanceof Array ? o[v] : []) : f[v] !== null && typeof f[v] == "object" && f[v].constructor === Object ? o[v] = At(o[v] || {}, f[v]) : o[v] = f[v]);
    return o;
  }
  function it(o) {
    for (var f = 1; f < arguments.length; f++)
      o = At(o, arguments[f]);
    return o;
  }
  function Ht(o) {
    var f = /[a-zA-Z0-9_\u00A0-\u02AF\u0392-\u03c9\u0410-\u04F9]+|[\u4E00-\u9FFF\u3400-\u4dbf\uf900-\ufaff\u3040-\u309f\uac00-\ud7af]+/g, v = o.match(f), x = 0;
    if (v === null) return x;
    for (var b = 0; b < v.length; b++)
      v[b].charCodeAt(0) >= 19968 ? x += v[b].length : x += 1;
    return x;
  }
  var xe = {
    bold: "fa fa-bold",
    italic: "fa fa-italic",
    strikethrough: "fa fa-strikethrough",
    heading: "fa fa-header fa-heading",
    "heading-smaller": "fa fa-header fa-heading header-smaller",
    "heading-bigger": "fa fa-header fa-heading header-bigger",
    "heading-1": "fa fa-header fa-heading header-1",
    "heading-2": "fa fa-header fa-heading header-2",
    "heading-3": "fa fa-header fa-heading header-3",
    code: "fa fa-code",
    quote: "fa fa-quote-left",
    "ordered-list": "fa fa-list-ol",
    "unordered-list": "fa fa-list-ul",
    "clean-block": "fa fa-eraser",
    link: "fa fa-link",
    image: "fa fa-image",
    "upload-image": "fa fa-image",
    table: "fa fa-table",
    "horizontal-rule": "fa fa-minus",
    preview: "fa fa-eye",
    "side-by-side": "fa fa-columns",
    fullscreen: "fa fa-arrows-alt",
    guide: "fa fa-question-circle",
    undo: "fa fa-undo",
    redo: "fa fa-repeat fa-redo"
  }, ot = {
    bold: {
      name: "bold",
      action: X,
      className: xe.bold,
      title: "Bold",
      default: !0
    },
    italic: {
      name: "italic",
      action: q,
      className: xe.italic,
      title: "Italic",
      default: !0
    },
    strikethrough: {
      name: "strikethrough",
      action: j,
      className: xe.strikethrough,
      title: "Strikethrough"
    },
    heading: {
      name: "heading",
      action: se,
      className: xe.heading,
      title: "Heading",
      default: !0
    },
    "heading-smaller": {
      name: "heading-smaller",
      action: se,
      className: xe["heading-smaller"],
      title: "Smaller Heading"
    },
    "heading-bigger": {
      name: "heading-bigger",
      action: me,
      className: xe["heading-bigger"],
      title: "Bigger Heading"
    },
    "heading-1": {
      name: "heading-1",
      action: Ue,
      className: xe["heading-1"],
      title: "Big Heading"
    },
    "heading-2": {
      name: "heading-2",
      action: ae,
      className: xe["heading-2"],
      title: "Medium Heading"
    },
    "heading-3": {
      name: "heading-3",
      action: Le,
      className: xe["heading-3"],
      title: "Small Heading"
    },
    "separator-1": {
      name: "separator-1"
    },
    code: {
      name: "code",
      action: ue,
      className: xe.code,
      title: "Code"
    },
    quote: {
      name: "quote",
      action: Z,
      className: xe.quote,
      title: "Quote",
      default: !0
    },
    "unordered-list": {
      name: "unordered-list",
      action: ee,
      className: xe["unordered-list"],
      title: "Generic List",
      default: !0
    },
    "ordered-list": {
      name: "ordered-list",
      action: J,
      className: xe["ordered-list"],
      title: "Numbered List",
      default: !0
    },
    "clean-block": {
      name: "clean-block",
      action: De,
      className: xe["clean-block"],
      title: "Clean block"
    },
    "separator-2": {
      name: "separator-2"
    },
    link: {
      name: "link",
      action: We,
      className: xe.link,
      title: "Create Link",
      default: !0
    },
    image: {
      name: "image",
      action: rt,
      className: xe.image,
      title: "Insert Image",
      default: !0
    },
    "upload-image": {
      name: "upload-image",
      action: D,
      className: xe["upload-image"],
      title: "Import an image"
    },
    table: {
      name: "table",
      action: G,
      className: xe.table,
      title: "Insert Table"
    },
    "horizontal-rule": {
      name: "horizontal-rule",
      action: ze,
      className: xe["horizontal-rule"],
      title: "Insert Horizontal Line"
    },
    "separator-3": {
      name: "separator-3"
    },
    preview: {
      name: "preview",
      action: Ke,
      className: xe.preview,
      noDisable: !0,
      title: "Toggle Preview",
      default: !0
    },
    "side-by-side": {
      name: "side-by-side",
      action: $e,
      className: xe["side-by-side"],
      noDisable: !0,
      noMobile: !0,
      title: "Toggle Side by Side",
      default: !0
    },
    fullscreen: {
      name: "fullscreen",
      action: _,
      className: xe.fullscreen,
      noDisable: !0,
      noMobile: !0,
      title: "Toggle Fullscreen",
      default: !0
    },
    "separator-4": {
      name: "separator-4"
    },
    guide: {
      name: "guide",
      action: "https://www.markdownguide.org/basic-syntax/",
      className: xe.guide,
      noDisable: !0,
      title: "Markdown Guide",
      default: !0
    },
    "separator-5": {
      name: "separator-5"
    },
    undo: {
      name: "undo",
      action: Te,
      className: xe.undo,
      noDisable: !0,
      title: "Undo"
    },
    redo: {
      name: "redo",
      action: Je,
      className: xe.redo,
      noDisable: !0,
      title: "Redo"
    }
  }, Wt = {
    link: ["[", "](#url#)"],
    image: ["![", "](#url#)"],
    uploadedImage: ["![](#url#)", ""],
    // uploadedImage: ['![](#url#)\n', ''], // TODO: New line insertion doesn't work here.
    table: ["", `

| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Text     | Text     | Text     |

`],
    horizontalRule: ["", `

-----

`]
  }, ar = {
    link: "URL for the link:",
    image: "URL of the image:"
  }, O = {
    locale: "en-US",
    format: {
      hour: "2-digit",
      minute: "2-digit"
    }
  }, R = {
    bold: "**",
    code: "```",
    italic: "*"
  }, F = {
    sbInit: "Attach files by drag and dropping or pasting from clipboard.",
    sbOnDragEnter: "Drop image to upload it.",
    sbOnDrop: "Uploading image #images_names#...",
    sbProgress: "Uploading #file_name#: #progress#%",
    sbOnUploaded: "Uploaded #image_name#",
    sizeUnits: " B, KB, MB"
  }, d = {
    noFileGiven: "You must select a file.",
    typeNotAllowed: "This image type is not allowed.",
    fileTooLarge: `Image #image_name# is too big (#image_size#).
Maximum file size is #image_max_size#.`,
    importError: "Something went wrong when uploading the image #image_name#."
  };
  function h(o) {
    o = o || {}, o.parent = this;
    var f = !0;
    if (o.autoDownloadFontAwesome === !1 && (f = !1), o.autoDownloadFontAwesome !== !0)
      for (var v = document.styleSheets, x = 0; x < v.length; x++)
        v[x].href && v[x].href.indexOf("//maxcdn.bootstrapcdn.com/font-awesome/") > -1 && (f = !1);
    if (f) {
      var b = document.createElement("link");
      b.rel = "stylesheet", b.href = "https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css", document.getElementsByTagName("head")[0].appendChild(b);
    }
    if (o.element)
      this.element = o.element;
    else if (o.element === null) {
      console.log("EasyMDE: Error. No element was found.");
      return;
    }
    if (o.toolbar === void 0) {
      o.toolbar = [];
      for (var M in ot)
        Object.prototype.hasOwnProperty.call(ot, M) && (M.indexOf("separator-") != -1 && o.toolbar.push("|"), (ot[M].default === !0 || o.showIcons && o.showIcons.constructor === Array && o.showIcons.indexOf(M) != -1) && o.toolbar.push(M));
    }
    if (Object.prototype.hasOwnProperty.call(o, "previewClass") || (o.previewClass = "editor-preview"), Object.prototype.hasOwnProperty.call(o, "status") || (o.status = ["autosave", "lines", "words", "cursor"], o.uploadImage && o.status.unshift("upload-image")), o.previewRender || (o.previewRender = function(y) {
      return this.parent.markdown(y);
    }), o.parsingConfig = it({
      highlightFormatting: !0
      // needed for toggleCodeBlock to detect types of code
    }, o.parsingConfig || {}), o.insertTexts = it({}, Wt, o.insertTexts || {}), o.promptTexts = it({}, ar, o.promptTexts || {}), o.blockStyles = it({}, R, o.blockStyles || {}), o.autosave != null && (o.autosave.timeFormat = it({}, O, o.autosave.timeFormat || {})), o.iconClassMap = it({}, xe, o.iconClassMap || {}), o.shortcuts = it({}, H, o.shortcuts || {}), o.maxHeight = o.maxHeight || void 0, o.direction = o.direction || "ltr", typeof o.maxHeight < "u" ? o.minHeight = o.maxHeight : o.minHeight = o.minHeight || "300px", o.errorCallback = o.errorCallback || function(y) {
      alert(y);
    }, o.uploadImage = o.uploadImage || !1, o.imageMaxSize = o.imageMaxSize || 2097152, o.imageAccept = o.imageAccept || "image/png, image/jpeg, image/gif, image/avif", o.imageTexts = it({}, F, o.imageTexts || {}), o.errorMessages = it({}, d, o.errorMessages || {}), o.imagePathAbsolute = o.imagePathAbsolute || !1, o.imageCSRFName = o.imageCSRFName || "csrfmiddlewaretoken", o.imageCSRFHeader = o.imageCSRFHeader || !1, o.imageInputName = o.imageInputName || "image", o.autosave != null && o.autosave.unique_id != null && o.autosave.unique_id != "" && (o.autosave.uniqueId = o.autosave.unique_id), o.overlayMode && o.overlayMode.combine === void 0 && (o.overlayMode.combine = !0), this.options = o, this.render(), o.initialValue && (!this.options.autosave || this.options.autosave.foundSavedValue !== !0) && this.value(o.initialValue), o.uploadImage) {
      var w = this;
      this.codemirror.on("dragenter", function(y, B) {
        w.updateStatusBar("upload-image", w.options.imageTexts.sbOnDragEnter), B.stopPropagation(), B.preventDefault();
      }), this.codemirror.on("dragend", function(y, B) {
        w.updateStatusBar("upload-image", w.options.imageTexts.sbInit), B.stopPropagation(), B.preventDefault();
      }), this.codemirror.on("dragleave", function(y, B) {
        w.updateStatusBar("upload-image", w.options.imageTexts.sbInit), B.stopPropagation(), B.preventDefault();
      }), this.codemirror.on("dragover", function(y, B) {
        w.updateStatusBar("upload-image", w.options.imageTexts.sbOnDragEnter), B.stopPropagation(), B.preventDefault();
      }), this.codemirror.on("drop", function(y, B) {
        B.stopPropagation(), B.preventDefault(), o.imageUploadFunction ? w.uploadImagesUsingCustomFunction(o.imageUploadFunction, B.dataTransfer.files) : w.uploadImages(B.dataTransfer.files);
      }), this.codemirror.on("paste", function(y, B) {
        o.imageUploadFunction ? w.uploadImagesUsingCustomFunction(o.imageUploadFunction, B.clipboardData.files) : w.uploadImages(B.clipboardData.files);
      });
    }
  }
  h.prototype.uploadImages = function(o, f, v) {
    if (o.length !== 0) {
      for (var x = [], b = 0; b < o.length; b++)
        x.push(o[b].name), this.uploadImage(o[b], f, v);
      this.updateStatusBar("upload-image", this.options.imageTexts.sbOnDrop.replace("#images_names#", x.join(", ")));
    }
  }, h.prototype.uploadImagesUsingCustomFunction = function(o, f) {
    if (f.length !== 0) {
      for (var v = [], x = 0; x < f.length; x++)
        v.push(f[x].name), this.uploadImageUsingCustomFunction(o, f[x]);
      this.updateStatusBar("upload-image", this.options.imageTexts.sbOnDrop.replace("#images_names#", v.join(", ")));
    }
  }, h.prototype.updateStatusBar = function(o, f) {
    if (this.gui.statusbar) {
      var v = this.gui.statusbar.getElementsByClassName(o);
      v.length === 1 ? this.gui.statusbar.getElementsByClassName(o)[0].textContent = f : v.length === 0 ? console.log("EasyMDE: status bar item " + o + " was not found.") : console.log("EasyMDE: Several status bar items named " + o + " was found.");
    }
  }, h.prototype.markdown = function(o) {
    if (k) {
      var f;
      if (this.options && this.options.renderingConfig && this.options.renderingConfig.markedOptions ? f = this.options.renderingConfig.markedOptions : f = {}, this.options && this.options.renderingConfig && this.options.renderingConfig.singleLineBreaks === !1 ? f.breaks = !1 : f.breaks = !0, this.options && this.options.renderingConfig && this.options.renderingConfig.codeSyntaxHighlighting === !0) {
        var v = this.options.renderingConfig.hljs || window.hljs;
        v && (f.highlight = function(b, M) {
          return M && v.getLanguage(M) ? v.highlight(M, b).value : v.highlightAuto(b).value;
        });
      }
      k.use(f);
      var x = k.parse(o);
      return this.options.renderingConfig && typeof this.options.renderingConfig.sanitizerFunction == "function" && (x = this.options.renderingConfig.sanitizerFunction.call(this, x)), x = P(x), x = re(x), x;
    }
  }, h.prototype.render = function(o) {
    if (o || (o = this.element || document.getElementsByTagName("textarea")[0]), this._rendered && this._rendered === o)
      return;
    this.element = o;
    var f = this.options, v = this, x = {};
    for (var b in f.shortcuts)
      f.shortcuts[b] !== null && I[b] !== null && (function(Ie) {
        x[Q(f.shortcuts[Ie])] = function() {
          var Ae = I[Ie];
          typeof Ae == "function" ? Ae(v) : typeof Ae == "string" && window.open(Ae, "_blank");
        };
      })(b);
    x.Enter = "newlineAndIndentContinueMarkdownList", x.Tab = "tabAndIndentMarkdownList", x["Shift-Tab"] = "shiftTabAndUnindentMarkdownList", x.Esc = function(Ie) {
      Ie.getOption("fullScreen") && _(v);
    }, this.documentOnKeyDown = function(Ie) {
      Ie = Ie || window.event, Ie.keyCode == 27 && v.codemirror.getOption("fullScreen") && _(v);
    }, document.addEventListener("keydown", this.documentOnKeyDown, !1);
    var M, w;
    f.overlayMode ? (ke.defineMode("overlay-mode", function(Ie) {
      return ke.overlayMode(ke.getMode(Ie, f.spellChecker !== !1 ? "spell-checker" : "gfm"), f.overlayMode.mode, f.overlayMode.combine);
    }), M = "overlay-mode", w = f.parsingConfig, w.gitHubSpice = !1) : (M = f.parsingConfig, M.name = "gfm", M.gitHubSpice = !1), f.spellChecker !== !1 && (M = "spell-checker", w = f.parsingConfig, w.name = "gfm", w.gitHubSpice = !1, typeof f.spellChecker == "function" ? f.spellChecker({
      codeMirrorInstance: ke
    }) : ye({
      codeMirrorInstance: ke
    }));
    function y(Ie, Ae, Xe) {
      return {
        addNew: !1
      };
    }
    if (this.codemirror = ke.fromTextArea(o, {
      mode: M,
      backdrop: w,
      theme: f.theme != null ? f.theme : "easymde",
      tabSize: f.tabSize != null ? f.tabSize : 2,
      indentUnit: f.tabSize != null ? f.tabSize : 2,
      indentWithTabs: f.indentWithTabs !== !1,
      lineNumbers: f.lineNumbers === !0,
      autofocus: f.autofocus === !0,
      extraKeys: x,
      direction: f.direction,
      lineWrapping: f.lineWrapping !== !1,
      allowDropFileTypes: ["text/plain"],
      placeholder: f.placeholder || o.getAttribute("placeholder") || "",
      styleSelectedText: f.styleSelectedText != null ? f.styleSelectedText : !T(),
      scrollbarStyle: f.scrollbarStyle != null ? f.scrollbarStyle : "native",
      configureMouse: y,
      inputStyle: f.inputStyle != null ? f.inputStyle : T() ? "contenteditable" : "textarea",
      spellcheck: f.nativeSpellcheck != null ? f.nativeSpellcheck : !0,
      autoRefresh: f.autoRefresh != null ? f.autoRefresh : !1
    }), this.codemirror.getScrollerElement().style.minHeight = f.minHeight, typeof f.maxHeight < "u" && (this.codemirror.getScrollerElement().style.height = f.maxHeight), f.forceSync === !0) {
      var B = this.codemirror;
      B.on("change", function() {
        B.save();
      });
    }
    this.gui = {};
    var A = document.createElement("div");
    A.classList.add("EasyMDEContainer"), A.setAttribute("role", "application");
    var ne = this.codemirror.getWrapperElement();
    ne.parentNode.insertBefore(A, ne), A.appendChild(ne), f.toolbar !== !1 && (this.gui.toolbar = this.createToolbar()), f.status !== !1 && (this.gui.statusbar = this.createStatusbar()), f.autosave != null && f.autosave.enabled === !0 && (this.autosave(), this.codemirror.on("change", function() {
      clearTimeout(v._autosave_timeout), v._autosave_timeout = setTimeout(function() {
        v.autosave();
      }, v.options.autosave.submit_delay || v.options.autosave.delay || 1e3);
    }));
    function ge(Ie, Ae) {
      var Xe, Ze = window.getComputedStyle(document.querySelector(".CodeMirror-sizer")).width.replace("px", "");
      return Ie < Ze ? Xe = Ae + "px" : Xe = Ae / Ie * 100 + "%", Xe;
    }
    var ve = this;
    function te(Ie, Ae) {
      var Xe = new URL(Ae.url, document.baseURI).href;
      Ie.setAttribute("data-img-src", Xe), Ie.setAttribute("style", "--bg-image:url(" + Xe + ");--width:" + Ae.naturalWidth + "px;--height:" + ge(Ae.naturalWidth, Ae.naturalHeight)), ve.codemirror.setSize();
    }
    function Be() {
      f.previewImagesInEditor && A.querySelectorAll(".cm-image-marker").forEach(function(Ie) {
        var Ae = Ie.parentElement;
        if (Ae.innerText.match(/^!\[.*?\]\(.*\)/g) && !Ae.hasAttribute("data-img-src")) {
          var Xe = Ae.innerText.match(/!\[.*?\]\((.*?)\)/);
          if (window.EMDEimagesCache || (window.EMDEimagesCache = {}), Xe && Xe.length >= 2) {
            var Ze = Xe[1];
            if (f.imagesPreviewHandler) {
              var ut = f.imagesPreviewHandler(Xe[1]);
              typeof ut == "string" && (Ze = ut);
            }
            if (window.EMDEimagesCache[Ze])
              te(Ae, window.EMDEimagesCache[Ze]);
            else {
              window.EMDEimagesCache[Ze] = {};
              var kt = document.createElement("img");
              kt.onload = function() {
                window.EMDEimagesCache[Ze] = {
                  naturalWidth: kt.naturalWidth,
                  naturalHeight: kt.naturalHeight,
                  url: Ze
                }, te(Ae, window.EMDEimagesCache[Ze]);
              }, kt.src = Ze;
            }
          }
        }
      });
    }
    this.codemirror.on("update", function() {
      Be();
    }), this.gui.sideBySide = this.createSideBySide(), this._rendered = this.element, (f.autofocus === !0 || o.autofocus) && this.codemirror.focus();
    var Me = this.codemirror;
    setTimeout((function() {
      Me.refresh();
    }).bind(Me), 0);
  }, h.prototype.cleanup = function() {
    document.removeEventListener("keydown", this.documentOnKeyDown);
  };
  function C() {
    if (typeof localStorage == "object")
      try {
        localStorage.setItem("smde_localStorage", 1), localStorage.removeItem("smde_localStorage");
      } catch {
        return !1;
      }
    else
      return !1;
    return !0;
  }
  return h.prototype.autosave = function() {
    if (C()) {
      var o = this;
      if (this.options.autosave.uniqueId == null || this.options.autosave.uniqueId == "") {
        console.log("EasyMDE: You must set a uniqueId to use the autosave feature");
        return;
      }
      this.options.autosave.binded !== !0 && (o.element.form != null && o.element.form != null && o.element.form.addEventListener("submit", function() {
        clearTimeout(o.autosaveTimeoutId), o.autosaveTimeoutId = void 0, localStorage.removeItem("smde_" + o.options.autosave.uniqueId);
      }), this.options.autosave.binded = !0), this.options.autosave.loaded !== !0 && (typeof localStorage.getItem("smde_" + this.options.autosave.uniqueId) == "string" && localStorage.getItem("smde_" + this.options.autosave.uniqueId) != "" && (this.codemirror.setValue(localStorage.getItem("smde_" + this.options.autosave.uniqueId)), this.options.autosave.foundSavedValue = !0), this.options.autosave.loaded = !0);
      var f = o.value();
      f !== "" ? localStorage.setItem("smde_" + this.options.autosave.uniqueId, f) : localStorage.removeItem("smde_" + this.options.autosave.uniqueId);
      var v = document.getElementById("autosaved");
      if (v != null && v != null && v != "") {
        var x = /* @__PURE__ */ new Date(), b = new Intl.DateTimeFormat([this.options.autosave.timeFormat.locale, "en-US"], this.options.autosave.timeFormat.format).format(x), M = this.options.autosave.text == null ? "Autosaved: " : this.options.autosave.text;
        v.innerHTML = M + b;
      }
    } else
      console.log("EasyMDE: localStorage not available, cannot autosave");
  }, h.prototype.clearAutosavedValue = function() {
    if (C()) {
      if (this.options.autosave == null || this.options.autosave.uniqueId == null || this.options.autosave.uniqueId == "") {
        console.log("EasyMDE: You must set a uniqueId to clear the autosave value");
        return;
      }
      localStorage.removeItem("smde_" + this.options.autosave.uniqueId);
    } else
      console.log("EasyMDE: localStorage not available, cannot autosave");
  }, h.prototype.openBrowseFileWindow = function(o, f) {
    var v = this, x = this.gui.toolbar.getElementsByClassName("imageInput")[0];
    x.click();
    function b(M) {
      v.options.imageUploadFunction ? v.uploadImagesUsingCustomFunction(v.options.imageUploadFunction, M.target.files) : v.uploadImages(M.target.files, o, f), x.removeEventListener("change", b);
    }
    x.addEventListener("change", b);
  }, h.prototype.uploadImage = function(o, f, v) {
    var x = this;
    f = f || function(A) {
      p(x, A);
    };
    function b(B) {
      x.updateStatusBar("upload-image", B), setTimeout(function() {
        x.updateStatusBar("upload-image", x.options.imageTexts.sbInit);
      }, 1e4), v && typeof v == "function" && v(B), x.options.errorCallback(B);
    }
    function M(B) {
      var A = x.options.imageTexts.sizeUnits.split(",");
      return B.replace("#image_name#", o.name).replace("#image_size#", Dt(o.size, A)).replace("#image_max_size#", Dt(x.options.imageMaxSize, A));
    }
    if (o.size > this.options.imageMaxSize) {
      b(M(this.options.errorMessages.fileTooLarge));
      return;
    }
    var w = new FormData();
    w.append("image", o), x.options.imageCSRFToken && !x.options.imageCSRFHeader && w.append(x.options.imageCSRFName, x.options.imageCSRFToken);
    var y = new XMLHttpRequest();
    y.upload.onprogress = function(B) {
      if (B.lengthComputable) {
        var A = "" + Math.round(B.loaded * 100 / B.total);
        x.updateStatusBar("upload-image", x.options.imageTexts.sbProgress.replace("#file_name#", o.name).replace("#progress#", A));
      }
    }, y.open("POST", this.options.imageUploadEndpoint), x.options.imageCSRFToken && x.options.imageCSRFHeader && y.setRequestHeader(x.options.imageCSRFName, x.options.imageCSRFToken), y.onload = function() {
      try {
        var B = JSON.parse(this.responseText);
      } catch {
        console.error("EasyMDE: The server did not return a valid json."), b(M(x.options.errorMessages.importError));
        return;
      }
      this.status === 200 && B && !B.error && B.data && B.data.filePath ? f((x.options.imagePathAbsolute ? "" : window.location.origin + "/") + B.data.filePath) : B.error && B.error in x.options.errorMessages ? b(M(x.options.errorMessages[B.error])) : B.error ? b(M(B.error)) : (console.error("EasyMDE: Received an unexpected response after uploading the image." + this.status + " (" + this.statusText + ")"), b(M(x.options.errorMessages.importError)));
    }, y.onerror = function(B) {
      console.error("EasyMDE: An unexpected error occurred when trying to upload the image." + B.target.status + " (" + B.target.statusText + ")"), b(x.options.errorMessages.importError);
    }, y.send(w);
  }, h.prototype.uploadImageUsingCustomFunction = function(o, f) {
    var v = this;
    function x(w) {
      p(v, w);
    }
    function b(w) {
      var y = M(w);
      v.updateStatusBar("upload-image", y), setTimeout(function() {
        v.updateStatusBar("upload-image", v.options.imageTexts.sbInit);
      }, 1e4), v.options.errorCallback(y);
    }
    function M(w) {
      var y = v.options.imageTexts.sizeUnits.split(",");
      return w.replace("#image_name#", f.name).replace("#image_size#", Dt(f.size, y)).replace("#image_max_size#", Dt(v.options.imageMaxSize, y));
    }
    o.apply(this, [f, x, b]);
  }, h.prototype.setPreviewMaxHeight = function() {
    var o = this.codemirror, f = o.getWrapperElement(), v = f.nextSibling, x = parseInt(window.getComputedStyle(f).paddingTop), b = parseInt(window.getComputedStyle(f).borderTopWidth), M = parseInt(this.options.maxHeight), w = M + x * 2 + b * 2, y = w.toString() + "px";
    v.style.height = y;
  }, h.prototype.createSideBySide = function() {
    var o = this.codemirror, f = o.getWrapperElement(), v = f.nextSibling;
    if (!v || !v.classList.contains("editor-preview-side")) {
      if (v = document.createElement("div"), v.className = "editor-preview-side", this.options.previewClass)
        if (Array.isArray(this.options.previewClass))
          for (var x = 0; x < this.options.previewClass.length; x++)
            v.classList.add(this.options.previewClass[x]);
        else typeof this.options.previewClass == "string" && v.classList.add(this.options.previewClass);
      f.parentNode.insertBefore(v, f.nextSibling);
    }
    if (typeof this.options.maxHeight < "u" && this.setPreviewMaxHeight(), this.options.syncSideBySidePreviewScroll === !1) return v;
    var b = !1, M = !1;
    return o.on("scroll", function(w) {
      if (b) {
        b = !1;
        return;
      }
      M = !0;
      var y = w.getScrollInfo().height - w.getScrollInfo().clientHeight, B = parseFloat(w.getScrollInfo().top) / y, A = (v.scrollHeight - v.clientHeight) * B;
      v.scrollTop = A;
    }), v.onscroll = function() {
      if (M) {
        M = !1;
        return;
      }
      b = !0;
      var w = v.scrollHeight - v.clientHeight, y = parseFloat(v.scrollTop) / w, B = (o.getScrollInfo().height - o.getScrollInfo().clientHeight) * y;
      o.scrollTo(0, B);
    }, v;
  }, h.prototype.createToolbar = function(o) {
    if (o = o || this.options.toolbar, !(!o || o.length === 0)) {
      var f;
      for (f = 0; f < o.length; f++)
        ot[o[f]] != null && (o[f] = ot[o[f]]);
      var v = document.createElement("div");
      v.className = "editor-toolbar", v.setAttribute("role", "toolbar");
      var x = this, b = {};
      for (x.toolbar = o, f = 0; f < o.length; f++)
        if (!(o[f].name == "guide" && x.options.toolbarGuideIcon === !1) && !(x.options.hideIcons && x.options.hideIcons.indexOf(o[f].name) != -1) && !((o[f].name == "fullscreen" || o[f].name == "side-by-side") && T())) {
          if (o[f] === "|") {
            for (var M = !1, w = f + 1; w < o.length; w++)
              o[w] !== "|" && (!x.options.hideIcons || x.options.hideIcons.indexOf(o[w].name) == -1) && (M = !0);
            if (!M)
              continue;
          }
          (function(A) {
            var ne;
            if (A === "|" ? ne = ie() : A.children ? ne = K(A, x.options.toolbarTips, x.options.shortcuts, x) : ne = fe(A, !0, x.options.toolbarTips, x.options.shortcuts, "button", x), b[A.name || A] = ne, v.appendChild(ne), A.name === "upload-image") {
              var ge = document.createElement("input");
              ge.className = "imageInput", ge.type = "file", ge.multiple = !0, ge.name = x.options.imageInputName, ge.accept = x.options.imageAccept, ge.style.display = "none", ge.style.opacity = 0, v.appendChild(ge);
            }
          })(o[f]);
        }
      x.toolbar_div = v, x.toolbarElements = b;
      var y = this.codemirror;
      y.on("cursorActivity", function() {
        var A = de(y);
        for (var ne in b)
          (function(ge) {
            var ve = b[ge];
            A[ge] ? ve.classList.add("active") : ge != "fullscreen" && ge != "side-by-side" && ve.classList.remove("active");
          })(ne);
      });
      var B = y.getWrapperElement();
      return B.parentNode.insertBefore(v, B), v;
    }
  }, h.prototype.createStatusbar = function(o) {
    o = o || this.options.status;
    var f = this.options, v = this.codemirror;
    if (!(!o || o.length === 0)) {
      var x = [], b, M, w, y;
      for (b = 0; b < o.length; b++)
        if (M = void 0, w = void 0, y = void 0, typeof o[b] == "object")
          x.push({
            className: o[b].className,
            defaultValue: o[b].defaultValue,
            onUpdate: o[b].onUpdate,
            onActivity: o[b].onActivity
          });
        else {
          var B = o[b];
          B === "words" ? (y = function(te) {
            te.innerHTML = Ht(v.getValue());
          }, M = function(te) {
            te.innerHTML = Ht(v.getValue());
          }) : B === "lines" ? (y = function(te) {
            te.innerHTML = v.lineCount();
          }, M = function(te) {
            te.innerHTML = v.lineCount();
          }) : B === "cursor" ? (y = function(te) {
            te.innerHTML = "1:1";
          }, w = function(te) {
            var Be = v.getCursor(), Me = Be.line + 1, Ie = Be.ch + 1;
            te.innerHTML = Me + ":" + Ie;
          }) : B === "autosave" ? y = function(te) {
            f.autosave != null && f.autosave.enabled === !0 && te.setAttribute("id", "autosaved");
          } : B === "upload-image" && (y = function(te) {
            te.innerHTML = f.imageTexts.sbInit;
          }), x.push({
            className: B,
            defaultValue: y,
            onUpdate: M,
            onActivity: w
          });
        }
      var A = document.createElement("div");
      for (A.className = "editor-statusbar", b = 0; b < x.length; b++) {
        var ne = x[b], ge = document.createElement("span");
        ge.className = ne.className, typeof ne.defaultValue == "function" && ne.defaultValue(ge), typeof ne.onUpdate == "function" && this.codemirror.on("update", /* @__PURE__ */ (function(te, Be) {
          return function() {
            Be.onUpdate(te);
          };
        })(ge, ne)), typeof ne.onActivity == "function" && this.codemirror.on("cursorActivity", /* @__PURE__ */ (function(te, Be) {
          return function() {
            Be.onActivity(te);
          };
        })(ge, ne)), A.appendChild(ge);
      }
      var ve = this.codemirror.getWrapperElement();
      return ve.parentNode.insertBefore(A, ve.nextSibling), A;
    }
  }, h.prototype.value = function(o) {
    var f = this.codemirror;
    if (o === void 0)
      return f.getValue();
    if (f.getDoc().setValue(o), this.isPreviewActive()) {
      var v = f.getWrapperElement(), x = v.lastChild, b = this.options.previewRender(o, x);
      b !== null && (x.innerHTML = b);
    }
    return this;
  }, h.toggleBold = X, h.toggleItalic = q, h.toggleStrikethrough = j, h.toggleBlockquote = Z, h.toggleHeadingSmaller = se, h.toggleHeadingBigger = me, h.toggleHeading1 = Ue, h.toggleHeading2 = ae, h.toggleHeading3 = Le, h.toggleHeading4 = Ee, h.toggleHeading5 = He, h.toggleHeading6 = E, h.toggleCodeBlock = ue, h.toggleUnorderedList = ee, h.toggleOrderedList = J, h.cleanBlock = De, h.drawLink = We, h.drawImage = rt, h.drawUploadedImage = D, h.drawTable = G, h.drawHorizontalRule = ze, h.undo = Te, h.redo = Je, h.togglePreview = Ke, h.toggleSideBySide = $e, h.toggleFullScreen = _, h.prototype.toggleBold = function() {
    X(this);
  }, h.prototype.toggleItalic = function() {
    q(this);
  }, h.prototype.toggleStrikethrough = function() {
    j(this);
  }, h.prototype.toggleBlockquote = function() {
    Z(this);
  }, h.prototype.toggleHeadingSmaller = function() {
    se(this);
  }, h.prototype.toggleHeadingBigger = function() {
    me(this);
  }, h.prototype.toggleHeading1 = function() {
    Ue(this);
  }, h.prototype.toggleHeading2 = function() {
    ae(this);
  }, h.prototype.toggleHeading3 = function() {
    Le(this);
  }, h.prototype.toggleHeading4 = function() {
    Ee(this);
  }, h.prototype.toggleHeading5 = function() {
    He(this);
  }, h.prototype.toggleHeading6 = function() {
    E(this);
  }, h.prototype.toggleCodeBlock = function() {
    ue(this);
  }, h.prototype.toggleUnorderedList = function() {
    ee(this);
  }, h.prototype.toggleOrderedList = function() {
    J(this);
  }, h.prototype.cleanBlock = function() {
    De(this);
  }, h.prototype.drawLink = function() {
    We(this);
  }, h.prototype.drawImage = function() {
    rt(this);
  }, h.prototype.drawUploadedImage = function() {
    D(this);
  }, h.prototype.drawTable = function() {
    G(this);
  }, h.prototype.drawHorizontalRule = function() {
    ze(this);
  }, h.prototype.undo = function() {
    Te(this);
  }, h.prototype.redo = function() {
    Je(this);
  }, h.prototype.togglePreview = function() {
    Ke(this);
  }, h.prototype.toggleSideBySide = function() {
    $e(this);
  }, h.prototype.toggleFullScreen = function() {
    _(this);
  }, h.prototype.isPreviewActive = function() {
    var o = this.codemirror, f = o.getWrapperElement(), v = f.lastChild;
    return v.classList.contains("editor-preview-active");
  }, h.prototype.isSideBySideActive = function() {
    var o = this.codemirror, f = o.getWrapperElement(), v = f.nextSibling;
    return v.classList.contains("editor-preview-active-side");
  }, h.prototype.isFullscreenActive = function() {
    var o = this.codemirror;
    return o.getOption("fullScreen");
  }, h.prototype.getState = function() {
    var o = this.codemirror;
    return de(o);
  }, h.prototype.toTextArea = function() {
    var o = this.codemirror, f = o.getWrapperElement(), v = f.parentNode;
    v && (this.gui.toolbar && v.removeChild(this.gui.toolbar), this.gui.statusbar && v.removeChild(this.gui.statusbar), this.gui.sideBySide && v.removeChild(this.gui.sideBySide)), v.parentNode.insertBefore(f, v), v.remove(), o.toTextArea(), this.autosaveTimeoutId && (clearTimeout(this.autosaveTimeoutId), this.autosaveTimeoutId = void 0, this.clearAutosavedValue());
  }, pa = h, pa;
}
var Yo = df();
const pf = /* @__PURE__ */ Qs(Yo), vf = /* @__PURE__ */ Js({
  __proto__: null,
  default: pf
}, [Yo]);
export {
  vf as e
};
