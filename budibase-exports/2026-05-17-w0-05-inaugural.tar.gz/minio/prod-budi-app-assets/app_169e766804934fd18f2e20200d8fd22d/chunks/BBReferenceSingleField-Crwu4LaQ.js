import { bJ as s, g as i, m as n, cw as o, i as c, b1 as t, A as l, w as d } from "./index-CMyk0zjR.js";
import _ from "./BBReferenceField-BjJGUYoe.js";
function B(a, e) {
  const r = s(e, ["children", "$$slots", "$$events", "$$legacy"]), p = s(r, []);
  i(e, !1), n(), _(a, o(() => p, {
    get type() {
      return c(t), l(() => t.BB_REFERENCE_SINGLE);
    }
  })), d();
}
export {
  B as default
};
