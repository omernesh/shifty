const PUBLIC_VERSION = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add("5");
let legacy_mode_flag = !1, tracing_mode_flag = !1;
function enable_legacy_mode_flag() {
  legacy_mode_flag = !0;
}
enable_legacy_mode_flag();
const EACH_ITEM_REACTIVE = 1, EACH_INDEX_REACTIVE = 2, EACH_IS_CONTROLLED = 4, EACH_IS_ANIMATED = 8, EACH_ITEM_IMMUTABLE = 16, PROPS_IS_IMMUTABLE = 1, PROPS_IS_RUNES = 2, PROPS_IS_UPDATED = 4, PROPS_IS_BINDABLE = 8, PROPS_IS_LAZY_INITIAL = 16, TRANSITION_IN = 1, TRANSITION_OUT = 2, TRANSITION_GLOBAL = 4, TEMPLATE_FRAGMENT = 1, TEMPLATE_USE_IMPORT_NODE = 2, TEMPLATE_USE_SVG = 4, TEMPLATE_USE_MATHML = 8, HYDRATION_START = "[", HYDRATION_START_ELSE = "[!", HYDRATION_END = "]", HYDRATION_ERROR = {}, UNINITIALIZED = /* @__PURE__ */ Symbol(), FILENAME = /* @__PURE__ */ Symbol("filename"), HMR = /* @__PURE__ */ Symbol("hmr"), NAMESPACE_HTML = "http://www.w3.org/1999/xhtml", NAMESPACE_SVG = "http://www.w3.org/2000/svg", NAMESPACE_MATHML = "http://www.w3.org/1998/Math/MathML", ATTACHMENT_KEY = "@attach", DEV = !1;
var is_array = Array.isArray, index_of = Array.prototype.indexOf, array_from = Array.from, object_keys = Object.keys, define_property = Object.defineProperty, get_descriptor = Object.getOwnPropertyDescriptor, get_descriptors = Object.getOwnPropertyDescriptors, object_prototype = Object.prototype, array_prototype = Array.prototype, get_prototype_of = Object.getPrototypeOf, is_extensible = Object.isExtensible;
function is_function$1(u) {
  return typeof u == "function";
}
const noop$4 = () => {
};
function is_promise$1(u) {
  return typeof u?.then == "function";
}
function run$1(u) {
  return u();
}
function run_all$1(u) {
  for (var l = 0; l < u.length; l++)
    u[l]();
}
function deferred() {
  var u, l, f = new Promise((p, m) => {
    u = p, l = m;
  });
  return { promise: f, resolve: u, reject: l };
}
function fallback(u, l, f = !1) {
  return u === void 0 ? f ? (
    /** @type {() => V} */
    l()
  ) : (
    /** @type {V} */
    l
  ) : u;
}
function to_array(u, l) {
  if (Array.isArray(u))
    return u;
  if (l === void 0 || !(Symbol.iterator in u))
    return Array.from(u);
  const f = [];
  for (const p of u)
    if (f.push(p), f.length === l) break;
  return f;
}
const DERIVED = 2, EFFECT = 4, RENDER_EFFECT = 8, BLOCK_EFFECT = 16, BRANCH_EFFECT = 32, ROOT_EFFECT = 64, BOUNDARY_EFFECT = 128, UNOWNED = 256, DISCONNECTED = 512, CLEAN = 1024, DIRTY = 2048, MAYBE_DIRTY = 4096, INERT = 8192, DESTROYED = 16384, EFFECT_RAN = 32768, EFFECT_TRANSPARENT = 65536, INSPECT_EFFECT = 1 << 17, HEAD_EFFECT = 1 << 18, EFFECT_PRESERVED = 1 << 19, USER_EFFECT = 1 << 20, REACTION_IS_UPDATING = 1 << 21, ASYNC = 1 << 22, ERROR_VALUE = 1 << 23, STATE_SYMBOL = /* @__PURE__ */ Symbol("$state"), LEGACY_PROPS = /* @__PURE__ */ Symbol("legacy props"), LOADING_ATTR_SYMBOL = /* @__PURE__ */ Symbol(""), PROXY_PATH_SYMBOL = /* @__PURE__ */ Symbol("proxy path"), STALE_REACTION = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}(), ELEMENT_NODE = 1, TEXT_NODE = 3, COMMENT_NODE = 8, DOCUMENT_FRAGMENT_NODE = 11;
function invalid_default_snippet() {
  throw new Error("https://svelte.dev/e/invalid_default_snippet");
}
function invalid_snippet_arguments() {
  throw new Error("https://svelte.dev/e/invalid_snippet_arguments");
}
function lifecycle_outside_component(u) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
function missing_context() {
  throw new Error("https://svelte.dev/e/missing_context");
}
function snippet_without_render_tag() {
  throw new Error("https://svelte.dev/e/snippet_without_render_tag");
}
function store_invalid_shape(u) {
  throw new Error("https://svelte.dev/e/store_invalid_shape");
}
function svelte_element_invalid_this_value() {
  throw new Error("https://svelte.dev/e/svelte_element_invalid_this_value");
}
function async_derived_orphan() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function component_api_changed(u, l) {
  throw new Error("https://svelte.dev/e/component_api_changed");
}
function component_api_invalid_new(u, l) {
  throw new Error("https://svelte.dev/e/component_api_invalid_new");
}
function each_key_duplicate(u, l, f) {
  throw new Error("https://svelte.dev/e/each_key_duplicate");
}
function effect_in_teardown(u) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function effect_in_unowned_derived() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function effect_orphan(u) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function effect_pending_outside_reaction() {
  throw new Error("https://svelte.dev/e/effect_pending_outside_reaction");
}
function effect_update_depth_exceeded() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function get_abort_signal_outside_reaction() {
  throw new Error("https://svelte.dev/e/get_abort_signal_outside_reaction");
}
function hydration_failed() {
  throw new Error("https://svelte.dev/e/hydration_failed");
}
function lifecycle_legacy_only(u) {
  throw new Error("https://svelte.dev/e/lifecycle_legacy_only");
}
function props_invalid_value(u) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function state_descriptors_fixed() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function state_prototype_fixed() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function state_unsafe_mutation() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function svelte_boundary_reset_onerror() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function assignment_value_stale(u, l) {
  console.warn("https://svelte.dev/e/assignment_value_stale");
}
function binding_property_non_reactive(u, l) {
  console.warn("https://svelte.dev/e/binding_property_non_reactive");
}
function console_log_state(u) {
  console.warn("https://svelte.dev/e/console_log_state");
}
function event_handler_invalid(u, l) {
  console.warn("https://svelte.dev/e/event_handler_invalid");
}
function hydration_mismatch(u) {
  console.warn("https://svelte.dev/e/hydration_mismatch");
}
function ownership_invalid_binding(u, l, f, p) {
  console.warn("https://svelte.dev/e/ownership_invalid_binding");
}
function ownership_invalid_mutation(u, l, f, p) {
  console.warn("https://svelte.dev/e/ownership_invalid_mutation");
}
function select_multiple_invalid_value() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function state_proxy_equality_mismatch(u) {
  console.warn("https://svelte.dev/e/state_proxy_equality_mismatch");
}
function svelte_boundary_reset_noop() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
let hydrating = !1;
function set_hydrating(u) {
  hydrating = u;
}
let hydrate_node;
function set_hydrate_node(u) {
  if (u === null)
    throw hydration_mismatch(), HYDRATION_ERROR;
  return hydrate_node = u;
}
function hydrate_next() {
  return set_hydrate_node(
    /** @type {TemplateNode} */
    /* @__PURE__ */ get_next_sibling(hydrate_node)
  );
}
function reset(u) {
  if (hydrating) {
    if (/* @__PURE__ */ get_next_sibling(hydrate_node) !== null)
      throw hydration_mismatch(), HYDRATION_ERROR;
    hydrate_node = u;
  }
}
function hydrate_template(u) {
  hydrating && (hydrate_node = u.content);
}
function next(u = 1) {
  if (hydrating) {
    for (var l = u, f = hydrate_node; l--; )
      f = /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(f);
    hydrate_node = f;
  }
}
function skip_nodes(u = !0) {
  for (var l = 0, f = hydrate_node; ; ) {
    if (f.nodeType === COMMENT_NODE) {
      var p = (
        /** @type {Comment} */
        f.data
      );
      if (p === HYDRATION_END) {
        if (l === 0) return f;
        l -= 1;
      } else (p === HYDRATION_START || p === HYDRATION_START_ELSE) && (l += 1);
    }
    var m = (
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(f)
    );
    u && f.remove(), f = m;
  }
}
function read_hydration_instruction(u) {
  if (!u || u.nodeType !== COMMENT_NODE)
    throw hydration_mismatch(), HYDRATION_ERROR;
  return (
    /** @type {Comment} */
    u.data
  );
}
function equals$1(u) {
  return u === this.v;
}
function safe_not_equal$1(u, l) {
  return u != u ? l == l : u !== l || u !== null && typeof u == "object" || typeof u == "function";
}
function not_equal$1(u, l) {
  return u !== l;
}
function safe_equals(u) {
  return !safe_not_equal$1(u, this.v);
}
function dynamic_void_element_content(u) {
  console.warn("https://svelte.dev/e/dynamic_void_element_content");
}
const empty$2 = [];
function snapshot(u, l = !1, f = !1) {
  return clone$2(u, /* @__PURE__ */ new Map(), "", empty$2, null, f);
}
function clone$2(u, l, f, p, m = null, b = !1) {
  if (typeof u == "object" && u !== null) {
    var y = l.get(u);
    if (y !== void 0) return y;
    if (u instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(u)
    );
    if (u instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(u)
    );
    if (is_array(u)) {
      var v = (
        /** @type {Snapshot<any>} */
        Array(u.length)
      );
      l.set(u, v), m !== null && l.set(m, v);
      for (var $ = 0; $ < u.length; $ += 1) {
        var w = u[$];
        $ in u && (v[$] = clone$2(w, l, f, p, null, b));
      }
      return v;
    }
    if (get_prototype_of(u) === object_prototype) {
      v = {}, l.set(u, v), m !== null && l.set(m, v);
      for (var P in u)
        v[P] = clone$2(
          // @ts-expect-error
          u[P],
          l,
          f,
          p,
          null,
          b
        );
      return v;
    }
    if (u instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(u)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    u.toJSON == "function" && !b)
      return clone$2(
        /** @type {T & { toJSON(): any } } */
        u.toJSON(),
        l,
        f,
        p,
        // Associate the instance with the toJSON clone
        u
      );
  }
  if (u instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      u
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(u)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      u
    );
  }
}
let tracing_expressions = null;
function log_entry(u, l) {
  const f = u.v;
  if (f === UNINITIALIZED)
    return;
  const p = get_type(u), m = (
    /** @type {Reaction} */
    active_reaction
  ), b = u.wv > m.wv || m.wv === 0, y = b ? "color: CornflowerBlue; font-weight: bold" : "color: grey; font-weight: normal";
  if (console.groupCollapsed(
    u.label ? `%c${p}%c ${u.label}` : `%c${p}%c`,
    y,
    b ? "font-weight: normal" : y,
    typeof f == "object" && f !== null && STATE_SYMBOL in f ? snapshot(f, !0) : f
  ), p === "$derived") {
    const $ = new Set(
      /** @type {Derived} */
      u.deps
    );
    for (const w of $)
      log_entry(w);
  }
  if (u.created && console.log(u.created), b && u.updated)
    for (const $ of u.updated.values())
      console.log($.error);
  if (l)
    for (var v of l.traces)
      console.log(v);
  console.groupEnd();
}
function get_type(u) {
  return (u.f & (DERIVED | ASYNC)) !== 0 ? "$derived" : u.label?.startsWith("$") ? "store" : "$state";
}
function trace(u, l) {
  var f = tracing_expressions;
  try {
    tracing_expressions = { entries: /* @__PURE__ */ new Map(), reaction: active_reaction };
    var p = performance.now(), m = l(), b = (performance.now() - p).toFixed(2), y = untrack(u);
    if (!effect_tracking())
      console.log(`${y} %cran outside of an effect (${b}ms)`, "color: grey");
    else if (tracing_expressions.entries.size === 0)
      console.log(`${y} %cno reactive dependencies (${b}ms)`, "color: grey");
    else {
      console.group(`${y} %c(${b}ms)`, "color: grey");
      var v = tracing_expressions.entries;
      untrack(() => {
        for (const [$, w] of v)
          log_entry($, w);
      }), tracing_expressions = null, console.groupEnd();
    }
    return m;
  } finally {
    tracing_expressions = f;
  }
}
function tag$2(u, l) {
  return u.label = l, tag_proxy(u.v, l), u;
}
function tag_proxy(u, l) {
  return u?.[PROXY_PATH_SYMBOL]?.(l), u;
}
let component_context = null;
function set_component_context(u) {
  component_context = u;
}
let dev_stack = null;
function add_svelte_meta(u, l, f, p, m, b) {
  const y = dev_stack;
  dev_stack = {
    type: l,
    file: f[FILENAME],
    line: p,
    column: m,
    parent: y,
    ...b
  };
  try {
    return u();
  } finally {
    dev_stack = y;
  }
}
let dev_current_component_function = null;
function set_dev_current_component_function(u) {
  dev_current_component_function = u;
}
function createContext$1() {
  const u = {};
  return [
    () => (hasContext$1(u) || missing_context(), getContext$2(u)),
    (l) => setContext$1(u, l)
  ];
}
function getContext$2(u) {
  return (
    /** @type {T} */
    get_or_init_context_map().get(u)
  );
}
function setContext$1(u, l) {
  return get_or_init_context_map().set(u, l), l;
}
function hasContext$1(u) {
  return get_or_init_context_map().has(u);
}
function getAllContexts$1() {
  return get_or_init_context_map();
}
function push$2(u, l = !1, f) {
  component_context = {
    p: component_context,
    c: null,
    e: null,
    s: u,
    x: null,
    l: legacy_mode_flag && !l ? { s: null, u: null, $: [] } : null
  };
}
function pop(u) {
  var l = (
    /** @type {ComponentContext} */
    component_context
  ), f = l.e;
  if (f !== null) {
    l.e = null;
    for (var p of f)
      create_user_effect(p);
  }
  return u !== void 0 && (l.x = u), component_context = l.p, u ?? /** @type {T} */
  {};
}
function is_runes() {
  return !legacy_mode_flag || component_context !== null && component_context.l === null;
}
function get_or_init_context_map(u) {
  return component_context === null && lifecycle_outside_component(), component_context.c ??= new Map(get_parent_context(component_context) || void 0);
}
function get_parent_context(u) {
  let l = u.p;
  for (; l !== null; ) {
    const f = l.c;
    if (f !== null)
      return f;
    l = l.p;
  }
  return null;
}
let micro_tasks = [];
function run_micro_tasks() {
  var u = micro_tasks;
  micro_tasks = [], run_all$1(u);
}
function queue_micro_task(u) {
  if (micro_tasks.length === 0 && !is_flushing_sync) {
    var l = micro_tasks;
    queueMicrotask(() => {
      l === micro_tasks && run_micro_tasks();
    });
  }
  micro_tasks.push(u);
}
function flush_tasks() {
  for (; micro_tasks.length > 0; )
    run_micro_tasks();
}
const adjustments = /* @__PURE__ */ new WeakMap();
function handle_error(u) {
  var l = active_effect;
  if (l === null)
    return active_reaction.f |= ERROR_VALUE, u;
  if ((l.f & EFFECT_RAN) === 0) {
    if ((l.f & BOUNDARY_EFFECT) === 0)
      throw !l.parent && u instanceof Error && apply_adjustments(u), u;
    l.b.error(u);
  } else
    invoke_error_boundary(u, l);
}
function invoke_error_boundary(u, l) {
  for (; l !== null; ) {
    if ((l.f & BOUNDARY_EFFECT) !== 0)
      try {
        l.b.error(u);
        return;
      } catch (f) {
        u = f;
      }
    l = l.parent;
  }
  throw u instanceof Error && apply_adjustments(u), u;
}
function apply_adjustments(u) {
  const l = adjustments.get(u);
  l && (define_property(u, "message", {
    value: l.message
  }), define_property(u, "stack", {
    value: l.stack
  }));
}
const batches = /* @__PURE__ */ new Set();
let current_batch = null, previous_batch = null, batch_values = null, effect_pending_updates = /* @__PURE__ */ new Set(), queued_root_effects = [], last_scheduled_effect = null, is_flushing = !1, is_flushing_sync = !1;
class Batch {
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #n = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #a = null;
  /**
   * Async effects inside a newly-created `<svelte:boundary>`
   * — these do not prevent the batch from committing
   * @type {Effect[]}
   */
  #c = [];
  /**
   * Template effects and `$effect.pre` effects, which run when
   * a batch is committed
   * @type {Effect[]}
   */
  #i = [];
  /**
   * The same as `#render_effects`, but for `$effect` (which runs after)
   * @type {Effect[]}
   */
  #r = [];
  /**
   * Block effects, which may need to re-run on subsequent flushes
   * in order to update internal sources (e.g. each block items)
   * @type {Effect[]}
   */
  #o = [];
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Effect[]}
   */
  #d = [];
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Effect[]}
   */
  #u = [];
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(l) {
    queued_root_effects = [], previous_batch = null, this.apply();
    for (const b of l)
      this.#s(b);
    if (this.#n === 0) {
      var f = batch_values;
      this.#f();
      var p = this.#i, m = this.#r;
      this.#i = [], this.#r = [], this.#o = [], previous_batch = this, current_batch = null, batch_values = f, flush_queued_effects(p), flush_queued_effects(m), previous_batch = null, this.#a?.resolve();
    } else
      this.#l(this.#i), this.#l(this.#r), this.#l(this.#o);
    batch_values = null;
    for (const b of this.#c)
      update_effect(b);
    this.#c = [];
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   */
  #s(l) {
    l.f ^= CLEAN;
    for (var f = l.first; f !== null; ) {
      var p = f.f, m = (p & (BRANCH_EFFECT | ROOT_EFFECT)) !== 0, b = m && (p & CLEAN) !== 0, y = b || (p & INERT) !== 0 || this.skipped_effects.has(f);
      if (!y && f.fn !== null) {
        m ? f.f ^= CLEAN : (p & EFFECT) !== 0 ? this.#r.push(f) : (p & CLEAN) === 0 && ((p & ASYNC) !== 0 && f.b?.is_pending() ? this.#c.push(f) : is_dirty(f) && ((f.f & BLOCK_EFFECT) !== 0 && this.#o.push(f), update_effect(f)));
        var v = f.first;
        if (v !== null) {
          f = v;
          continue;
        }
      }
      var $ = f.parent;
      for (f = f.next; f === null && $ !== null; )
        f = $.next, $ = $.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #l(l) {
    for (const f of l)
      ((f.f & DIRTY) !== 0 ? this.#d : this.#u).push(f), set_signal_status(f, CLEAN);
    l.length = 0;
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(l, f) {
    this.#e.has(l) || this.#e.set(l, f), this.current.set(l, l.v), batch_values?.set(l, l.v);
  }
  activate() {
    current_batch = this;
  }
  deactivate() {
    current_batch = null, batch_values = null;
  }
  flush() {
    if (queued_root_effects.length > 0) {
      if (this.activate(), flush_effects(), current_batch !== null && current_batch !== this)
        return;
    } else this.#n === 0 && this.#f();
    this.deactivate();
    for (const l of effect_pending_updates)
      if (effect_pending_updates.delete(l), l(), current_batch !== null)
        break;
  }
  /**
   * Append and remove branches to/from the DOM
   */
  #f() {
    for (const l of this.#t)
      l();
    if (this.#t.clear(), batches.size > 1) {
      this.#e.clear();
      let l = !0;
      for (const f of batches) {
        if (f === this) {
          l = !1;
          continue;
        }
        const p = [];
        for (const [b, y] of this.current) {
          if (f.current.has(b))
            if (l && y !== f.current.get(b))
              f.current.set(b, y);
            else
              continue;
          p.push(b);
        }
        if (p.length === 0)
          continue;
        const m = [...f.current.keys()].filter((b) => !this.current.has(b));
        if (m.length > 0) {
          for (const b of p)
            mark_effects(b, m);
          if (queued_root_effects.length > 0) {
            current_batch = f, f.apply();
            for (const b of queued_root_effects)
              f.#s(b);
            queued_root_effects = [], f.deactivate();
          }
        }
      }
      current_batch = null;
    }
    batches.delete(this);
  }
  increment() {
    this.#n += 1;
  }
  decrement() {
    this.#n -= 1;
    for (const l of this.#d)
      set_signal_status(l, DIRTY), schedule_effect(l);
    for (const l of this.#u)
      set_signal_status(l, MAYBE_DIRTY), schedule_effect(l);
    this.flush();
  }
  /** @param {() => void} fn */
  add_callback(l) {
    this.#t.add(l);
  }
  settled() {
    return (this.#a ??= deferred()).promise;
  }
  static ensure() {
    if (current_batch === null) {
      const l = current_batch = new Batch();
      batches.add(current_batch), is_flushing_sync || Batch.enqueue(() => {
        current_batch === l && l.flush();
      });
    }
    return current_batch;
  }
  /** @param {() => void} task */
  static enqueue(l) {
    queue_micro_task(l);
  }
  apply() {
  }
}
function flushSync(u) {
  var l = is_flushing_sync;
  is_flushing_sync = !0;
  try {
    var f;
    for (u && (current_batch !== null && flush_effects(), f = u()); ; ) {
      if (flush_tasks(), queued_root_effects.length === 0 && (current_batch?.flush(), queued_root_effects.length === 0))
        return last_scheduled_effect = null, /** @type {T} */
        f;
      flush_effects();
    }
  } finally {
    is_flushing_sync = l;
  }
}
function flush_effects() {
  var u = is_updating_effect;
  is_flushing = !0;
  try {
    var l = 0;
    for (set_is_updating_effect(!0); queued_root_effects.length > 0; ) {
      var f = Batch.ensure();
      if (l++ > 1e3) {
        var p, m;
        infinite_loop_guard();
      }
      f.process(queued_root_effects), old_values.clear();
    }
  } finally {
    is_flushing = !1, set_is_updating_effect(u), last_scheduled_effect = null;
  }
}
function infinite_loop_guard() {
  try {
    effect_update_depth_exceeded();
  } catch (u) {
    invoke_error_boundary(u, last_scheduled_effect);
  }
}
let eager_block_effects = null;
function flush_queued_effects(u) {
  var l = u.length;
  if (l !== 0) {
    for (var f = 0; f < l; ) {
      var p = u[f++];
      if ((p.f & (DESTROYED | INERT)) === 0 && is_dirty(p) && (eager_block_effects = [], update_effect(p), p.deps === null && p.first === null && p.nodes_start === null && (p.teardown === null && p.ac === null ? unlink_effect(p) : p.fn = null), eager_block_effects?.length > 0)) {
        old_values.clear();
        for (const m of eager_block_effects)
          update_effect(m);
        eager_block_effects = [];
      }
    }
    eager_block_effects = null;
  }
}
function mark_effects(u, l) {
  if (u.reactions !== null)
    for (const f of u.reactions) {
      const p = f.f;
      (p & DERIVED) !== 0 ? mark_effects(
        /** @type {Derived} */
        f,
        l
      ) : (p & (ASYNC | BLOCK_EFFECT)) !== 0 && depends_on(f, l) && (set_signal_status(f, DIRTY), schedule_effect(
        /** @type {Effect} */
        f
      ));
    }
}
function depends_on(u, l) {
  if (u.deps !== null) {
    for (const f of u.deps)
      if (l.includes(f) || (f.f & DERIVED) !== 0 && depends_on(
        /** @type {Derived} */
        f,
        l
      ))
        return !0;
  }
  return !1;
}
function schedule_effect(u) {
  for (var l = last_scheduled_effect = u; l.parent !== null; ) {
    l = l.parent;
    var f = l.f;
    if (is_flushing && l === active_effect && (f & BLOCK_EFFECT) !== 0)
      return;
    if ((f & (ROOT_EFFECT | BRANCH_EFFECT)) !== 0) {
      if ((f & CLEAN) === 0) return;
      l.f ^= CLEAN;
    }
  }
  queued_root_effects.push(l);
}
function createSubscriber(u) {
  let l = 0, f = source(0), p;
  return () => {
    effect_tracking() && (get$2(f), render_effect(() => (l === 0 && (p = untrack(() => u(() => increment(f)))), l += 1, () => {
      queue_micro_task(() => {
        l -= 1, l === 0 && (p?.(), p = void 0, increment(f));
      });
    })));
  };
}
var flags = EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT;
function boundary(u, l, f) {
  new Boundary(u, l, f);
}
class Boundary {
  /** @type {Boundary | null} */
  parent;
  #e = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #n = hydrating ? hydrate_node : null;
  /** @type {BoundaryProps} */
  #a;
  /** @type {((anchor: Node) => void)} */
  #c;
  /** @type {Effect} */
  #i;
  /** @type {Effect | null} */
  #r = null;
  /** @type {Effect | null} */
  #o = null;
  /** @type {Effect | null} */
  #d = null;
  /** @type {DocumentFragment | null} */
  #u = null;
  #s = 0;
  #l = 0;
  #f = !1;
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #h = null;
  #y = () => {
    this.#h && internal_set(this.#h, this.#s);
  };
  #b = createSubscriber(() => (this.#h = source(this.#s), () => {
    this.#h = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(l, f, p) {
    this.#t = l, this.#a = f, this.#c = p, this.parent = /** @type {Effect} */
    active_effect.b, this.#e = !!this.#a.pending, this.#i = block$1(() => {
      if (active_effect.b = this, hydrating) {
        const m = this.#n;
        hydrate_next(), /** @type {Comment} */
        m.nodeType === COMMENT_NODE && /** @type {Comment} */
        m.data === HYDRATION_START_ELSE ? this.#_() : this.#v();
      } else {
        try {
          this.#r = branch(() => p(this.#t));
        } catch (m) {
          this.error(m);
        }
        this.#l > 0 ? this.#m() : this.#e = !1;
      }
    }, flags), hydrating && (this.#t = hydrate_node);
  }
  #v() {
    try {
      this.#r = branch(() => this.#c(this.#t));
    } catch (l) {
      this.error(l);
    }
    this.#e = !1;
  }
  #_() {
    const l = this.#a.pending;
    l && (this.#o = branch(() => l(this.#t)), Batch.enqueue(() => {
      this.#r = this.#p(() => (Batch.ensure(), branch(() => this.#c(this.#t)))), this.#l > 0 ? this.#m() : (pause_effect(
        /** @type {Effect} */
        this.#o,
        () => {
          this.#o = null;
        }
      ), this.#e = !1);
    }));
  }
  /**
   * Returns `true` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_pending() {
    return this.#e || !!this.parent && this.parent.is_pending();
  }
  has_pending_snippet() {
    return !!this.#a.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(l) {
    var f = active_effect, p = active_reaction, m = component_context;
    set_active_effect(this.#i), set_active_reaction(this.#i), set_component_context(this.#i.ctx);
    try {
      return l();
    } catch (b) {
      return handle_error(b), null;
    } finally {
      set_active_effect(f), set_active_reaction(p), set_component_context(m);
    }
  }
  #m() {
    const l = (
      /** @type {(anchor: Node) => void} */
      this.#a.pending
    );
    this.#r !== null && (this.#u = document.createDocumentFragment(), move_effect(this.#r, this.#u)), this.#o === null && (this.#o = branch(() => l(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #g(l) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#g(l);
      return;
    }
    this.#l += l, this.#l === 0 && (this.#e = !1, this.#o && pause_effect(this.#o, () => {
      this.#o = null;
    }), this.#u && (this.#t.before(this.#u), this.#u = null), queue_micro_task(() => {
      Batch.ensure().flush();
    }));
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(l) {
    this.#g(l), this.#s += l, effect_pending_updates.add(this.#y);
  }
  get_effect_pending() {
    return this.#b(), get$2(
      /** @type {Source<number>} */
      this.#h
    );
  }
  /** @param {unknown} error */
  error(l) {
    var f = this.#a.onerror;
    let p = this.#a.failed;
    if (this.#f || !f && !p)
      throw l;
    this.#r && (destroy_effect(this.#r), this.#r = null), this.#o && (destroy_effect(this.#o), this.#o = null), this.#d && (destroy_effect(this.#d), this.#d = null), hydrating && (set_hydrate_node(
      /** @type {TemplateNode} */
      this.#n
    ), next(), set_hydrate_node(skip_nodes()));
    var m = !1, b = !1;
    const y = () => {
      if (m) {
        svelte_boundary_reset_noop();
        return;
      }
      m = !0, b && svelte_boundary_reset_onerror(), Batch.ensure(), this.#s = 0, this.#d !== null && pause_effect(this.#d, () => {
        this.#d = null;
      }), this.#e = this.has_pending_snippet(), this.#r = this.#p(() => (this.#f = !1, branch(() => this.#c(this.#t)))), this.#l > 0 ? this.#m() : this.#e = !1;
    };
    var v = active_reaction;
    try {
      set_active_reaction(null), b = !0, f?.(l, y), b = !1;
    } catch ($) {
      invoke_error_boundary($, this.#i && this.#i.parent);
    } finally {
      set_active_reaction(v);
    }
    p && queue_micro_task(() => {
      this.#d = this.#p(() => {
        this.#f = !0;
        try {
          return branch(() => {
            p(
              this.#t,
              () => l,
              () => y
            );
          });
        } catch ($) {
          return invoke_error_boundary(
            $,
            /** @type {Effect} */
            this.#i.parent
          ), null;
        } finally {
          this.#f = !1;
        }
      });
    });
  }
}
function move_effect(u, l) {
  for (var f = u.nodes_start, p = u.nodes_end; f !== null; ) {
    var m = f === p ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(f)
    );
    l.append(f), f = m;
  }
}
function get_boundary() {
  return (
    /** @type {Boundary} */
    /** @type {Effect} */
    active_effect.b
  );
}
function pending$1() {
  active_effect === null && effect_pending_outside_reaction();
  var u = active_effect.b;
  return u === null ? 0 : u.get_effect_pending();
}
function flatten$1(u, l, f) {
  const p = is_runes() ? derived$2 : derived_safe_equal;
  if (l.length === 0) {
    f(u.map(p));
    return;
  }
  var m = current_batch, b = (
    /** @type {Effect} */
    active_effect
  ), y = capture(), v = hydrating;
  Promise.all(l.map(($) => /* @__PURE__ */ async_derived($))).then(($) => {
    y();
    try {
      f([...u.map(p), ...$]);
    } catch (w) {
      (b.f & DESTROYED) === 0 && invoke_error_boundary(w, b);
    }
    v && set_hydrating(!1), m?.deactivate(), unset_context();
  }).catch(($) => {
    invoke_error_boundary($, b);
  });
}
function capture() {
  var u = active_effect, l = active_reaction, f = component_context, p = current_batch, m = hydrating;
  if (m)
    var b = hydrate_node;
  return function() {
    set_active_effect(u), set_active_reaction(l), set_component_context(f), p?.activate(), m && (set_hydrating(!0), set_hydrate_node(b));
  };
}
async function save(u) {
  var l = capture(), f = await u;
  return () => (l(), f);
}
async function track_reactivity_loss(u) {
  var l = await u;
  return () => l;
}
async function* for_await_track_reactivity_loss(u) {
  const l = u[Symbol.asyncIterator]?.() ?? u[Symbol.iterator]?.();
  if (l === void 0)
    throw new TypeError("value is not async iterable");
  let f = !1;
  try {
    for (; ; ) {
      const { done: p, value: m } = (await track_reactivity_loss(l.next()))();
      if (p) {
        f = !0;
        break;
      }
      yield m;
    }
  } finally {
    if (f && l.return !== void 0)
      return (
        /** @type {TReturn} */
        (await track_reactivity_loss(l.return()))().value
      );
  }
}
function unset_context() {
  set_active_effect(null), set_active_reaction(null), set_component_context(null);
}
async function async_body(u) {
  var l = get_boundary(), f = (
    /** @type {Batch} */
    current_batch
  ), p = l.is_pending();
  l.update_pending_count(1), p || f.increment();
  var m = (
    /** @type {Effect} */
    active_effect
  ), b = hydrating, y = void 0;
  b && (hydrate_next(), y = skip_nodes(!1));
  try {
    var v = u();
  } finally {
    y && (set_hydrate_node(y), hydrate_next());
  }
  try {
    await v;
  } catch ($) {
    aborted$1(m) || invoke_error_boundary($, m);
  } finally {
    b && set_hydrating(!1), l.update_pending_count(-1), p ? f.flush() : f.decrement(), unset_context();
  }
}
// @__NO_SIDE_EFFECTS__
function derived$2(u) {
  var l = DERIVED | DIRTY, f = active_reaction !== null && (active_reaction.f & DERIVED) !== 0 ? (
    /** @type {Derived} */
    active_reaction
  ) : null;
  return active_effect === null || f !== null && (f.f & UNOWNED) !== 0 ? l |= UNOWNED : active_effect.f |= EFFECT_PRESERVED, {
    ctx: component_context,
    deps: null,
    effects: null,
    equals: equals$1,
    f: l,
    fn: u,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      UNINITIALIZED
    ),
    wv: 0,
    parent: f ?? active_effect,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function async_derived(u, l) {
  let f = (
    /** @type {Effect | null} */
    active_effect
  );
  f === null && async_derived_orphan();
  var p = (
    /** @type {Boundary} */
    f.b
  ), m = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), b = source(
    /** @type {V} */
    UNINITIALIZED
  ), y = !active_reaction, v = /* @__PURE__ */ new Map();
  return async_effect(() => {
    var $ = deferred();
    m = $.promise;
    try {
      Promise.resolve(u()).then($.resolve, $.reject).then(unset_context);
    } catch (x) {
      $.reject(x), unset_context();
    }
    var w = (
      /** @type {Batch} */
      current_batch
    ), P = p.is_pending();
    y && (p.update_pending_count(1), P || (w.increment(), v.get(w)?.reject(STALE_REACTION), v.delete(w), v.set(w, $)));
    const k = (x, S = void 0) => {
      if (P || w.activate(), S)
        S !== STALE_REACTION && (b.f |= ERROR_VALUE, internal_set(b, S));
      else {
        (b.f & ERROR_VALUE) !== 0 && (b.f ^= ERROR_VALUE), internal_set(b, x);
        for (const [T, M] of v) {
          if (v.delete(T), T === w) break;
          M.reject(STALE_REACTION);
        }
      }
      y && (p.update_pending_count(-1), P || w.decrement());
    };
    $.promise.then(k, (x) => k(null, x || "unknown"));
  }), teardown(() => {
    for (const $ of v.values())
      $.reject(STALE_REACTION);
  }), new Promise(($) => {
    function w(P) {
      function k() {
        P === m ? $(b) : w(m);
      }
      P.then(k, k);
    }
    w(m);
  });
}
// @__NO_SIDE_EFFECTS__
function user_derived(u) {
  const l = /* @__PURE__ */ derived$2(u);
  return push_reaction_value(l), l;
}
// @__NO_SIDE_EFFECTS__
function derived_safe_equal(u) {
  const l = /* @__PURE__ */ derived$2(u);
  return l.equals = safe_equals, l;
}
function destroy_derived_effects(u) {
  var l = u.effects;
  if (l !== null) {
    u.effects = null;
    for (var f = 0; f < l.length; f += 1)
      destroy_effect(
        /** @type {Effect} */
        l[f]
      );
  }
}
function get_derived_parent_effect(u) {
  for (var l = u.parent; l !== null; ) {
    if ((l.f & DERIVED) === 0)
      return (
        /** @type {Effect} */
        l
      );
    l = l.parent;
  }
  return null;
}
function execute_derived(u) {
  var l, f = active_effect;
  set_active_effect(get_derived_parent_effect(u));
  try {
    destroy_derived_effects(u), l = update_reaction(u);
  } finally {
    set_active_effect(f);
  }
  return l;
}
function update_derived(u) {
  var l = execute_derived(u);
  if (u.equals(l) || (u.v = l, u.wv = increment_write_version()), !is_destroying_effect)
    if (batch_values !== null)
      batch_values.set(u, u.v);
    else {
      var f = (skip_reaction || (u.f & UNOWNED) !== 0) && u.deps !== null ? MAYBE_DIRTY : CLEAN;
      set_signal_status(u, f);
    }
}
const old_values = /* @__PURE__ */ new Map();
function source(u, l) {
  var f = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: u,
    reactions: null,
    equals: equals$1,
    rv: 0,
    wv: 0
  };
  return f;
}
// @__NO_SIDE_EFFECTS__
function state(u, l) {
  const f = source(u);
  return push_reaction_value(f), f;
}
// @__NO_SIDE_EFFECTS__
function mutable_source(u, l = !1, f = !0) {
  const p = source(u);
  return l || (p.equals = safe_equals), legacy_mode_flag && f && component_context !== null && component_context.l !== null && (component_context.l.s ??= []).push(p), p;
}
function mutate(u, l) {
  return set(
    u,
    untrack(() => get$2(u))
  ), l;
}
function set(u, l, f = !1) {
  active_reaction !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!untracking || (active_reaction.f & INSPECT_EFFECT) !== 0) && is_runes() && (active_reaction.f & (DERIVED | BLOCK_EFFECT | ASYNC | INSPECT_EFFECT)) !== 0 && !current_sources?.includes(u) && state_unsafe_mutation();
  let p = f ? proxy(l) : l;
  return internal_set(u, p);
}
function internal_set(u, l) {
  if (!u.equals(l)) {
    var f = u.v;
    is_destroying_effect ? old_values.set(u, l) : old_values.set(u, f), u.v = l;
    var p = Batch.ensure();
    p.capture(u, f), (u.f & DERIVED) !== 0 && ((u.f & DIRTY) !== 0 && execute_derived(
      /** @type {Derived} */
      u
    ), set_signal_status(u, (u.f & UNOWNED) === 0 ? CLEAN : MAYBE_DIRTY)), u.wv = increment_write_version(), mark_reactions(u, DIRTY), is_runes() && active_effect !== null && (active_effect.f & CLEAN) !== 0 && (active_effect.f & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 && (untracked_writes === null ? set_untracked_writes([u]) : untracked_writes.push(u));
  }
  return l;
}
function update$1(u, l = 1) {
  var f = get$2(u), p = l === 1 ? f++ : f--;
  return set(u, f), p;
}
function update_pre(u, l = 1) {
  var f = get$2(u);
  return set(u, l === 1 ? ++f : --f);
}
function increment(u) {
  set(u, u.v + 1);
}
function mark_reactions(u, l) {
  var f = u.reactions;
  if (f !== null)
    for (var p = is_runes(), m = f.length, b = 0; b < m; b++) {
      var y = f[b], v = y.f;
      if (!(!p && y === active_effect)) {
        var $ = (v & DIRTY) === 0;
        $ && set_signal_status(y, l), (v & DERIVED) !== 0 ? mark_reactions(
          /** @type {Derived} */
          y,
          MAYBE_DIRTY
        ) : $ && ((v & BLOCK_EFFECT) !== 0 && eager_block_effects !== null && eager_block_effects.push(
          /** @type {Effect} */
          y
        ), schedule_effect(
          /** @type {Effect} */
          y
        ));
      }
    }
}
function proxy(u) {
  if (typeof u != "object" || u === null || STATE_SYMBOL in u)
    return u;
  const l = get_prototype_of(u);
  if (l !== object_prototype && l !== array_prototype)
    return u;
  var f = /* @__PURE__ */ new Map(), p = is_array(u), m = /* @__PURE__ */ state(0), b = update_version, y = (v) => {
    if (update_version === b)
      return v();
    var $ = active_reaction, w = update_version;
    set_active_reaction(null), set_update_version(b);
    var P = v();
    return set_active_reaction($), set_update_version(w), P;
  };
  return p && f.set("length", /* @__PURE__ */ state(
    /** @type {any[]} */
    u.length
  )), new Proxy(
    /** @type {any} */
    u,
    {
      defineProperty(v, $, w) {
        (!("value" in w) || w.configurable === !1 || w.enumerable === !1 || w.writable === !1) && state_descriptors_fixed();
        var P = f.get($);
        return P === void 0 ? P = y(() => {
          var k = /* @__PURE__ */ state(w.value);
          return f.set($, k), k;
        }) : set(P, w.value, !0), !0;
      },
      deleteProperty(v, $) {
        var w = f.get($);
        if (w === void 0) {
          if ($ in v) {
            const P = y(() => /* @__PURE__ */ state(UNINITIALIZED));
            f.set($, P), increment(m);
          }
        } else
          set(w, UNINITIALIZED), increment(m);
        return !0;
      },
      get(v, $, w) {
        if ($ === STATE_SYMBOL)
          return u;
        var P = f.get($), k = $ in v;
        if (P === void 0 && (!k || get_descriptor(v, $)?.writable) && (P = y(() => {
          var S = proxy(k ? v[$] : UNINITIALIZED), T = /* @__PURE__ */ state(S);
          return T;
        }), f.set($, P)), P !== void 0) {
          var x = get$2(P);
          return x === UNINITIALIZED ? void 0 : x;
        }
        return Reflect.get(v, $, w);
      },
      getOwnPropertyDescriptor(v, $) {
        var w = Reflect.getOwnPropertyDescriptor(v, $);
        if (w && "value" in w) {
          var P = f.get($);
          P && (w.value = get$2(P));
        } else if (w === void 0) {
          var k = f.get($), x = k?.v;
          if (k !== void 0 && x !== UNINITIALIZED)
            return {
              enumerable: !0,
              configurable: !0,
              value: x,
              writable: !0
            };
        }
        return w;
      },
      has(v, $) {
        if ($ === STATE_SYMBOL)
          return !0;
        var w = f.get($), P = w !== void 0 && w.v !== UNINITIALIZED || Reflect.has(v, $);
        if (w !== void 0 || active_effect !== null && (!P || get_descriptor(v, $)?.writable)) {
          w === void 0 && (w = y(() => {
            var x = P ? proxy(v[$]) : UNINITIALIZED, S = /* @__PURE__ */ state(x);
            return S;
          }), f.set($, w));
          var k = get$2(w);
          if (k === UNINITIALIZED)
            return !1;
        }
        return P;
      },
      set(v, $, w, P) {
        var k = f.get($), x = $ in v;
        if (p && $ === "length")
          for (var S = w; S < /** @type {Source<number>} */
          k.v; S += 1) {
            var T = f.get(S + "");
            T !== void 0 ? set(T, UNINITIALIZED) : S in v && (T = y(() => /* @__PURE__ */ state(UNINITIALIZED)), f.set(S + "", T));
          }
        if (k === void 0)
          (!x || get_descriptor(v, $)?.writable) && (k = y(() => /* @__PURE__ */ state(void 0)), set(k, proxy(w)), f.set($, k));
        else {
          x = k.v !== UNINITIALIZED;
          var M = y(() => proxy(w));
          set(k, M);
        }
        var E = Reflect.getOwnPropertyDescriptor(v, $);
        if (E?.set && E.set.call(P, w), !x) {
          if (p && typeof $ == "string") {
            var R = (
              /** @type {Source<number>} */
              f.get("length")
            ), O = Number($);
            Number.isInteger(O) && O >= R.v && set(R, O + 1);
          }
          increment(m);
        }
        return !0;
      },
      ownKeys(v) {
        get$2(m);
        var $ = Reflect.ownKeys(v).filter((k) => {
          var x = f.get(k);
          return x === void 0 || x.v !== UNINITIALIZED;
        });
        for (var [w, P] of f)
          P.v !== UNINITIALIZED && !(w in v) && $.push(w);
        return $;
      },
      setPrototypeOf() {
        state_prototype_fixed();
      }
    }
  );
}
function get_proxied_value(u) {
  try {
    if (u !== null && typeof u == "object" && STATE_SYMBOL in u)
      return u[STATE_SYMBOL];
  } catch {
  }
  return u;
}
function is$1(u, l) {
  return Object.is(get_proxied_value(u), get_proxied_value(l));
}
function strict_equals(u, l, f = !0) {
  try {
    u === l != (get_proxied_value(u) === get_proxied_value(l)) && state_proxy_equality_mismatch(f ? "===" : "!==");
  } catch {
  }
  return u === l === f;
}
function equals(u, l, f = !0) {
  return u == l != (get_proxied_value(u) == get_proxied_value(l)) && state_proxy_equality_mismatch(), u == l === f;
}
var $window, $document, is_firefox, first_child_getter, next_sibling_getter;
function init_operations() {
  if ($window === void 0) {
    $window = window, $document = document, is_firefox = /Firefox/.test(navigator.userAgent);
    var u = Element.prototype, l = Node.prototype, f = Text.prototype;
    first_child_getter = get_descriptor(l, "firstChild").get, next_sibling_getter = get_descriptor(l, "nextSibling").get, is_extensible(u) && (u.__click = void 0, u.__className = void 0, u.__attributes = null, u.__style = void 0, u.__e = void 0), is_extensible(f) && (f.__t = void 0);
  }
}
function create_text(u = "") {
  return document.createTextNode(u);
}
// @__NO_SIDE_EFFECTS__
function get_first_child(u) {
  return first_child_getter.call(u);
}
// @__NO_SIDE_EFFECTS__
function get_next_sibling(u) {
  return next_sibling_getter.call(u);
}
function child(u, l) {
  if (!hydrating)
    return /* @__PURE__ */ get_first_child(u);
  var f = (
    /** @type {TemplateNode} */
    /* @__PURE__ */ get_first_child(hydrate_node)
  );
  if (f === null)
    f = hydrate_node.appendChild(create_text());
  else if (l && f.nodeType !== TEXT_NODE) {
    var p = create_text();
    return f?.before(p), set_hydrate_node(p), p;
  }
  return set_hydrate_node(f), f;
}
function first_child(u, l = !1) {
  if (!hydrating) {
    var f = (
      /** @type {DocumentFragment} */
      /* @__PURE__ */ get_first_child(
        /** @type {Node} */
        u
      )
    );
    return f instanceof Comment && f.data === "" ? /* @__PURE__ */ get_next_sibling(f) : f;
  }
  if (l && hydrate_node?.nodeType !== TEXT_NODE) {
    var p = create_text();
    return hydrate_node?.before(p), set_hydrate_node(p), p;
  }
  return hydrate_node;
}
function sibling(u, l = 1, f = !1) {
  let p = hydrating ? hydrate_node : u;
  for (var m; l--; )
    m = p, p = /** @type {TemplateNode} */
    /* @__PURE__ */ get_next_sibling(p);
  if (!hydrating)
    return p;
  if (f && p?.nodeType !== TEXT_NODE) {
    var b = create_text();
    return p === null ? m?.after(b) : p.before(b), set_hydrate_node(b), b;
  }
  return set_hydrate_node(p), /** @type {TemplateNode} */
  p;
}
function clear_text_content(u) {
  u.textContent = "";
}
function should_defer_append() {
  return !1;
}
function create_element(u, l, f) {
  let p = f ? { is: f } : void 0;
  return l ? document.createElementNS(l, u, p) : document.createElement(u, p);
}
function create_fragment() {
  return document.createDocumentFragment();
}
function create_comment(u = "") {
  return document.createComment(u);
}
function set_attribute$1(u, l, f = "") {
  if (l.startsWith("xlink:")) {
    u.setAttributeNS("http://www.w3.org/1999/xlink", l, f);
    return;
  }
  return u.setAttribute(l, f);
}
function autofocus(u, l) {
  if (l) {
    const f = document.body;
    u.autofocus = !0, queue_micro_task(() => {
      document.activeElement === f && u.focus();
    });
  }
}
function remove_textarea_child(u) {
  hydrating && /* @__PURE__ */ get_first_child(u) !== null && clear_text_content(u);
}
let listening_to_form_reset = !1;
function add_form_reset_listener() {
  listening_to_form_reset || (listening_to_form_reset = !0, document.addEventListener(
    "reset",
    (u) => {
      Promise.resolve().then(() => {
        if (!u.defaultPrevented)
          for (
            const l of
            /**@type {HTMLFormElement} */
            u.target.elements
          )
            l.__on_r?.();
      });
    },
    // In the capture phase to guarantee we get noticed of it (no possiblity of stopPropagation)
    { capture: !0 }
  ));
}
function listen$1(u, l, f, p = !0) {
  p && f();
  for (var m of l)
    u.addEventListener(m, f);
  teardown(() => {
    for (var b of l)
      u.removeEventListener(b, f);
  });
}
function without_reactive_context(u) {
  var l = active_reaction, f = active_effect;
  set_active_reaction(null), set_active_effect(null);
  try {
    return u();
  } finally {
    set_active_reaction(l), set_active_effect(f);
  }
}
function listen_to_event_and_reset_event(u, l, f, p = f) {
  u.addEventListener(l, () => without_reactive_context(f));
  const m = u.__on_r;
  m ? u.__on_r = () => {
    m(), p(!0);
  } : u.__on_r = () => p(!0), add_form_reset_listener();
}
function validate_effect(u) {
  active_effect === null && active_reaction === null && effect_orphan(), active_reaction !== null && (active_reaction.f & UNOWNED) !== 0 && active_effect === null && effect_in_unowned_derived(), is_destroying_effect && effect_in_teardown();
}
function push_effect(u, l) {
  var f = l.last;
  f === null ? l.last = l.first = u : (f.next = u, u.prev = f, l.last = u);
}
function create_effect(u, l, f, p = !0) {
  var m = active_effect;
  m !== null && (m.f & INERT) !== 0 && (u |= INERT);
  var b = {
    ctx: component_context,
    deps: null,
    nodes_start: null,
    nodes_end: null,
    f: u | DIRTY,
    first: null,
    fn: l,
    last: null,
    next: null,
    parent: m,
    b: m && m.b,
    prev: null,
    teardown: null,
    transitions: null,
    wv: 0,
    ac: null
  };
  if (f)
    try {
      update_effect(b), b.f |= EFFECT_RAN;
    } catch ($) {
      throw destroy_effect(b), $;
    }
  else l !== null && schedule_effect(b);
  if (p) {
    var y = b;
    if (f && y.deps === null && y.teardown === null && y.nodes_start === null && y.first === y.last && // either `null`, or a singular child
    (y.f & EFFECT_PRESERVED) === 0 && (y = y.first), y !== null && (y.parent = m, m !== null && push_effect(y, m), active_reaction !== null && (active_reaction.f & DERIVED) !== 0 && (u & ROOT_EFFECT) === 0)) {
      var v = (
        /** @type {Derived} */
        active_reaction
      );
      (v.effects ??= []).push(y);
    }
  }
  return b;
}
function effect_tracking() {
  return active_reaction !== null && !untracking;
}
function teardown(u) {
  const l = create_effect(RENDER_EFFECT, null, !1);
  return set_signal_status(l, CLEAN), l.teardown = u, l;
}
function user_effect(u) {
  validate_effect();
  var l = (
    /** @type {Effect} */
    active_effect.f
  ), f = !active_reaction && (l & BRANCH_EFFECT) !== 0 && (l & EFFECT_RAN) === 0;
  if (f) {
    var p = (
      /** @type {ComponentContext} */
      component_context
    );
    (p.e ??= []).push(u);
  } else
    return create_user_effect(u);
}
function create_user_effect(u) {
  return create_effect(EFFECT | USER_EFFECT, u, !1);
}
function user_pre_effect(u) {
  return validate_effect(), create_effect(RENDER_EFFECT | USER_EFFECT, u, !0);
}
function inspect_effect(u) {
  return create_effect(INSPECT_EFFECT, u, !0);
}
function effect_root(u) {
  Batch.ensure();
  const l = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, u, !0);
  return () => {
    destroy_effect(l);
  };
}
function component_root(u) {
  Batch.ensure();
  const l = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, u, !0);
  return (f = {}) => new Promise((p) => {
    f.outro ? pause_effect(l, () => {
      destroy_effect(l), p(void 0);
    }) : (destroy_effect(l), p(void 0));
  });
}
function effect(u) {
  return create_effect(EFFECT, u, !1);
}
function legacy_pre_effect(u, l) {
  var f = (
    /** @type {ComponentContextLegacy} */
    component_context
  ), p = { effect: null, ran: !1, deps: u };
  f.l.$.push(p), p.effect = render_effect(() => {
    u(), !p.ran && (p.ran = !0, untrack(l));
  });
}
function legacy_pre_effect_reset() {
  var u = (
    /** @type {ComponentContextLegacy} */
    component_context
  );
  render_effect(() => {
    for (var l of u.l.$) {
      l.deps();
      var f = l.effect;
      (f.f & CLEAN) !== 0 && set_signal_status(f, MAYBE_DIRTY), is_dirty(f) && update_effect(f), l.ran = !1;
    }
  });
}
function async_effect(u) {
  return create_effect(ASYNC | EFFECT_PRESERVED, u, !0);
}
function render_effect(u, l = 0) {
  return create_effect(RENDER_EFFECT | l, u, !0);
}
function template_effect(u, l = [], f = []) {
  flatten$1(l, f, (p) => {
    create_effect(RENDER_EFFECT, () => u(...p.map(get$2)), !0);
  });
}
function block$1(u, l = 0) {
  var f = create_effect(BLOCK_EFFECT | l, u, !0);
  return f;
}
function branch(u, l = !0) {
  return create_effect(BRANCH_EFFECT | EFFECT_PRESERVED, u, !0, l);
}
function execute_effect_teardown(u) {
  var l = u.teardown;
  if (l !== null) {
    const f = is_destroying_effect, p = active_reaction;
    set_is_destroying_effect(!0), set_active_reaction(null);
    try {
      l.call(null);
    } finally {
      set_is_destroying_effect(f), set_active_reaction(p);
    }
  }
}
function destroy_effect_children(u, l = !1) {
  var f = u.first;
  for (u.first = u.last = null; f !== null; ) {
    const m = f.ac;
    m !== null && without_reactive_context(() => {
      m.abort(STALE_REACTION);
    });
    var p = f.next;
    (f.f & ROOT_EFFECT) !== 0 ? f.parent = null : destroy_effect(f, l), f = p;
  }
}
function destroy_block_effect_children(u) {
  for (var l = u.first; l !== null; ) {
    var f = l.next;
    (l.f & BRANCH_EFFECT) === 0 && destroy_effect(l), l = f;
  }
}
function destroy_effect(u, l = !0) {
  var f = !1;
  (l || (u.f & HEAD_EFFECT) !== 0) && u.nodes_start !== null && u.nodes_end !== null && (remove_effect_dom(
    u.nodes_start,
    /** @type {TemplateNode} */
    u.nodes_end
  ), f = !0), destroy_effect_children(u, l && !f), remove_reactions(u, 0), set_signal_status(u, DESTROYED);
  var p = u.transitions;
  if (p !== null)
    for (const b of p)
      b.stop();
  execute_effect_teardown(u);
  var m = u.parent;
  m !== null && m.first !== null && unlink_effect(u), u.next = u.prev = u.teardown = u.ctx = u.deps = u.fn = u.nodes_start = u.nodes_end = u.ac = null;
}
function remove_effect_dom(u, l) {
  for (; u !== null; ) {
    var f = u === l ? null : (
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(u)
    );
    u.remove(), u = f;
  }
}
function unlink_effect(u) {
  var l = u.parent, f = u.prev, p = u.next;
  f !== null && (f.next = p), p !== null && (p.prev = f), l !== null && (l.first === u && (l.first = p), l.last === u && (l.last = f));
}
function pause_effect(u, l) {
  var f = [];
  pause_children(u, f, !0), run_out_transitions(f, () => {
    destroy_effect(u), l && l();
  });
}
function run_out_transitions(u, l) {
  var f = u.length;
  if (f > 0) {
    var p = () => --f || l();
    for (var m of u)
      m.out(p);
  } else
    l();
}
function pause_children(u, l, f) {
  if ((u.f & INERT) === 0) {
    if (u.f ^= INERT, u.transitions !== null)
      for (const y of u.transitions)
        (y.is_global || f) && l.push(y);
    for (var p = u.first; p !== null; ) {
      var m = p.next, b = (p.f & EFFECT_TRANSPARENT) !== 0 || (p.f & BRANCH_EFFECT) !== 0;
      pause_children(p, l, b ? f : !1), p = m;
    }
  }
}
function resume_effect(u) {
  resume_children(u, !0);
}
function resume_children(u, l) {
  if ((u.f & INERT) !== 0) {
    u.f ^= INERT, (u.f & CLEAN) === 0 && (set_signal_status(u, DIRTY), schedule_effect(u));
    for (var f = u.first; f !== null; ) {
      var p = f.next, m = (f.f & EFFECT_TRANSPARENT) !== 0 || (f.f & BRANCH_EFFECT) !== 0;
      resume_children(f, m ? l : !1), f = p;
    }
    if (u.transitions !== null)
      for (const b of u.transitions)
        (b.is_global || l) && b.in();
  }
}
function aborted$1(u = (
  /** @type {Effect} */
  active_effect
)) {
  return (u.f & DESTROYED) !== 0;
}
let captured_signals = null;
function capture_signals(u) {
  var l = captured_signals;
  try {
    if (captured_signals = /* @__PURE__ */ new Set(), untrack(u), l !== null)
      for (var f of captured_signals)
        l.add(f);
    return captured_signals;
  } finally {
    captured_signals = l;
  }
}
function invalidate_inner_signals(u) {
  for (var l of capture_signals(u))
    internal_set(l, l.v);
}
let is_updating_effect = !1;
function set_is_updating_effect(u) {
  is_updating_effect = u;
}
let is_destroying_effect = !1;
function set_is_destroying_effect(u) {
  is_destroying_effect = u;
}
let active_reaction = null, untracking = !1;
function set_active_reaction(u) {
  active_reaction = u;
}
let active_effect = null;
function set_active_effect(u) {
  active_effect = u;
}
let current_sources = null;
function push_reaction_value(u) {
  active_reaction !== null && (current_sources === null ? current_sources = [u] : current_sources.push(u));
}
let new_deps = null, skipped_deps = 0, untracked_writes = null;
function set_untracked_writes(u) {
  untracked_writes = u;
}
let write_version = 1, read_version = 0, update_version = read_version;
function set_update_version(u) {
  update_version = u;
}
let skip_reaction = !1;
function increment_write_version() {
  return ++write_version;
}
function is_dirty(u) {
  var l = u.f;
  if ((l & DIRTY) !== 0)
    return !0;
  if ((l & MAYBE_DIRTY) !== 0) {
    var f = u.deps, p = (l & UNOWNED) !== 0;
    if (f !== null) {
      var m, b, y = (l & DISCONNECTED) !== 0, v = p && active_effect !== null && !skip_reaction, $ = f.length;
      if ((y || v) && (active_effect === null || (active_effect.f & DESTROYED) === 0)) {
        var w = (
          /** @type {Derived} */
          u
        ), P = w.parent;
        for (m = 0; m < $; m++)
          b = f[m], (y || !b?.reactions?.includes(w)) && (b.reactions ??= []).push(w);
        y && (w.f ^= DISCONNECTED), v && P !== null && (P.f & UNOWNED) === 0 && (w.f ^= UNOWNED);
      }
      for (m = 0; m < $; m++)
        if (b = f[m], is_dirty(
          /** @type {Derived} */
          b
        ) && update_derived(
          /** @type {Derived} */
          b
        ), b.wv > u.wv)
          return !0;
    }
    (!p || active_effect !== null && !skip_reaction) && set_signal_status(u, CLEAN);
  }
  return !1;
}
function schedule_possible_effect_self_invalidation(u, l, f = !0) {
  var p = u.reactions;
  if (p !== null && !current_sources?.includes(u))
    for (var m = 0; m < p.length; m++) {
      var b = p[m];
      (b.f & DERIVED) !== 0 ? schedule_possible_effect_self_invalidation(
        /** @type {Derived} */
        b,
        l,
        !1
      ) : l === b && (f ? set_signal_status(b, DIRTY) : (b.f & CLEAN) !== 0 && set_signal_status(b, MAYBE_DIRTY), schedule_effect(
        /** @type {Effect} */
        b
      ));
    }
}
function update_reaction(u) {
  var l = new_deps, f = skipped_deps, p = untracked_writes, m = active_reaction, b = skip_reaction, y = current_sources, v = component_context, $ = untracking, w = update_version, P = u.f;
  new_deps = /** @type {null | Value[]} */
  null, skipped_deps = 0, untracked_writes = null, skip_reaction = (P & UNOWNED) !== 0 && (untracking || !is_updating_effect || active_reaction === null), active_reaction = (P & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 ? u : null, current_sources = null, set_component_context(u.ctx), untracking = !1, update_version = ++read_version, u.ac !== null && (without_reactive_context(() => {
    u.ac.abort(STALE_REACTION);
  }), u.ac = null);
  try {
    u.f |= REACTION_IS_UPDATING;
    var k = (
      /** @type {Function} */
      u.fn
    ), x = k(), S = u.deps;
    if (new_deps !== null) {
      var T;
      if (remove_reactions(u, skipped_deps), S !== null && skipped_deps > 0)
        for (S.length = skipped_deps + new_deps.length, T = 0; T < new_deps.length; T++)
          S[skipped_deps + T] = new_deps[T];
      else
        u.deps = S = new_deps;
      if (!skip_reaction || // Deriveds that already have reactions can cleanup, so we still add them as reactions
      (P & DERIVED) !== 0 && /** @type {import('#client').Derived} */
      u.reactions !== null)
        for (T = skipped_deps; T < S.length; T++)
          (S[T].reactions ??= []).push(u);
    } else S !== null && skipped_deps < S.length && (remove_reactions(u, skipped_deps), S.length = skipped_deps);
    if (is_runes() && untracked_writes !== null && !untracking && S !== null && (u.f & (DERIVED | MAYBE_DIRTY | DIRTY)) === 0)
      for (T = 0; T < /** @type {Source[]} */
      untracked_writes.length; T++)
        schedule_possible_effect_self_invalidation(
          untracked_writes[T],
          /** @type {Effect} */
          u
        );
    return m !== null && m !== u && (read_version++, untracked_writes !== null && (p === null ? p = untracked_writes : p.push(.../** @type {Source[]} */
    untracked_writes))), (u.f & ERROR_VALUE) !== 0 && (u.f ^= ERROR_VALUE), x;
  } catch (M) {
    return handle_error(M);
  } finally {
    u.f ^= REACTION_IS_UPDATING, new_deps = l, skipped_deps = f, untracked_writes = p, active_reaction = m, skip_reaction = b, current_sources = y, set_component_context(v), untracking = $, update_version = w;
  }
}
function remove_reaction(u, l) {
  let f = l.reactions;
  if (f !== null) {
    var p = index_of.call(f, u);
    if (p !== -1) {
      var m = f.length - 1;
      m === 0 ? f = l.reactions = null : (f[p] = f[m], f.pop());
    }
  }
  f === null && (l.f & DERIVED) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (new_deps === null || !new_deps.includes(l)) && (set_signal_status(l, MAYBE_DIRTY), (l.f & (UNOWNED | DISCONNECTED)) === 0 && (l.f ^= DISCONNECTED), destroy_derived_effects(
    /** @type {Derived} **/
    l
  ), remove_reactions(
    /** @type {Derived} **/
    l,
    0
  ));
}
function remove_reactions(u, l) {
  var f = u.deps;
  if (f !== null)
    for (var p = l; p < f.length; p++)
      remove_reaction(u, f[p]);
}
function update_effect(u) {
  var l = u.f;
  if ((l & DESTROYED) === 0) {
    set_signal_status(u, CLEAN);
    var f = active_effect, p = is_updating_effect;
    active_effect = u, is_updating_effect = !0;
    try {
      (l & BLOCK_EFFECT) !== 0 ? destroy_block_effect_children(u) : destroy_effect_children(u), execute_effect_teardown(u);
      var m = update_reaction(u);
      u.teardown = typeof m == "function" ? m : null, u.wv = write_version;
      var b;
      DEV && tracing_mode_flag && (u.f & DIRTY) !== 0 && u.deps;
    } finally {
      is_updating_effect = p, active_effect = f;
    }
  }
}
async function tick$1() {
  await Promise.resolve(), flushSync();
}
function settled() {
  return Batch.ensure().settled();
}
function get$2(u) {
  var l = u.f, f = (l & DERIVED) !== 0;
  if (captured_signals?.add(u), active_reaction !== null && !untracking) {
    var p = active_effect !== null && (active_effect.f & DESTROYED) !== 0;
    if (!p && !current_sources?.includes(u)) {
      var m = active_reaction.deps;
      if ((active_reaction.f & REACTION_IS_UPDATING) !== 0)
        u.rv < read_version && (u.rv = read_version, new_deps === null && m !== null && m[skipped_deps] === u ? skipped_deps++ : new_deps === null ? new_deps = [u] : (!skip_reaction || !new_deps.includes(u)) && new_deps.push(u));
      else {
        (active_reaction.deps ??= []).push(u);
        var b = u.reactions;
        b === null ? u.reactions = [active_reaction] : b.includes(active_reaction) || b.push(active_reaction);
      }
    }
  } else if (f && /** @type {Derived} */
  u.deps === null && /** @type {Derived} */
  u.effects === null) {
    var y = (
      /** @type {Derived} */
      u
    ), v = y.parent;
    v !== null && (v.f & UNOWNED) === 0 && (y.f ^= UNOWNED);
  }
  if (is_destroying_effect) {
    if (old_values.has(u))
      return old_values.get(u);
    if (f) {
      y = /** @type {Derived} */
      u;
      var $ = y.v;
      return ((y.f & CLEAN) === 0 && y.reactions !== null || depends_on_old_values(y)) && ($ = execute_derived(y)), old_values.set(y, $), $;
    }
  } else if (f) {
    if (y = /** @type {Derived} */
    u, batch_values?.has(y))
      return batch_values.get(y);
    is_dirty(y) && update_derived(y);
  }
  if (batch_values?.has(u))
    return batch_values.get(u);
  if ((u.f & ERROR_VALUE) !== 0)
    throw u.v;
  return u.v;
}
function depends_on_old_values(u) {
  if (u.v === UNINITIALIZED) return !0;
  if (u.deps === null) return !1;
  for (const l of u.deps)
    if (old_values.has(l) || (l.f & DERIVED) !== 0 && depends_on_old_values(
      /** @type {Derived} */
      l
    ))
      return !0;
  return !1;
}
function safe_get(u) {
  return u && get$2(u);
}
function untrack(u) {
  var l = untracking;
  try {
    return untracking = !0, u();
  } finally {
    untracking = l;
  }
}
const STATUS_MASK = -7169;
function set_signal_status(u, l) {
  u.f = u.f & STATUS_MASK | l;
}
function exclude_from_object(u, l) {
  var f = {};
  for (var p in u)
    l.includes(p) || (f[p] = u[p]);
  return f;
}
function deep_read_state(u) {
  if (!(typeof u != "object" || !u || u instanceof EventTarget)) {
    if (STATE_SYMBOL in u)
      deep_read(u);
    else if (!Array.isArray(u))
      for (let l in u) {
        const f = u[l];
        typeof f == "object" && f && STATE_SYMBOL in f && deep_read(f);
      }
  }
}
function deep_read(u, l = /* @__PURE__ */ new Set()) {
  if (typeof u == "object" && u !== null && // We don't want to traverse DOM elements
  !(u instanceof EventTarget) && !l.has(u)) {
    l.add(u), u instanceof Date && u.getTime();
    for (let p in u)
      try {
        deep_read(u[p], l);
      } catch {
      }
    const f = get_prototype_of(u);
    if (f !== Object.prototype && f !== Array.prototype && f !== Map.prototype && f !== Set.prototype && f !== Date.prototype) {
      const p = get_descriptors(f);
      for (let m in p) {
        const b = p[m].get;
        if (b)
          try {
            b.call(u);
          } catch {
          }
      }
    }
  }
}
const all_registered_events = /* @__PURE__ */ new Set(), root_event_handles = /* @__PURE__ */ new Set();
function replay_events(u) {
  if (!hydrating) return;
  u.removeAttribute("onload"), u.removeAttribute("onerror");
  const l = u.__e;
  l !== void 0 && (u.__e = void 0, queueMicrotask(() => {
    u.isConnected && u.dispatchEvent(l);
  }));
}
function create_event(u, l, f, p = {}) {
  function m(b) {
    if (p.capture || handle_event_propagation.call(l, b), !b.cancelBubble)
      return without_reactive_context(() => f?.call(this, b));
  }
  return u.startsWith("pointer") || u.startsWith("touch") || u === "wheel" ? queue_micro_task(() => {
    l.addEventListener(u, m, p);
  }) : l.addEventListener(u, m, p), m;
}
function on$2(u, l, f, p = {}) {
  var m = create_event(l, u, f, p);
  return () => {
    u.removeEventListener(l, m, p);
  };
}
function event(u, l, f, p, m) {
  var b = { capture: p, passive: m }, y = create_event(u, l, f, b);
  (l === document.body || // @ts-ignore
  l === window || // @ts-ignore
  l === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  l instanceof HTMLMediaElement) && teardown(() => {
    l.removeEventListener(u, y, b);
  });
}
function delegate(u) {
  for (var l = 0; l < u.length; l++)
    all_registered_events.add(u[l]);
  for (var f of root_event_handles)
    f(u);
}
let last_propagated_event = null;
function handle_event_propagation(u) {
  var l = this, f = (
    /** @type {Node} */
    l.ownerDocument
  ), p = u.type, m = u.composedPath?.() || [], b = (
    /** @type {null | Element} */
    m[0] || u.target
  );
  last_propagated_event = u;
  var y = 0, v = last_propagated_event === u && u.__root;
  if (v) {
    var $ = m.indexOf(v);
    if ($ !== -1 && (l === document || l === /** @type {any} */
    window)) {
      u.__root = l;
      return;
    }
    var w = m.indexOf(l);
    if (w === -1)
      return;
    $ <= w && (y = $);
  }
  if (b = /** @type {Element} */
  m[y] || u.target, b !== l) {
    define_property(u, "currentTarget", {
      configurable: !0,
      get() {
        return b || f;
      }
    });
    var P = active_reaction, k = active_effect;
    set_active_reaction(null), set_active_effect(null);
    try {
      for (var x, S = []; b !== null; ) {
        var T = b.assignedSlot || b.parentNode || /** @type {any} */
        b.host || null;
        try {
          var M = b["__" + p];
          if (M != null && (!/** @type {any} */
          b.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          u.target === b))
            if (is_array(M)) {
              var [E, ...R] = M;
              E.apply(b, [u, ...R]);
            } else
              M.call(b, u);
        } catch (O) {
          x ? S.push(O) : x = O;
        }
        if (u.cancelBubble || T === l || T === null)
          break;
        b = T;
      }
      if (x) {
        for (let O of S)
          queueMicrotask(() => {
            throw O;
          });
        throw x;
      }
    } finally {
      u.__root = l, delete u.currentTarget, set_active_reaction(P), set_active_effect(k);
    }
  }
}
function apply$1(u, l, f, p, m, b = !1, y = !1) {
  let v, $;
  try {
    v = u();
  } catch (w) {
    $ = w;
  }
  if (typeof v != "function" && (b || v != null || $)) {
    const w = p?.[FILENAME];
    m ? `${w}${m[0]}${m[1]}` : `${w}`;
    const P = f[0]?.eventPhase < Event.BUBBLING_PHASE ? "capture" : "";
    if (f[0]?.type + P, event_handler_invalid(), $)
      throw $;
  }
  v?.apply(l, f);
}
let head_anchor;
function reset_head_anchor() {
  head_anchor = void 0;
}
function head(u) {
  let l = null, f = hydrating;
  var p;
  if (hydrating) {
    for (l = hydrate_node, head_anchor === void 0 && (head_anchor = /** @type {TemplateNode} */
    /* @__PURE__ */ get_first_child(document.head)); head_anchor !== null && (head_anchor.nodeType !== COMMENT_NODE || /** @type {Comment} */
    head_anchor.data !== HYDRATION_START); )
      head_anchor = /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(head_anchor);
    head_anchor === null ? set_hydrating(!1) : head_anchor = set_hydrate_node(
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(head_anchor)
    );
  }
  hydrating || (p = document.head.appendChild(create_text()));
  try {
    block$1(() => u(p), HEAD_EFFECT);
  } finally {
    f && (set_hydrating(!0), head_anchor = hydrate_node, set_hydrate_node(
      /** @type {TemplateNode} */
      l
    ));
  }
}
function create_fragment_from_html(u) {
  var l = document.createElement("template");
  return l.innerHTML = u.replaceAll("<!>", "<!---->"), l.content;
}
function assign_nodes(u, l) {
  var f = (
    /** @type {Effect} */
    active_effect
  );
  f.nodes_start === null && (f.nodes_start = u, f.nodes_end = l);
}
// @__NO_SIDE_EFFECTS__
function from_html(u, l) {
  var f = (l & TEMPLATE_FRAGMENT) !== 0, p = (l & TEMPLATE_USE_IMPORT_NODE) !== 0, m, b = !u.startsWith("<!>");
  return () => {
    if (hydrating)
      return assign_nodes(hydrate_node, null), hydrate_node;
    m === void 0 && (m = create_fragment_from_html(b ? u : "<!>" + u), f || (m = /** @type {Node} */
    /* @__PURE__ */ get_first_child(m)));
    var y = (
      /** @type {TemplateNode} */
      p || is_firefox ? document.importNode(m, !0) : m.cloneNode(!0)
    );
    if (f) {
      var v = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(y)
      ), $ = (
        /** @type {TemplateNode} */
        y.lastChild
      );
      assign_nodes(v, $);
    } else
      assign_nodes(y, y);
    return y;
  };
}
// @__NO_SIDE_EFFECTS__
function from_namespace(u, l, f = "svg") {
  var p = !u.startsWith("<!>"), m = (l & TEMPLATE_FRAGMENT) !== 0, b = `<${f}>${p ? u : "<!>" + u}</${f}>`, y;
  return () => {
    if (hydrating)
      return assign_nodes(hydrate_node, null), hydrate_node;
    if (!y) {
      var v = (
        /** @type {DocumentFragment} */
        create_fragment_from_html(b)
      ), $ = (
        /** @type {Element} */
        /* @__PURE__ */ get_first_child(v)
      );
      if (m)
        for (y = document.createDocumentFragment(); /* @__PURE__ */ get_first_child($); )
          y.appendChild(
            /** @type {Node} */
            /* @__PURE__ */ get_first_child($)
          );
      else
        y = /** @type {Element} */
        /* @__PURE__ */ get_first_child($);
    }
    var w = (
      /** @type {TemplateNode} */
      y.cloneNode(!0)
    );
    if (m) {
      var P = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(w)
      ), k = (
        /** @type {TemplateNode} */
        w.lastChild
      );
      assign_nodes(P, k);
    } else
      assign_nodes(w, w);
    return w;
  };
}
// @__NO_SIDE_EFFECTS__
function from_svg(u, l) {
  return /* @__PURE__ */ from_namespace(u, l, "svg");
}
// @__NO_SIDE_EFFECTS__
function from_mathml(u, l) {
  return /* @__PURE__ */ from_namespace(u, l, "math");
}
function fragment_from_tree(u, l) {
  var f = create_fragment();
  for (var p of u) {
    if (typeof p == "string") {
      f.append(create_text(p));
      continue;
    }
    if (p === void 0 || p[0][0] === "/") {
      f.append(create_comment(p ? p[0].slice(3) : ""));
      continue;
    }
    const [v, $, ...w] = p, P = v === "svg" ? NAMESPACE_SVG : v === "math" ? NAMESPACE_MATHML : l;
    var m = create_element(v, P, $?.is);
    for (var b in $)
      set_attribute$1(m, b, $[b]);
    if (w.length > 0) {
      var y = m.tagName === "TEMPLATE" ? (
        /** @type {HTMLTemplateElement} */
        m.content
      ) : m;
      y.append(
        fragment_from_tree(w, m.tagName === "foreignObject" ? void 0 : P)
      );
    }
    f.append(m);
  }
  return f;
}
// @__NO_SIDE_EFFECTS__
function from_tree(u, l) {
  var f = (l & TEMPLATE_FRAGMENT) !== 0, p = (l & TEMPLATE_USE_IMPORT_NODE) !== 0, m;
  return () => {
    if (hydrating)
      return assign_nodes(hydrate_node, null), hydrate_node;
    if (m === void 0) {
      const $ = (l & TEMPLATE_USE_SVG) !== 0 ? NAMESPACE_SVG : (l & TEMPLATE_USE_MATHML) !== 0 ? NAMESPACE_MATHML : void 0;
      m = fragment_from_tree(u, $), f || (m = /** @type {Node} */
      /* @__PURE__ */ get_first_child(m));
    }
    var b = (
      /** @type {TemplateNode} */
      p || is_firefox ? document.importNode(m, !0) : m.cloneNode(!0)
    );
    if (f) {
      var y = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(b)
      ), v = (
        /** @type {TemplateNode} */
        b.lastChild
      );
      assign_nodes(y, v);
    } else
      assign_nodes(b, b);
    return b;
  };
}
function with_script(u) {
  return () => run_scripts(u());
}
function run_scripts(u) {
  if (hydrating) return u;
  const l = u.nodeType === DOCUMENT_FRAGMENT_NODE, f = (
    /** @type {HTMLElement} */
    u.tagName === "SCRIPT" ? [
      /** @type {HTMLScriptElement} */
      u
    ] : u.querySelectorAll("script")
  ), p = (
    /** @type {Effect} */
    active_effect
  );
  for (const b of f) {
    const y = document.createElement("script");
    for (var m of b.attributes)
      y.setAttribute(m.name, m.value);
    y.textContent = b.textContent, (l ? u.firstChild === b : u === b) && (p.nodes_start = y), (l ? u.lastChild === b : u === b) && (p.nodes_end = y), b.replaceWith(y);
  }
  return u;
}
function text$4(u = "") {
  if (!hydrating) {
    var l = create_text(u + "");
    return assign_nodes(l, l), l;
  }
  var f = hydrate_node;
  return f.nodeType !== TEXT_NODE && (f.before(f = create_text()), set_hydrate_node(f)), assign_nodes(f, f), f;
}
function comment$2() {
  if (hydrating)
    return assign_nodes(hydrate_node, null), hydrate_node;
  var u = document.createDocumentFragment(), l = document.createComment(""), f = create_text();
  return u.append(l, f), assign_nodes(l, f), u;
}
function append$2(u, l) {
  if (hydrating) {
    active_effect.nodes_end = hydrate_node, hydrate_next();
    return;
  }
  u !== null && u.before(
    /** @type {Node} */
    l
  );
}
function props_id() {
  if (hydrating && hydrate_node && hydrate_node.nodeType === COMMENT_NODE && hydrate_node.textContent?.startsWith("$")) {
    const u = hydrate_node.textContent.substring(1);
    return hydrate_next(), u;
  }
  return (window.__svelte ??= {}).uid ??= 1, `c${window.__svelte.uid++}`;
}
const VOID_ELEMENT_NAMES = [
  "area",
  "base",
  "br",
  "col",
  "command",
  "embed",
  "hr",
  "img",
  "input",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
];
function is_void$1(u) {
  return VOID_ELEMENT_NAMES.includes(u) || u.toLowerCase() === "!doctype";
}
function is_capture_event(u) {
  return u.endsWith("capture") && u !== "gotpointercapture" && u !== "lostpointercapture";
}
const DELEGATED_EVENTS = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function is_delegated(u) {
  return DELEGATED_EVENTS.includes(u);
}
const ATTRIBUTE_ALIASES = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function normalize_attribute(u) {
  return u = u.toLowerCase(), ATTRIBUTE_ALIASES[u] ?? u;
}
const PASSIVE_EVENTS = ["touchstart", "touchmove"];
function is_passive_event(u) {
  return PASSIVE_EVENTS.includes(u);
}
const RAW_TEXT_ELEMENTS = (
  /** @type {const} */
  ["textarea", "script", "style", "title"]
);
function is_raw_text_element(u) {
  return RAW_TEXT_ELEMENTS.includes(
    /** @type {typeof RAW_TEXT_ELEMENTS[number]} */
    u
  );
}
function sanitize_location(u) {
  return (
    /** @type {T} */
    u?.replace(/\//g, "/​")
  );
}
let should_intro = !0;
function set_should_intro(u) {
  should_intro = u;
}
function set_text(u, l) {
  var f = l == null ? "" : typeof l == "object" ? l + "" : l;
  f !== (u.__t ??= u.nodeValue) && (u.__t = f, u.nodeValue = f + "");
}
function mount(u, l) {
  return _mount(u, l);
}
function hydrate(u, l) {
  init_operations(), l.intro = l.intro ?? !1;
  const f = l.target, p = hydrating, m = hydrate_node;
  try {
    for (var b = (
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_first_child(f)
    ); b && (b.nodeType !== COMMENT_NODE || /** @type {Comment} */
    b.data !== HYDRATION_START); )
      b = /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(b);
    if (!b)
      throw HYDRATION_ERROR;
    set_hydrating(!0), set_hydrate_node(
      /** @type {Comment} */
      b
    );
    const y = _mount(u, { ...l, anchor: b });
    return set_hydrating(!1), /**  @type {Exports} */
    y;
  } catch (y) {
    if (y instanceof Error && y.message.split(`
`).some((v) => v.startsWith("https://svelte.dev/e/")))
      throw y;
    return y !== HYDRATION_ERROR && console.warn("Failed to hydrate: ", y), l.recover === !1 && hydration_failed(), init_operations(), clear_text_content(f), set_hydrating(!1), mount(u, l);
  } finally {
    set_hydrating(p), set_hydrate_node(m), reset_head_anchor();
  }
}
const document_listeners = /* @__PURE__ */ new Map();
function _mount(u, { target: l, anchor: f, props: p = {}, events: m, context: b, intro: y = !0 }) {
  init_operations();
  var v = /* @__PURE__ */ new Set(), $ = (k) => {
    for (var x = 0; x < k.length; x++) {
      var S = k[x];
      if (!v.has(S)) {
        v.add(S);
        var T = is_passive_event(S);
        l.addEventListener(S, handle_event_propagation, { passive: T });
        var M = document_listeners.get(S);
        M === void 0 ? (document.addEventListener(S, handle_event_propagation, { passive: T }), document_listeners.set(S, 1)) : document_listeners.set(S, M + 1);
      }
    }
  };
  $(array_from(all_registered_events)), root_event_handles.add($);
  var w = void 0, P = component_root(() => {
    var k = f ?? l.appendChild(create_text());
    return boundary(
      /** @type {TemplateNode} */
      k,
      {
        pending: () => {
        }
      },
      (x) => {
        if (b) {
          push$2({});
          var S = (
            /** @type {ComponentContext} */
            component_context
          );
          S.c = b;
        }
        if (m && (p.$$events = m), hydrating && assign_nodes(
          /** @type {TemplateNode} */
          x,
          null
        ), should_intro = y, w = u(x, p) || {}, should_intro = !0, hydrating && (active_effect.nodes_end = hydrate_node, hydrate_node === null || hydrate_node.nodeType !== COMMENT_NODE || /** @type {Comment} */
        hydrate_node.data !== HYDRATION_END))
          throw hydration_mismatch(), HYDRATION_ERROR;
        b && pop();
      }
    ), () => {
      for (var x of v) {
        l.removeEventListener(x, handle_event_propagation);
        var S = (
          /** @type {number} */
          document_listeners.get(x)
        );
        --S === 0 ? (document.removeEventListener(x, handle_event_propagation), document_listeners.delete(x)) : document_listeners.set(x, S);
      }
      root_event_handles.delete($), k !== f && k.parentNode?.removeChild(k);
    };
  });
  return mounted_components.set(w, P), w;
}
let mounted_components = /* @__PURE__ */ new WeakMap();
function unmount(u, l) {
  const f = mounted_components.get(u);
  return f ? (mounted_components.delete(u), f(l)) : Promise.resolve();
}
function validate_void_dynamic_element$1(u) {
  const l = u();
  l && is_void$1(l) && dynamic_void_element_content();
}
function validate_dynamic_element_tag(u) {
  const l = u();
  l && !(typeof l == "string") && svelte_element_invalid_this_value();
}
function validate_store$1(u, l) {
  u != null && typeof u.subscribe != "function" && store_invalid_shape();
}
function prevent_snippet_stringification(u) {
  return u.toString = () => (snippet_without_render_tag(), ""), u;
}
function snippet(u, l, ...f) {
  var p = u, m = noop$4, b;
  block$1(() => {
    m !== (m = l()) && (b && (destroy_effect(b), b = null), b = branch(() => (
      /** @type {SnippetFn} */
      m(p, ...f)
    )));
  }, EFFECT_TRANSPARENT), hydrating && (p = hydrate_node);
}
function wrap_snippet(u, l) {
  const f = (p, ...m) => {
    var b = dev_current_component_function;
    set_dev_current_component_function(u);
    try {
      return l(p, ...m);
    } finally {
      set_dev_current_component_function(b);
    }
  };
  return prevent_snippet_stringification(f), f;
}
function createRawSnippet(u) {
  return (l, ...f) => {
    var p = u(...f), m;
    if (hydrating)
      m = /** @type {Element} */
      hydrate_node, hydrate_next();
    else {
      var b = p.render().trim(), y = create_fragment_from_html(b);
      m = /** @type {Element} */
      /* @__PURE__ */ get_first_child(y), l.before(m);
    }
    const v = p.setup?.(m);
    assign_nodes(m, m), typeof v == "function" && teardown(v);
  };
}
function getAbortSignal() {
  return active_reaction === null && get_abort_signal_outside_reaction(), (active_reaction.ac ??= new AbortController()).signal;
}
function onMount$1(u) {
  component_context === null && lifecycle_outside_component(), legacy_mode_flag && component_context.l !== null ? init_update_callbacks(component_context).m.push(u) : user_effect(() => {
    const l = untrack(u);
    if (typeof l == "function") return (
      /** @type {() => void} */
      l
    );
  });
}
function onDestroy$1(u) {
  component_context === null && lifecycle_outside_component(), onMount$1(() => () => untrack(u));
}
function create_custom_event(u, l, { bubbles: f = !1, cancelable: p = !1 } = {}) {
  return new CustomEvent(u, { detail: l, bubbles: f, cancelable: p });
}
function createEventDispatcher$1() {
  const u = component_context;
  return u === null && lifecycle_outside_component(), (l, f, p) => {
    const m = (
      /** @type {Record<string, Function | Function[]>} */
      u.s.$$events?.[
        /** @type {string} */
        l
      ]
    );
    if (m) {
      const b = is_array(m) ? m.slice() : [m], y = create_custom_event(
        /** @type {string} */
        l,
        f,
        p
      );
      for (const v of b)
        v.call(u.x, y);
      return !y.defaultPrevented;
    }
    return !0;
  };
}
function beforeUpdate$1(u) {
  component_context === null && lifecycle_outside_component(), component_context.l === null && lifecycle_legacy_only(), init_update_callbacks(component_context).b.push(u);
}
function afterUpdate$1(u) {
  component_context === null && lifecycle_outside_component(), component_context.l === null && lifecycle_legacy_only(), init_update_callbacks(component_context).a.push(u);
}
function init_update_callbacks(u) {
  var l = (
    /** @type {ComponentContextLegacy} */
    u.l
  );
  return l.u ??= { a: [], b: [], m: [] };
}
const svelte = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  afterUpdate: afterUpdate$1,
  beforeUpdate: beforeUpdate$1,
  createContext: createContext$1,
  createEventDispatcher: createEventDispatcher$1,
  createRawSnippet,
  flushSync,
  getAbortSignal,
  getAllContexts: getAllContexts$1,
  getContext: getContext$2,
  hasContext: hasContext$1,
  hydrate,
  mount,
  onDestroy: onDestroy$1,
  onMount: onMount$1,
  setContext: setContext$1,
  settled,
  tick: tick$1,
  unmount,
  untrack
}, Symbol.toStringTag, { value: "Module" }));
function createAttachmentKey() {
  return Symbol(ATTACHMENT_KEY);
}
function compare$1(u, l, f, p) {
  return u !== l && assignment_value_stale(
    f,
    /** @type {string} */
    sanitize_location(p)
  ), u;
}
function assign$2(u, l, f, p) {
  return compare$1(
    u[l] = f,
    untrack(() => u[l]),
    l,
    p
  );
}
function assign_and(u, l, f, p) {
  return compare$1(
    u[l] &&= f,
    untrack(() => u[l]),
    l,
    p
  );
}
function assign_or(u, l, f, p) {
  return compare$1(
    u[l] ||= f,
    untrack(() => u[l]),
    l,
    p
  );
}
function assign_nullish(u, l, f, p) {
  return compare$1(
    u[l] ??= f,
    untrack(() => u[l]),
    l,
    p
  );
}
var all_styles = /* @__PURE__ */ new Map();
function cleanup_styles(u) {
  var l = all_styles.get(u);
  if (l) {
    for (const f of l)
      f.remove();
    all_styles.delete(u);
  }
}
function add_locations(u, l, f) {
  return (...p) => {
    const m = u(...p);
    var b = hydrating ? m : m.nodeType === DOCUMENT_FRAGMENT_NODE ? m.firstChild : m;
    return assign_locations(b, l, f), m;
  };
}
function assign_location(u, l, f) {
  u.__svelte_meta = {
    parent: dev_stack,
    loc: { file: l, line: f[0], column: f[1] }
  }, f[2] && assign_locations(u.firstChild, l, f[2]);
}
function assign_locations(u, l, f) {
  for (var p = 0, m = 0; u && p < f.length; ) {
    if (hydrating && u.nodeType === COMMENT_NODE) {
      var b = (
        /** @type {Comment} */
        u
      );
      b.data === HYDRATION_START || b.data === HYDRATION_START_ELSE ? m += 1 : b.data[0] === HYDRATION_END && (m -= 1);
    }
    m === 0 && u.nodeType === ELEMENT_NODE && assign_location(
      /** @type {Element} */
      u,
      l,
      f[p++]
    ), u = u.nextSibling;
  }
}
function hmr(u, l) {
  function f(p, m) {
    let b = {}, y, v = !1;
    return block$1(() => {
      const $ = l(), w = get$2($);
      if (y) {
        for (var P in b) delete b[P];
        destroy_effect(y);
      }
      y = branch(() => {
        v && set_should_intro(!1), Object.defineProperties(
          b,
          Object.getOwnPropertyDescriptors(
            // @ts-expect-error
            new.target ? new w(p, m) : w(p, m)
          )
        ), v && set_should_intro(!0);
      });
    }, EFFECT_TRANSPARENT), v = !0, hydrating && (p = hydrate_node), b;
  }
  return f[FILENAME] = u[FILENAME], f[HMR] = {
    // When we accept an update, we set the original source to the new component
    original: u,
    // The `get_source` parameter reads `wrapper[HMR].source`, but in the `accept`
    // function we always replace it with `previous[HMR].source`, which in practice
    // means we only ever update the original
    source: source(u)
  }, f;
}
function create_ownership_validator(u) {
  const l = component_context?.function, f = component_context?.p?.function;
  return {
    /**
     * @param {string} prop
     * @param {any[]} path
     * @param {any} result
     * @param {number} line
     * @param {number} column
     */
    mutation: (p, m, b, y, v) => {
      const $ = m[0];
      if (is_bound_or_unset(u, $) || !f)
        return b;
      let w = u;
      for (let k = 0; k < m.length - 1; k++)
        if (w = w[m[k]], !w?.[STATE_SYMBOL])
          return b;
      const P = sanitize_location(`${l[FILENAME]}:${y}:${v}`);
      return ownership_invalid_mutation($, P, p, f[FILENAME]), b;
    },
    /**
     * @param {any} key
     * @param {any} child_component
     * @param {() => any} value
     */
    binding: (p, m, b) => {
      !is_bound_or_unset(u, p) && f && b()?.[STATE_SYMBOL] && ownership_invalid_binding(
        l[FILENAME],
        p,
        m[FILENAME],
        f[FILENAME]
      );
    }
  };
}
function is_bound_or_unset(u, l) {
  const f = STATE_SYMBOL in u || LEGACY_PROPS in u;
  return !!get_descriptor(u, l)?.set || f && l in u || !(l in u);
}
function check_target(u) {
  u && component_api_invalid_new(u[FILENAME] ?? "a component", u.name);
}
function legacy_api() {
  const u = component_context?.function;
  function l(f) {
    component_api_changed(f, u[FILENAME]);
  }
  return {
    $destroy: () => l("$destroy()"),
    $on: () => l("$on(...)"),
    $set: () => l("$set(...)")
  };
}
function inspect$1(u, l = console.log) {
  validate_effect();
  let f = !0, p = (
    /** @type {any} */
    UNINITIALIZED
  );
  inspect_effect(() => {
    try {
      var m = u();
    } catch (y) {
      p = y;
      return;
    }
    var b = snapshot(m, !0, !0);
    untrack(() => {
      l(f ? "init" : "update", ...b);
    }), f = !1;
  }), render_effect(() => {
    try {
      u();
    } catch {
    }
    p !== UNINITIALIZED && (console.error(p), p = UNINITIALIZED);
  });
}
function async(u, l, f) {
  var p = get_boundary();
  p.update_pending_count(1);
  var m = hydrating;
  if (m) {
    hydrate_next();
    var b = hydrate_node, y = skip_nodes(!1);
    set_hydrate_node(y);
  }
  flatten$1([], l, (v) => {
    m && (set_hydrating(!0), set_hydrate_node(b));
    try {
      for (const $ of v) get$2($);
      f(u, ...v);
    } finally {
      p.update_pending_count(-1);
    }
    m && set_hydrating(!1);
  });
}
function validate_snippet_args(u, ...l) {
  (typeof u != "object" || !(u instanceof Node)) && invalid_snippet_arguments();
  for (let f of l)
    typeof f != "function" && invalid_snippet_arguments();
}
const PENDING = 0, THEN = 1, CATCH = 2;
function await_block(u, l, f, p, m) {
  hydrating && hydrate_next();
  var b = u, y = is_runes(), v = component_context, $ = UNINITIALIZED, w, P, k, x = y ? source(
    /** @type {V} */
    void 0
  ) : /* @__PURE__ */ mutable_source(
    /** @type {V} */
    void 0,
    !1,
    !1
  ), S = y ? source(void 0) : /* @__PURE__ */ mutable_source(void 0, !1, !1), T = !1;
  function M(R, O) {
    T = !0, O && (set_active_effect(E), set_active_reaction(E), set_component_context(v));
    try {
      R === PENDING && f && (w ? resume_effect(w) : w = branch(() => f(b))), R === THEN && p && (P ? resume_effect(P) : P = branch(() => p(b, x))), R === CATCH && m && (k ? resume_effect(k) : k = branch(() => m(b, S))), R !== PENDING && w && pause_effect(w, () => w = null), R !== THEN && P && pause_effect(P, () => P = null), R !== CATCH && k && pause_effect(k, () => k = null);
    } finally {
      O && (set_component_context(null), set_active_reaction(null), set_active_effect(null), is_flushing_sync || flushSync());
    }
  }
  var E = block$1(() => {
    if ($ === ($ = l())) return;
    let R = hydrating && is_promise$1($) === (b.data === HYDRATION_START_ELSE);
    if (R && (b = skip_nodes(), set_hydrate_node(b), set_hydrating(!1), R = !0), is_promise$1($)) {
      var O = $;
      T = !1, O.then(
        (D) => {
          O === $ && (internal_set(x, D), M(THEN, !0));
        },
        (D) => {
          if (O === $ && (internal_set(S, D), M(CATCH, !0), !m))
            throw S.v;
        }
      ), hydrating ? f && (w = branch(() => f(b))) : queue_micro_task(() => {
        T || M(PENDING, !0);
      });
    } else
      internal_set(x, $), M(THEN, !1);
    return R && set_hydrating(!0), () => $ = UNINITIALIZED;
  });
  hydrating && (b = hydrate_node);
}
function if_block(u, l, f = !1) {
  hydrating && hydrate_next();
  var p = u, m = null, b = null, y = UNINITIALIZED, v = f ? EFFECT_TRANSPARENT : 0, $ = !1;
  const w = (S, T = !0) => {
    $ = !0, x(T, S);
  };
  var P = null;
  function k() {
    P !== null && (P.lastChild.remove(), p.before(P), P = null);
    var S = y ? m : b, T = y ? b : m;
    S && resume_effect(S), T && pause_effect(T, () => {
      y ? b = null : m = null;
    });
  }
  const x = (S, T) => {
    if (y === (y = S)) return;
    let M = !1;
    if (hydrating) {
      const F = read_hydration_instruction(p) === HYDRATION_START_ELSE;
      !!y === F && (p = skip_nodes(), set_hydrate_node(p), set_hydrating(!1), M = !0);
    }
    var E = should_defer_append(), R = p;
    if (E && (P = document.createDocumentFragment(), P.append(R = create_text())), y ? m ??= T && branch(() => T(R)) : b ??= T && branch(() => T(R)), E) {
      var O = (
        /** @type {Batch} */
        current_batch
      ), D = y ? m : b, q = y ? b : m;
      D && O.skipped_effects.delete(D), q && O.skipped_effects.add(q), O.add_callback(k);
    } else
      k();
    M && set_hydrating(!0);
  };
  block$1(() => {
    $ = !1, l(w), $ || x(null, null);
  }, v), hydrating && (p = hydrate_node);
}
function key(u, l, f) {
  hydrating && hydrate_next();
  var p = u, m = UNINITIALIZED, b, y, v = null, $ = is_runes() ? not_equal$1 : safe_not_equal$1;
  function w() {
    b && pause_effect(b), v !== null && (v.lastChild.remove(), p.before(v), v = null), b = y;
  }
  block$1(() => {
    if ($(m, m = l())) {
      var P = p, k = should_defer_append();
      k && (v = document.createDocumentFragment(), v.append(P = create_text())), y = branch(() => f(P)), k ? current_batch.add_callback(w) : w();
    }
  }), hydrating && (p = hydrate_node);
}
function css_props(u, l) {
  hydrating && set_hydrate_node(
    /** @type {TemplateNode} */
    /* @__PURE__ */ get_first_child(u)
  ), render_effect(() => {
    var f = l();
    for (var p in f) {
      var m = f[p];
      m ? u.style.setProperty(p, m) : u.style.removeProperty(p);
    }
  });
}
let current_each_item = null;
function set_current_each_item(u) {
  current_each_item = u;
}
function index(u, l) {
  return l;
}
function pause_effects(u, l, f) {
  for (var p = u.items, m = [], b = l.length, y = 0; y < b; y++)
    pause_children(l[y].e, m, !0);
  var v = b > 0 && m.length === 0 && f !== null;
  if (v) {
    var $ = (
      /** @type {Element} */
      /** @type {Element} */
      f.parentNode
    );
    clear_text_content($), $.append(
      /** @type {Element} */
      f
    ), p.clear(), link$3(u, l[0].prev, l[b - 1].next);
  }
  run_out_transitions(m, () => {
    for (var w = 0; w < b; w++) {
      var P = l[w];
      v || (p.delete(P.k), link$3(u, P.prev, P.next)), destroy_effect(P.e, !v);
    }
  });
}
function each$2(u, l, f, p, m, b = null) {
  var y = u, v = { flags: l, items: /* @__PURE__ */ new Map(), first: null }, $ = (l & EACH_IS_CONTROLLED) !== 0;
  if ($) {
    var w = (
      /** @type {Element} */
      u
    );
    y = hydrating ? set_hydrate_node(
      /** @type {Comment | Text} */
      /* @__PURE__ */ get_first_child(w)
    ) : w.appendChild(create_text());
  }
  hydrating && hydrate_next();
  var P = null, k = !1, x = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ derived_safe_equal(() => {
    var R = f();
    return is_array(R) ? R : R == null ? [] : array_from(R);
  }), T, M;
  function E() {
    reconcile(
      M,
      T,
      v,
      x,
      y,
      m,
      l,
      p,
      f
    ), b !== null && (T.length === 0 ? P ? resume_effect(P) : P = branch(() => b(y)) : P !== null && pause_effect(P, () => {
      P = null;
    }));
  }
  block$1(() => {
    M ??= /** @type {Effect} */
    active_effect, T = /** @type {V[]} */
    get$2(S);
    var R = T.length;
    if (k && R === 0)
      return;
    k = R === 0;
    let O = !1;
    if (hydrating) {
      var D = read_hydration_instruction(y) === HYDRATION_START_ELSE;
      D !== (R === 0) && (y = skip_nodes(), set_hydrate_node(y), set_hydrating(!1), O = !0);
    }
    if (hydrating) {
      for (var q = null, F, L = 0; L < R; L++) {
        if (hydrate_node.nodeType === COMMENT_NODE && /** @type {Comment} */
        hydrate_node.data === HYDRATION_END) {
          y = /** @type {Comment} */
          hydrate_node, O = !0, set_hydrating(!1);
          break;
        }
        var N = T[L], z = p(N, L);
        F = create_item(
          hydrate_node,
          v,
          q,
          null,
          N,
          z,
          L,
          m,
          l,
          f
        ), v.items.set(z, F), q = F;
      }
      R > 0 && set_hydrate_node(skip_nodes());
    }
    if (hydrating)
      R === 0 && b && (P = branch(() => b(y)));
    else if (should_defer_append()) {
      var V = /* @__PURE__ */ new Set(), W = (
        /** @type {Batch} */
        current_batch
      );
      for (L = 0; L < R; L += 1) {
        N = T[L], z = p(N, L);
        var j = v.items.get(z) ?? x.get(z);
        j ? (l & (EACH_ITEM_REACTIVE | EACH_INDEX_REACTIVE)) !== 0 && update_item(j, N, L, l) : (F = create_item(
          null,
          v,
          null,
          null,
          N,
          z,
          L,
          m,
          l,
          f,
          !0
        ), x.set(z, F)), V.add(z);
      }
      for (const [U, Z] of v.items)
        V.has(U) || W.skipped_effects.add(Z.e);
      W.add_callback(E);
    } else
      E();
    O && set_hydrating(!0), get$2(S);
  }), hydrating && (y = hydrate_node);
}
function reconcile(u, l, f, p, m, b, y, v, $) {
  var w = (y & EACH_IS_ANIMATED) !== 0, P = (y & (EACH_ITEM_REACTIVE | EACH_INDEX_REACTIVE)) !== 0, k = l.length, x = f.items, S = f.first, T = S, M, E = null, R, O = [], D = [], q, F, L, N;
  if (w)
    for (N = 0; N < k; N += 1)
      q = l[N], F = v(q, N), L = x.get(F), L !== void 0 && (L.a?.measure(), (R ??= /* @__PURE__ */ new Set()).add(L));
  for (N = 0; N < k; N += 1) {
    if (q = l[N], F = v(q, N), L = x.get(F), L === void 0) {
      var z = p.get(F);
      if (z !== void 0) {
        p.delete(F), x.set(F, z);
        var V = E ? E.next : T;
        link$3(f, E, z), link$3(f, z, V), move(z, V, m), E = z;
      } else {
        var W = T ? (
          /** @type {TemplateNode} */
          T.e.nodes_start
        ) : m;
        E = create_item(
          W,
          f,
          E,
          E === null ? f.first : E.next,
          q,
          F,
          N,
          b,
          y,
          $
        );
      }
      x.set(F, E), O = [], D = [], T = E.next;
      continue;
    }
    if (P && update_item(L, q, N, y), (L.e.f & INERT) !== 0 && (resume_effect(L.e), w && (L.a?.unfix(), (R ??= /* @__PURE__ */ new Set()).delete(L))), L !== T) {
      if (M !== void 0 && M.has(L)) {
        if (O.length < D.length) {
          var j = D[0], U;
          E = j.prev;
          var Z = O[0], X = O[O.length - 1];
          for (U = 0; U < O.length; U += 1)
            move(O[U], j, m);
          for (U = 0; U < D.length; U += 1)
            M.delete(D[U]);
          link$3(f, Z.prev, X.next), link$3(f, E, Z), link$3(f, X, j), T = j, E = X, N -= 1, O = [], D = [];
        } else
          M.delete(L), move(L, T, m), link$3(f, L.prev, L.next), link$3(f, L, E === null ? f.first : E.next), link$3(f, E, L), E = L;
        continue;
      }
      for (O = [], D = []; T !== null && T.k !== F; )
        (T.e.f & INERT) === 0 && (M ??= /* @__PURE__ */ new Set()).add(T), D.push(T), T = T.next;
      if (T === null)
        continue;
      L = T;
    }
    O.push(L), E = L, T = L.next;
  }
  if (T !== null || M !== void 0) {
    for (var B = M === void 0 ? [] : array_from(M); T !== null; )
      (T.e.f & INERT) === 0 && B.push(T), T = T.next;
    var H = B.length;
    if (H > 0) {
      var Y = (y & EACH_IS_CONTROLLED) !== 0 && k === 0 ? m : null;
      if (w) {
        for (N = 0; N < H; N += 1)
          B[N].a?.measure();
        for (N = 0; N < H; N += 1)
          B[N].a?.fix();
      }
      pause_effects(f, B, Y);
    }
  }
  w && queue_micro_task(() => {
    if (R !== void 0)
      for (L of R)
        L.a?.apply();
  }), u.first = f.first && f.first.e, u.last = E && E.e;
  for (var K of p.values())
    destroy_effect(K.e);
  p.clear();
}
function update_item(u, l, f, p) {
  (p & EACH_ITEM_REACTIVE) !== 0 && internal_set(u.v, l), (p & EACH_INDEX_REACTIVE) !== 0 ? internal_set(
    /** @type {Value<number>} */
    u.i,
    f
  ) : u.i = f;
}
function create_item(u, l, f, p, m, b, y, v, $, w, P) {
  var k = current_each_item, x = ($ & EACH_ITEM_REACTIVE) !== 0, S = ($ & EACH_ITEM_IMMUTABLE) === 0, T = x ? S ? /* @__PURE__ */ mutable_source(m, !1, !1) : source(m) : m, M = ($ & EACH_INDEX_REACTIVE) === 0 ? y : source(y), E = {
    i: M,
    v: T,
    k: b,
    a: null,
    // @ts-expect-error
    e: null,
    prev: f,
    next: p
  };
  current_each_item = E;
  try {
    if (u === null) {
      var R = document.createDocumentFragment();
      R.append(u = create_text());
    }
    return E.e = branch(() => v(
      /** @type {Node} */
      u,
      T,
      M,
      w
    ), hydrating), E.e.prev = f && f.e, E.e.next = p && p.e, f === null ? P || (l.first = E) : (f.next = E, f.e.next = E.e), p !== null && (p.prev = E, p.e.prev = E.e), E;
  } finally {
    current_each_item = k;
  }
}
function move(u, l, f) {
  for (var p = u.next ? (
    /** @type {TemplateNode} */
    u.next.e.nodes_start
  ) : f, m = l ? (
    /** @type {TemplateNode} */
    l.e.nodes_start
  ) : f, b = (
    /** @type {TemplateNode} */
    u.e.nodes_start
  ); b !== null && b !== p; ) {
    var y = (
      /** @type {TemplateNode} */
      /* @__PURE__ */ get_next_sibling(b)
    );
    m.before(b), b = y;
  }
}
function link$3(u, l, f) {
  l === null ? u.first = f : (l.next = f, l.e.next = f && f.e), f !== null && (f.prev = l, f.e.prev = l && l.e);
}
function html(u, l, f = !1, p = !1, m = !1) {
  var b = u, y = "";
  template_effect(() => {
    var v = (
      /** @type {Effect} */
      active_effect
    );
    if (y === (y = l() ?? "")) {
      hydrating && hydrate_next();
      return;
    }
    if (v.nodes_start !== null && (remove_effect_dom(
      v.nodes_start,
      /** @type {TemplateNode} */
      v.nodes_end
    ), v.nodes_start = v.nodes_end = null), y !== "") {
      if (hydrating) {
        hydrate_node.data;
        for (var $ = hydrate_next(), w = $; $ !== null && ($.nodeType !== COMMENT_NODE || /** @type {Comment} */
        $.data !== ""); )
          w = $, $ = /** @type {TemplateNode} */
          /* @__PURE__ */ get_next_sibling($);
        if ($ === null)
          throw hydration_mismatch(), HYDRATION_ERROR;
        assign_nodes(hydrate_node, w), b = set_hydrate_node($);
        return;
      }
      var P = y + "";
      f ? P = `<svg>${P}</svg>` : p && (P = `<math>${P}</math>`);
      var k = create_fragment_from_html(P);
      if ((f || p) && (k = /** @type {Element} */
      /* @__PURE__ */ get_first_child(k)), assign_nodes(
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(k),
        /** @type {TemplateNode} */
        k.lastChild
      ), f || p)
        for (; /* @__PURE__ */ get_first_child(k); )
          b.before(
            /** @type {Node} */
            /* @__PURE__ */ get_first_child(k)
          );
      else
        b.before(k);
    }
  });
}
function slot(u, l, f, p, m) {
  hydrating && hydrate_next();
  var b = l.$$slots?.[f], y = !1;
  b === !0 && (b = l[f === "default" ? "children" : f], y = !0), b === void 0 ? m !== null && m(u) : b(u, y ? () => p : p);
}
function sanitize_slots(u) {
  const l = {};
  u.children && (l.default = !0);
  for (const f in u.$$slots)
    l[f] = !0;
  return l;
}
function component(u, l, f) {
  hydrating && hydrate_next();
  var p = u, m, b, y = null, v = null;
  function $() {
    b && (pause_effect(b), b = null), y && (y.lastChild.remove(), p.before(y), y = null), b = v, v = null;
  }
  block$1(() => {
    if (m !== (m = l())) {
      var w = should_defer_append();
      if (m) {
        var P = p;
        w && (y = document.createDocumentFragment(), y.append(P = create_text()), b && current_batch.skipped_effects.add(b)), v = branch(() => f(P, m));
      }
      w ? current_batch.add_callback($) : $();
    }
  }, EFFECT_TRANSPARENT), hydrating && (p = hydrate_node);
}
function element$1(u, l, f, p, m, b) {
  let y = hydrating;
  hydrating && hydrate_next();
  var v, $, w = null;
  hydrating && hydrate_node.nodeType === ELEMENT_NODE && (w = /** @type {Element} */
  hydrate_node, hydrate_next());
  var P = (
    /** @type {TemplateNode} */
    hydrating ? hydrate_node : u
  ), k, x = current_each_item;
  block$1(() => {
    const S = l() || null;
    var T = m ? m() : f || S === "svg" ? NAMESPACE_SVG : null;
    if (S !== v) {
      var M = current_each_item;
      set_current_each_item(x), k && (S === null ? pause_effect(k, () => {
        k = null, $ = null;
      }) : S === $ ? resume_effect(k) : (destroy_effect(k), set_should_intro(!1))), S && S !== $ && (k = branch(() => {
        if (w = hydrating ? (
          /** @type {Element} */
          w
        ) : T ? document.createElementNS(T, S) : document.createElement(S), assign_nodes(w, w), p) {
          hydrating && is_raw_text_element(S) && w.append(document.createComment(""));
          var E = (
            /** @type {TemplateNode} */
            hydrating ? /* @__PURE__ */ get_first_child(w) : w.appendChild(create_text())
          );
          hydrating && (E === null ? set_hydrating(!1) : set_hydrate_node(E)), p(w, E);
        }
        active_effect.nodes_end = w, P.before(w);
      })), v = S, v && ($ = v), set_should_intro(!0), set_current_each_item(M);
    }
  }, EFFECT_TRANSPARENT), y && (set_hydrating(!0), set_hydrate_node(P));
}
function append_styles$2(u, l) {
  effect(() => {
    var f = u.getRootNode(), p = (
      /** @type {ShadowRoot} */
      f.host ? (
        /** @type {ShadowRoot} */
        f
      ) : (
        /** @type {Document} */
        f.head ?? /** @type {Document} */
        f.ownerDocument.head
      )
    );
    if (!p.querySelector("#" + l.hash)) {
      const m = document.createElement("style");
      m.id = l.hash, m.textContent = l.code, p.appendChild(m);
    }
  });
}
function action(u, l, f) {
  effect(() => {
    var p = untrack(() => l(u, f?.()) || {});
    if (f && p?.update) {
      var m = !1, b = (
        /** @type {any} */
        {}
      );
      render_effect(() => {
        var y = f();
        deep_read_state(y), m && safe_not_equal$1(b, y) && (b = y, p.update(y));
      }), m = !0;
    }
    if (p?.destroy)
      return () => (
        /** @type {Function} */
        p.destroy()
      );
  });
}
function attach(u, l) {
  var f = void 0, p;
  block$1(() => {
    f !== (f = l()) && (p && (destroy_effect(p), p = null), f && (p = branch(() => {
      effect(() => (
        /** @type {(node: Element) => void} */
        f(u)
      ));
    })));
  });
}
const ATTR_REGEX$1 = /[&"<]/g;
function escape_html(u, l) {
  const f = String(u ?? ""), p = ATTR_REGEX$1;
  p.lastIndex = 0;
  let m = "", b = 0;
  for (; p.test(f); ) {
    const y = p.lastIndex - 1, v = f[y];
    m += f.substring(b, y) + (v === "&" ? "&amp;" : v === '"' ? "&quot;" : "&lt;"), b = y + 1;
  }
  return m + f.substring(b);
}
function r$1(u) {
  var l, f, p = "";
  if (typeof u == "string" || typeof u == "number") p += u;
  else if (typeof u == "object") if (Array.isArray(u)) {
    var m = u.length;
    for (l = 0; l < m; l++) u[l] && (f = r$1(u[l])) && (p && (p += " "), p += f);
  } else for (f in u) u[f] && (p && (p += " "), p += f);
  return p;
}
function clsx$1() {
  for (var u, l, f = 0, p = "", m = arguments.length; f < m; f++) (u = arguments[f]) && (l = r$1(u)) && (p && (p += " "), p += l);
  return p;
}
const replacements = {
  translate: /* @__PURE__ */ new Map([
    [!0, "yes"],
    [!1, "no"]
  ])
};
function attr$1(u, l, f = !1) {
  if (u === "hidden" && l !== "until-found" && (f = !0), l == null || !l && f) return "";
  const p = u in replacements && replacements[u].get(l) || l, m = f ? "" : `="${escape_html(p)}"`;
  return ` ${u}${m}`;
}
function clsx(u) {
  return typeof u == "object" ? clsx$1(u) : u ?? "";
}
const whitespace = [...` 	
\r\f \v\uFEFF`];
function to_class(u, l, f) {
  var p = u == null ? "" : "" + u;
  if (l && (p = p ? p + " " + l : l), f) {
    for (var m in f)
      if (f[m])
        p = p ? p + " " + m : m;
      else if (p.length)
        for (var b = m.length, y = 0; (y = p.indexOf(m, y)) >= 0; ) {
          var v = y + b;
          (y === 0 || whitespace.includes(p[y - 1])) && (v === p.length || whitespace.includes(p[v])) ? p = (y === 0 ? "" : p.substring(0, y)) + p.substring(v + 1) : y = v;
        }
  }
  return p === "" ? null : p;
}
function append_styles$1(u, l = !1) {
  var f = l ? " !important;" : ";", p = "";
  for (var m in u) {
    var b = u[m];
    b != null && b !== "" && (p += " " + m + ": " + b + f);
  }
  return p;
}
function to_css_name(u) {
  return u[0] !== "-" || u[1] !== "-" ? u.toLowerCase() : u;
}
function to_style(u, l) {
  if (l) {
    var f = "", p, m;
    if (Array.isArray(l) ? (p = l[0], m = l[1]) : p = l, u) {
      u = String(u).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var b = !1, y = 0, v = !1, $ = [];
      p && $.push(...Object.keys(p).map(to_css_name)), m && $.push(...Object.keys(m).map(to_css_name));
      var w = 0, P = -1;
      const M = u.length;
      for (var k = 0; k < M; k++) {
        var x = u[k];
        if (v ? x === "/" && u[k - 1] === "*" && (v = !1) : b ? b === x && (b = !1) : x === "/" && u[k + 1] === "*" ? v = !0 : x === '"' || x === "'" ? b = x : x === "(" ? y++ : x === ")" && y--, !v && b === !1 && y === 0) {
          if (x === ":" && P === -1)
            P = k;
          else if (x === ";" || k === M - 1) {
            if (P !== -1) {
              var S = to_css_name(u.substring(w, P).trim());
              if (!$.includes(S)) {
                x !== ";" && k++;
                var T = u.substring(w, k).trim();
                f += " " + T + ";";
              }
            }
            w = k + 1, P = -1;
          }
        }
      }
    }
    return p && (f += append_styles$1(p)), m && (f += append_styles$1(m, !0)), f = f.trim(), f === "" ? null : f;
  }
  return u == null ? null : String(u);
}
function set_class(u, l, f, p, m, b) {
  var y = u.__className;
  if (hydrating || y !== f || y === void 0) {
    var v = to_class(f, p, b);
    (!hydrating || v !== u.getAttribute("class")) && (v == null ? u.removeAttribute("class") : l ? u.className = v : u.setAttribute("class", v)), u.__className = f;
  } else if (b && m !== b)
    for (var $ in b) {
      var w = !!b[$];
      (m == null || w !== !!m[$]) && u.classList.toggle($, w);
    }
  return b;
}
function update_styles(u, l = {}, f, p) {
  for (var m in f) {
    var b = f[m];
    l[m] !== b && (f[m] == null ? u.style.removeProperty(m) : u.style.setProperty(m, b, p));
  }
}
function set_style$1(u, l, f, p) {
  var m = u.__style;
  if (hydrating || m !== l) {
    var b = to_style(l, p);
    (!hydrating || b !== u.getAttribute("style")) && (b == null ? u.removeAttribute("style") : u.style.cssText = b), u.__style = l;
  } else p && (Array.isArray(p) ? (update_styles(u, f?.[0], p[0]), update_styles(u, f?.[1], p[1], "important")) : update_styles(u, f, p));
  return p;
}
function select_option$1(u, l, f = !1) {
  if (u.multiple) {
    if (l == null)
      return;
    if (!is_array(l))
      return select_multiple_invalid_value();
    for (var p of u.options)
      p.selected = l.includes(get_option_value(p));
    return;
  }
  for (p of u.options) {
    var m = get_option_value(p);
    if (is$1(m, l)) {
      p.selected = !0;
      return;
    }
  }
  (!f || l !== void 0) && (u.selectedIndex = -1);
}
function init_select(u) {
  var l = new MutationObserver(() => {
    select_option$1(u, u.__value);
  });
  l.observe(u, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), teardown(() => {
    l.disconnect();
  });
}
function bind_select_value(u, l, f = l) {
  var p = !0;
  listen_to_event_and_reset_event(u, "change", (m) => {
    var b = m ? "[selected]" : ":checked", y;
    if (u.multiple)
      y = [].map.call(u.querySelectorAll(b), get_option_value);
    else {
      var v = u.querySelector(b) ?? // will fall back to first non-disabled option if no option is selected
      u.querySelector("option:not([disabled])");
      y = v && get_option_value(v);
    }
    f(y);
  }), effect(() => {
    var m = l();
    if (select_option$1(u, m, p), p && m === void 0) {
      var b = u.querySelector(":checked");
      b !== null && (m = get_option_value(b), f(m));
    }
    u.__value = m, p = !1;
  }), init_select(u);
}
function get_option_value(u) {
  return "__value" in u ? u.__value : u.value;
}
const CLASS = /* @__PURE__ */ Symbol("class"), STYLE = /* @__PURE__ */ Symbol("style"), IS_CUSTOM_ELEMENT = /* @__PURE__ */ Symbol("is custom element"), IS_HTML = /* @__PURE__ */ Symbol("is html");
function remove_input_defaults(u) {
  if (hydrating) {
    var l = !1, f = () => {
      if (!l) {
        if (l = !0, u.hasAttribute("value")) {
          var p = u.value;
          set_attribute(u, "value", null), u.value = p;
        }
        if (u.hasAttribute("checked")) {
          var m = u.checked;
          set_attribute(u, "checked", null), u.checked = m;
        }
      }
    };
    u.__on_r = f, queue_micro_task(f), add_form_reset_listener();
  }
}
function set_value(u, l) {
  var f = get_attributes(u);
  f.value === (f.value = // treat null and undefined the same for the initial value
  l ?? void 0) || // @ts-expect-error
  // `progress` elements always need their value set when it's `0`
  u.value === l && (l !== 0 || u.nodeName !== "PROGRESS") || (u.value = l ?? "");
}
function set_checked(u, l) {
  var f = get_attributes(u);
  f.checked !== (f.checked = // treat null and undefined the same for the initial value
  l ?? void 0) && (u.checked = l);
}
function set_selected(u, l) {
  l ? u.hasAttribute("selected") || u.setAttribute("selected", "") : u.removeAttribute("selected");
}
function set_default_checked(u, l) {
  const f = u.checked;
  u.defaultChecked = l, u.checked = f;
}
function set_default_value(u, l) {
  const f = u.value;
  u.defaultValue = l, u.value = f;
}
function set_attribute(u, l, f, p) {
  var m = get_attributes(u);
  hydrating && (m[l] = u.getAttribute(l), l === "src" || l === "srcset" || l === "href" && u.nodeName === "LINK") || m[l] !== (m[l] = f) && (l === "loading" && (u[LOADING_ATTR_SYMBOL] = f), f == null ? u.removeAttribute(l) : typeof f != "string" && get_setters(u).includes(l) ? u[l] = f : u.setAttribute(l, f));
}
function set_xlink_attribute(u, l, f) {
  u.setAttributeNS("http://www.w3.org/1999/xlink", l, f);
}
function set_custom_element_data$1(u, l, f) {
  var p = active_reaction, m = active_effect;
  let b = hydrating;
  hydrating && set_hydrating(!1), set_active_reaction(null), set_active_effect(null);
  try {
    // `style` should use `set_attribute` rather than the setter
    l !== "style" && // Don't compute setters for custom elements while they aren't registered yet,
    // because during their upgrade/instantiation they might add more setters.
    // Instead, fall back to a simple "an object, then set as property" heuristic.
    (setters_cache.has(u.getAttribute("is") || u.nodeName) || // customElements may not be available in browser extension contexts
    !customElements || customElements.get(u.getAttribute("is") || u.tagName.toLowerCase()) ? get_setters(u).includes(l) : f && typeof f == "object") ? u[l] = f : set_attribute(u, l, f == null ? f : String(f));
  } finally {
    set_active_reaction(p), set_active_effect(m), b && set_hydrating(!0);
  }
}
function set_attributes$1(u, l, f, p, m = !1, b = !1) {
  if (hydrating && m && u.tagName === "INPUT") {
    var y = (
      /** @type {HTMLInputElement} */
      u
    ), v = y.type === "checkbox" ? "defaultChecked" : "defaultValue";
    v in f || remove_input_defaults(y);
  }
  var $ = get_attributes(u), w = $[IS_CUSTOM_ELEMENT], P = !$[IS_HTML];
  let k = hydrating && w;
  k && set_hydrating(!1);
  var x = l || {}, S = u.tagName === "OPTION";
  for (var T in l)
    T in f || (f[T] = null);
  f.class ? f.class = clsx(f.class) : (p || f[CLASS]) && (f.class = null), f[STYLE] && (f.style ??= null);
  var M = get_setters(u);
  for (const L in f) {
    let N = f[L];
    if (S && L === "value" && N == null) {
      u.value = u.__value = "", x[L] = N;
      continue;
    }
    if (L === "class") {
      var E = u.namespaceURI === "http://www.w3.org/1999/xhtml";
      set_class(u, E, N, p, l?.[CLASS], f[CLASS]), x[L] = N, x[CLASS] = f[CLASS];
      continue;
    }
    if (L === "style") {
      set_style$1(u, N, l?.[STYLE], f[STYLE]), x[L] = N, x[STYLE] = f[STYLE];
      continue;
    }
    var R = x[L];
    if (!(N === R && !(N === void 0 && u.hasAttribute(L)))) {
      x[L] = N;
      var O = L[0] + L[1];
      if (O !== "$$")
        if (O === "on") {
          const z = {}, V = "$$" + L;
          let W = L.slice(2);
          var D = is_delegated(W);
          if (is_capture_event(W) && (W = W.slice(0, -7), z.capture = !0), !D && R) {
            if (N != null) continue;
            u.removeEventListener(W, x[V], z), x[V] = null;
          }
          if (N != null)
            if (D)
              u[`__${W}`] = N, delegate([W]);
            else {
              let j = function(U) {
                x[L].call(this, U);
              };
              x[V] = create_event(W, u, j, z);
            }
          else D && (u[`__${W}`] = void 0);
        } else if (L === "style")
          set_attribute(u, L, N);
        else if (L === "autofocus")
          autofocus(
            /** @type {HTMLElement} */
            u,
            !!N
          );
        else if (!w && (L === "__value" || L === "value" && N != null))
          u.value = u.__value = N;
        else if (L === "selected" && S)
          set_selected(
            /** @type {HTMLOptionElement} */
            u,
            N
          );
        else {
          var q = L;
          P || (q = normalize_attribute(q));
          var F = q === "defaultValue" || q === "defaultChecked";
          if (N == null && !w && !F)
            if ($[L] = null, q === "value" || q === "checked") {
              let z = (
                /** @type {HTMLInputElement} */
                u
              );
              const V = l === void 0;
              if (q === "value") {
                let W = z.defaultValue;
                z.removeAttribute(q), z.defaultValue = W, z.value = z.__value = V ? W : null;
              } else {
                let W = z.defaultChecked;
                z.removeAttribute(q), z.defaultChecked = W, z.checked = V ? W : !1;
              }
            } else
              u.removeAttribute(L);
          else F || M.includes(q) && (w || typeof N != "string") ? (u[q] = N, q in $ && ($[q] = UNINITIALIZED)) : typeof N != "function" && set_attribute(u, q, N);
        }
    }
  }
  return k && set_hydrating(!0), x;
}
function attribute_effect(u, l, f = [], p = [], m, b = !1, y = !1) {
  flatten$1(f, p, (v) => {
    var $ = void 0, w = {}, P = u.nodeName === "SELECT", k = !1;
    if (block$1(() => {
      var S = l(...v.map(get$2)), T = set_attributes$1(
        u,
        $,
        S,
        m,
        b,
        y
      );
      k && P && "value" in S && select_option$1(
        /** @type {HTMLSelectElement} */
        u,
        S.value
      );
      for (let E of Object.getOwnPropertySymbols(w))
        S[E] || destroy_effect(w[E]);
      for (let E of Object.getOwnPropertySymbols(S)) {
        var M = S[E];
        E.description === ATTACHMENT_KEY && (!$ || M !== $[E]) && (w[E] && destroy_effect(w[E]), w[E] = branch(() => attach(u, () => M))), T[E] = M;
      }
      $ = T;
    }), P) {
      var x = (
        /** @type {HTMLSelectElement} */
        u
      );
      effect(() => {
        select_option$1(
          x,
          /** @type {Record<string | symbol, any>} */
          $.value,
          !0
        ), init_select(x);
      });
    }
    k = !0;
  });
}
function get_attributes(u) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    u.__attributes ??= {
      [IS_CUSTOM_ELEMENT]: u.nodeName.includes("-"),
      [IS_HTML]: u.namespaceURI === NAMESPACE_HTML
    }
  );
}
var setters_cache = /* @__PURE__ */ new Map();
function get_setters(u) {
  var l = u.getAttribute("is") || u.nodeName, f = setters_cache.get(l);
  if (f) return f;
  setters_cache.set(l, f = []);
  for (var p, m = u, b = Element.prototype; b !== m; ) {
    p = get_descriptors(m);
    for (var y in p)
      p[y].set && f.push(y);
    m = get_prototype_of(m);
  }
  return f;
}
const now$1 = () => performance.now(), raf$1 = {
  // don't access requestAnimationFrame eagerly outside method
  // this allows basic testing of user code without JSDOM
  // bunder will eval and remove ternary when the user's app is built
  tick: (
    /** @param {any} _ */
    (u) => requestAnimationFrame(u)
  ),
  now: () => now$1(),
  tasks: /* @__PURE__ */ new Set()
};
function run_tasks$1() {
  const u = raf$1.now();
  raf$1.tasks.forEach((l) => {
    l.c(u) || (raf$1.tasks.delete(l), l.f());
  }), raf$1.tasks.size !== 0 && raf$1.tick(run_tasks$1);
}
function loop$1(u) {
  let l;
  return raf$1.tasks.size === 0 && raf$1.tick(run_tasks$1), {
    promise: new Promise((f) => {
      raf$1.tasks.add(l = { c: u, f });
    }),
    abort() {
      raf$1.tasks.delete(l);
    }
  };
}
function dispatch_event(u, l) {
  without_reactive_context(() => {
    u.dispatchEvent(new CustomEvent(l));
  });
}
function css_property_to_camelcase(u) {
  if (u === "float") return "cssFloat";
  if (u === "offset") return "cssOffset";
  if (u.startsWith("--")) return u;
  const l = u.split("-");
  return l.length === 1 ? l[0] : l[0] + l.slice(1).map(
    /** @param {any} word */
    (f) => f[0].toUpperCase() + f.slice(1)
  ).join("");
}
function css_to_keyframe(u) {
  const l = {}, f = u.split(";");
  for (const p of f) {
    const [m, b] = p.split(":");
    if (!m || b === void 0) break;
    const y = css_property_to_camelcase(m.trim());
    l[y] = b.trim();
  }
  return l;
}
const linear$2 = (u) => u;
function animation(u, l, f) {
  var p = (
    /** @type {EachItem} */
    current_each_item
  ), m, b, y, v = null;
  p.a ??= {
    element: u,
    measure() {
      m = this.element.getBoundingClientRect();
    },
    apply() {
      if (y?.abort(), b = this.element.getBoundingClientRect(), m.left !== b.left || m.right !== b.right || m.top !== b.top || m.bottom !== b.bottom) {
        const $ = l()(this.element, { from: m, to: b }, f?.());
        y = animate(this.element, $, void 0, 1, () => {
          y?.abort(), y = void 0;
        });
      }
    },
    fix() {
      if (!u.getAnimations().length) {
        var { position: $, width: w, height: P } = getComputedStyle(u);
        if ($ !== "absolute" && $ !== "fixed") {
          var k = (
            /** @type {HTMLElement | SVGElement} */
            u.style
          );
          v = {
            position: k.position,
            width: k.width,
            height: k.height,
            transform: k.transform
          }, k.position = "absolute", k.width = w, k.height = P;
          var x = u.getBoundingClientRect();
          if (m.left !== x.left || m.top !== x.top) {
            var S = `translate(${m.left - x.left}px, ${m.top - x.top}px)`;
            k.transform = k.transform ? `${k.transform} ${S}` : S;
          }
        }
      }
    },
    unfix() {
      if (v) {
        var $ = (
          /** @type {HTMLElement | SVGElement} */
          u.style
        );
        $.position = v.position, $.width = v.width, $.height = v.height, $.transform = v.transform;
      }
    }
  }, p.a.element = u;
}
function transition(u, l, f, p) {
  var m = (u & TRANSITION_IN) !== 0, b = (u & TRANSITION_OUT) !== 0, y = m && b, v = (u & TRANSITION_GLOBAL) !== 0, $ = y ? "both" : m ? "in" : "out", w, P = l.inert, k = l.style.overflow, x, S;
  function T() {
    return without_reactive_context(() => w ??= f()(l, p?.() ?? /** @type {P} */
    {}, {
      direction: $
    }));
  }
  var M = {
    is_global: v,
    in() {
      if (l.inert = P, !m) {
        S?.abort(), S?.reset?.();
        return;
      }
      b || x?.abort(), dispatch_event(l, "introstart"), x = animate(l, T(), S, 1, () => {
        dispatch_event(l, "introend"), x?.abort(), x = w = void 0, l.style.overflow = k;
      });
    },
    out(D) {
      if (!b) {
        D?.(), w = void 0;
        return;
      }
      l.inert = !0, dispatch_event(l, "outrostart"), S = animate(l, T(), x, 0, () => {
        dispatch_event(l, "outroend"), D?.();
      });
    },
    stop: () => {
      x?.abort(), S?.abort();
    }
  }, E = (
    /** @type {Effect} */
    active_effect
  );
  if ((E.transitions ??= []).push(M), m && should_intro) {
    var R = v;
    if (!R) {
      for (var O = (
        /** @type {Effect | null} */
        E.parent
      ); O && (O.f & EFFECT_TRANSPARENT) !== 0; )
        for (; (O = O.parent) && (O.f & BLOCK_EFFECT) === 0; )
          ;
      R = !O || (O.f & EFFECT_RAN) !== 0;
    }
    R && effect(() => {
      untrack(() => M.in());
    });
  }
}
function animate(u, l, f, p, m) {
  var b = p === 1;
  if (is_function$1(l)) {
    var y, v = !1;
    return queue_micro_task(() => {
      if (!v) {
        var E = l({ direction: b ? "in" : "out" });
        y = animate(u, E, f, p, m);
      }
    }), {
      abort: () => {
        v = !0, y?.abort();
      },
      deactivate: () => y.deactivate(),
      reset: () => y.reset(),
      t: () => y.t()
    };
  }
  if (f?.deactivate(), !l?.duration)
    return m(), {
      abort: noop$4,
      deactivate: noop$4,
      reset: noop$4,
      t: () => p
    };
  const { delay: $ = 0, css: w, tick: P, easing: k = linear$2 } = l;
  var x = [];
  if (b && f === void 0 && (P && P(0, 1), w)) {
    var S = css_to_keyframe(w(0, 1));
    x.push(S, S);
  }
  var T = () => 1 - p, M = u.animate(x, { duration: $, fill: "forwards" });
  return M.onfinish = () => {
    M.cancel();
    var E = f?.t() ?? 1 - p;
    f?.abort();
    var R = p - E, O = (
      /** @type {number} */
      l.duration * Math.abs(R)
    ), D = [];
    if (O > 0) {
      var q = !1;
      if (w)
        for (var F = Math.ceil(O / 16.666666666666668), L = 0; L <= F; L += 1) {
          var N = E + R * k(L / F), z = css_to_keyframe(w(N, 1 - N));
          D.push(z), q ||= z.overflow === "hidden";
        }
      q && (u.style.overflow = "hidden"), T = () => {
        var V = (
          /** @type {number} */
          /** @type {globalThis.Animation} */
          M.currentTime
        );
        return E + R * k(V / O);
      }, P && loop$1(() => {
        if (M.playState !== "running") return !1;
        var V = T();
        return P(V, 1 - V), !0;
      });
    }
    M = u.animate(D, { duration: O, fill: "forwards" }), M.onfinish = () => {
      T = () => p, P?.(p, 1 - p), m();
    };
  }, {
    abort: () => {
      M && (M.cancel(), M.effect = null, M.onfinish = noop$4);
    },
    deactivate: () => {
      m = noop$4;
    },
    reset: () => {
      p === 0 && P?.(1, 0);
    },
    t: () => T()
  };
}
function bind_active_element(u) {
  listen$1(document, ["focusin", "focusout"], (l) => {
    l && l.type === "focusout" && /** @type {FocusEvent} */
    l.relatedTarget || u(document.activeElement);
  });
}
function bind_value(u, l, f = l) {
  var p = /* @__PURE__ */ new WeakSet();
  listen_to_event_and_reset_event(u, "input", async (m) => {
    var b = m ? u.defaultValue : u.value;
    if (b = is_numberlike_input(u) ? to_number$1(b) : b, f(b), current_batch !== null && p.add(current_batch), await tick$1(), b !== (b = l())) {
      var y = u.selectionStart, v = u.selectionEnd, $ = u.value.length;
      if (u.value = b ?? "", v !== null) {
        var w = u.value.length;
        y === v && v === $ && w > $ ? (u.selectionStart = w, u.selectionEnd = w) : (u.selectionStart = y, u.selectionEnd = Math.min(v, w));
      }
    }
  }), // If we are hydrating and the value has since changed,
  // then use the updated value from the input instead.
  (hydrating && u.defaultValue !== u.value || // If defaultValue is set, then value == defaultValue
  // TODO Svelte 6: remove input.value check and set to empty string?
  untrack(l) == null && u.value) && (f(is_numberlike_input(u) ? to_number$1(u.value) : u.value), current_batch !== null && p.add(current_batch)), render_effect(() => {
    var m = l();
    if (u === document.activeElement) {
      var b = (
        /** @type {Batch} */
        previous_batch ?? current_batch
      );
      if (p.has(b))
        return;
    }
    is_numberlike_input(u) && m === to_number$1(u.value) || u.type === "date" && !m && !u.value || m !== u.value && (u.value = m ?? "");
  });
}
const pending = /* @__PURE__ */ new Set();
function bind_group(u, l, f, p, m = p) {
  var b = f.getAttribute("type") === "checkbox", y = u;
  let v = !1;
  if (l !== null)
    for (var $ of l)
      y = y[$] ??= [];
  y.push(f), listen_to_event_and_reset_event(
    f,
    "change",
    () => {
      var w = f.__value;
      b && (w = get_binding_group_value$1(y, w, f.checked)), m(w);
    },
    // TODO better default value handling
    () => m(b ? [] : null)
  ), render_effect(() => {
    var w = p();
    if (hydrating && f.defaultChecked !== f.checked) {
      v = !0;
      return;
    }
    b ? (w = w || [], f.checked = w.includes(f.__value)) : f.checked = is$1(f.__value, w);
  }), teardown(() => {
    var w = y.indexOf(f);
    w !== -1 && y.splice(w, 1);
  }), pending.has(y) || (pending.add(y), queue_micro_task(() => {
    y.sort((w, P) => w.compareDocumentPosition(P) === 4 ? -1 : 1), pending.delete(y);
  })), queue_micro_task(() => {
    if (v) {
      var w;
      if (b)
        w = get_binding_group_value$1(y, w, f.checked);
      else {
        var P = y.find((k) => k.checked);
        w = P?.__value;
      }
      m(w);
    }
  });
}
function bind_checked(u, l, f = l) {
  listen_to_event_and_reset_event(u, "change", (p) => {
    var m = p ? u.defaultChecked : u.checked;
    f(m);
  }), // If we are hydrating and the value has since changed,
  // then use the update value from the input instead.
  (hydrating && u.defaultChecked !== u.checked || // If defaultChecked is set, then checked == defaultChecked
  untrack(l) == null) && f(u.checked), render_effect(() => {
    var p = l();
    u.checked = !!p;
  });
}
function get_binding_group_value$1(u, l, f) {
  for (var p = /* @__PURE__ */ new Set(), m = 0; m < u.length; m += 1)
    u[m].checked && p.add(u[m].__value);
  return f || p.delete(l), Array.from(p);
}
function is_numberlike_input(u) {
  var l = u.type;
  return l === "number" || l === "range";
}
function to_number$1(u) {
  return u === "" ? null : +u;
}
function bind_files(u, l, f = l) {
  listen_to_event_and_reset_event(u, "change", () => {
    f(u.files);
  }), // If we are hydrating and the value has since changed,
  // then use the updated value from the input instead.
  hydrating && u.files && f(u.files), render_effect(() => {
    u.files = l();
  });
}
function time_ranges_to_array$1(u) {
  for (var l = [], f = 0; f < u.length; f += 1)
    l.push({ start: u.start(f), end: u.end(f) });
  return l;
}
function bind_current_time(u, l, f = l) {
  var p, m, b = () => {
    cancelAnimationFrame(p), u.paused || (p = requestAnimationFrame(b));
    var y = u.currentTime;
    m !== y && f(m = y);
  };
  p = requestAnimationFrame(b), u.addEventListener("timeupdate", b), render_effect(() => {
    var y = Number(l());
    m !== y && !isNaN(
      /** @type {any} */
      y
    ) && (u.currentTime = m = y);
  }), teardown(() => {
    cancelAnimationFrame(p), u.removeEventListener("timeupdate", b);
  });
}
function bind_buffered(u, l) {
  var f;
  listen$1(u, ["loadedmetadata", "progress", "timeupdate", "seeking"], () => {
    var p = u.buffered;
    (!f || f.length !== p.length || f.some((m, b) => p.start(b) !== m.start || p.end(b) !== m.end)) && (f = time_ranges_to_array$1(p), l(f));
  });
}
function bind_seekable(u, l) {
  listen$1(u, ["loadedmetadata"], () => l(time_ranges_to_array$1(u.seekable)));
}
function bind_played(u, l) {
  listen$1(u, ["timeupdate"], () => l(time_ranges_to_array$1(u.played)));
}
function bind_seeking(u, l) {
  listen$1(u, ["seeking", "seeked"], () => l(u.seeking));
}
function bind_ended(u, l) {
  listen$1(u, ["timeupdate", "ended"], () => l(u.ended));
}
function bind_ready_state(u, l) {
  listen$1(
    u,
    ["loadedmetadata", "loadeddata", "canplay", "canplaythrough", "playing", "waiting", "emptied"],
    () => l(u.readyState)
  );
}
function bind_playback_rate(u, l, f = l) {
  effect(() => {
    var p = Number(l());
    p !== u.playbackRate && !isNaN(p) && (u.playbackRate = p);
  }), effect(() => {
    listen$1(u, ["ratechange"], () => {
      f(u.playbackRate);
    });
  });
}
function bind_paused(u, l, f = l) {
  var p = l(), m = () => {
    p !== u.paused && f(p = u.paused);
  };
  listen$1(u, ["play", "pause", "canplay"], m, p == null), effect(() => {
    (p = !!l()) !== u.paused && (p ? u.pause() : u.play().catch(() => {
      f(p = !0);
    }));
  });
}
function bind_volume(u, l, f = l) {
  var p = () => {
    f(u.volume);
  };
  l() == null && p(), listen$1(u, ["volumechange"], p, !1), render_effect(() => {
    var m = Number(l());
    m !== u.volume && !isNaN(m) && (u.volume = m);
  });
}
function bind_muted(u, l, f = l) {
  var p = () => {
    f(u.muted);
  };
  l() == null && p(), listen$1(u, ["volumechange"], p, !1), render_effect(() => {
    var m = !!l();
    u.muted !== m && (u.muted = m);
  });
}
function bind_online(u) {
  listen$1(window, ["online", "offline"], () => {
    u(navigator.onLine);
  });
}
function bind_prop(u, l, f) {
  var p = get_descriptor(u, l);
  p && p.set && (u[l] = f, teardown(() => {
    u[l] = null;
  }));
}
let ResizeObserverSingleton$1 = class pr {
  /** */
  #e = /* @__PURE__ */ new WeakMap();
  /** @type {ResizeObserver | undefined} */
  #t;
  /** @type {ResizeObserverOptions} */
  #n;
  /** @static */
  static entries = /* @__PURE__ */ new WeakMap();
  /** @param {ResizeObserverOptions} options */
  constructor(l) {
    this.#n = l;
  }
  /**
   * @param {Element} element
   * @param {(entry: ResizeObserverEntry) => any} listener
   */
  observe(l, f) {
    var p = this.#e.get(l) || /* @__PURE__ */ new Set();
    return p.add(f), this.#e.set(l, p), this.#a().observe(l, this.#n), () => {
      var m = this.#e.get(l);
      m.delete(f), m.size === 0 && (this.#e.delete(l), this.#t.unobserve(l));
    };
  }
  #a() {
    return this.#t ?? (this.#t = new ResizeObserver(
      /** @param {any} entries */
      (l) => {
        for (var f of l) {
          pr.entries.set(f.target, f);
          for (var p of this.#e.get(f.target) || [])
            p(f);
        }
      }
    ));
  }
};
var resize_observer_content_box$1 = /* @__PURE__ */ new ResizeObserverSingleton$1({
  box: "content-box"
}), resize_observer_border_box$1 = /* @__PURE__ */ new ResizeObserverSingleton$1({
  box: "border-box"
}), resize_observer_device_pixel_content_box$1 = /* @__PURE__ */ new ResizeObserverSingleton$1({
  box: "device-pixel-content-box"
});
function bind_resize_observer(u, l, f) {
  var p = l === "contentRect" || l === "contentBoxSize" ? resize_observer_content_box$1 : l === "borderBoxSize" ? resize_observer_border_box$1 : resize_observer_device_pixel_content_box$1, m = p.observe(
    u,
    /** @param {any} entry */
    (b) => f(b[l])
  );
  teardown(m);
}
function bind_element_size(u, l, f) {
  var p = resize_observer_border_box$1.observe(u, () => f(u[l]));
  effect(() => (untrack(() => f(u[l])), p));
}
function is_bound_this(u, l) {
  return u === l || u?.[STATE_SYMBOL] === l;
}
function bind_this(u = {}, l, f, p) {
  return effect(() => {
    var m, b;
    return render_effect(() => {
      m = b, b = p?.() || [], untrack(() => {
        u !== f(...b) && (l(u, ...b), m && is_bound_this(f(...m), u) && l(null, ...m));
      });
    }), () => {
      queue_micro_task(() => {
        b && is_bound_this(f(...b), u) && l(null, ...b);
      });
    };
  }), u;
}
function bind_content_editable(u, l, f, p = f) {
  l.addEventListener("input", () => {
    p(l[u]);
  }), render_effect(() => {
    var m = f();
    if (l[u] !== m)
      if (m == null) {
        var b = l[u];
        p(b);
      } else
        l[u] = m + "";
  });
}
function bind_property(u, l, f, p, m) {
  var b = () => {
    p(f[u]);
  };
  f.addEventListener(l, b), m ? render_effect(() => {
    f[u] = m();
  }) : b(), (f === document.body || f === window || f === document) && teardown(() => {
    f.removeEventListener(l, b);
  });
}
function bind_focused(u, l) {
  listen$1(u, ["focus", "blur"], () => {
    l(u === document.activeElement);
  });
}
function bind_window_scroll(u, l, f = l) {
  var p = u === "x", m = () => without_reactive_context(() => {
    b = !0, clearTimeout(y), y = setTimeout(v, 100), f(window[p ? "scrollX" : "scrollY"]);
  });
  addEventListener("scroll", m, {
    passive: !0
  });
  var b = !1, y, v = () => {
    b = !1;
  }, $ = !0;
  render_effect(() => {
    var w = l();
    $ ? $ = !1 : !b && w != null && (b = !0, clearTimeout(y), p ? scrollTo(w, window.scrollY) : scrollTo(window.scrollX, w), y = setTimeout(v, 100));
  }), effect(m), teardown(() => {
    removeEventListener("scroll", m);
  });
}
function bind_window_size(u, l) {
  listen$1(window, ["resize"], () => without_reactive_context(() => l(window[u])));
}
function trusted$1(u) {
  return function(...l) {
    var f = (
      /** @type {Event} */
      l[0]
    );
    f.isTrusted && u?.apply(this, l);
  };
}
function self$2(u) {
  return function(...l) {
    var f = (
      /** @type {Event} */
      l[0]
    );
    f.target === this && u?.apply(this, l);
  };
}
function stopPropagation(u) {
  return function(...l) {
    var f = (
      /** @type {Event} */
      l[0]
    );
    return f.stopPropagation(), u?.apply(this, l);
  };
}
function once$2(u) {
  var l = !1;
  return function(...f) {
    if (!l)
      return l = !0, u?.apply(this, f);
  };
}
function stopImmediatePropagation(u) {
  return function(...l) {
    var f = (
      /** @type {Event} */
      l[0]
    );
    return f.stopImmediatePropagation(), u?.apply(this, l);
  };
}
function preventDefault(u) {
  return function(...l) {
    var f = (
      /** @type {Event} */
      l[0]
    );
    return f.preventDefault(), u?.apply(this, l);
  };
}
function init$2(u = !1) {
  const l = (
    /** @type {ComponentContextLegacy} */
    component_context
  ), f = l.l.u;
  if (!f) return;
  let p = () => deep_read_state(l.s);
  if (u) {
    let m = 0, b = (
      /** @type {Record<string, any>} */
      {}
    );
    const y = /* @__PURE__ */ derived$2(() => {
      let v = !1;
      const $ = l.s;
      for (const w in $)
        $[w] !== b[w] && (b[w] = $[w], v = !0);
      return v && m++, m;
    });
    p = () => get$2(y);
  }
  f.b.length && user_pre_effect(() => {
    observe_all(l, p), run_all$1(f.b);
  }), user_effect(() => {
    const m = untrack(() => f.m.map(run$1));
    return () => {
      for (const b of m)
        typeof b == "function" && b();
    };
  }), f.a.length && user_effect(() => {
    observe_all(l, p), run_all$1(f.a);
  });
}
function observe_all(u, l) {
  if (u.l.s)
    for (const f of u.l.s) get$2(f);
  l();
}
function reactive_import(u) {
  var l = source(0);
  return function() {
    return arguments.length === 1 ? (set(l, get$2(l) + 1), arguments[0]) : (get$2(l), u());
  };
}
function bubble_event(u, l) {
  var f = (
    /** @type {Record<string, Function[] | Function>} */
    u.$$events?.[l.type]
  ), p = is_array(f) ? f.slice() : f == null ? [] : [f];
  for (var m of p)
    m.call(this, l);
}
function add_legacy_event_listener(u, l, f) {
  u.$$events ||= {}, u.$$events[l] ||= [], u.$$events[l].push(f);
}
function update_legacy_props(u) {
  for (var l in u)
    l in this && (this[l] = u[l]);
}
function subscribe_to_store(u, l, f) {
  if (u == null)
    return l(void 0), f && f(void 0), noop$4;
  const p = untrack(
    () => u.subscribe(
      l,
      // @ts-expect-error
      f
    )
  );
  return p.unsubscribe ? () => p.unsubscribe() : p;
}
const subscriber_queue$1 = [];
function readable$1(u, l) {
  return {
    subscribe: writable$1(u, l).subscribe
  };
}
function writable$1(u, l = noop$4) {
  let f = null;
  const p = /* @__PURE__ */ new Set();
  function m(v) {
    if (safe_not_equal$1(u, v) && (u = v, f)) {
      const $ = !subscriber_queue$1.length;
      for (const w of p)
        w[1](), subscriber_queue$1.push(w, u);
      if ($) {
        for (let w = 0; w < subscriber_queue$1.length; w += 2)
          subscriber_queue$1[w][0](subscriber_queue$1[w + 1]);
        subscriber_queue$1.length = 0;
      }
    }
  }
  function b(v) {
    m(v(
      /** @type {T} */
      u
    ));
  }
  function y(v, $ = noop$4) {
    const w = [v, $];
    return p.add(w), p.size === 1 && (f = l(m, b) || noop$4), v(
      /** @type {T} */
      u
    ), () => {
      p.delete(w), p.size === 0 && f && (f(), f = null);
    };
  }
  return { set: m, update: b, subscribe: y };
}
function derived$1(u, l, f) {
  const p = !Array.isArray(u), m = p ? [u] : u;
  if (!m.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const b = l.length < 2;
  return readable$1(f, (y, v) => {
    let $ = !1;
    const w = [];
    let P = 0, k = noop$4;
    const x = () => {
      if (P)
        return;
      k();
      const T = l(p ? w[0] : w, y, v);
      b ? y(T) : k = typeof T == "function" ? T : noop$4;
    }, S = m.map(
      (T, M) => subscribe_to_store(
        T,
        (E) => {
          w[M] = E, P &= ~(1 << M), $ && x();
        },
        () => {
          P |= 1 << M;
        }
      )
    );
    return $ = !0, x(), function() {
      run_all$1(S), k(), $ = !1;
    };
  });
}
function readonly$2(u) {
  return {
    // @ts-expect-error TODO i suspect the bind is unnecessary
    subscribe: u.subscribe.bind(u)
  };
}
function get$1(u) {
  let l;
  return subscribe_to_store(u, (f) => l = f)(), l;
}
let is_store_binding = !1, IS_UNMOUNTED = /* @__PURE__ */ Symbol();
function store_get(u, l, f) {
  const p = f[l] ??= {
    store: null,
    source: /* @__PURE__ */ mutable_source(void 0),
    unsubscribe: noop$4
  };
  if (p.store !== u && !(IS_UNMOUNTED in f))
    if (p.unsubscribe(), p.store = u ?? null, u == null)
      p.source.v = void 0, p.unsubscribe = noop$4;
    else {
      var m = !0;
      p.unsubscribe = subscribe_to_store(u, (b) => {
        m ? p.source.v = b : set(p.source, b);
      }), m = !1;
    }
  return u && IS_UNMOUNTED in f ? get$1(u) : get$2(p.source);
}
function store_unsub(u, l, f) {
  let p = f[l];
  return p && p.store !== u && (p.unsubscribe(), p.unsubscribe = noop$4), u;
}
function store_set(u, l) {
  return u.set(l), l;
}
function invalidate_store(u, l) {
  var f = u[l];
  f.store !== null && store_set(f.store, f.source.v);
}
function setup_stores() {
  const u = {};
  function l() {
    teardown(() => {
      for (var f in u)
        u[f].unsubscribe();
      define_property(u, IS_UNMOUNTED, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [u, l];
}
function store_mutate(u, l, f) {
  return u.set(f), l;
}
function update_store(u, l, f = 1) {
  return u.set(l + f), l;
}
function update_pre_store(u, l, f = 1) {
  const p = l + f;
  return u.set(p), p;
}
function mark_store_binding() {
  is_store_binding = !0;
}
function capture_store_binding(u) {
  var l = is_store_binding;
  try {
    return is_store_binding = !1, [u(), is_store_binding];
  } finally {
    is_store_binding = l;
  }
}
function update_prop(u, l = 1) {
  const f = u();
  return u(f + l), f;
}
function update_pre_prop(u, l = 1) {
  const f = u() + l;
  return u(f), f;
}
const rest_props_handler = {
  get(u, l) {
    if (!u.exclude.includes(l))
      return u.props[l];
  },
  set(u, l) {
    return !1;
  },
  getOwnPropertyDescriptor(u, l) {
    if (!u.exclude.includes(l) && l in u.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: u.props[l]
      };
  },
  has(u, l) {
    return u.exclude.includes(l) ? !1 : l in u.props;
  },
  ownKeys(u) {
    return Reflect.ownKeys(u.props).filter((l) => !u.exclude.includes(l));
  }
};
// @__NO_SIDE_EFFECTS__
function rest_props(u, l, f) {
  return new Proxy(
    { props: u, exclude: l },
    rest_props_handler
  );
}
const legacy_rest_props_handler = {
  get(u, l) {
    if (!u.exclude.includes(l))
      return get$2(u.version), l in u.special ? u.special[l]() : u.props[l];
  },
  set(u, l, f) {
    if (!(l in u.special)) {
      var p = active_effect;
      try {
        set_active_effect(u.parent_effect), u.special[l] = prop(
          {
            get [l]() {
              return u.props[l];
            }
          },
          /** @type {string} */
          l,
          PROPS_IS_UPDATED
        );
      } finally {
        set_active_effect(p);
      }
    }
    return u.special[l](f), update$1(u.version), !0;
  },
  getOwnPropertyDescriptor(u, l) {
    if (!u.exclude.includes(l) && l in u.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: u.props[l]
      };
  },
  deleteProperty(u, l) {
    return u.exclude.includes(l) || (u.exclude.push(l), update$1(u.version)), !0;
  },
  has(u, l) {
    return u.exclude.includes(l) ? !1 : l in u.props;
  },
  ownKeys(u) {
    return Reflect.ownKeys(u.props).filter((l) => !u.exclude.includes(l));
  }
};
function legacy_rest_props(u, l) {
  return new Proxy(
    {
      props: u,
      exclude: l,
      special: {},
      version: source(0),
      // TODO this is only necessary because we need to track component
      // destruction inside `prop`, because of `bind:this`, but it
      // seems likely that we can simplify `bind:this` instead
      parent_effect: (
        /** @type {Effect} */
        active_effect
      )
    },
    legacy_rest_props_handler
  );
}
const spread_props_handler = {
  get(u, l) {
    let f = u.props.length;
    for (; f--; ) {
      let p = u.props[f];
      if (is_function$1(p) && (p = p()), typeof p == "object" && p !== null && l in p) return p[l];
    }
  },
  set(u, l, f) {
    let p = u.props.length;
    for (; p--; ) {
      let m = u.props[p];
      is_function$1(m) && (m = m());
      const b = get_descriptor(m, l);
      if (b && b.set)
        return b.set(f), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(u, l) {
    let f = u.props.length;
    for (; f--; ) {
      let p = u.props[f];
      if (is_function$1(p) && (p = p()), typeof p == "object" && p !== null && l in p) {
        const m = get_descriptor(p, l);
        return m && !m.configurable && (m.configurable = !0), m;
      }
    }
  },
  has(u, l) {
    if (l === STATE_SYMBOL || l === LEGACY_PROPS) return !1;
    for (let f of u.props)
      if (is_function$1(f) && (f = f()), f != null && l in f) return !0;
    return !1;
  },
  ownKeys(u) {
    const l = [];
    for (let f of u.props)
      if (is_function$1(f) && (f = f()), !!f) {
        for (const p in f)
          l.includes(p) || l.push(p);
        for (const p of Object.getOwnPropertySymbols(f))
          l.includes(p) || l.push(p);
      }
    return l;
  }
};
function spread_props(...u) {
  return new Proxy({ props: u }, spread_props_handler);
}
function prop(u, l, f, p) {
  var m = !legacy_mode_flag || (f & PROPS_IS_RUNES) !== 0, b = (f & PROPS_IS_BINDABLE) !== 0, y = (f & PROPS_IS_LAZY_INITIAL) !== 0, v = (
    /** @type {V} */
    p
  ), $ = !0, w = () => ($ && ($ = !1, v = y ? untrack(
    /** @type {() => V} */
    p
  ) : (
    /** @type {V} */
    p
  )), v), P;
  if (b) {
    var k = STATE_SYMBOL in u || LEGACY_PROPS in u;
    P = get_descriptor(u, l)?.set ?? (k && l in u ? (D) => u[l] = D : void 0);
  }
  var x, S = !1;
  b ? [x, S] = capture_store_binding(() => (
    /** @type {V} */
    u[l]
  )) : x = /** @type {V} */
  u[l], x === void 0 && p !== void 0 && (x = w(), P && (m && props_invalid_value(), P(x)));
  var T;
  if (m ? T = () => {
    var D = (
      /** @type {V} */
      u[l]
    );
    return D === void 0 ? w() : ($ = !0, D);
  } : T = () => {
    var D = (
      /** @type {V} */
      u[l]
    );
    return D !== void 0 && (v = /** @type {V} */
    void 0), D === void 0 ? v : D;
  }, m && (f & PROPS_IS_UPDATED) === 0)
    return T;
  if (P) {
    var M = u.$$legacy;
    return (
      /** @type {() => V} */
      (function(D, q) {
        return arguments.length > 0 ? ((!m || !q || M || S) && P(q ? T() : D), D) : T();
      })
    );
  }
  var E = !1, R = ((f & PROPS_IS_IMMUTABLE) !== 0 ? derived$2 : derived_safe_equal)(() => (E = !1, T()));
  b && get$2(R);
  var O = (
    /** @type {Effect} */
    active_effect
  );
  return (
    /** @type {() => V} */
    (function(D, q) {
      if (arguments.length > 0) {
        const F = q ? get$2(R) : m && b ? proxy(D) : D;
        return set(R, F), E = !0, v !== void 0 && (v = F), D;
      }
      return is_destroying_effect && E || (O.f & DESTROYED) !== 0 ? R.v : get$2(R);
    })
  );
}
function validate_each_keys$1(u, l) {
  render_effect(() => {
    const f = /* @__PURE__ */ new Map(), p = u(), m = is_array(p) ? p : p == null ? [] : Array.from(p), b = m.length;
    for (let y = 0; y < b; y++) {
      const v = l(m[y], y);
      if (f.has(v)) {
        String(f.get(v));
        let $ = String(v);
        $.startsWith("[object ") && ($ = null), each_key_duplicate();
      }
      f.set(v, y);
    }
  });
}
function validate_binding(u, l, f, p, m) {
  var b = !1;
  dev_current_component_function?.[FILENAME], render_effect(() => {
    if (!b) {
      var [y, v] = capture_store_binding(l);
      if (!v) {
        var $ = f(), w = !1, P = render_effect(() => {
          w || y[$];
        });
        w = !0, P.deps === null && (binding_property_non_reactive(), b = !0);
      }
    }
  });
}
function createClassComponent(u) {
  return new Svelte4Component(u);
}
class Svelte4Component {
  /** @type {any} */
  #e;
  /** @type {Record<string, any>} */
  #t;
  /**
   * @param {ComponentConstructorOptions & {
   *  component: any;
   * }} options
   */
  constructor(l) {
    var f = /* @__PURE__ */ new Map(), p = (b, y) => {
      var v = /* @__PURE__ */ mutable_source(y, !1, !1);
      return f.set(b, v), v;
    };
    const m = new Proxy(
      { ...l.props || {}, $$events: {} },
      {
        get(b, y) {
          return get$2(f.get(y) ?? p(y, Reflect.get(b, y)));
        },
        has(b, y) {
          return y === LEGACY_PROPS ? !0 : (get$2(f.get(y) ?? p(y, Reflect.get(b, y))), Reflect.has(b, y));
        },
        set(b, y, v) {
          return set(f.get(y) ?? p(y, v), v), Reflect.set(b, y, v);
        }
      }
    );
    this.#t = (l.hydrate ? hydrate : mount)(l.component, {
      target: l.target,
      anchor: l.anchor,
      props: m,
      context: l.context,
      intro: l.intro ?? !1,
      recover: l.recover
    }), (!l?.props?.$$host || l.sync === !1) && flushSync(), this.#e = m.$$events;
    for (const b of Object.keys(this.#t))
      b === "$set" || b === "$destroy" || b === "$on" || define_property(this, b, {
        get() {
          return this.#t[b];
        },
        /** @param {any} value */
        set(y) {
          this.#t[b] = y;
        },
        enumerable: !0
      });
    this.#t.$set = /** @param {Record<string, any>} next */
    (b) => {
      Object.assign(m, b);
    }, this.#t.$destroy = () => {
      unmount(this.#t);
    };
  }
  /** @param {Record<string, any>} props */
  $set(l) {
    this.#t.$set(l);
  }
  /**
   * @param {string} event
   * @param {(...args: any[]) => any} callback
   * @returns {any}
   */
  $on(l, f) {
    this.#e[l] = this.#e[l] || [];
    const p = (...m) => f.call(this, ...m);
    return this.#e[l].push(p), () => {
      this.#e[l] = this.#e[l].filter(
        /** @param {any} fn */
        (m) => m !== p
      );
    };
  }
  $destroy() {
    this.#t.$destroy();
  }
}
let SvelteElement$1;
typeof HTMLElement == "function" && (SvelteElement$1 = class extends HTMLElement {
  /** The Svelte component constructor */
  $$ctor;
  /** Slots */
  $$s;
  /** @type {any} The Svelte component instance */
  $$c;
  /** Whether or not the custom element is connected */
  $$cn = !1;
  /** @type {Record<string, any>} Component props data */
  $$d = {};
  /** `true` if currently in the process of reflecting component props back to attributes */
  $$r = !1;
  /** @type {Record<string, CustomElementPropDefinition>} Props definition (name, reflected, type etc) */
  $$p_d = {};
  /** @type {Record<string, EventListenerOrEventListenerObject[]>} Event listeners */
  $$l = {};
  /** @type {Map<EventListenerOrEventListenerObject, Function>} Event listener unsubscribe functions */
  $$l_u = /* @__PURE__ */ new Map();
  /** @type {any} The managed render effect for reflecting attributes */
  $$me;
  /**
   * @param {*} $$componentCtor
   * @param {*} $$slots
   * @param {*} use_shadow_dom
   */
  constructor(u, l, f) {
    super(), this.$$ctor = u, this.$$s = l, f && this.attachShadow({ mode: "open" });
  }
  /**
   * @param {string} type
   * @param {EventListenerOrEventListenerObject} listener
   * @param {boolean | AddEventListenerOptions} [options]
   */
  addEventListener(u, l, f) {
    if (this.$$l[u] = this.$$l[u] || [], this.$$l[u].push(l), this.$$c) {
      const p = this.$$c.$on(u, l);
      this.$$l_u.set(l, p);
    }
    super.addEventListener(u, l, f);
  }
  /**
   * @param {string} type
   * @param {EventListenerOrEventListenerObject} listener
   * @param {boolean | AddEventListenerOptions} [options]
   */
  removeEventListener(u, l, f) {
    if (super.removeEventListener(u, l, f), this.$$c) {
      const p = this.$$l_u.get(l);
      p && (p(), this.$$l_u.delete(l));
    }
  }
  async connectedCallback() {
    if (this.$$cn = !0, !this.$$c) {
      let u = function(p) {
        return (m) => {
          const b = document.createElement("slot");
          p !== "default" && (b.name = p), append$2(m, b);
        };
      };
      if (await Promise.resolve(), !this.$$cn || this.$$c)
        return;
      const l = {}, f = get_custom_elements_slots$1(this);
      for (const p of this.$$s)
        p in f && (p === "default" && !this.$$d.children ? (this.$$d.children = u(p), l.default = !0) : l[p] = u(p));
      for (const p of this.attributes) {
        const m = this.$$g_p(p.name);
        m in this.$$d || (this.$$d[m] = get_custom_element_value$1(m, p.value, this.$$p_d, "toProp"));
      }
      for (const p in this.$$p_d)
        !(p in this.$$d) && this[p] !== void 0 && (this.$$d[p] = this[p], delete this[p]);
      this.$$c = createClassComponent({
        component: this.$$ctor,
        target: this.shadowRoot || this,
        props: {
          ...this.$$d,
          $$slots: l,
          $$host: this
        }
      }), this.$$me = effect_root(() => {
        render_effect(() => {
          this.$$r = !0;
          for (const p of object_keys(this.$$c)) {
            if (!this.$$p_d[p]?.reflect) continue;
            this.$$d[p] = this.$$c[p];
            const m = get_custom_element_value$1(
              p,
              this.$$d[p],
              this.$$p_d,
              "toAttribute"
            );
            m == null ? this.removeAttribute(this.$$p_d[p].attribute || p) : this.setAttribute(this.$$p_d[p].attribute || p, m);
          }
          this.$$r = !1;
        });
      });
      for (const p in this.$$l)
        for (const m of this.$$l[p]) {
          const b = this.$$c.$on(p, m);
          this.$$l_u.set(m, b);
        }
      this.$$l = {};
    }
  }
  // We don't need this when working within Svelte code, but for compatibility of people using this outside of Svelte
  // and setting attributes through setAttribute etc, this is helpful
  /**
   * @param {string} attr
   * @param {string} _oldValue
   * @param {string} newValue
   */
  attributeChangedCallback(u, l, f) {
    this.$$r || (u = this.$$g_p(u), this.$$d[u] = get_custom_element_value$1(u, f, this.$$p_d, "toProp"), this.$$c?.$set({ [u]: this.$$d[u] }));
  }
  disconnectedCallback() {
    this.$$cn = !1, Promise.resolve().then(() => {
      !this.$$cn && this.$$c && (this.$$c.$destroy(), this.$$me(), this.$$c = void 0);
    });
  }
  /**
   * @param {string} attribute_name
   */
  $$g_p(u) {
    return object_keys(this.$$p_d).find(
      (l) => this.$$p_d[l].attribute === u || !this.$$p_d[l].attribute && l.toLowerCase() === u
    ) || u;
  }
});
function get_custom_element_value$1(u, l, f, p) {
  const m = f[u]?.type;
  if (l = m === "Boolean" && typeof l != "boolean" ? l != null : l, !p || !f[u])
    return l;
  if (p === "toAttribute")
    switch (m) {
      case "Object":
      case "Array":
        return l == null ? null : JSON.stringify(l);
      case "Boolean":
        return l ? "" : null;
      case "Number":
        return l ?? null;
      default:
        return l;
    }
  else
    switch (m) {
      case "Object":
      case "Array":
        return l && JSON.parse(l);
      case "Boolean":
        return l;
      // conversion already handled above
      case "Number":
        return l != null ? +l : l;
      default:
        return l;
    }
}
function get_custom_elements_slots$1(u) {
  const l = {};
  return u.childNodes.forEach((f) => {
    l[
      /** @type {Element} node */
      f.slot || "default"
    ] = !0;
  }), l;
}
function create_custom_element$1(u, l, f, p, m, b) {
  let y = class extends SvelteElement$1 {
    constructor() {
      super(u, f, m), this.$$p_d = l;
    }
    static get observedAttributes() {
      return object_keys(l).map(
        (v) => (l[v].attribute || v).toLowerCase()
      );
    }
  };
  return object_keys(l).forEach((v) => {
    define_property(y.prototype, v, {
      get() {
        return this.$$c && v in this.$$c ? this.$$c[v] : this.$$d[v];
      },
      set($) {
        $ = get_custom_element_value$1(v, $, l), this.$$d[v] = $;
        var w = this.$$c;
        if (w) {
          var P = get_descriptor(w, v)?.get;
          P ? w[v] = $ : w.$set({ [v]: $ });
        }
      }
    });
  }), p.forEach((v) => {
    define_property(y.prototype, v, {
      get() {
        return this.$$c?.[v];
      }
    });
  }), b && (y = b(y)), u.element = /** @type {any} */
  y, y;
}
function log_if_contains_state(u, ...l) {
  return untrack(() => {
    try {
      let f = !1;
      const p = [];
      for (const m of l)
        m && typeof m == "object" && STATE_SYMBOL in m ? (p.push(snapshot(m, !0)), f = !0) : p.push(m);
      f && (console_log_state(u), console.log("%c[snapshot]", "color: grey", ...p));
    } catch {
    }
  }), l;
}
const svelteInternal = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  CLASS,
  FILENAME,
  HMR,
  NAMESPACE_SVG,
  STYLE,
  aborted: aborted$1,
  action,
  get active_effect() {
    return active_effect;
  },
  add_legacy_event_listener,
  add_locations,
  add_svelte_meta,
  animation,
  append: append$2,
  append_styles: append_styles$2,
  apply: apply$1,
  assign: assign$2,
  assign_and,
  assign_nullish,
  assign_or,
  async,
  async_body,
  async_derived,
  attach,
  attachment: createAttachmentKey,
  attr: attr$1,
  attribute_effect,
  autofocus,
  await: await_block,
  bind_active_element,
  bind_buffered,
  bind_checked,
  bind_content_editable,
  bind_current_time,
  bind_element_size,
  bind_ended,
  bind_files,
  bind_focused,
  bind_group,
  bind_muted,
  bind_online,
  bind_paused,
  bind_playback_rate,
  bind_played,
  bind_prop,
  bind_property,
  bind_ready_state,
  bind_resize_observer,
  bind_seekable,
  bind_seeking,
  bind_select_value,
  bind_this,
  bind_value,
  bind_volume,
  bind_window_scroll,
  bind_window_size,
  boundary,
  bubble_event,
  check_target,
  child,
  cleanup_styles,
  clsx,
  comment: comment$2,
  component,
  create_custom_element: create_custom_element$1,
  create_ownership_validator,
  css_props,
  deep_read,
  deep_read_state,
  delegate,
  derived: user_derived,
  derived_safe_equal,
  get document() {
    return $document;
  },
  each: each$2,
  effect,
  effect_root,
  effect_tracking,
  element: element$1,
  equals,
  event,
  exclude_from_object,
  fallback,
  first_child,
  flush: flushSync,
  for_await_track_reactivity_loss,
  from_html,
  from_mathml,
  from_svg,
  from_tree,
  get: get$2,
  head,
  hmr,
  html,
  hydrate_template,
  if: if_block,
  index,
  init: init$2,
  init_select,
  inspect: inspect$1,
  invalid_default_snippet,
  invalidate_inner_signals,
  invalidate_store,
  invoke_error_boundary,
  key,
  legacy_api,
  legacy_pre_effect,
  legacy_pre_effect_reset,
  legacy_rest_props,
  log_if_contains_state,
  mark_store_binding,
  mutable_source,
  mutate,
  next,
  noop: noop$4,
  once: once$2,
  pending: pending$1,
  pop,
  preventDefault,
  prevent_snippet_stringification,
  prop,
  props_id,
  proxy,
  push: push$2,
  raf: raf$1,
  reactive_import,
  remove_input_defaults,
  remove_textarea_child,
  render_effect,
  replay_events,
  reset,
  rest_props,
  safe_get,
  sanitize_slots,
  save,
  select_option: select_option$1,
  self: self$2,
  set,
  set_attribute,
  set_checked,
  set_class,
  set_custom_element_data: set_custom_element_data$1,
  set_default_checked,
  set_default_value,
  set_selected,
  set_style: set_style$1,
  set_text,
  set_value,
  set_xlink_attribute,
  setup_stores,
  sibling,
  slot,
  snapshot,
  snippet,
  spread_props,
  state,
  stopImmediatePropagation,
  stopPropagation,
  store_get,
  store_mutate,
  store_set,
  store_unsub,
  strict_equals,
  tag: tag$2,
  tag_proxy,
  template_effect,
  text: text$4,
  tick: tick$1,
  to_array,
  trace,
  track_reactivity_loss,
  transition,
  trusted: trusted$1,
  untrack,
  update: update$1,
  update_legacy_props,
  update_pre,
  update_pre_prop,
  update_pre_store,
  update_prop,
  update_store,
  user_effect,
  user_pre_effect,
  validate_binding,
  validate_dynamic_element_tag,
  validate_each_keys: validate_each_keys$1,
  validate_snippet_args,
  validate_store: validate_store$1,
  validate_void_dynamic_element: validate_void_dynamic_element$1,
  get window() {
    return $window;
  },
  with_script,
  wrap_snippet
}, Symbol.toStringTag, { value: "Module" }));
function toStore(u, l) {
  var f = active_effect, p = active_reaction, m = u();
  const b = writable$1(m, (y) => {
    var v = m !== u(), $, w = active_reaction, P = active_effect;
    set_active_reaction(p), set_active_effect(f);
    try {
      $ = effect_root(() => {
        render_effect(() => {
          const k = u();
          v && y(k);
        });
      });
    } finally {
      set_active_reaction(w), set_active_effect(P);
    }
    return v = !0, $;
  });
  return l ? {
    set: l,
    update: (y) => l(y(u())),
    subscribe: b.subscribe
  } : {
    subscribe: b.subscribe
  };
}
function fromStore(u) {
  let l;
  const f = createSubscriber((m) => {
    let b = !1;
    const y = u.subscribe((v) => {
      l = v, b && m();
    });
    return b = !0, y;
  });
  function p() {
    return effect_tracking() ? (f(), l) : get$1(u);
  }
  return "set" in u ? {
    get current() {
      return p();
    },
    set current(m) {
      u.set(m);
    }
  } : {
    get current() {
      return p();
    }
  };
}
const svelteStore = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  derived: derived$1,
  fromStore,
  get: get$1,
  readable: readable$1,
  readonly: readonly$2,
  toStore,
  writable: writable$1
}, Symbol.toStringTag, { value: "Module" }));
var PopoverAlignment = /* @__PURE__ */ ((u) => (u.Left = "left", u.Right = "right", u.LeftOutside = "left-outside", u.RightOutside = "right-outside", u.Center = "center", u.RightContextMenu = "right-context-menu", u.LeftContextMenu = "left-context-menu", u))(PopoverAlignment || {}), TooltipPosition = /* @__PURE__ */ ((u) => (u.Top = "top", u.Right = "right", u.Bottom = "bottom", u.Left = "left", u))(TooltipPosition || {}), TooltipType = /* @__PURE__ */ ((u) => (u.Default = "default", u.Info = "info", u.Positive = "positive", u.Negative = "negative", u))(TooltipType || {}), ModalCancelFrom = /* @__PURE__ */ ((u) => (u.CLOSE_BUTTON = "close_button", u.CANCEL_BUTTON = "cancel_button", u.ESCAPE_KEY = "escape_key", u.OUTSIDE_CLICK = "outside_click", u))(ModalCancelFrom || {});
function portal(u, l = "body") {
  let f;
  async function p(b) {
    if (l = b, typeof l == "string") {
      if (f = document.querySelector(l), f === null && (await tick$1(), f = document.querySelector(l)), f === null)
        throw new Error(`No element found matching css selector: "${l}"`);
    } else if (l instanceof HTMLElement)
      f = l;
    else
      throw new TypeError(`Unknown portal target type: ${l === null ? "null" : typeof l}. Allowed types: string (CSS selector) or HTMLElement.`);
    f.appendChild(u), u.hidden = !1;
  }
  function m() {
    u.parentNode && u.parentNode.removeChild(u);
  }
  return p(l), { update: p, destroy: m };
}
var root$16 = /* @__PURE__ */ from_html('<div hidden=""><!></div>');
function Portal(u, l) {
  push$2(l, !1);
  let f = prop(l, "target", 8, "body");
  init$2();
  var p = root$16(), m = child(p);
  slot(m, l, "default", {}, null), reset(p), action(p, (b, y) => portal?.(b, y), f), append$2(u, p), pop();
}
const linear$1 = (u) => u;
function cubic_out(u) {
  const l = u - 1;
  return l * l * l + 1;
}
function cubic_in_out(u) {
  return u < 0.5 ? 4 * u * u * u : 0.5 * Math.pow(2 * u - 2, 3) + 1;
}
function split_css_unit$1(u) {
  const l = typeof u == "string" && u.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return l ? [parseFloat(l[1]), l[2] || "px"] : [
    /** @type {number} */
    u,
    "px"
  ];
}
function blur$1(u, { delay: l = 0, duration: f = 400, easing: p = cubic_in_out, amount: m = 5, opacity: b = 0 } = {}) {
  const y = getComputedStyle(u), v = +y.opacity, $ = y.filter === "none" ? "" : y.filter, w = v * (1 - b), [P, k] = split_css_unit$1(m);
  return {
    delay: l,
    duration: f,
    easing: p,
    css: (x, S) => `opacity: ${v - w * S}; filter: ${$} blur(${S * P}${k});`
  };
}
function fade$1(u, { delay: l = 0, duration: f = 400, easing: p = linear$1 } = {}) {
  const m = +getComputedStyle(u).opacity;
  return {
    delay: l,
    duration: f,
    easing: p,
    css: (b) => `opacity: ${b * m}`
  };
}
function fly$1(u, { delay: l = 0, duration: f = 400, easing: p = cubic_out, x: m = 0, y: b = 0, opacity: y = 0 } = {}) {
  const v = getComputedStyle(u), $ = +v.opacity, w = v.transform === "none" ? "" : v.transform, P = $ * (1 - y), [k, x] = split_css_unit$1(m), [S, T] = split_css_unit$1(b);
  return {
    delay: l,
    duration: f,
    easing: p,
    css: (M, E) => `
			transform: ${w} translate(${(1 - M) * k}${x}, ${(1 - M) * S}${T});
			opacity: ${$ - P * E}`
  };
}
function slide$1(u, { delay: l = 0, duration: f = 400, easing: p = cubic_out, axis: m = "y" } = {}) {
  const b = getComputedStyle(u), y = +b.opacity, v = m === "y" ? "height" : "width", $ = parseFloat(b[v]), w = m === "y" ? ["top", "bottom"] : ["left", "right"], P = w.map(
    (R) => (
      /** @type {'Left' | 'Right' | 'Top' | 'Bottom'} */
      `${R[0].toUpperCase()}${R.slice(1)}`
    )
  ), k = parseFloat(b[`padding${P[0]}`]), x = parseFloat(b[`padding${P[1]}`]), S = parseFloat(b[`margin${P[0]}`]), T = parseFloat(b[`margin${P[1]}`]), M = parseFloat(
    b[`border${P[0]}Width`]
  ), E = parseFloat(
    b[`border${P[1]}Width`]
  );
  return {
    delay: l,
    duration: f,
    easing: p,
    css: (R) => `overflow: hidden;opacity: ${Math.min(R * 20, 1) * y};${v}: ${R * $}px;padding-${w[0]}: ${R * k}px;padding-${w[1]}: ${R * x}px;margin-${w[0]}: ${R * S}px;margin-${w[1]}: ${R * T}px;border-${w[0]}-width: ${R * M}px;border-${w[1]}-width: ${R * E}px;min-${v}: 0`
  };
}
function scale$1(u, { delay: l = 0, duration: f = 400, easing: p = cubic_out, start: m = 0, opacity: b = 0 } = {}) {
  const y = getComputedStyle(u), v = +y.opacity, $ = y.transform === "none" ? "" : y.transform, w = 1 - m, P = v * (1 - b);
  return {
    delay: l,
    duration: f,
    easing: p,
    css: (k, x) => `
			transform: ${$} scale(${1 - w * x});
			opacity: ${v - P * x}
		`
  };
}
function draw$1(u, { delay: l = 0, speed: f, duration: p, easing: m = cubic_in_out } = {}) {
  let b = u.getTotalLength();
  const y = getComputedStyle(u);
  return y.strokeLinecap !== "butt" && (b += parseInt(y.strokeWidth)), p === void 0 ? f === void 0 ? p = 800 : p = b / f : typeof p == "function" && (p = p(b)), {
    delay: l,
    duration: p,
    easing: m,
    css: (v, $) => `
			stroke-dasharray: ${b};
			stroke-dashoffset: ${$ * b};
		`
  };
}
function assign$1(u, l) {
  for (const f in l) u[f] = l[f];
  return (
    /** @type {T & S} */
    u
  );
}
function crossfade$1({ fallback: u, ...l }) {
  const f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new Map();
  function m(y, v, $) {
    const {
      delay: w = 0,
      duration: P = (
        /** @param {number} d */
        (L) => Math.sqrt(L) * 30
      ),
      easing: k = cubic_out
    } = assign$1(assign$1({}, l), $), x = y.getBoundingClientRect(), S = v.getBoundingClientRect(), T = x.left - S.left, M = x.top - S.top, E = x.width / S.width, R = x.height / S.height, O = Math.sqrt(T * T + M * M), D = getComputedStyle(v), q = D.transform === "none" ? "" : D.transform, F = +D.opacity;
    return {
      delay: w,
      duration: typeof P == "function" ? P(O) : P,
      easing: k,
      css: (L, N) => `
			   opacity: ${L * F};
			   transform-origin: top left;
			   transform: ${q} translate(${N * T}px,${N * M}px) scale(${L + (1 - L) * E}, ${L + (1 - L) * R});
		   `
    };
  }
  function b(y, v, $) {
    return (w, P) => (y.set(P.key, w), () => {
      if (v.has(P.key)) {
        const k = v.get(P.key);
        return v.delete(P.key), m(
          /** @type {Element} */
          k,
          w,
          P
        );
      }
      return y.delete(P.key), u && u(w, P, $);
    });
  }
  return [b(p, f, !1), b(f, p, !0)];
}
const svelteTransition = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  blur: blur$1,
  crossfade: crossfade$1,
  draw: draw$1,
  fade: fade$1,
  fly: fly$1,
  scale: scale$1,
  slide: slide$1
}, Symbol.toStringTag, { value: "Module" }));
var root_2$y = /* @__PURE__ */ from_html('<span><span class="spectrum-Tooltip-label svelte-pqm2fz"> </span> <span class="spectrum-Tooltip-tip svelte-pqm2fz"></span></span>'), root$15 = /* @__PURE__ */ from_html('<div class="abs-tooltip svelte-pqm2fz"><!></div> <!>', 1);
function AbsTooltip(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source(), p = /* @__PURE__ */ mutable_source();
  let m = prop(l, "position", 24, () => TooltipPosition.Top), b = prop(l, "type", 24, () => TooltipType.Default), y = prop(l, "text", 8, ""), v = prop(l, "fixed", 8, !1), $ = prop(l, "color", 24, () => {
  }), w = prop(l, "noWrap", 8, !1), P = /* @__PURE__ */ mutable_source(), k = /* @__PURE__ */ mutable_source(!1), x = /* @__PURE__ */ mutable_source(), S = /* @__PURE__ */ mutable_source(), T = /* @__PURE__ */ mutable_source(!1), M = /* @__PURE__ */ mutable_source(), E;
  const R = () => {
    const V = get$2(P)?.children?.[0];
    if (!V) {
      set(x, void 0), set(S, void 0);
      return;
    }
    const W = V.getBoundingClientRect();
    m() === TooltipPosition.Top ? (set(x, W.left + W.width / 2), set(S, W.top)) : m() === TooltipPosition.Right ? (set(x, W.left + W.width), set(S, W.top + W.height / 2)) : m() === TooltipPosition.Bottom ? (set(x, W.left + W.width / 2), set(S, W.top + W.height)) : m() === TooltipPosition.Left && (set(x, W.left), set(S, W.top + W.height / 2));
  }, O = () => {
    R(), E = setInterval(R, 100), set(T, !0);
  }, D = () => {
    clearTimeout(get$2(M)), clearInterval(E), set(T, !1);
  };
  onDestroy$1(D), legacy_pre_effect(() => (get$2(k), deep_read_state(v())), () => {
    get$2(k) || v() ? set(M, setTimeout(O, 200)) : D();
  }), legacy_pre_effect(() => deep_read_state($()), () => {
    set(f, $() ? `background:${$()};` : null);
  }), legacy_pre_effect(() => deep_read_state($()), () => {
    set(p, $() ? `border-top-color:${$()};` : null);
  }), legacy_pre_effect_reset(), init$2();
  var q = root$15(), F = first_child(q), L = child(F);
  slot(L, l, "default", {}, null), reset(F), bind_this(F, (V) => set(P, V), () => get$2(P));
  var N = sibling(F, 2);
  {
    var z = (V) => {
      Portal(V, {
        target: ".spectrum",
        children: (W, j) => {
          var U = root_2$y();
          let Z;
          var X = child(U), B = child(X, !0);
          reset(X);
          var H = sibling(X, 2);
          reset(U), template_effect(
            (Y) => {
              Z = set_class(U, 1, `spectrum-Tooltip spectrum-Tooltip--${b() ?? ""} spectrum-Tooltip--${m() ?? ""} is-open`, "svelte-pqm2fz", Z, Y), set_style$1(U, `left:${get$2(x)}px;top:${get$2(S)}px;${get$2(f)}`), set_text(B, y()), set_style$1(H, get$2(p));
            },
            [() => ({ noWrap: w() })]
          ), transition(3, U, () => fade$1, () => ({ duration: 130 })), append$2(W, U);
        },
        $$slots: { default: !0 }
      });
    };
    if_block(N, (V) => {
      get$2(T) && y() && get$2(x) != null && get$2(S) != null && V(z);
    });
  }
  event("focus", F, function(...V) {
  }), event("mouseover", F, () => set(k, !0)), event("mouseleave", F, () => set(k, !1)), append$2(u, q), pop();
}
var PingSource = /* @__PURE__ */ ((u) => (u.BUILDER = "builder", u.APP = "app", u))(PingSource || {}), SortOrder = /* @__PURE__ */ ((u) => (u.ASCENDING = "ascending", u.DESCENDING = "descending", u))(SortOrder || {}), SortType = /* @__PURE__ */ ((u) => (u.STRING = "string", u.NUMBER = "number", u))(SortType || {});
function $constructor(u, l, f) {
  function p(v, $) {
    if (v._zod || Object.defineProperty(v, "_zod", {
      value: {
        def: $,
        constr: y,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), v._zod.traits.has(u))
      return;
    v._zod.traits.add(u), l(v, $);
    const w = y.prototype, P = Object.keys(w);
    for (let k = 0; k < P.length; k++) {
      const x = P[k];
      x in v || (v[x] = w[x].bind(v));
    }
  }
  const m = f?.Parent ?? Object;
  class b extends m {
  }
  Object.defineProperty(b, "name", { value: u });
  function y(v) {
    var $;
    const w = f?.Parent ? new b() : this;
    p(w, v), ($ = w._zod).deferred ?? ($.deferred = []);
    for (const P of w._zod.deferred)
      P();
    return w;
  }
  return Object.defineProperty(y, "init", { value: p }), Object.defineProperty(y, Symbol.hasInstance, {
    value: (v) => f?.Parent && v instanceof f.Parent ? !0 : v?._zod?.traits?.has(u)
  }), Object.defineProperty(y, "name", { value: u }), y;
}
class $ZodAsyncError extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class $ZodEncodeError extends Error {
  constructor(l) {
    super(`Encountered unidirectional transform during encode: ${l}`), this.name = "ZodEncodeError";
  }
}
const globalConfig = {};
function config$1(u) {
  return globalConfig;
}
function getEnumValues(u) {
  const l = Object.values(u).filter((p) => typeof p == "number");
  return Object.entries(u).filter(([p, m]) => l.indexOf(+p) === -1).map(([p, m]) => m);
}
function jsonStringifyReplacer(u, l) {
  return typeof l == "bigint" ? l.toString() : l;
}
function cached(u) {
  return {
    get value() {
      {
        const l = u();
        return Object.defineProperty(this, "value", { value: l }), l;
      }
    }
  };
}
function nullish(u) {
  return u == null;
}
function cleanRegex(u) {
  const l = u.startsWith("^") ? 1 : 0, f = u.endsWith("$") ? u.length - 1 : u.length;
  return u.slice(l, f);
}
function floatSafeRemainder(u, l) {
  const f = (u.toString().split(".")[1] || "").length, p = l.toString();
  let m = (p.split(".")[1] || "").length;
  if (m === 0 && /\d?e-\d?/.test(p)) {
    const $ = p.match(/\d?e-(\d?)/);
    $?.[1] && (m = Number.parseInt($[1]));
  }
  const b = f > m ? f : m, y = Number.parseInt(u.toFixed(b).replace(".", "")), v = Number.parseInt(l.toFixed(b).replace(".", ""));
  return y % v / 10 ** b;
}
const EVALUATING = /* @__PURE__ */ Symbol("evaluating");
function defineLazy(u, l, f) {
  let p;
  Object.defineProperty(u, l, {
    get() {
      if (p !== EVALUATING)
        return p === void 0 && (p = EVALUATING, p = f()), p;
    },
    set(m) {
      Object.defineProperty(u, l, {
        value: m
        // configurable: true,
      });
    },
    configurable: !0
  });
}
function assignProp(u, l, f) {
  Object.defineProperty(u, l, {
    value: f,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function mergeDefs(...u) {
  const l = {};
  for (const f of u) {
    const p = Object.getOwnPropertyDescriptors(f);
    Object.assign(l, p);
  }
  return Object.defineProperties({}, l);
}
function esc(u) {
  return JSON.stringify(u);
}
function slugify(u) {
  return u.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (...u) => {
};
function isObject$7(u) {
  return typeof u == "object" && u !== null && !Array.isArray(u);
}
const allowsEval = cached(() => {
  if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    const u = Function;
    return new u(""), !0;
  } catch {
    return !1;
  }
});
function isPlainObject$3(u) {
  if (isObject$7(u) === !1)
    return !1;
  const l = u.constructor;
  if (l === void 0 || typeof l != "function")
    return !0;
  const f = l.prototype;
  return !(isObject$7(f) === !1 || Object.prototype.hasOwnProperty.call(f, "isPrototypeOf") === !1);
}
function shallowClone(u) {
  return isPlainObject$3(u) ? { ...u } : Array.isArray(u) ? [...u] : u;
}
const propertyKeyTypes = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function escapeRegex(u) {
  return u.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone$1(u, l, f) {
  const p = new u._zod.constr(l ?? u._zod.def);
  return (!l || f?.parent) && (p._zod.parent = u), p;
}
function normalizeParams(u) {
  const l = u;
  if (!l)
    return {};
  if (typeof l == "string")
    return { error: () => l };
  if (l?.message !== void 0) {
    if (l?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    l.error = l.message;
  }
  return delete l.message, typeof l.error == "string" ? { ...l, error: () => l.error } : l;
}
function optionalKeys(u) {
  return Object.keys(u).filter((l) => u[l]._zod.optin === "optional" && u[l]._zod.optout === "optional");
}
const NUMBER_FORMAT_RANGES = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function pick$2(u, l) {
  const f = u._zod.def, p = f.checks;
  if (p && p.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const b = mergeDefs(u._zod.def, {
    get shape() {
      const y = {};
      for (const v in l) {
        if (!(v in f.shape))
          throw new Error(`Unrecognized key: "${v}"`);
        l[v] && (y[v] = f.shape[v]);
      }
      return assignProp(this, "shape", y), y;
    },
    checks: []
  });
  return clone$1(u, b);
}
function omit(u, l) {
  const f = u._zod.def, p = f.checks;
  if (p && p.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const b = mergeDefs(u._zod.def, {
    get shape() {
      const y = { ...u._zod.def.shape };
      for (const v in l) {
        if (!(v in f.shape))
          throw new Error(`Unrecognized key: "${v}"`);
        l[v] && delete y[v];
      }
      return assignProp(this, "shape", y), y;
    },
    checks: []
  });
  return clone$1(u, b);
}
function extend(u, l) {
  if (!isPlainObject$3(l))
    throw new Error("Invalid input to extend: expected a plain object");
  const f = u._zod.def.checks;
  if (f && f.length > 0) {
    const b = u._zod.def.shape;
    for (const y in l)
      if (Object.getOwnPropertyDescriptor(b, y) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  const m = mergeDefs(u._zod.def, {
    get shape() {
      const b = { ...u._zod.def.shape, ...l };
      return assignProp(this, "shape", b), b;
    }
  });
  return clone$1(u, m);
}
function safeExtend(u, l) {
  if (!isPlainObject$3(l))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  const f = mergeDefs(u._zod.def, {
    get shape() {
      const p = { ...u._zod.def.shape, ...l };
      return assignProp(this, "shape", p), p;
    }
  });
  return clone$1(u, f);
}
function merge(u, l) {
  const f = mergeDefs(u._zod.def, {
    get shape() {
      const p = { ...u._zod.def.shape, ...l._zod.def.shape };
      return assignProp(this, "shape", p), p;
    },
    get catchall() {
      return l._zod.def.catchall;
    },
    checks: []
    // delete existing checks
  });
  return clone$1(u, f);
}
function partial(u, l, f) {
  const m = l._zod.def.checks;
  if (m && m.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  const y = mergeDefs(l._zod.def, {
    get shape() {
      const v = l._zod.def.shape, $ = { ...v };
      if (f)
        for (const w in f) {
          if (!(w in v))
            throw new Error(`Unrecognized key: "${w}"`);
          f[w] && ($[w] = u ? new u({
            type: "optional",
            innerType: v[w]
          }) : v[w]);
        }
      else
        for (const w in v)
          $[w] = u ? new u({
            type: "optional",
            innerType: v[w]
          }) : v[w];
      return assignProp(this, "shape", $), $;
    },
    checks: []
  });
  return clone$1(l, y);
}
function required(u, l, f) {
  const p = mergeDefs(l._zod.def, {
    get shape() {
      const m = l._zod.def.shape, b = { ...m };
      if (f)
        for (const y in f) {
          if (!(y in b))
            throw new Error(`Unrecognized key: "${y}"`);
          f[y] && (b[y] = new u({
            type: "nonoptional",
            innerType: m[y]
          }));
        }
      else
        for (const y in m)
          b[y] = new u({
            type: "nonoptional",
            innerType: m[y]
          });
      return assignProp(this, "shape", b), b;
    }
  });
  return clone$1(l, p);
}
function aborted(u, l = 0) {
  if (u.aborted === !0)
    return !0;
  for (let f = l; f < u.issues.length; f++)
    if (u.issues[f]?.continue !== !0)
      return !0;
  return !1;
}
function prefixIssues(u, l) {
  return l.map((f) => {
    var p;
    return (p = f).path ?? (p.path = []), f.path.unshift(u), f;
  });
}
function unwrapMessage(u) {
  return typeof u == "string" ? u : u?.message;
}
function finalizeIssue(u, l, f) {
  const p = { ...u, path: u.path ?? [] };
  if (!u.message) {
    const m = unwrapMessage(u.inst?._zod.def?.error?.(u)) ?? unwrapMessage(l?.error?.(u)) ?? unwrapMessage(f.customError?.(u)) ?? unwrapMessage(f.localeError?.(u)) ?? "Invalid input";
    p.message = m;
  }
  return delete p.inst, delete p.continue, l?.reportInput || delete p.input, p;
}
function getLengthableOrigin(u) {
  return Array.isArray(u) ? "array" : typeof u == "string" ? "string" : "unknown";
}
function issue(...u) {
  const [l, f, p] = u;
  return typeof l == "string" ? {
    message: l,
    code: "custom",
    input: f,
    inst: p
  } : { ...l };
}
const initializer$1 = (u, l) => {
  u.name = "$ZodError", Object.defineProperty(u, "_zod", {
    value: u._zod,
    enumerable: !1
  }), Object.defineProperty(u, "issues", {
    value: l,
    enumerable: !1
  }), u.message = JSON.stringify(l, jsonStringifyReplacer, 2), Object.defineProperty(u, "toString", {
    value: () => u.message,
    enumerable: !1
  });
}, $ZodError = $constructor("$ZodError", initializer$1), $ZodRealError = $constructor("$ZodError", initializer$1, { Parent: Error });
function flattenError(u, l = (f) => f.message) {
  const f = {}, p = [];
  for (const m of u.issues)
    m.path.length > 0 ? (f[m.path[0]] = f[m.path[0]] || [], f[m.path[0]].push(l(m))) : p.push(l(m));
  return { formErrors: p, fieldErrors: f };
}
function formatError$1(u, l = (f) => f.message) {
  const f = { _errors: [] }, p = (m) => {
    for (const b of m.issues)
      if (b.code === "invalid_union" && b.errors.length)
        b.errors.map((y) => p({ issues: y }));
      else if (b.code === "invalid_key")
        p({ issues: b.issues });
      else if (b.code === "invalid_element")
        p({ issues: b.issues });
      else if (b.path.length === 0)
        f._errors.push(l(b));
      else {
        let y = f, v = 0;
        for (; v < b.path.length; ) {
          const $ = b.path[v];
          v === b.path.length - 1 ? (y[$] = y[$] || { _errors: [] }, y[$]._errors.push(l(b))) : y[$] = y[$] || { _errors: [] }, y = y[$], v++;
        }
      }
  };
  return p(u), f;
}
const _parse$1 = (u) => (l, f, p, m) => {
  const b = p ? Object.assign(p, { async: !1 }) : { async: !1 }, y = l._zod.run({ value: f, issues: [] }, b);
  if (y instanceof Promise)
    throw new $ZodAsyncError();
  if (y.issues.length) {
    const v = new (m?.Err ?? u)(y.issues.map(($) => finalizeIssue($, b, config$1())));
    throw captureStackTrace(v, m?.callee), v;
  }
  return y.value;
}, _parseAsync = (u) => async (l, f, p, m) => {
  const b = p ? Object.assign(p, { async: !0 }) : { async: !0 };
  let y = l._zod.run({ value: f, issues: [] }, b);
  if (y instanceof Promise && (y = await y), y.issues.length) {
    const v = new (m?.Err ?? u)(y.issues.map(($) => finalizeIssue($, b, config$1())));
    throw captureStackTrace(v, m?.callee), v;
  }
  return y.value;
}, _safeParse = (u) => (l, f, p) => {
  const m = p ? { ...p, async: !1 } : { async: !1 }, b = l._zod.run({ value: f, issues: [] }, m);
  if (b instanceof Promise)
    throw new $ZodAsyncError();
  return b.issues.length ? {
    success: !1,
    error: new (u ?? $ZodError)(b.issues.map((y) => finalizeIssue(y, m, config$1())))
  } : { success: !0, data: b.value };
}, safeParse$1 = /* @__PURE__ */ _safeParse($ZodRealError), _safeParseAsync = (u) => async (l, f, p) => {
  const m = p ? Object.assign(p, { async: !0 }) : { async: !0 };
  let b = l._zod.run({ value: f, issues: [] }, m);
  return b instanceof Promise && (b = await b), b.issues.length ? {
    success: !1,
    error: new u(b.issues.map((y) => finalizeIssue(y, m, config$1())))
  } : { success: !0, data: b.value };
}, safeParseAsync$1 = /* @__PURE__ */ _safeParseAsync($ZodRealError), _encode = (u) => (l, f, p) => {
  const m = p ? Object.assign(p, { direction: "backward" }) : { direction: "backward" };
  return _parse$1(u)(l, f, m);
}, _decode = (u) => (l, f, p) => _parse$1(u)(l, f, p), _encodeAsync = (u) => async (l, f, p) => {
  const m = p ? Object.assign(p, { direction: "backward" }) : { direction: "backward" };
  return _parseAsync(u)(l, f, m);
}, _decodeAsync = (u) => async (l, f, p) => _parseAsync(u)(l, f, p), _safeEncode = (u) => (l, f, p) => {
  const m = p ? Object.assign(p, { direction: "backward" }) : { direction: "backward" };
  return _safeParse(u)(l, f, m);
}, _safeDecode = (u) => (l, f, p) => _safeParse(u)(l, f, p), _safeEncodeAsync = (u) => async (l, f, p) => {
  const m = p ? Object.assign(p, { direction: "backward" }) : { direction: "backward" };
  return _safeParseAsync(u)(l, f, m);
}, _safeDecodeAsync = (u) => async (l, f, p) => _safeParseAsync(u)(l, f, p), cuid = /^[cC][^\s-]{8,}$/, cuid2 = /^[0-9a-z]+$/, ulid = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, xid = /^[0-9a-vA-V]{20}$/, ksuid = /^[A-Za-z0-9]{27}$/, nanoid$1 = /^[a-zA-Z0-9_-]{21}$/, duration$3 = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, uuid$1 = (u) => u ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${u}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, email = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, _emoji$1 = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function emoji() {
  return new RegExp(_emoji$1, "u");
}
const ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, base64$1 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, base64url = /^[A-Za-z0-9_-]*$/, e164 = /^\+[1-9]\d{6,14}$/, dateSource = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", date$2 = /* @__PURE__ */ new RegExp(`^${dateSource}$`);
function timeSource(u) {
  const l = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof u.precision == "number" ? u.precision === -1 ? `${l}` : u.precision === 0 ? `${l}:[0-5]\\d` : `${l}:[0-5]\\d\\.\\d{${u.precision}}` : `${l}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function time$1(u) {
  return new RegExp(`^${timeSource(u)}$`);
}
function datetime$1(u) {
  const l = timeSource({ precision: u.precision }), f = ["Z"];
  u.local && f.push(""), u.offset && f.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const p = `${l}(?:${f.join("|")})`;
  return new RegExp(`^${dateSource}T(?:${p})$`);
}
const string$2 = (u) => {
  const l = u ? `[\\s\\S]{${u?.minimum ?? 0},${u?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${l}$`);
}, integer = /^-?\d+$/, number$2 = /^-?\d+(?:\.\d+)?$/, boolean$1 = /^(?:true|false)$/i, _null$2 = /^null$/i, lowercase = /^[^A-Z]*$/, uppercase = /^[^a-z]*$/, $ZodCheck = /* @__PURE__ */ $constructor("$ZodCheck", (u, l) => {
  var f;
  u._zod ?? (u._zod = {}), u._zod.def = l, (f = u._zod).onattach ?? (f.onattach = []);
}), numericOriginMap = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, $ZodCheckLessThan = /* @__PURE__ */ $constructor("$ZodCheckLessThan", (u, l) => {
  $ZodCheck.init(u, l);
  const f = numericOriginMap[typeof l.value];
  u._zod.onattach.push((p) => {
    const m = p._zod.bag, b = (l.inclusive ? m.maximum : m.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    l.value < b && (l.inclusive ? m.maximum = l.value : m.exclusiveMaximum = l.value);
  }), u._zod.check = (p) => {
    (l.inclusive ? p.value <= l.value : p.value < l.value) || p.issues.push({
      origin: f,
      code: "too_big",
      maximum: typeof l.value == "object" ? l.value.getTime() : l.value,
      input: p.value,
      inclusive: l.inclusive,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckGreaterThan = /* @__PURE__ */ $constructor("$ZodCheckGreaterThan", (u, l) => {
  $ZodCheck.init(u, l);
  const f = numericOriginMap[typeof l.value];
  u._zod.onattach.push((p) => {
    const m = p._zod.bag, b = (l.inclusive ? m.minimum : m.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    l.value > b && (l.inclusive ? m.minimum = l.value : m.exclusiveMinimum = l.value);
  }), u._zod.check = (p) => {
    (l.inclusive ? p.value >= l.value : p.value > l.value) || p.issues.push({
      origin: f,
      code: "too_small",
      minimum: typeof l.value == "object" ? l.value.getTime() : l.value,
      input: p.value,
      inclusive: l.inclusive,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckMultipleOf = /* @__PURE__ */ $constructor("$ZodCheckMultipleOf", (u, l) => {
  $ZodCheck.init(u, l), u._zod.onattach.push((f) => {
    var p;
    (p = f._zod.bag).multipleOf ?? (p.multipleOf = l.value);
  }), u._zod.check = (f) => {
    if (typeof f.value != typeof l.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof f.value == "bigint" ? f.value % l.value === BigInt(0) : floatSafeRemainder(f.value, l.value) === 0) || f.issues.push({
      origin: typeof f.value,
      code: "not_multiple_of",
      divisor: l.value,
      input: f.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckNumberFormat = /* @__PURE__ */ $constructor("$ZodCheckNumberFormat", (u, l) => {
  $ZodCheck.init(u, l), l.format = l.format || "float64";
  const f = l.format?.includes("int"), p = f ? "int" : "number", [m, b] = NUMBER_FORMAT_RANGES[l.format];
  u._zod.onattach.push((y) => {
    const v = y._zod.bag;
    v.format = l.format, v.minimum = m, v.maximum = b, f && (v.pattern = integer);
  }), u._zod.check = (y) => {
    const v = y.value;
    if (f) {
      if (!Number.isInteger(v)) {
        y.issues.push({
          expected: p,
          format: l.format,
          code: "invalid_type",
          continue: !1,
          input: v,
          inst: u
        });
        return;
      }
      if (!Number.isSafeInteger(v)) {
        v > 0 ? y.issues.push({
          input: v,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: u,
          origin: p,
          inclusive: !0,
          continue: !l.abort
        }) : y.issues.push({
          input: v,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: u,
          origin: p,
          inclusive: !0,
          continue: !l.abort
        });
        return;
      }
    }
    v < m && y.issues.push({
      origin: "number",
      input: v,
      code: "too_small",
      minimum: m,
      inclusive: !0,
      inst: u,
      continue: !l.abort
    }), v > b && y.issues.push({
      origin: "number",
      input: v,
      code: "too_big",
      maximum: b,
      inclusive: !0,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckMaxLength = /* @__PURE__ */ $constructor("$ZodCheckMaxLength", (u, l) => {
  var f;
  $ZodCheck.init(u, l), (f = u._zod.def).when ?? (f.when = (p) => {
    const m = p.value;
    return !nullish(m) && m.length !== void 0;
  }), u._zod.onattach.push((p) => {
    const m = p._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    l.maximum < m && (p._zod.bag.maximum = l.maximum);
  }), u._zod.check = (p) => {
    const m = p.value;
    if (m.length <= l.maximum)
      return;
    const y = getLengthableOrigin(m);
    p.issues.push({
      origin: y,
      code: "too_big",
      maximum: l.maximum,
      inclusive: !0,
      input: m,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckMinLength = /* @__PURE__ */ $constructor("$ZodCheckMinLength", (u, l) => {
  var f;
  $ZodCheck.init(u, l), (f = u._zod.def).when ?? (f.when = (p) => {
    const m = p.value;
    return !nullish(m) && m.length !== void 0;
  }), u._zod.onattach.push((p) => {
    const m = p._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    l.minimum > m && (p._zod.bag.minimum = l.minimum);
  }), u._zod.check = (p) => {
    const m = p.value;
    if (m.length >= l.minimum)
      return;
    const y = getLengthableOrigin(m);
    p.issues.push({
      origin: y,
      code: "too_small",
      minimum: l.minimum,
      inclusive: !0,
      input: m,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckLengthEquals = /* @__PURE__ */ $constructor("$ZodCheckLengthEquals", (u, l) => {
  var f;
  $ZodCheck.init(u, l), (f = u._zod.def).when ?? (f.when = (p) => {
    const m = p.value;
    return !nullish(m) && m.length !== void 0;
  }), u._zod.onattach.push((p) => {
    const m = p._zod.bag;
    m.minimum = l.length, m.maximum = l.length, m.length = l.length;
  }), u._zod.check = (p) => {
    const m = p.value, b = m.length;
    if (b === l.length)
      return;
    const y = getLengthableOrigin(m), v = b > l.length;
    p.issues.push({
      origin: y,
      ...v ? { code: "too_big", maximum: l.length } : { code: "too_small", minimum: l.length },
      inclusive: !0,
      exact: !0,
      input: p.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckStringFormat = /* @__PURE__ */ $constructor("$ZodCheckStringFormat", (u, l) => {
  var f, p;
  $ZodCheck.init(u, l), u._zod.onattach.push((m) => {
    const b = m._zod.bag;
    b.format = l.format, l.pattern && (b.patterns ?? (b.patterns = /* @__PURE__ */ new Set()), b.patterns.add(l.pattern));
  }), l.pattern ? (f = u._zod).check ?? (f.check = (m) => {
    l.pattern.lastIndex = 0, !l.pattern.test(m.value) && m.issues.push({
      origin: "string",
      code: "invalid_format",
      format: l.format,
      input: m.value,
      ...l.pattern ? { pattern: l.pattern.toString() } : {},
      inst: u,
      continue: !l.abort
    });
  }) : (p = u._zod).check ?? (p.check = () => {
  });
}), $ZodCheckRegex = /* @__PURE__ */ $constructor("$ZodCheckRegex", (u, l) => {
  $ZodCheckStringFormat.init(u, l), u._zod.check = (f) => {
    l.pattern.lastIndex = 0, !l.pattern.test(f.value) && f.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: f.value,
      pattern: l.pattern.toString(),
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckLowerCase = /* @__PURE__ */ $constructor("$ZodCheckLowerCase", (u, l) => {
  l.pattern ?? (l.pattern = lowercase), $ZodCheckStringFormat.init(u, l);
}), $ZodCheckUpperCase = /* @__PURE__ */ $constructor("$ZodCheckUpperCase", (u, l) => {
  l.pattern ?? (l.pattern = uppercase), $ZodCheckStringFormat.init(u, l);
}), $ZodCheckIncludes = /* @__PURE__ */ $constructor("$ZodCheckIncludes", (u, l) => {
  $ZodCheck.init(u, l);
  const f = escapeRegex(l.includes), p = new RegExp(typeof l.position == "number" ? `^.{${l.position}}${f}` : f);
  l.pattern = p, u._zod.onattach.push((m) => {
    const b = m._zod.bag;
    b.patterns ?? (b.patterns = /* @__PURE__ */ new Set()), b.patterns.add(p);
  }), u._zod.check = (m) => {
    m.value.includes(l.includes, l.position) || m.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: l.includes,
      input: m.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckStartsWith = /* @__PURE__ */ $constructor("$ZodCheckStartsWith", (u, l) => {
  $ZodCheck.init(u, l);
  const f = new RegExp(`^${escapeRegex(l.prefix)}.*`);
  l.pattern ?? (l.pattern = f), u._zod.onattach.push((p) => {
    const m = p._zod.bag;
    m.patterns ?? (m.patterns = /* @__PURE__ */ new Set()), m.patterns.add(f);
  }), u._zod.check = (p) => {
    p.value.startsWith(l.prefix) || p.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: l.prefix,
      input: p.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckEndsWith = /* @__PURE__ */ $constructor("$ZodCheckEndsWith", (u, l) => {
  $ZodCheck.init(u, l);
  const f = new RegExp(`.*${escapeRegex(l.suffix)}$`);
  l.pattern ?? (l.pattern = f), u._zod.onattach.push((p) => {
    const m = p._zod.bag;
    m.patterns ?? (m.patterns = /* @__PURE__ */ new Set()), m.patterns.add(f);
  }), u._zod.check = (p) => {
    p.value.endsWith(l.suffix) || p.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: l.suffix,
      input: p.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodCheckOverwrite = /* @__PURE__ */ $constructor("$ZodCheckOverwrite", (u, l) => {
  $ZodCheck.init(u, l), u._zod.check = (f) => {
    f.value = l.tx(f.value);
  };
});
class Doc {
  constructor(l = []) {
    this.content = [], this.indent = 0, this && (this.args = l);
  }
  indented(l) {
    this.indent += 1, l(this), this.indent -= 1;
  }
  write(l) {
    if (typeof l == "function") {
      l(this, { execution: "sync" }), l(this, { execution: "async" });
      return;
    }
    const p = l.split(`
`).filter((y) => y), m = Math.min(...p.map((y) => y.length - y.trimStart().length)), b = p.map((y) => y.slice(m)).map((y) => " ".repeat(this.indent * 2) + y);
    for (const y of b)
      this.content.push(y);
  }
  compile() {
    const l = Function, f = this?.args, m = [...(this?.content ?? [""]).map((b) => `  ${b}`)];
    return new l(...f, m.join(`
`));
  }
}
const version$1 = {
  major: 4,
  minor: 3,
  patch: 6
}, $ZodType = /* @__PURE__ */ $constructor("$ZodType", (u, l) => {
  var f;
  u ?? (u = {}), u._zod.def = l, u._zod.bag = u._zod.bag || {}, u._zod.version = version$1;
  const p = [...u._zod.def.checks ?? []];
  u._zod.traits.has("$ZodCheck") && p.unshift(u);
  for (const m of p)
    for (const b of m._zod.onattach)
      b(u);
  if (p.length === 0)
    (f = u._zod).deferred ?? (f.deferred = []), u._zod.deferred?.push(() => {
      u._zod.run = u._zod.parse;
    });
  else {
    const m = (y, v, $) => {
      let w = aborted(y), P;
      for (const k of v) {
        if (k._zod.def.when) {
          if (!k._zod.def.when(y))
            continue;
        } else if (w)
          continue;
        const x = y.issues.length, S = k._zod.check(y);
        if (S instanceof Promise && $?.async === !1)
          throw new $ZodAsyncError();
        if (P || S instanceof Promise)
          P = (P ?? Promise.resolve()).then(async () => {
            await S, y.issues.length !== x && (w || (w = aborted(y, x)));
          });
        else {
          if (y.issues.length === x)
            continue;
          w || (w = aborted(y, x));
        }
      }
      return P ? P.then(() => y) : y;
    }, b = (y, v, $) => {
      if (aborted(y))
        return y.aborted = !0, y;
      const w = m(v, p, $);
      if (w instanceof Promise) {
        if ($.async === !1)
          throw new $ZodAsyncError();
        return w.then((P) => u._zod.parse(P, $));
      }
      return u._zod.parse(w, $);
    };
    u._zod.run = (y, v) => {
      if (v.skipChecks)
        return u._zod.parse(y, v);
      if (v.direction === "backward") {
        const w = u._zod.parse({ value: y.value, issues: [] }, { ...v, skipChecks: !0 });
        return w instanceof Promise ? w.then((P) => b(P, y, v)) : b(w, y, v);
      }
      const $ = u._zod.parse(y, v);
      if ($ instanceof Promise) {
        if (v.async === !1)
          throw new $ZodAsyncError();
        return $.then((w) => m(w, p, v));
      }
      return m($, p, v);
    };
  }
  defineLazy(u, "~standard", () => ({
    validate: (m) => {
      try {
        const b = safeParse$1(u, m);
        return b.success ? { value: b.data } : { issues: b.error?.issues };
      } catch {
        return safeParseAsync$1(u, m).then((y) => y.success ? { value: y.data } : { issues: y.error?.issues });
      }
    },
    vendor: "zod",
    version: 1
  }));
}), $ZodString = /* @__PURE__ */ $constructor("$ZodString", (u, l) => {
  $ZodType.init(u, l), u._zod.pattern = [...u?._zod.bag?.patterns ?? []].pop() ?? string$2(u._zod.bag), u._zod.parse = (f, p) => {
    if (l.coerce)
      try {
        f.value = String(f.value);
      } catch {
      }
    return typeof f.value == "string" || f.issues.push({
      expected: "string",
      code: "invalid_type",
      input: f.value,
      inst: u
    }), f;
  };
}), $ZodStringFormat = /* @__PURE__ */ $constructor("$ZodStringFormat", (u, l) => {
  $ZodCheckStringFormat.init(u, l), $ZodString.init(u, l);
}), $ZodGUID = /* @__PURE__ */ $constructor("$ZodGUID", (u, l) => {
  l.pattern ?? (l.pattern = guid), $ZodStringFormat.init(u, l);
}), $ZodUUID = /* @__PURE__ */ $constructor("$ZodUUID", (u, l) => {
  if (l.version) {
    const p = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[l.version];
    if (p === void 0)
      throw new Error(`Invalid UUID version: "${l.version}"`);
    l.pattern ?? (l.pattern = uuid$1(p));
  } else
    l.pattern ?? (l.pattern = uuid$1());
  $ZodStringFormat.init(u, l);
}), $ZodEmail = /* @__PURE__ */ $constructor("$ZodEmail", (u, l) => {
  l.pattern ?? (l.pattern = email), $ZodStringFormat.init(u, l);
}), $ZodURL = /* @__PURE__ */ $constructor("$ZodURL", (u, l) => {
  $ZodStringFormat.init(u, l), u._zod.check = (f) => {
    try {
      const p = f.value.trim(), m = new URL(p);
      l.hostname && (l.hostname.lastIndex = 0, l.hostname.test(m.hostname) || f.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: l.hostname.source,
        input: f.value,
        inst: u,
        continue: !l.abort
      })), l.protocol && (l.protocol.lastIndex = 0, l.protocol.test(m.protocol.endsWith(":") ? m.protocol.slice(0, -1) : m.protocol) || f.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: l.protocol.source,
        input: f.value,
        inst: u,
        continue: !l.abort
      })), l.normalize ? f.value = m.href : f.value = p;
      return;
    } catch {
      f.issues.push({
        code: "invalid_format",
        format: "url",
        input: f.value,
        inst: u,
        continue: !l.abort
      });
    }
  };
}), $ZodEmoji = /* @__PURE__ */ $constructor("$ZodEmoji", (u, l) => {
  l.pattern ?? (l.pattern = emoji()), $ZodStringFormat.init(u, l);
}), $ZodNanoID = /* @__PURE__ */ $constructor("$ZodNanoID", (u, l) => {
  l.pattern ?? (l.pattern = nanoid$1), $ZodStringFormat.init(u, l);
}), $ZodCUID = /* @__PURE__ */ $constructor("$ZodCUID", (u, l) => {
  l.pattern ?? (l.pattern = cuid), $ZodStringFormat.init(u, l);
}), $ZodCUID2 = /* @__PURE__ */ $constructor("$ZodCUID2", (u, l) => {
  l.pattern ?? (l.pattern = cuid2), $ZodStringFormat.init(u, l);
}), $ZodULID = /* @__PURE__ */ $constructor("$ZodULID", (u, l) => {
  l.pattern ?? (l.pattern = ulid), $ZodStringFormat.init(u, l);
}), $ZodXID = /* @__PURE__ */ $constructor("$ZodXID", (u, l) => {
  l.pattern ?? (l.pattern = xid), $ZodStringFormat.init(u, l);
}), $ZodKSUID = /* @__PURE__ */ $constructor("$ZodKSUID", (u, l) => {
  l.pattern ?? (l.pattern = ksuid), $ZodStringFormat.init(u, l);
}), $ZodISODateTime = /* @__PURE__ */ $constructor("$ZodISODateTime", (u, l) => {
  l.pattern ?? (l.pattern = datetime$1(l)), $ZodStringFormat.init(u, l);
}), $ZodISODate = /* @__PURE__ */ $constructor("$ZodISODate", (u, l) => {
  l.pattern ?? (l.pattern = date$2), $ZodStringFormat.init(u, l);
}), $ZodISOTime = /* @__PURE__ */ $constructor("$ZodISOTime", (u, l) => {
  l.pattern ?? (l.pattern = time$1(l)), $ZodStringFormat.init(u, l);
}), $ZodISODuration = /* @__PURE__ */ $constructor("$ZodISODuration", (u, l) => {
  l.pattern ?? (l.pattern = duration$3), $ZodStringFormat.init(u, l);
}), $ZodIPv4 = /* @__PURE__ */ $constructor("$ZodIPv4", (u, l) => {
  l.pattern ?? (l.pattern = ipv4), $ZodStringFormat.init(u, l), u._zod.bag.format = "ipv4";
}), $ZodIPv6 = /* @__PURE__ */ $constructor("$ZodIPv6", (u, l) => {
  l.pattern ?? (l.pattern = ipv6), $ZodStringFormat.init(u, l), u._zod.bag.format = "ipv6", u._zod.check = (f) => {
    try {
      new URL(`http://[${f.value}]`);
    } catch {
      f.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: f.value,
        inst: u,
        continue: !l.abort
      });
    }
  };
}), $ZodCIDRv4 = /* @__PURE__ */ $constructor("$ZodCIDRv4", (u, l) => {
  l.pattern ?? (l.pattern = cidrv4), $ZodStringFormat.init(u, l);
}), $ZodCIDRv6 = /* @__PURE__ */ $constructor("$ZodCIDRv6", (u, l) => {
  l.pattern ?? (l.pattern = cidrv6), $ZodStringFormat.init(u, l), u._zod.check = (f) => {
    const p = f.value.split("/");
    try {
      if (p.length !== 2)
        throw new Error();
      const [m, b] = p;
      if (!b)
        throw new Error();
      const y = Number(b);
      if (`${y}` !== b)
        throw new Error();
      if (y < 0 || y > 128)
        throw new Error();
      new URL(`http://[${m}]`);
    } catch {
      f.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: f.value,
        inst: u,
        continue: !l.abort
      });
    }
  };
});
function isValidBase64(u) {
  if (u === "")
    return !0;
  if (u.length % 4 !== 0)
    return !1;
  try {
    return atob(u), !0;
  } catch {
    return !1;
  }
}
const $ZodBase64 = /* @__PURE__ */ $constructor("$ZodBase64", (u, l) => {
  l.pattern ?? (l.pattern = base64$1), $ZodStringFormat.init(u, l), u._zod.bag.contentEncoding = "base64", u._zod.check = (f) => {
    isValidBase64(f.value) || f.issues.push({
      code: "invalid_format",
      format: "base64",
      input: f.value,
      inst: u,
      continue: !l.abort
    });
  };
});
function isValidBase64URL(u) {
  if (!base64url.test(u))
    return !1;
  const l = u.replace(/[-_]/g, (p) => p === "-" ? "+" : "/"), f = l.padEnd(Math.ceil(l.length / 4) * 4, "=");
  return isValidBase64(f);
}
const $ZodBase64URL = /* @__PURE__ */ $constructor("$ZodBase64URL", (u, l) => {
  l.pattern ?? (l.pattern = base64url), $ZodStringFormat.init(u, l), u._zod.bag.contentEncoding = "base64url", u._zod.check = (f) => {
    isValidBase64URL(f.value) || f.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: f.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodE164 = /* @__PURE__ */ $constructor("$ZodE164", (u, l) => {
  l.pattern ?? (l.pattern = e164), $ZodStringFormat.init(u, l);
});
function isValidJWT(u, l = null) {
  try {
    const f = u.split(".");
    if (f.length !== 3)
      return !1;
    const [p] = f;
    if (!p)
      return !1;
    const m = JSON.parse(atob(p));
    return !("typ" in m && m?.typ !== "JWT" || !m.alg || l && (!("alg" in m) || m.alg !== l));
  } catch {
    return !1;
  }
}
const $ZodJWT = /* @__PURE__ */ $constructor("$ZodJWT", (u, l) => {
  $ZodStringFormat.init(u, l), u._zod.check = (f) => {
    isValidJWT(f.value, l.alg) || f.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: f.value,
      inst: u,
      continue: !l.abort
    });
  };
}), $ZodNumber = /* @__PURE__ */ $constructor("$ZodNumber", (u, l) => {
  $ZodType.init(u, l), u._zod.pattern = u._zod.bag.pattern ?? number$2, u._zod.parse = (f, p) => {
    if (l.coerce)
      try {
        f.value = Number(f.value);
      } catch {
      }
    const m = f.value;
    if (typeof m == "number" && !Number.isNaN(m) && Number.isFinite(m))
      return f;
    const b = typeof m == "number" ? Number.isNaN(m) ? "NaN" : Number.isFinite(m) ? void 0 : "Infinity" : void 0;
    return f.issues.push({
      expected: "number",
      code: "invalid_type",
      input: m,
      inst: u,
      ...b ? { received: b } : {}
    }), f;
  };
}), $ZodNumberFormat = /* @__PURE__ */ $constructor("$ZodNumberFormat", (u, l) => {
  $ZodCheckNumberFormat.init(u, l), $ZodNumber.init(u, l);
}), $ZodBoolean = /* @__PURE__ */ $constructor("$ZodBoolean", (u, l) => {
  $ZodType.init(u, l), u._zod.pattern = boolean$1, u._zod.parse = (f, p) => {
    if (l.coerce)
      try {
        f.value = !!f.value;
      } catch {
      }
    const m = f.value;
    return typeof m == "boolean" || f.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: m,
      inst: u
    }), f;
  };
}), $ZodNull = /* @__PURE__ */ $constructor("$ZodNull", (u, l) => {
  $ZodType.init(u, l), u._zod.pattern = _null$2, u._zod.values = /* @__PURE__ */ new Set([null]), u._zod.parse = (f, p) => {
    const m = f.value;
    return m === null || f.issues.push({
      expected: "null",
      code: "invalid_type",
      input: m,
      inst: u
    }), f;
  };
}), $ZodUnknown = /* @__PURE__ */ $constructor("$ZodUnknown", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f) => f;
}), $ZodNever = /* @__PURE__ */ $constructor("$ZodNever", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f, p) => (f.issues.push({
    expected: "never",
    code: "invalid_type",
    input: f.value,
    inst: u
  }), f);
});
function handleArrayResult(u, l, f) {
  u.issues.length && l.issues.push(...prefixIssues(f, u.issues)), l.value[f] = u.value;
}
const $ZodArray = /* @__PURE__ */ $constructor("$ZodArray", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f, p) => {
    const m = f.value;
    if (!Array.isArray(m))
      return f.issues.push({
        expected: "array",
        code: "invalid_type",
        input: m,
        inst: u
      }), f;
    f.value = Array(m.length);
    const b = [];
    for (let y = 0; y < m.length; y++) {
      const v = m[y], $ = l.element._zod.run({
        value: v,
        issues: []
      }, p);
      $ instanceof Promise ? b.push($.then((w) => handleArrayResult(w, f, y))) : handleArrayResult($, f, y);
    }
    return b.length ? Promise.all(b).then(() => f) : f;
  };
});
function handlePropertyResult(u, l, f, p, m) {
  if (u.issues.length) {
    if (m && !(f in p))
      return;
    l.issues.push(...prefixIssues(f, u.issues));
  }
  u.value === void 0 ? f in p && (l.value[f] = void 0) : l.value[f] = u.value;
}
function normalizeDef(u) {
  const l = Object.keys(u.shape);
  for (const p of l)
    if (!u.shape?.[p]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${p}": expected a Zod schema`);
  const f = optionalKeys(u.shape);
  return {
    ...u,
    keys: l,
    keySet: new Set(l),
    numKeys: l.length,
    optionalKeys: new Set(f)
  };
}
function handleCatchall(u, l, f, p, m, b) {
  const y = [], v = m.keySet, $ = m.catchall._zod, w = $.def.type, P = $.optout === "optional";
  for (const k in l) {
    if (v.has(k))
      continue;
    if (w === "never") {
      y.push(k);
      continue;
    }
    const x = $.run({ value: l[k], issues: [] }, p);
    x instanceof Promise ? u.push(x.then((S) => handlePropertyResult(S, f, k, l, P))) : handlePropertyResult(x, f, k, l, P);
  }
  return y.length && f.issues.push({
    code: "unrecognized_keys",
    keys: y,
    input: l,
    inst: b
  }), u.length ? Promise.all(u).then(() => f) : f;
}
const $ZodObject = /* @__PURE__ */ $constructor("$ZodObject", (u, l) => {
  if ($ZodType.init(u, l), !Object.getOwnPropertyDescriptor(l, "shape")?.get) {
    const v = l.shape;
    Object.defineProperty(l, "shape", {
      get: () => {
        const $ = { ...v };
        return Object.defineProperty(l, "shape", {
          value: $
        }), $;
      }
    });
  }
  const p = cached(() => normalizeDef(l));
  defineLazy(u._zod, "propValues", () => {
    const v = l.shape, $ = {};
    for (const w in v) {
      const P = v[w]._zod;
      if (P.values) {
        $[w] ?? ($[w] = /* @__PURE__ */ new Set());
        for (const k of P.values)
          $[w].add(k);
      }
    }
    return $;
  });
  const m = isObject$7, b = l.catchall;
  let y;
  u._zod.parse = (v, $) => {
    y ?? (y = p.value);
    const w = v.value;
    if (!m(w))
      return v.issues.push({
        expected: "object",
        code: "invalid_type",
        input: w,
        inst: u
      }), v;
    v.value = {};
    const P = [], k = y.shape;
    for (const x of y.keys) {
      const S = k[x], T = S._zod.optout === "optional", M = S._zod.run({ value: w[x], issues: [] }, $);
      M instanceof Promise ? P.push(M.then((E) => handlePropertyResult(E, v, x, w, T))) : handlePropertyResult(M, v, x, w, T);
    }
    return b ? handleCatchall(P, w, v, $, p.value, u) : P.length ? Promise.all(P).then(() => v) : v;
  };
}), $ZodObjectJIT = /* @__PURE__ */ $constructor("$ZodObjectJIT", (u, l) => {
  $ZodObject.init(u, l);
  const f = u._zod.parse, p = cached(() => normalizeDef(l)), m = (x) => {
    const S = new Doc(["shape", "payload", "ctx"]), T = p.value, M = (D) => {
      const q = esc(D);
      return `shape[${q}]._zod.run({ value: input[${q}], issues: [] }, ctx)`;
    };
    S.write("const input = payload.value;");
    const E = /* @__PURE__ */ Object.create(null);
    let R = 0;
    for (const D of T.keys)
      E[D] = `key_${R++}`;
    S.write("const newResult = {};");
    for (const D of T.keys) {
      const q = E[D], F = esc(D), N = x[D]?._zod?.optout === "optional";
      S.write(`const ${q} = ${M(D)};`), N ? S.write(`
        if (${q}.issues.length) {
          if (${F} in input) {
            payload.issues = payload.issues.concat(${q}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${F}, ...iss.path] : [${F}]
            })));
          }
        }
        
        if (${q}.value === undefined) {
          if (${F} in input) {
            newResult[${F}] = undefined;
          }
        } else {
          newResult[${F}] = ${q}.value;
        }
        
      `) : S.write(`
        if (${q}.issues.length) {
          payload.issues = payload.issues.concat(${q}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${F}, ...iss.path] : [${F}]
          })));
        }
        
        if (${q}.value === undefined) {
          if (${F} in input) {
            newResult[${F}] = undefined;
          }
        } else {
          newResult[${F}] = ${q}.value;
        }
        
      `);
    }
    S.write("payload.value = newResult;"), S.write("return payload;");
    const O = S.compile();
    return (D, q) => O(x, D, q);
  };
  let b;
  const y = isObject$7, v = !globalConfig.jitless, w = v && allowsEval.value, P = l.catchall;
  let k;
  u._zod.parse = (x, S) => {
    k ?? (k = p.value);
    const T = x.value;
    return y(T) ? v && w && S?.async === !1 && S.jitless !== !0 ? (b || (b = m(l.shape)), x = b(x, S), P ? handleCatchall([], T, x, S, k, u) : x) : f(x, S) : (x.issues.push({
      expected: "object",
      code: "invalid_type",
      input: T,
      inst: u
    }), x);
  };
});
function handleUnionResults(u, l, f, p) {
  for (const b of u)
    if (b.issues.length === 0)
      return l.value = b.value, l;
  const m = u.filter((b) => !aborted(b));
  return m.length === 1 ? (l.value = m[0].value, m[0]) : (l.issues.push({
    code: "invalid_union",
    input: l.value,
    inst: f,
    errors: u.map((b) => b.issues.map((y) => finalizeIssue(y, p, config$1())))
  }), l);
}
const $ZodUnion = /* @__PURE__ */ $constructor("$ZodUnion", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "optin", () => l.options.some((m) => m._zod.optin === "optional") ? "optional" : void 0), defineLazy(u._zod, "optout", () => l.options.some((m) => m._zod.optout === "optional") ? "optional" : void 0), defineLazy(u._zod, "values", () => {
    if (l.options.every((m) => m._zod.values))
      return new Set(l.options.flatMap((m) => Array.from(m._zod.values)));
  }), defineLazy(u._zod, "pattern", () => {
    if (l.options.every((m) => m._zod.pattern)) {
      const m = l.options.map((b) => b._zod.pattern);
      return new RegExp(`^(${m.map((b) => cleanRegex(b.source)).join("|")})$`);
    }
  });
  const f = l.options.length === 1, p = l.options[0]._zod.run;
  u._zod.parse = (m, b) => {
    if (f)
      return p(m, b);
    let y = !1;
    const v = [];
    for (const $ of l.options) {
      const w = $._zod.run({
        value: m.value,
        issues: []
      }, b);
      if (w instanceof Promise)
        v.push(w), y = !0;
      else {
        if (w.issues.length === 0)
          return w;
        v.push(w);
      }
    }
    return y ? Promise.all(v).then(($) => handleUnionResults($, m, u, b)) : handleUnionResults(v, m, u, b);
  };
}), $ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("$ZodDiscriminatedUnion", (u, l) => {
  l.inclusive = !1, $ZodUnion.init(u, l);
  const f = u._zod.parse;
  defineLazy(u._zod, "propValues", () => {
    const m = {};
    for (const b of l.options) {
      const y = b._zod.propValues;
      if (!y || Object.keys(y).length === 0)
        throw new Error(`Invalid discriminated union option at index "${l.options.indexOf(b)}"`);
      for (const [v, $] of Object.entries(y)) {
        m[v] || (m[v] = /* @__PURE__ */ new Set());
        for (const w of $)
          m[v].add(w);
      }
    }
    return m;
  });
  const p = cached(() => {
    const m = l.options, b = /* @__PURE__ */ new Map();
    for (const y of m) {
      const v = y._zod.propValues?.[l.discriminator];
      if (!v || v.size === 0)
        throw new Error(`Invalid discriminated union option at index "${l.options.indexOf(y)}"`);
      for (const $ of v) {
        if (b.has($))
          throw new Error(`Duplicate discriminator value "${String($)}"`);
        b.set($, y);
      }
    }
    return b;
  });
  u._zod.parse = (m, b) => {
    const y = m.value;
    if (!isObject$7(y))
      return m.issues.push({
        code: "invalid_type",
        expected: "object",
        input: y,
        inst: u
      }), m;
    const v = p.value.get(y?.[l.discriminator]);
    return v ? v._zod.run(m, b) : l.unionFallback ? f(m, b) : (m.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: l.discriminator,
      input: y,
      path: [l.discriminator],
      inst: u
    }), m);
  };
}), $ZodIntersection = /* @__PURE__ */ $constructor("$ZodIntersection", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f, p) => {
    const m = f.value, b = l.left._zod.run({ value: m, issues: [] }, p), y = l.right._zod.run({ value: m, issues: [] }, p);
    return b instanceof Promise || y instanceof Promise ? Promise.all([b, y]).then(([$, w]) => handleIntersectionResults(f, $, w)) : handleIntersectionResults(f, b, y);
  };
});
function mergeValues(u, l) {
  if (u === l)
    return { valid: !0, data: u };
  if (u instanceof Date && l instanceof Date && +u == +l)
    return { valid: !0, data: u };
  if (isPlainObject$3(u) && isPlainObject$3(l)) {
    const f = Object.keys(l), p = Object.keys(u).filter((b) => f.indexOf(b) !== -1), m = { ...u, ...l };
    for (const b of p) {
      const y = mergeValues(u[b], l[b]);
      if (!y.valid)
        return {
          valid: !1,
          mergeErrorPath: [b, ...y.mergeErrorPath]
        };
      m[b] = y.data;
    }
    return { valid: !0, data: m };
  }
  if (Array.isArray(u) && Array.isArray(l)) {
    if (u.length !== l.length)
      return { valid: !1, mergeErrorPath: [] };
    const f = [];
    for (let p = 0; p < u.length; p++) {
      const m = u[p], b = l[p], y = mergeValues(m, b);
      if (!y.valid)
        return {
          valid: !1,
          mergeErrorPath: [p, ...y.mergeErrorPath]
        };
      f.push(y.data);
    }
    return { valid: !0, data: f };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function handleIntersectionResults(u, l, f) {
  const p = /* @__PURE__ */ new Map();
  let m;
  for (const v of l.issues)
    if (v.code === "unrecognized_keys") {
      m ?? (m = v);
      for (const $ of v.keys)
        p.has($) || p.set($, {}), p.get($).l = !0;
    } else
      u.issues.push(v);
  for (const v of f.issues)
    if (v.code === "unrecognized_keys")
      for (const $ of v.keys)
        p.has($) || p.set($, {}), p.get($).r = !0;
    else
      u.issues.push(v);
  const b = [...p].filter(([, v]) => v.l && v.r).map(([v]) => v);
  if (b.length && m && u.issues.push({ ...m, keys: b }), aborted(u))
    return u;
  const y = mergeValues(l.value, f.value);
  if (!y.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(y.mergeErrorPath)}`);
  return u.value = y.data, u;
}
const $ZodRecord = /* @__PURE__ */ $constructor("$ZodRecord", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f, p) => {
    const m = f.value;
    if (!isPlainObject$3(m))
      return f.issues.push({
        expected: "record",
        code: "invalid_type",
        input: m,
        inst: u
      }), f;
    const b = [], y = l.keyType._zod.values;
    if (y) {
      f.value = {};
      const v = /* @__PURE__ */ new Set();
      for (const w of y)
        if (typeof w == "string" || typeof w == "number" || typeof w == "symbol") {
          v.add(typeof w == "number" ? w.toString() : w);
          const P = l.valueType._zod.run({ value: m[w], issues: [] }, p);
          P instanceof Promise ? b.push(P.then((k) => {
            k.issues.length && f.issues.push(...prefixIssues(w, k.issues)), f.value[w] = k.value;
          })) : (P.issues.length && f.issues.push(...prefixIssues(w, P.issues)), f.value[w] = P.value);
        }
      let $;
      for (const w in m)
        v.has(w) || ($ = $ ?? [], $.push(w));
      $ && $.length > 0 && f.issues.push({
        code: "unrecognized_keys",
        input: m,
        inst: u,
        keys: $
      });
    } else {
      f.value = {};
      for (const v of Reflect.ownKeys(m)) {
        if (v === "__proto__")
          continue;
        let $ = l.keyType._zod.run({ value: v, issues: [] }, p);
        if ($ instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof v == "string" && number$2.test(v) && $.issues.length) {
          const k = l.keyType._zod.run({ value: Number(v), issues: [] }, p);
          if (k instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          k.issues.length === 0 && ($ = k);
        }
        if ($.issues.length) {
          l.mode === "loose" ? f.value[v] = m[v] : f.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: $.issues.map((k) => finalizeIssue(k, p, config$1())),
            input: v,
            path: [v],
            inst: u
          });
          continue;
        }
        const P = l.valueType._zod.run({ value: m[v], issues: [] }, p);
        P instanceof Promise ? b.push(P.then((k) => {
          k.issues.length && f.issues.push(...prefixIssues(v, k.issues)), f.value[$.value] = k.value;
        })) : (P.issues.length && f.issues.push(...prefixIssues(v, P.issues)), f.value[$.value] = P.value);
      }
    }
    return b.length ? Promise.all(b).then(() => f) : f;
  };
}), $ZodEnum = /* @__PURE__ */ $constructor("$ZodEnum", (u, l) => {
  $ZodType.init(u, l);
  const f = getEnumValues(l.entries), p = new Set(f);
  u._zod.values = p, u._zod.pattern = new RegExp(`^(${f.filter((m) => propertyKeyTypes.has(typeof m)).map((m) => typeof m == "string" ? escapeRegex(m) : m.toString()).join("|")})$`), u._zod.parse = (m, b) => {
    const y = m.value;
    return p.has(y) || m.issues.push({
      code: "invalid_value",
      values: f,
      input: y,
      inst: u
    }), m;
  };
}), $ZodLiteral = /* @__PURE__ */ $constructor("$ZodLiteral", (u, l) => {
  if ($ZodType.init(u, l), l.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  const f = new Set(l.values);
  u._zod.values = f, u._zod.pattern = new RegExp(`^(${l.values.map((p) => typeof p == "string" ? escapeRegex(p) : p ? escapeRegex(p.toString()) : String(p)).join("|")})$`), u._zod.parse = (p, m) => {
    const b = p.value;
    return f.has(b) || p.issues.push({
      code: "invalid_value",
      values: l.values,
      input: b,
      inst: u
    }), p;
  };
}), $ZodTransform = /* @__PURE__ */ $constructor("$ZodTransform", (u, l) => {
  $ZodType.init(u, l), u._zod.parse = (f, p) => {
    if (p.direction === "backward")
      throw new $ZodEncodeError(u.constructor.name);
    const m = l.transform(f.value, f);
    if (p.async)
      return (m instanceof Promise ? m : Promise.resolve(m)).then((y) => (f.value = y, f));
    if (m instanceof Promise)
      throw new $ZodAsyncError();
    return f.value = m, f;
  };
});
function handleOptionalResult(u, l) {
  return u.issues.length && l === void 0 ? { issues: [], value: void 0 } : u;
}
const $ZodOptional = /* @__PURE__ */ $constructor("$ZodOptional", (u, l) => {
  $ZodType.init(u, l), u._zod.optin = "optional", u._zod.optout = "optional", defineLazy(u._zod, "values", () => l.innerType._zod.values ? /* @__PURE__ */ new Set([...l.innerType._zod.values, void 0]) : void 0), defineLazy(u._zod, "pattern", () => {
    const f = l.innerType._zod.pattern;
    return f ? new RegExp(`^(${cleanRegex(f.source)})?$`) : void 0;
  }), u._zod.parse = (f, p) => {
    if (l.innerType._zod.optin === "optional") {
      const m = l.innerType._zod.run(f, p);
      return m instanceof Promise ? m.then((b) => handleOptionalResult(b, f.value)) : handleOptionalResult(m, f.value);
    }
    return f.value === void 0 ? f : l.innerType._zod.run(f, p);
  };
}), $ZodExactOptional = /* @__PURE__ */ $constructor("$ZodExactOptional", (u, l) => {
  $ZodOptional.init(u, l), defineLazy(u._zod, "values", () => l.innerType._zod.values), defineLazy(u._zod, "pattern", () => l.innerType._zod.pattern), u._zod.parse = (f, p) => l.innerType._zod.run(f, p);
}), $ZodNullable = /* @__PURE__ */ $constructor("$ZodNullable", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "optin", () => l.innerType._zod.optin), defineLazy(u._zod, "optout", () => l.innerType._zod.optout), defineLazy(u._zod, "pattern", () => {
    const f = l.innerType._zod.pattern;
    return f ? new RegExp(`^(${cleanRegex(f.source)}|null)$`) : void 0;
  }), defineLazy(u._zod, "values", () => l.innerType._zod.values ? /* @__PURE__ */ new Set([...l.innerType._zod.values, null]) : void 0), u._zod.parse = (f, p) => f.value === null ? f : l.innerType._zod.run(f, p);
}), $ZodDefault = /* @__PURE__ */ $constructor("$ZodDefault", (u, l) => {
  $ZodType.init(u, l), u._zod.optin = "optional", defineLazy(u._zod, "values", () => l.innerType._zod.values), u._zod.parse = (f, p) => {
    if (p.direction === "backward")
      return l.innerType._zod.run(f, p);
    if (f.value === void 0)
      return f.value = l.defaultValue, f;
    const m = l.innerType._zod.run(f, p);
    return m instanceof Promise ? m.then((b) => handleDefaultResult(b, l)) : handleDefaultResult(m, l);
  };
});
function handleDefaultResult(u, l) {
  return u.value === void 0 && (u.value = l.defaultValue), u;
}
const $ZodPrefault = /* @__PURE__ */ $constructor("$ZodPrefault", (u, l) => {
  $ZodType.init(u, l), u._zod.optin = "optional", defineLazy(u._zod, "values", () => l.innerType._zod.values), u._zod.parse = (f, p) => (p.direction === "backward" || f.value === void 0 && (f.value = l.defaultValue), l.innerType._zod.run(f, p));
}), $ZodNonOptional = /* @__PURE__ */ $constructor("$ZodNonOptional", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "values", () => {
    const f = l.innerType._zod.values;
    return f ? new Set([...f].filter((p) => p !== void 0)) : void 0;
  }), u._zod.parse = (f, p) => {
    const m = l.innerType._zod.run(f, p);
    return m instanceof Promise ? m.then((b) => handleNonOptionalResult(b, u)) : handleNonOptionalResult(m, u);
  };
});
function handleNonOptionalResult(u, l) {
  return !u.issues.length && u.value === void 0 && u.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: u.value,
    inst: l
  }), u;
}
const $ZodCatch = /* @__PURE__ */ $constructor("$ZodCatch", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "optin", () => l.innerType._zod.optin), defineLazy(u._zod, "optout", () => l.innerType._zod.optout), defineLazy(u._zod, "values", () => l.innerType._zod.values), u._zod.parse = (f, p) => {
    if (p.direction === "backward")
      return l.innerType._zod.run(f, p);
    const m = l.innerType._zod.run(f, p);
    return m instanceof Promise ? m.then((b) => (f.value = b.value, b.issues.length && (f.value = l.catchValue({
      ...f,
      error: {
        issues: b.issues.map((y) => finalizeIssue(y, p, config$1()))
      },
      input: f.value
    }), f.issues = []), f)) : (f.value = m.value, m.issues.length && (f.value = l.catchValue({
      ...f,
      error: {
        issues: m.issues.map((b) => finalizeIssue(b, p, config$1()))
      },
      input: f.value
    }), f.issues = []), f);
  };
}), $ZodPipe = /* @__PURE__ */ $constructor("$ZodPipe", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "values", () => l.in._zod.values), defineLazy(u._zod, "optin", () => l.in._zod.optin), defineLazy(u._zod, "optout", () => l.out._zod.optout), defineLazy(u._zod, "propValues", () => l.in._zod.propValues), u._zod.parse = (f, p) => {
    if (p.direction === "backward") {
      const b = l.out._zod.run(f, p);
      return b instanceof Promise ? b.then((y) => handlePipeResult(y, l.in, p)) : handlePipeResult(b, l.in, p);
    }
    const m = l.in._zod.run(f, p);
    return m instanceof Promise ? m.then((b) => handlePipeResult(b, l.out, p)) : handlePipeResult(m, l.out, p);
  };
});
function handlePipeResult(u, l, f) {
  return u.issues.length ? (u.aborted = !0, u) : l._zod.run({ value: u.value, issues: u.issues }, f);
}
const $ZodReadonly = /* @__PURE__ */ $constructor("$ZodReadonly", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "propValues", () => l.innerType._zod.propValues), defineLazy(u._zod, "values", () => l.innerType._zod.values), defineLazy(u._zod, "optin", () => l.innerType?._zod?.optin), defineLazy(u._zod, "optout", () => l.innerType?._zod?.optout), u._zod.parse = (f, p) => {
    if (p.direction === "backward")
      return l.innerType._zod.run(f, p);
    const m = l.innerType._zod.run(f, p);
    return m instanceof Promise ? m.then(handleReadonlyResult) : handleReadonlyResult(m);
  };
});
function handleReadonlyResult(u) {
  return u.value = Object.freeze(u.value), u;
}
const $ZodLazy = /* @__PURE__ */ $constructor("$ZodLazy", (u, l) => {
  $ZodType.init(u, l), defineLazy(u._zod, "innerType", () => l.getter()), defineLazy(u._zod, "pattern", () => u._zod.innerType?._zod?.pattern), defineLazy(u._zod, "propValues", () => u._zod.innerType?._zod?.propValues), defineLazy(u._zod, "optin", () => u._zod.innerType?._zod?.optin ?? void 0), defineLazy(u._zod, "optout", () => u._zod.innerType?._zod?.optout ?? void 0), u._zod.parse = (f, p) => u._zod.innerType._zod.run(f, p);
}), $ZodCustom = /* @__PURE__ */ $constructor("$ZodCustom", (u, l) => {
  $ZodCheck.init(u, l), $ZodType.init(u, l), u._zod.parse = (f, p) => f, u._zod.check = (f) => {
    const p = f.value, m = l.fn(p);
    if (m instanceof Promise)
      return m.then((b) => handleRefineResult(b, f, p, u));
    handleRefineResult(m, f, p, u);
  };
});
function handleRefineResult(u, l, f, p) {
  if (!u) {
    const m = {
      code: "custom",
      input: f,
      inst: p,
      // incorporates params.error into issue reporting
      path: [...p._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !p._zod.def.abort
      // params: inst._zod.def.params,
    };
    p._zod.def.params && (m.params = p._zod.def.params), l.issues.push(issue(m));
  }
}
var _a$1;
class $ZodRegistry {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(l, ...f) {
    const p = f[0];
    return this._map.set(l, p), p && typeof p == "object" && "id" in p && this._idmap.set(p.id, l), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(l) {
    const f = this._map.get(l);
    return f && typeof f == "object" && "id" in f && this._idmap.delete(f.id), this._map.delete(l), this;
  }
  get(l) {
    const f = l._zod.parent;
    if (f) {
      const p = { ...this.get(f) ?? {} };
      delete p.id;
      const m = { ...p, ...this._map.get(l) };
      return Object.keys(m).length ? m : void 0;
    }
    return this._map.get(l);
  }
  has(l) {
    return this._map.has(l);
  }
}
function registry() {
  return new $ZodRegistry();
}
(_a$1 = globalThis).__zod_globalRegistry ?? (_a$1.__zod_globalRegistry = registry());
const globalRegistry = globalThis.__zod_globalRegistry;
// @__NO_SIDE_EFFECTS__
function _string(u, l) {
  return new u({
    type: "string",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _email(u, l) {
  return new u({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _guid(u, l) {
  return new u({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _uuid(u, l) {
  return new u({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _uuidv4(u, l) {
  return new u({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _uuidv6(u, l) {
  return new u({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _uuidv7(u, l) {
  return new u({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _url(u, l) {
  return new u({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _emoji(u, l) {
  return new u({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _nanoid(u, l) {
  return new u({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _cuid(u, l) {
  return new u({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _cuid2(u, l) {
  return new u({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _ulid(u, l) {
  return new u({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _xid(u, l) {
  return new u({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _ksuid(u, l) {
  return new u({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _ipv4(u, l) {
  return new u({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _ipv6(u, l) {
  return new u({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _cidrv4(u, l) {
  return new u({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _cidrv6(u, l) {
  return new u({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _base64(u, l) {
  return new u({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _base64url(u, l) {
  return new u({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _e164(u, l) {
  return new u({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _jwt(u, l) {
  return new u({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _isoDateTime(u, l) {
  return new u({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _isoDate(u, l) {
  return new u({
    type: "string",
    format: "date",
    check: "string_format",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _isoTime(u, l) {
  return new u({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _isoDuration(u, l) {
  return new u({
    type: "string",
    format: "duration",
    check: "string_format",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _number(u, l) {
  return new u({
    type: "number",
    checks: [],
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _int(u, l) {
  return new u({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _boolean(u, l) {
  return new u({
    type: "boolean",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _null$1(u, l) {
  return new u({
    type: "null",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _unknown(u) {
  return new u({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function _never(u, l) {
  return new u({
    type: "never",
    ...normalizeParams(l)
  });
}
// @__NO_SIDE_EFFECTS__
function _lt(u, l) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(l),
    value: u,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function _lte(u, l) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(l),
    value: u,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function _gt(u, l) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(l),
    value: u,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function _gte(u, l) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(l),
    value: u,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function _multipleOf(u, l) {
  return new $ZodCheckMultipleOf({
    check: "multiple_of",
    ...normalizeParams(l),
    value: u
  });
}
// @__NO_SIDE_EFFECTS__
function _maxLength(u, l) {
  return new $ZodCheckMaxLength({
    check: "max_length",
    ...normalizeParams(l),
    maximum: u
  });
}
// @__NO_SIDE_EFFECTS__
function _minLength(u, l) {
  return new $ZodCheckMinLength({
    check: "min_length",
    ...normalizeParams(l),
    minimum: u
  });
}
// @__NO_SIDE_EFFECTS__
function _length(u, l) {
  return new $ZodCheckLengthEquals({
    check: "length_equals",
    ...normalizeParams(l),
    length: u
  });
}
// @__NO_SIDE_EFFECTS__
function _regex(u, l) {
  return new $ZodCheckRegex({
    check: "string_format",
    format: "regex",
    ...normalizeParams(l),
    pattern: u
  });
}
// @__NO_SIDE_EFFECTS__
function _lowercase(u) {
  return new $ZodCheckLowerCase({
    check: "string_format",
    format: "lowercase",
    ...normalizeParams(u)
  });
}
// @__NO_SIDE_EFFECTS__
function _uppercase(u) {
  return new $ZodCheckUpperCase({
    check: "string_format",
    format: "uppercase",
    ...normalizeParams(u)
  });
}
// @__NO_SIDE_EFFECTS__
function _includes(u, l) {
  return new $ZodCheckIncludes({
    check: "string_format",
    format: "includes",
    ...normalizeParams(l),
    includes: u
  });
}
// @__NO_SIDE_EFFECTS__
function _startsWith(u, l) {
  return new $ZodCheckStartsWith({
    check: "string_format",
    format: "starts_with",
    ...normalizeParams(l),
    prefix: u
  });
}
// @__NO_SIDE_EFFECTS__
function _endsWith(u, l) {
  return new $ZodCheckEndsWith({
    check: "string_format",
    format: "ends_with",
    ...normalizeParams(l),
    suffix: u
  });
}
// @__NO_SIDE_EFFECTS__
function _overwrite(u) {
  return new $ZodCheckOverwrite({
    check: "overwrite",
    tx: u
  });
}
// @__NO_SIDE_EFFECTS__
function _normalize(u) {
  return /* @__PURE__ */ _overwrite((l) => l.normalize(u));
}
// @__NO_SIDE_EFFECTS__
function _trim() {
  return /* @__PURE__ */ _overwrite((u) => u.trim());
}
// @__NO_SIDE_EFFECTS__
function _toLowerCase() {
  return /* @__PURE__ */ _overwrite((u) => u.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function _toUpperCase() {
  return /* @__PURE__ */ _overwrite((u) => u.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function _slugify() {
  return /* @__PURE__ */ _overwrite((u) => slugify(u));
}
// @__NO_SIDE_EFFECTS__
function _array(u, l, f) {
  return new u({
    type: "array",
    element: l,
    // get element() {
    //   return element;
    // },
    ...normalizeParams(f)
  });
}
// @__NO_SIDE_EFFECTS__
function _custom(u, l, f) {
  const p = normalizeParams(f);
  return p.abort ?? (p.abort = !0), new u({
    type: "custom",
    check: "custom",
    fn: l,
    ...p
  });
}
// @__NO_SIDE_EFFECTS__
function _refine(u, l, f) {
  return new u({
    type: "custom",
    check: "custom",
    fn: l,
    ...normalizeParams(f)
  });
}
// @__NO_SIDE_EFFECTS__
function _superRefine(u) {
  const l = /* @__PURE__ */ _check((f) => (f.addIssue = (p) => {
    if (typeof p == "string")
      f.issues.push(issue(p, f.value, l._zod.def));
    else {
      const m = p;
      m.fatal && (m.continue = !1), m.code ?? (m.code = "custom"), m.input ?? (m.input = f.value), m.inst ?? (m.inst = l), m.continue ?? (m.continue = !l._zod.def.abort), f.issues.push(issue(m));
    }
  }, u(f.value, f)));
  return l;
}
// @__NO_SIDE_EFFECTS__
function _check(u, l) {
  const f = new $ZodCheck({
    check: "custom",
    ...normalizeParams(l)
  });
  return f._zod.check = u, f;
}
function initializeContext(u) {
  let l = u?.target ?? "draft-2020-12";
  return l === "draft-4" && (l = "draft-04"), l === "draft-7" && (l = "draft-07"), {
    processors: u.processors ?? {},
    metadataRegistry: u?.metadata ?? globalRegistry,
    target: l,
    unrepresentable: u?.unrepresentable ?? "throw",
    override: u?.override ?? (() => {
    }),
    io: u?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: u?.cycles ?? "ref",
    reused: u?.reused ?? "inline",
    external: u?.external ?? void 0
  };
}
function process$2(u, l, f = { path: [], schemaPath: [] }) {
  var p;
  const m = u._zod.def, b = l.seen.get(u);
  if (b)
    return b.count++, f.schemaPath.includes(u) && (b.cycle = f.path), b.schema;
  const y = { schema: {}, count: 1, cycle: void 0, path: f.path };
  l.seen.set(u, y);
  const v = u._zod.toJSONSchema?.();
  if (v)
    y.schema = v;
  else {
    const P = {
      ...f,
      schemaPath: [...f.schemaPath, u],
      path: f.path
    };
    if (u._zod.processJSONSchema)
      u._zod.processJSONSchema(l, y.schema, P);
    else {
      const x = y.schema, S = l.processors[m.type];
      if (!S)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${m.type}`);
      S(u, l, x, P);
    }
    const k = u._zod.parent;
    k && (y.ref || (y.ref = k), process$2(k, l, P), l.seen.get(k).isParent = !0);
  }
  const $ = l.metadataRegistry.get(u);
  return $ && Object.assign(y.schema, $), l.io === "input" && isTransforming(u) && (delete y.schema.examples, delete y.schema.default), l.io === "input" && y.schema._prefault && ((p = y.schema).default ?? (p.default = y.schema._prefault)), delete y.schema._prefault, l.seen.get(u).schema;
}
function extractDefs(u, l) {
  const f = u.seen.get(l);
  if (!f)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const p = /* @__PURE__ */ new Map();
  for (const y of u.seen.entries()) {
    const v = u.metadataRegistry.get(y[0])?.id;
    if (v) {
      const $ = p.get(v);
      if ($ && $ !== y[0])
        throw new Error(`Duplicate schema id "${v}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      p.set(v, y[0]);
    }
  }
  const m = (y) => {
    const v = u.target === "draft-2020-12" ? "$defs" : "definitions";
    if (u.external) {
      const k = u.external.registry.get(y[0])?.id, x = u.external.uri ?? ((T) => T);
      if (k)
        return { ref: x(k) };
      const S = y[1].defId ?? y[1].schema.id ?? `schema${u.counter++}`;
      return y[1].defId = S, { defId: S, ref: `${x("__shared")}#/${v}/${S}` };
    }
    if (y[1] === f)
      return { ref: "#" };
    const w = `#/${v}/`, P = y[1].schema.id ?? `__schema${u.counter++}`;
    return { defId: P, ref: w + P };
  }, b = (y) => {
    if (y[1].schema.$ref)
      return;
    const v = y[1], { ref: $, defId: w } = m(y);
    v.def = { ...v.schema }, w && (v.defId = w);
    const P = v.schema;
    for (const k in P)
      delete P[k];
    P.$ref = $;
  };
  if (u.cycles === "throw")
    for (const y of u.seen.entries()) {
      const v = y[1];
      if (v.cycle)
        throw new Error(`Cycle detected: #/${v.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const y of u.seen.entries()) {
    const v = y[1];
    if (l === y[0]) {
      b(y);
      continue;
    }
    if (u.external) {
      const w = u.external.registry.get(y[0])?.id;
      if (l !== y[0] && w) {
        b(y);
        continue;
      }
    }
    if (u.metadataRegistry.get(y[0])?.id) {
      b(y);
      continue;
    }
    if (v.cycle) {
      b(y);
      continue;
    }
    if (v.count > 1 && u.reused === "ref") {
      b(y);
      continue;
    }
  }
}
function finalize(u, l) {
  const f = u.seen.get(l);
  if (!f)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const p = (y) => {
    const v = u.seen.get(y);
    if (v.ref === null)
      return;
    const $ = v.def ?? v.schema, w = { ...$ }, P = v.ref;
    if (v.ref = null, P) {
      p(P);
      const x = u.seen.get(P), S = x.schema;
      if (S.$ref && (u.target === "draft-07" || u.target === "draft-04" || u.target === "openapi-3.0") ? ($.allOf = $.allOf ?? [], $.allOf.push(S)) : Object.assign($, S), Object.assign($, w), y._zod.parent === P)
        for (const M in $)
          M === "$ref" || M === "allOf" || M in w || delete $[M];
      if (S.$ref && x.def)
        for (const M in $)
          M === "$ref" || M === "allOf" || M in x.def && JSON.stringify($[M]) === JSON.stringify(x.def[M]) && delete $[M];
    }
    const k = y._zod.parent;
    if (k && k !== P) {
      p(k);
      const x = u.seen.get(k);
      if (x?.schema.$ref && ($.$ref = x.schema.$ref, x.def))
        for (const S in $)
          S === "$ref" || S === "allOf" || S in x.def && JSON.stringify($[S]) === JSON.stringify(x.def[S]) && delete $[S];
    }
    u.override({
      zodSchema: y,
      jsonSchema: $,
      path: v.path ?? []
    });
  };
  for (const y of [...u.seen.entries()].reverse())
    p(y[0]);
  const m = {};
  if (u.target === "draft-2020-12" ? m.$schema = "https://json-schema.org/draft/2020-12/schema" : u.target === "draft-07" ? m.$schema = "http://json-schema.org/draft-07/schema#" : u.target === "draft-04" ? m.$schema = "http://json-schema.org/draft-04/schema#" : u.target, u.external?.uri) {
    const y = u.external.registry.get(l)?.id;
    if (!y)
      throw new Error("Schema is missing an `id` property");
    m.$id = u.external.uri(y);
  }
  Object.assign(m, f.def ?? f.schema);
  const b = u.external?.defs ?? {};
  for (const y of u.seen.entries()) {
    const v = y[1];
    v.def && v.defId && (b[v.defId] = v.def);
  }
  u.external || Object.keys(b).length > 0 && (u.target === "draft-2020-12" ? m.$defs = b : m.definitions = b);
  try {
    const y = JSON.parse(JSON.stringify(m));
    return Object.defineProperty(y, "~standard", {
      value: {
        ...l["~standard"],
        jsonSchema: {
          input: createStandardJSONSchemaMethod(l, "input", u.processors),
          output: createStandardJSONSchemaMethod(l, "output", u.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), y;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function isTransforming(u, l) {
  const f = l ?? { seen: /* @__PURE__ */ new Set() };
  if (f.seen.has(u))
    return !1;
  f.seen.add(u);
  const p = u._zod.def;
  if (p.type === "transform")
    return !0;
  if (p.type === "array")
    return isTransforming(p.element, f);
  if (p.type === "set")
    return isTransforming(p.valueType, f);
  if (p.type === "lazy")
    return isTransforming(p.getter(), f);
  if (p.type === "promise" || p.type === "optional" || p.type === "nonoptional" || p.type === "nullable" || p.type === "readonly" || p.type === "default" || p.type === "prefault")
    return isTransforming(p.innerType, f);
  if (p.type === "intersection")
    return isTransforming(p.left, f) || isTransforming(p.right, f);
  if (p.type === "record" || p.type === "map")
    return isTransforming(p.keyType, f) || isTransforming(p.valueType, f);
  if (p.type === "pipe")
    return isTransforming(p.in, f) || isTransforming(p.out, f);
  if (p.type === "object") {
    for (const m in p.shape)
      if (isTransforming(p.shape[m], f))
        return !0;
    return !1;
  }
  if (p.type === "union") {
    for (const m of p.options)
      if (isTransforming(m, f))
        return !0;
    return !1;
  }
  if (p.type === "tuple") {
    for (const m of p.items)
      if (isTransforming(m, f))
        return !0;
    return !!(p.rest && isTransforming(p.rest, f));
  }
  return !1;
}
const createToJSONSchemaMethod = (u, l = {}) => (f) => {
  const p = initializeContext({ ...f, processors: l });
  return process$2(u, p), extractDefs(p, u), finalize(p, u);
}, createStandardJSONSchemaMethod = (u, l, f = {}) => (p) => {
  const { libraryOptions: m, target: b } = p ?? {}, y = initializeContext({ ...m ?? {}, target: b, io: l, processors: f });
  return process$2(u, y), extractDefs(y, u), finalize(y, u);
}, formatMap = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, stringProcessor = (u, l, f, p) => {
  const m = f;
  m.type = "string";
  const { minimum: b, maximum: y, format: v, patterns: $, contentEncoding: w } = u._zod.bag;
  if (typeof b == "number" && (m.minLength = b), typeof y == "number" && (m.maxLength = y), v && (m.format = formatMap[v] ?? v, m.format === "" && delete m.format, v === "time" && delete m.format), w && (m.contentEncoding = w), $ && $.size > 0) {
    const P = [...$];
    P.length === 1 ? m.pattern = P[0].source : P.length > 1 && (m.allOf = [
      ...P.map((k) => ({
        ...l.target === "draft-07" || l.target === "draft-04" || l.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: k.source
      }))
    ]);
  }
}, numberProcessor = (u, l, f, p) => {
  const m = f, { minimum: b, maximum: y, format: v, multipleOf: $, exclusiveMaximum: w, exclusiveMinimum: P } = u._zod.bag;
  typeof v == "string" && v.includes("int") ? m.type = "integer" : m.type = "number", typeof P == "number" && (l.target === "draft-04" || l.target === "openapi-3.0" ? (m.minimum = P, m.exclusiveMinimum = !0) : m.exclusiveMinimum = P), typeof b == "number" && (m.minimum = b, typeof P == "number" && l.target !== "draft-04" && (P >= b ? delete m.minimum : delete m.exclusiveMinimum)), typeof w == "number" && (l.target === "draft-04" || l.target === "openapi-3.0" ? (m.maximum = w, m.exclusiveMaximum = !0) : m.exclusiveMaximum = w), typeof y == "number" && (m.maximum = y, typeof w == "number" && l.target !== "draft-04" && (w <= y ? delete m.maximum : delete m.exclusiveMaximum)), typeof $ == "number" && (m.multipleOf = $);
}, booleanProcessor = (u, l, f, p) => {
  f.type = "boolean";
}, bigintProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, symbolProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, nullProcessor = (u, l, f, p) => {
  l.target === "openapi-3.0" ? (f.type = "string", f.nullable = !0, f.enum = [null]) : f.type = "null";
}, undefinedProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, voidProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, neverProcessor = (u, l, f, p) => {
  f.not = {};
}, anyProcessor = (u, l, f, p) => {
}, unknownProcessor = (u, l, f, p) => {
}, dateProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, enumProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = getEnumValues(m.entries);
  b.every((y) => typeof y == "number") && (f.type = "number"), b.every((y) => typeof y == "string") && (f.type = "string"), f.enum = b;
}, literalProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = [];
  for (const y of m.values)
    if (y === void 0) {
      if (l.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof y == "bigint") {
      if (l.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      b.push(Number(y));
    } else
      b.push(y);
  if (b.length !== 0) if (b.length === 1) {
    const y = b[0];
    f.type = y === null ? "null" : typeof y, l.target === "draft-04" || l.target === "openapi-3.0" ? f.enum = [y] : f.const = y;
  } else
    b.every((y) => typeof y == "number") && (f.type = "number"), b.every((y) => typeof y == "string") && (f.type = "string"), b.every((y) => typeof y == "boolean") && (f.type = "boolean"), b.every((y) => y === null) && (f.type = "null"), f.enum = b;
}, nanProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, templateLiteralProcessor = (u, l, f, p) => {
  const m = f, b = u._zod.pattern;
  if (!b)
    throw new Error("Pattern not found in template literal");
  m.type = "string", m.pattern = b.source;
}, fileProcessor = (u, l, f, p) => {
  const m = f, b = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: y, maximum: v, mime: $ } = u._zod.bag;
  y !== void 0 && (b.minLength = y), v !== void 0 && (b.maxLength = v), $ ? $.length === 1 ? (b.contentMediaType = $[0], Object.assign(m, b)) : (Object.assign(m, b), m.anyOf = $.map((w) => ({ contentMediaType: w }))) : Object.assign(m, b);
}, successProcessor = (u, l, f, p) => {
  f.type = "boolean";
}, customProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, functionProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, transformProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, mapProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, setProcessor = (u, l, f, p) => {
  if (l.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, arrayProcessor = (u, l, f, p) => {
  const m = f, b = u._zod.def, { minimum: y, maximum: v } = u._zod.bag;
  typeof y == "number" && (m.minItems = y), typeof v == "number" && (m.maxItems = v), m.type = "array", m.items = process$2(b.element, l, { ...p, path: [...p.path, "items"] });
}, objectProcessor = (u, l, f, p) => {
  const m = f, b = u._zod.def;
  m.type = "object", m.properties = {};
  const y = b.shape;
  for (const w in y)
    m.properties[w] = process$2(y[w], l, {
      ...p,
      path: [...p.path, "properties", w]
    });
  const v = new Set(Object.keys(y)), $ = new Set([...v].filter((w) => {
    const P = b.shape[w]._zod;
    return l.io === "input" ? P.optin === void 0 : P.optout === void 0;
  }));
  $.size > 0 && (m.required = Array.from($)), b.catchall?._zod.def.type === "never" ? m.additionalProperties = !1 : b.catchall ? b.catchall && (m.additionalProperties = process$2(b.catchall, l, {
    ...p,
    path: [...p.path, "additionalProperties"]
  })) : l.io === "output" && (m.additionalProperties = !1);
}, unionProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = m.inclusive === !1, y = m.options.map((v, $) => process$2(v, l, {
    ...p,
    path: [...p.path, b ? "oneOf" : "anyOf", $]
  }));
  b ? f.oneOf = y : f.anyOf = y;
}, intersectionProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = process$2(m.left, l, {
    ...p,
    path: [...p.path, "allOf", 0]
  }), y = process$2(m.right, l, {
    ...p,
    path: [...p.path, "allOf", 1]
  }), v = (w) => "allOf" in w && Object.keys(w).length === 1, $ = [
    ...v(b) ? b.allOf : [b],
    ...v(y) ? y.allOf : [y]
  ];
  f.allOf = $;
}, tupleProcessor = (u, l, f, p) => {
  const m = f, b = u._zod.def;
  m.type = "array";
  const y = l.target === "draft-2020-12" ? "prefixItems" : "items", v = l.target === "draft-2020-12" || l.target === "openapi-3.0" ? "items" : "additionalItems", $ = b.items.map((x, S) => process$2(x, l, {
    ...p,
    path: [...p.path, y, S]
  })), w = b.rest ? process$2(b.rest, l, {
    ...p,
    path: [...p.path, v, ...l.target === "openapi-3.0" ? [b.items.length] : []]
  }) : null;
  l.target === "draft-2020-12" ? (m.prefixItems = $, w && (m.items = w)) : l.target === "openapi-3.0" ? (m.items = {
    anyOf: $
  }, w && m.items.anyOf.push(w), m.minItems = $.length, w || (m.maxItems = $.length)) : (m.items = $, w && (m.additionalItems = w));
  const { minimum: P, maximum: k } = u._zod.bag;
  typeof P == "number" && (m.minItems = P), typeof k == "number" && (m.maxItems = k);
}, recordProcessor = (u, l, f, p) => {
  const m = f, b = u._zod.def;
  m.type = "object";
  const y = b.keyType, $ = y._zod.bag?.patterns;
  if (b.mode === "loose" && $ && $.size > 0) {
    const P = process$2(b.valueType, l, {
      ...p,
      path: [...p.path, "patternProperties", "*"]
    });
    m.patternProperties = {};
    for (const k of $)
      m.patternProperties[k.source] = P;
  } else
    (l.target === "draft-07" || l.target === "draft-2020-12") && (m.propertyNames = process$2(b.keyType, l, {
      ...p,
      path: [...p.path, "propertyNames"]
    })), m.additionalProperties = process$2(b.valueType, l, {
      ...p,
      path: [...p.path, "additionalProperties"]
    });
  const w = y._zod.values;
  if (w) {
    const P = [...w].filter((k) => typeof k == "string" || typeof k == "number");
    P.length > 0 && (m.required = P);
  }
}, nullableProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = process$2(m.innerType, l, p), y = l.seen.get(u);
  l.target === "openapi-3.0" ? (y.ref = m.innerType, f.nullable = !0) : f.anyOf = [b, { type: "null" }];
}, nonoptionalProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType;
}, defaultProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType, f.default = JSON.parse(JSON.stringify(m.defaultValue));
}, prefaultProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType, l.io === "input" && (f._prefault = JSON.parse(JSON.stringify(m.defaultValue)));
}, catchProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType;
  let y;
  try {
    y = m.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  f.default = y;
}, pipeProcessor = (u, l, f, p) => {
  const m = u._zod.def, b = l.io === "input" ? m.in._zod.def.type === "transform" ? m.out : m.in : m.out;
  process$2(b, l, p);
  const y = l.seen.get(u);
  y.ref = b;
}, readonlyProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType, f.readOnly = !0;
}, promiseProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType;
}, optionalProcessor = (u, l, f, p) => {
  const m = u._zod.def;
  process$2(m.innerType, l, p);
  const b = l.seen.get(u);
  b.ref = m.innerType;
}, lazyProcessor = (u, l, f, p) => {
  const m = u._zod.innerType;
  process$2(m, l, p);
  const b = l.seen.get(u);
  b.ref = m;
}, allProcessors = {
  string: stringProcessor,
  number: numberProcessor,
  boolean: booleanProcessor,
  bigint: bigintProcessor,
  symbol: symbolProcessor,
  null: nullProcessor,
  undefined: undefinedProcessor,
  void: voidProcessor,
  never: neverProcessor,
  any: anyProcessor,
  unknown: unknownProcessor,
  date: dateProcessor,
  enum: enumProcessor,
  literal: literalProcessor,
  nan: nanProcessor,
  template_literal: templateLiteralProcessor,
  file: fileProcessor,
  success: successProcessor,
  custom: customProcessor,
  function: functionProcessor,
  transform: transformProcessor,
  map: mapProcessor,
  set: setProcessor,
  array: arrayProcessor,
  object: objectProcessor,
  union: unionProcessor,
  intersection: intersectionProcessor,
  tuple: tupleProcessor,
  record: recordProcessor,
  nullable: nullableProcessor,
  nonoptional: nonoptionalProcessor,
  default: defaultProcessor,
  prefault: prefaultProcessor,
  catch: catchProcessor,
  pipe: pipeProcessor,
  readonly: readonlyProcessor,
  promise: promiseProcessor,
  optional: optionalProcessor,
  lazy: lazyProcessor
};
function toJSONSchema(u, l) {
  if ("_idmap" in u) {
    const p = u, m = initializeContext({ ...l, processors: allProcessors }), b = {};
    for (const $ of p._idmap.entries()) {
      const [w, P] = $;
      process$2(P, m);
    }
    const y = {}, v = {
      registry: p,
      uri: l?.uri,
      defs: b
    };
    m.external = v;
    for (const $ of p._idmap.entries()) {
      const [w, P] = $;
      extractDefs(m, P), y[w] = finalize(m, P);
    }
    if (Object.keys(b).length > 0) {
      const $ = m.target === "draft-2020-12" ? "$defs" : "definitions";
      y.__shared = {
        [$]: b
      };
    }
    return { schemas: y };
  }
  const f = initializeContext({ ...l, processors: allProcessors });
  return process$2(u, f), extractDefs(f, u), finalize(f, u);
}
const ZodISODateTime = /* @__PURE__ */ $constructor("ZodISODateTime", (u, l) => {
  $ZodISODateTime.init(u, l), ZodStringFormat.init(u, l);
});
function datetime(u) {
  return /* @__PURE__ */ _isoDateTime(ZodISODateTime, u);
}
const ZodISODate = /* @__PURE__ */ $constructor("ZodISODate", (u, l) => {
  $ZodISODate.init(u, l), ZodStringFormat.init(u, l);
});
function date(u) {
  return /* @__PURE__ */ _isoDate(ZodISODate, u);
}
const ZodISOTime = /* @__PURE__ */ $constructor("ZodISOTime", (u, l) => {
  $ZodISOTime.init(u, l), ZodStringFormat.init(u, l);
});
function time(u) {
  return /* @__PURE__ */ _isoTime(ZodISOTime, u);
}
const ZodISODuration = /* @__PURE__ */ $constructor("ZodISODuration", (u, l) => {
  $ZodISODuration.init(u, l), ZodStringFormat.init(u, l);
});
function duration$2(u) {
  return /* @__PURE__ */ _isoDuration(ZodISODuration, u);
}
const initializer = (u, l) => {
  $ZodError.init(u, l), u.name = "ZodError", Object.defineProperties(u, {
    format: {
      value: (f) => formatError$1(u, f)
      // enumerable: false,
    },
    flatten: {
      value: (f) => flattenError(u, f)
      // enumerable: false,
    },
    addIssue: {
      value: (f) => {
        u.issues.push(f), u.message = JSON.stringify(u.issues, jsonStringifyReplacer, 2);
      }
      // enumerable: false,
    },
    addIssues: {
      value: (f) => {
        u.issues.push(...f), u.message = JSON.stringify(u.issues, jsonStringifyReplacer, 2);
      }
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return u.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, ZodRealError = $constructor("ZodError", initializer, {
  Parent: Error
}), parse$6 = /* @__PURE__ */ _parse$1(ZodRealError), parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError), safeParse = /* @__PURE__ */ _safeParse(ZodRealError), safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError), encode$5 = /* @__PURE__ */ _encode(ZodRealError), decode$4 = /* @__PURE__ */ _decode(ZodRealError), encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError), decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError), safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError), safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError), safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError), safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError), ZodType = /* @__PURE__ */ $constructor("ZodType", (u, l) => ($ZodType.init(u, l), Object.assign(u["~standard"], {
  jsonSchema: {
    input: createStandardJSONSchemaMethod(u, "input"),
    output: createStandardJSONSchemaMethod(u, "output")
  }
}), u.toJSONSchema = createToJSONSchemaMethod(u, {}), u.def = l, u.type = l.type, Object.defineProperty(u, "_def", { value: l }), u.check = (...f) => u.clone(mergeDefs(l, {
  checks: [
    ...l.checks ?? [],
    ...f.map((p) => typeof p == "function" ? { _zod: { check: p, def: { check: "custom" }, onattach: [] } } : p)
  ]
}), {
  parent: !0
}), u.with = u.check, u.clone = (f, p) => clone$1(u, f, p), u.brand = () => u, u.register = ((f, p) => (f.add(u, p), u)), u.parse = (f, p) => parse$6(u, f, p, { callee: u.parse }), u.safeParse = (f, p) => safeParse(u, f, p), u.parseAsync = async (f, p) => parseAsync(u, f, p, { callee: u.parseAsync }), u.safeParseAsync = async (f, p) => safeParseAsync(u, f, p), u.spa = u.safeParseAsync, u.encode = (f, p) => encode$5(u, f, p), u.decode = (f, p) => decode$4(u, f, p), u.encodeAsync = async (f, p) => encodeAsync(u, f, p), u.decodeAsync = async (f, p) => decodeAsync(u, f, p), u.safeEncode = (f, p) => safeEncode(u, f, p), u.safeDecode = (f, p) => safeDecode(u, f, p), u.safeEncodeAsync = async (f, p) => safeEncodeAsync(u, f, p), u.safeDecodeAsync = async (f, p) => safeDecodeAsync(u, f, p), u.refine = (f, p) => u.check(refine(f, p)), u.superRefine = (f) => u.check(superRefine(f)), u.overwrite = (f) => u.check(/* @__PURE__ */ _overwrite(f)), u.optional = () => optional(u), u.exactOptional = () => exactOptional(u), u.nullable = () => nullable(u), u.nullish = () => optional(nullable(u)), u.nonoptional = (f) => nonoptional(u, f), u.array = () => array$2(u), u.or = (f) => union([u, f]), u.and = (f) => intersection(u, f), u.transform = (f) => pipe(u, transform$1(f)), u.default = (f) => _default$1(u, f), u.prefault = (f) => prefault(u, f), u.catch = (f) => _catch(u, f), u.pipe = (f) => pipe(u, f), u.readonly = () => readonly$1(u), u.describe = (f) => {
  const p = u.clone();
  return globalRegistry.add(p, { description: f }), p;
}, Object.defineProperty(u, "description", {
  get() {
    return globalRegistry.get(u)?.description;
  },
  configurable: !0
}), u.meta = (...f) => {
  if (f.length === 0)
    return globalRegistry.get(u);
  const p = u.clone();
  return globalRegistry.add(p, f[0]), p;
}, u.isOptional = () => u.safeParse(void 0).success, u.isNullable = () => u.safeParse(null).success, u.apply = (f) => f(u), u)), _ZodString = /* @__PURE__ */ $constructor("_ZodString", (u, l) => {
  $ZodString.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (p, m, b) => stringProcessor(u, p, m);
  const f = u._zod.bag;
  u.format = f.format ?? null, u.minLength = f.minimum ?? null, u.maxLength = f.maximum ?? null, u.regex = (...p) => u.check(/* @__PURE__ */ _regex(...p)), u.includes = (...p) => u.check(/* @__PURE__ */ _includes(...p)), u.startsWith = (...p) => u.check(/* @__PURE__ */ _startsWith(...p)), u.endsWith = (...p) => u.check(/* @__PURE__ */ _endsWith(...p)), u.min = (...p) => u.check(/* @__PURE__ */ _minLength(...p)), u.max = (...p) => u.check(/* @__PURE__ */ _maxLength(...p)), u.length = (...p) => u.check(/* @__PURE__ */ _length(...p)), u.nonempty = (...p) => u.check(/* @__PURE__ */ _minLength(1, ...p)), u.lowercase = (p) => u.check(/* @__PURE__ */ _lowercase(p)), u.uppercase = (p) => u.check(/* @__PURE__ */ _uppercase(p)), u.trim = () => u.check(/* @__PURE__ */ _trim()), u.normalize = (...p) => u.check(/* @__PURE__ */ _normalize(...p)), u.toLowerCase = () => u.check(/* @__PURE__ */ _toLowerCase()), u.toUpperCase = () => u.check(/* @__PURE__ */ _toUpperCase()), u.slugify = () => u.check(/* @__PURE__ */ _slugify());
}), ZodString = /* @__PURE__ */ $constructor("ZodString", (u, l) => {
  $ZodString.init(u, l), _ZodString.init(u, l), u.email = (f) => u.check(/* @__PURE__ */ _email(ZodEmail, f)), u.url = (f) => u.check(/* @__PURE__ */ _url(ZodURL, f)), u.jwt = (f) => u.check(/* @__PURE__ */ _jwt(ZodJWT, f)), u.emoji = (f) => u.check(/* @__PURE__ */ _emoji(ZodEmoji, f)), u.guid = (f) => u.check(/* @__PURE__ */ _guid(ZodGUID, f)), u.uuid = (f) => u.check(/* @__PURE__ */ _uuid(ZodUUID, f)), u.uuidv4 = (f) => u.check(/* @__PURE__ */ _uuidv4(ZodUUID, f)), u.uuidv6 = (f) => u.check(/* @__PURE__ */ _uuidv6(ZodUUID, f)), u.uuidv7 = (f) => u.check(/* @__PURE__ */ _uuidv7(ZodUUID, f)), u.nanoid = (f) => u.check(/* @__PURE__ */ _nanoid(ZodNanoID, f)), u.guid = (f) => u.check(/* @__PURE__ */ _guid(ZodGUID, f)), u.cuid = (f) => u.check(/* @__PURE__ */ _cuid(ZodCUID, f)), u.cuid2 = (f) => u.check(/* @__PURE__ */ _cuid2(ZodCUID2, f)), u.ulid = (f) => u.check(/* @__PURE__ */ _ulid(ZodULID, f)), u.base64 = (f) => u.check(/* @__PURE__ */ _base64(ZodBase64, f)), u.base64url = (f) => u.check(/* @__PURE__ */ _base64url(ZodBase64URL, f)), u.xid = (f) => u.check(/* @__PURE__ */ _xid(ZodXID, f)), u.ksuid = (f) => u.check(/* @__PURE__ */ _ksuid(ZodKSUID, f)), u.ipv4 = (f) => u.check(/* @__PURE__ */ _ipv4(ZodIPv4, f)), u.ipv6 = (f) => u.check(/* @__PURE__ */ _ipv6(ZodIPv6, f)), u.cidrv4 = (f) => u.check(/* @__PURE__ */ _cidrv4(ZodCIDRv4, f)), u.cidrv6 = (f) => u.check(/* @__PURE__ */ _cidrv6(ZodCIDRv6, f)), u.e164 = (f) => u.check(/* @__PURE__ */ _e164(ZodE164, f)), u.datetime = (f) => u.check(datetime(f)), u.date = (f) => u.check(date(f)), u.time = (f) => u.check(time(f)), u.duration = (f) => u.check(duration$2(f));
});
function string(u) {
  return /* @__PURE__ */ _string(ZodString, u);
}
const ZodStringFormat = /* @__PURE__ */ $constructor("ZodStringFormat", (u, l) => {
  $ZodStringFormat.init(u, l), _ZodString.init(u, l);
}), ZodEmail = /* @__PURE__ */ $constructor("ZodEmail", (u, l) => {
  $ZodEmail.init(u, l), ZodStringFormat.init(u, l);
}), ZodGUID = /* @__PURE__ */ $constructor("ZodGUID", (u, l) => {
  $ZodGUID.init(u, l), ZodStringFormat.init(u, l);
}), ZodUUID = /* @__PURE__ */ $constructor("ZodUUID", (u, l) => {
  $ZodUUID.init(u, l), ZodStringFormat.init(u, l);
}), ZodURL = /* @__PURE__ */ $constructor("ZodURL", (u, l) => {
  $ZodURL.init(u, l), ZodStringFormat.init(u, l);
}), ZodEmoji = /* @__PURE__ */ $constructor("ZodEmoji", (u, l) => {
  $ZodEmoji.init(u, l), ZodStringFormat.init(u, l);
}), ZodNanoID = /* @__PURE__ */ $constructor("ZodNanoID", (u, l) => {
  $ZodNanoID.init(u, l), ZodStringFormat.init(u, l);
}), ZodCUID = /* @__PURE__ */ $constructor("ZodCUID", (u, l) => {
  $ZodCUID.init(u, l), ZodStringFormat.init(u, l);
}), ZodCUID2 = /* @__PURE__ */ $constructor("ZodCUID2", (u, l) => {
  $ZodCUID2.init(u, l), ZodStringFormat.init(u, l);
}), ZodULID = /* @__PURE__ */ $constructor("ZodULID", (u, l) => {
  $ZodULID.init(u, l), ZodStringFormat.init(u, l);
}), ZodXID = /* @__PURE__ */ $constructor("ZodXID", (u, l) => {
  $ZodXID.init(u, l), ZodStringFormat.init(u, l);
}), ZodKSUID = /* @__PURE__ */ $constructor("ZodKSUID", (u, l) => {
  $ZodKSUID.init(u, l), ZodStringFormat.init(u, l);
}), ZodIPv4 = /* @__PURE__ */ $constructor("ZodIPv4", (u, l) => {
  $ZodIPv4.init(u, l), ZodStringFormat.init(u, l);
}), ZodIPv6 = /* @__PURE__ */ $constructor("ZodIPv6", (u, l) => {
  $ZodIPv6.init(u, l), ZodStringFormat.init(u, l);
}), ZodCIDRv4 = /* @__PURE__ */ $constructor("ZodCIDRv4", (u, l) => {
  $ZodCIDRv4.init(u, l), ZodStringFormat.init(u, l);
}), ZodCIDRv6 = /* @__PURE__ */ $constructor("ZodCIDRv6", (u, l) => {
  $ZodCIDRv6.init(u, l), ZodStringFormat.init(u, l);
}), ZodBase64 = /* @__PURE__ */ $constructor("ZodBase64", (u, l) => {
  $ZodBase64.init(u, l), ZodStringFormat.init(u, l);
}), ZodBase64URL = /* @__PURE__ */ $constructor("ZodBase64URL", (u, l) => {
  $ZodBase64URL.init(u, l), ZodStringFormat.init(u, l);
}), ZodE164 = /* @__PURE__ */ $constructor("ZodE164", (u, l) => {
  $ZodE164.init(u, l), ZodStringFormat.init(u, l);
}), ZodJWT = /* @__PURE__ */ $constructor("ZodJWT", (u, l) => {
  $ZodJWT.init(u, l), ZodStringFormat.init(u, l);
}), ZodNumber = /* @__PURE__ */ $constructor("ZodNumber", (u, l) => {
  $ZodNumber.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (p, m, b) => numberProcessor(u, p, m), u.gt = (p, m) => u.check(/* @__PURE__ */ _gt(p, m)), u.gte = (p, m) => u.check(/* @__PURE__ */ _gte(p, m)), u.min = (p, m) => u.check(/* @__PURE__ */ _gte(p, m)), u.lt = (p, m) => u.check(/* @__PURE__ */ _lt(p, m)), u.lte = (p, m) => u.check(/* @__PURE__ */ _lte(p, m)), u.max = (p, m) => u.check(/* @__PURE__ */ _lte(p, m)), u.int = (p) => u.check(int(p)), u.safe = (p) => u.check(int(p)), u.positive = (p) => u.check(/* @__PURE__ */ _gt(0, p)), u.nonnegative = (p) => u.check(/* @__PURE__ */ _gte(0, p)), u.negative = (p) => u.check(/* @__PURE__ */ _lt(0, p)), u.nonpositive = (p) => u.check(/* @__PURE__ */ _lte(0, p)), u.multipleOf = (p, m) => u.check(/* @__PURE__ */ _multipleOf(p, m)), u.step = (p, m) => u.check(/* @__PURE__ */ _multipleOf(p, m)), u.finite = () => u;
  const f = u._zod.bag;
  u.minValue = Math.max(f.minimum ?? Number.NEGATIVE_INFINITY, f.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, u.maxValue = Math.min(f.maximum ?? Number.POSITIVE_INFINITY, f.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, u.isInt = (f.format ?? "").includes("int") || Number.isSafeInteger(f.multipleOf ?? 0.5), u.isFinite = !0, u.format = f.format ?? null;
});
function number(u) {
  return /* @__PURE__ */ _number(ZodNumber, u);
}
const ZodNumberFormat = /* @__PURE__ */ $constructor("ZodNumberFormat", (u, l) => {
  $ZodNumberFormat.init(u, l), ZodNumber.init(u, l);
});
function int(u) {
  return /* @__PURE__ */ _int(ZodNumberFormat, u);
}
const ZodBoolean = /* @__PURE__ */ $constructor("ZodBoolean", (u, l) => {
  $ZodBoolean.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => booleanProcessor(u, f, p);
});
function boolean(u) {
  return /* @__PURE__ */ _boolean(ZodBoolean, u);
}
const ZodNull = /* @__PURE__ */ $constructor("ZodNull", (u, l) => {
  $ZodNull.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => nullProcessor(u, f, p);
});
function _null(u) {
  return /* @__PURE__ */ _null$1(ZodNull, u);
}
const ZodUnknown = /* @__PURE__ */ $constructor("ZodUnknown", (u, l) => {
  $ZodUnknown.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => unknownProcessor();
});
function unknown() {
  return /* @__PURE__ */ _unknown(ZodUnknown);
}
const ZodNever = /* @__PURE__ */ $constructor("ZodNever", (u, l) => {
  $ZodNever.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => neverProcessor(u, f, p);
});
function never(u) {
  return /* @__PURE__ */ _never(ZodNever, u);
}
const ZodArray = /* @__PURE__ */ $constructor("ZodArray", (u, l) => {
  $ZodArray.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => arrayProcessor(u, f, p, m), u.element = l.element, u.min = (f, p) => u.check(/* @__PURE__ */ _minLength(f, p)), u.nonempty = (f) => u.check(/* @__PURE__ */ _minLength(1, f)), u.max = (f, p) => u.check(/* @__PURE__ */ _maxLength(f, p)), u.length = (f, p) => u.check(/* @__PURE__ */ _length(f, p)), u.unwrap = () => u.element;
});
function array$2(u, l) {
  return /* @__PURE__ */ _array(ZodArray, u, l);
}
const ZodObject = /* @__PURE__ */ $constructor("ZodObject", (u, l) => {
  $ZodObjectJIT.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => objectProcessor(u, f, p, m), defineLazy(u, "shape", () => l.shape), u.keyof = () => _enum(Object.keys(u._zod.def.shape)), u.catchall = (f) => u.clone({ ...u._zod.def, catchall: f }), u.passthrough = () => u.clone({ ...u._zod.def, catchall: unknown() }), u.loose = () => u.clone({ ...u._zod.def, catchall: unknown() }), u.strict = () => u.clone({ ...u._zod.def, catchall: never() }), u.strip = () => u.clone({ ...u._zod.def, catchall: void 0 }), u.extend = (f) => extend(u, f), u.safeExtend = (f) => safeExtend(u, f), u.merge = (f) => merge(u, f), u.pick = (f) => pick$2(u, f), u.omit = (f) => omit(u, f), u.partial = (...f) => partial(ZodOptional, u, f[0]), u.required = (...f) => required(ZodNonOptional, u, f[0]);
});
function object$2(u, l) {
  const f = {
    type: "object",
    shape: u ?? {},
    ...normalizeParams(l)
  };
  return new ZodObject(f);
}
function strictObject(u, l) {
  return new ZodObject({
    type: "object",
    shape: u,
    catchall: never(),
    ...normalizeParams(l)
  });
}
const ZodUnion = /* @__PURE__ */ $constructor("ZodUnion", (u, l) => {
  $ZodUnion.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => unionProcessor(u, f, p, m), u.options = l.options;
});
function union(u, l) {
  return new ZodUnion({
    type: "union",
    options: u,
    ...normalizeParams(l)
  });
}
const ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("ZodDiscriminatedUnion", (u, l) => {
  ZodUnion.init(u, l), $ZodDiscriminatedUnion.init(u, l);
});
function discriminatedUnion(u, l, f) {
  return new ZodDiscriminatedUnion({
    type: "union",
    options: l,
    discriminator: u,
    ...normalizeParams(f)
  });
}
const ZodIntersection = /* @__PURE__ */ $constructor("ZodIntersection", (u, l) => {
  $ZodIntersection.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => intersectionProcessor(u, f, p, m);
});
function intersection(u, l) {
  return new ZodIntersection({
    type: "intersection",
    left: u,
    right: l
  });
}
const ZodRecord = /* @__PURE__ */ $constructor("ZodRecord", (u, l) => {
  $ZodRecord.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => recordProcessor(u, f, p, m), u.keyType = l.keyType, u.valueType = l.valueType;
});
function record(u, l, f) {
  return new ZodRecord({
    type: "record",
    keyType: u,
    valueType: l,
    ...normalizeParams(f)
  });
}
const ZodEnum = /* @__PURE__ */ $constructor("ZodEnum", (u, l) => {
  $ZodEnum.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (p, m, b) => enumProcessor(u, p, m), u.enum = l.entries, u.options = Object.values(l.entries);
  const f = new Set(Object.keys(l.entries));
  u.extract = (p, m) => {
    const b = {};
    for (const y of p)
      if (f.has(y))
        b[y] = l.entries[y];
      else
        throw new Error(`Key ${y} not found in enum`);
    return new ZodEnum({
      ...l,
      checks: [],
      ...normalizeParams(m),
      entries: b
    });
  }, u.exclude = (p, m) => {
    const b = { ...l.entries };
    for (const y of p)
      if (f.has(y))
        delete b[y];
      else
        throw new Error(`Key ${y} not found in enum`);
    return new ZodEnum({
      ...l,
      checks: [],
      ...normalizeParams(m),
      entries: b
    });
  };
});
function _enum(u, l) {
  const f = Array.isArray(u) ? Object.fromEntries(u.map((p) => [p, p])) : u;
  return new ZodEnum({
    type: "enum",
    entries: f,
    ...normalizeParams(l)
  });
}
const ZodLiteral = /* @__PURE__ */ $constructor("ZodLiteral", (u, l) => {
  $ZodLiteral.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => literalProcessor(u, f, p), u.values = new Set(l.values), Object.defineProperty(u, "value", {
    get() {
      if (l.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return l.values[0];
    }
  });
});
function literal(u, l) {
  return new ZodLiteral({
    type: "literal",
    values: Array.isArray(u) ? u : [u],
    ...normalizeParams(l)
  });
}
const ZodTransform = /* @__PURE__ */ $constructor("ZodTransform", (u, l) => {
  $ZodTransform.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => transformProcessor(u, f), u._zod.parse = (f, p) => {
    if (p.direction === "backward")
      throw new $ZodEncodeError(u.constructor.name);
    f.addIssue = (b) => {
      if (typeof b == "string")
        f.issues.push(issue(b, f.value, l));
      else {
        const y = b;
        y.fatal && (y.continue = !1), y.code ?? (y.code = "custom"), y.input ?? (y.input = f.value), y.inst ?? (y.inst = u), f.issues.push(issue(y));
      }
    };
    const m = l.transform(f.value, f);
    return m instanceof Promise ? m.then((b) => (f.value = b, f)) : (f.value = m, f);
  };
});
function transform$1(u) {
  return new ZodTransform({
    type: "transform",
    transform: u
  });
}
const ZodOptional = /* @__PURE__ */ $constructor("ZodOptional", (u, l) => {
  $ZodOptional.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => optionalProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function optional(u) {
  return new ZodOptional({
    type: "optional",
    innerType: u
  });
}
const ZodExactOptional = /* @__PURE__ */ $constructor("ZodExactOptional", (u, l) => {
  $ZodExactOptional.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => optionalProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function exactOptional(u) {
  return new ZodExactOptional({
    type: "optional",
    innerType: u
  });
}
const ZodNullable = /* @__PURE__ */ $constructor("ZodNullable", (u, l) => {
  $ZodNullable.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => nullableProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function nullable(u) {
  return new ZodNullable({
    type: "nullable",
    innerType: u
  });
}
const ZodDefault = /* @__PURE__ */ $constructor("ZodDefault", (u, l) => {
  $ZodDefault.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => defaultProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType, u.removeDefault = u.unwrap;
});
function _default$1(u, l) {
  return new ZodDefault({
    type: "default",
    innerType: u,
    get defaultValue() {
      return typeof l == "function" ? l() : shallowClone(l);
    }
  });
}
const ZodPrefault = /* @__PURE__ */ $constructor("ZodPrefault", (u, l) => {
  $ZodPrefault.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => prefaultProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function prefault(u, l) {
  return new ZodPrefault({
    type: "prefault",
    innerType: u,
    get defaultValue() {
      return typeof l == "function" ? l() : shallowClone(l);
    }
  });
}
const ZodNonOptional = /* @__PURE__ */ $constructor("ZodNonOptional", (u, l) => {
  $ZodNonOptional.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => nonoptionalProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function nonoptional(u, l) {
  return new ZodNonOptional({
    type: "nonoptional",
    innerType: u,
    ...normalizeParams(l)
  });
}
const ZodCatch = /* @__PURE__ */ $constructor("ZodCatch", (u, l) => {
  $ZodCatch.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => catchProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType, u.removeCatch = u.unwrap;
});
function _catch(u, l) {
  return new ZodCatch({
    type: "catch",
    innerType: u,
    catchValue: typeof l == "function" ? l : () => l
  });
}
const ZodPipe = /* @__PURE__ */ $constructor("ZodPipe", (u, l) => {
  $ZodPipe.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => pipeProcessor(u, f, p, m), u.in = l.in, u.out = l.out;
});
function pipe(u, l) {
  return new ZodPipe({
    type: "pipe",
    in: u,
    out: l
    // ...util.normalizeParams(params),
  });
}
const ZodReadonly = /* @__PURE__ */ $constructor("ZodReadonly", (u, l) => {
  $ZodReadonly.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => readonlyProcessor(u, f, p, m), u.unwrap = () => u._zod.def.innerType;
});
function readonly$1(u) {
  return new ZodReadonly({
    type: "readonly",
    innerType: u
  });
}
const ZodLazy = /* @__PURE__ */ $constructor("ZodLazy", (u, l) => {
  $ZodLazy.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => lazyProcessor(u, f, p, m), u.unwrap = () => u._zod.def.getter();
});
function lazy(u) {
  return new ZodLazy({
    type: "lazy",
    getter: u
  });
}
const ZodCustom = /* @__PURE__ */ $constructor("ZodCustom", (u, l) => {
  $ZodCustom.init(u, l), ZodType.init(u, l), u._zod.processJSONSchema = (f, p, m) => customProcessor(u, f);
});
function custom(u, l) {
  return /* @__PURE__ */ _custom(ZodCustom, u ?? (() => !0), l);
}
function refine(u, l = {}) {
  return /* @__PURE__ */ _refine(ZodCustom, u, l);
}
function superRefine(u) {
  return /* @__PURE__ */ _superRefine(u);
}
function _instanceof(u, l = {}) {
  const f = new ZodCustom({
    type: "custom",
    check: "custom",
    fn: (p) => p instanceof u,
    abort: !0,
    ...normalizeParams(l)
  });
  return f._zod.bag.Class = u, f._zod.check = (p) => {
    p.value instanceof u || p.issues.push({
      code: "invalid_type",
      expected: u.name,
      input: p.value,
      inst: f,
      path: [...f._zod.def.path ?? []]
    });
  }, f;
}
var Feature = /* @__PURE__ */ ((u) => (u.USER_GROUPS = "userGroups", u.WORKSPACE_BACKUPS = "appBackups", u.ENVIRONMENT_VARIABLES = "environmentVariables", u.AUDIT_LOGS = "auditLogs", u.ENFORCEABLE_SSO = "enforceableSSO", u.BRANDING = "branding", u.SCIM = "scim", u.SYNC_AUTOMATIONS = "syncAutomations", u.TRIGGER_AUTOMATION_RUN = "triggerAutomationRun", u.OFFLINE = "offline", u.EXPANDED_PUBLIC_API = "expandedPublicApi", u.WORKSPACE_IMPORT_EXPORT = "workspaceImportExport", u.CUSTOM_APP_SCRIPTS = "customAppScripts", u.PDF = "pdf", u.TRANSLATIONS = "translations", u.VIEW_PERMISSIONS = "viewPermissions", u.VIEW_READONLY_COLUMNS = "viewReadonlyColumns", u.BUDIBASE_AI = "budibaseAI", u.AI_CUSTOM_CONFIGS = "aiCustomConfigs", u.PWA = "pwa", u.RECAPTCHA = "recaptcha", u.PKCE_OIDC = "pkceOidc", u.MICROFRONTEND = "microfrontend", u))(Feature || {}), commonjsGlobal$1 = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function getDefaultExportFromCjs$1(u) {
  return u && u.__esModule && Object.prototype.hasOwnProperty.call(u, "default") ? u.default : u;
}
function getAugmentedNamespace(u) {
  if (Object.prototype.hasOwnProperty.call(u, "__esModule")) return u;
  var l = u.default;
  if (typeof l == "function") {
    var f = function p() {
      var m = !1;
      try {
        m = this instanceof p;
      } catch {
      }
      return m ? Reflect.construct(l, arguments, this.constructor) : l.apply(this, arguments);
    };
    f.prototype = l.prototype;
  } else f = {};
  return Object.defineProperty(f, "__esModule", { value: !0 }), Object.keys(u).forEach(function(p) {
    var m = Object.getOwnPropertyDescriptor(u, p);
    Object.defineProperty(f, p, m.get ? m : {
      enumerable: !0,
      get: function() {
        return u[p];
      }
    });
  }), f;
}
var _freeGlobal$2, hasRequired_freeGlobal$1;
function require_freeGlobal$1() {
  if (hasRequired_freeGlobal$1) return _freeGlobal$2;
  hasRequired_freeGlobal$1 = 1;
  var u = typeof commonjsGlobal$1 == "object" && commonjsGlobal$1 && commonjsGlobal$1.Object === Object && commonjsGlobal$1;
  return _freeGlobal$2 = u, _freeGlobal$2;
}
var _root$2, hasRequired_root$1;
function require_root$1() {
  if (hasRequired_root$1) return _root$2;
  hasRequired_root$1 = 1;
  var u = require_freeGlobal$1(), l = typeof self == "object" && self && self.Object === Object && self, f = u || l || Function("return this")();
  return _root$2 = f, _root$2;
}
var _Symbol$2, hasRequired_Symbol$1;
function require_Symbol$1() {
  if (hasRequired_Symbol$1) return _Symbol$2;
  hasRequired_Symbol$1 = 1;
  var u = require_root$1(), l = u.Symbol;
  return _Symbol$2 = l, _Symbol$2;
}
var _getRawTag$2, hasRequired_getRawTag$1;
function require_getRawTag$1() {
  if (hasRequired_getRawTag$1) return _getRawTag$2;
  hasRequired_getRawTag$1 = 1;
  var u = require_Symbol$1(), l = Object.prototype, f = l.hasOwnProperty, p = l.toString, m = u ? u.toStringTag : void 0;
  function b(y) {
    var v = f.call(y, m), $ = y[m];
    try {
      y[m] = void 0;
      var w = !0;
    } catch {
    }
    var P = p.call(y);
    return w && (v ? y[m] = $ : delete y[m]), P;
  }
  return _getRawTag$2 = b, _getRawTag$2;
}
var _objectToString$2, hasRequired_objectToString$1;
function require_objectToString$1() {
  if (hasRequired_objectToString$1) return _objectToString$2;
  hasRequired_objectToString$1 = 1;
  var u = Object.prototype, l = u.toString;
  function f(p) {
    return l.call(p);
  }
  return _objectToString$2 = f, _objectToString$2;
}
var _baseGetTag$2, hasRequired_baseGetTag$1;
function require_baseGetTag$1() {
  if (hasRequired_baseGetTag$1) return _baseGetTag$2;
  hasRequired_baseGetTag$1 = 1;
  var u = require_Symbol$1(), l = require_getRawTag$1(), f = require_objectToString$1(), p = "[object Null]", m = "[object Undefined]", b = u ? u.toStringTag : void 0;
  function y(v) {
    return v == null ? v === void 0 ? m : p : b && b in Object(v) ? l(v) : f(v);
  }
  return _baseGetTag$2 = y, _baseGetTag$2;
}
var _overArg$2, hasRequired_overArg$1;
function require_overArg$1() {
  if (hasRequired_overArg$1) return _overArg$2;
  hasRequired_overArg$1 = 1;
  function u(l, f) {
    return function(p) {
      return l(f(p));
    };
  }
  return _overArg$2 = u, _overArg$2;
}
var _getPrototype$2, hasRequired_getPrototype$1;
function require_getPrototype$1() {
  if (hasRequired_getPrototype$1) return _getPrototype$2;
  hasRequired_getPrototype$1 = 1;
  var u = require_overArg$1(), l = u(Object.getPrototypeOf, Object);
  return _getPrototype$2 = l, _getPrototype$2;
}
var isObjectLike_1$2, hasRequiredIsObjectLike$1;
function requireIsObjectLike$1() {
  if (hasRequiredIsObjectLike$1) return isObjectLike_1$2;
  hasRequiredIsObjectLike$1 = 1;
  function u(l) {
    return l != null && typeof l == "object";
  }
  return isObjectLike_1$2 = u, isObjectLike_1$2;
}
var isPlainObject_1$2, hasRequiredIsPlainObject$2;
function requireIsPlainObject$2() {
  if (hasRequiredIsPlainObject$2) return isPlainObject_1$2;
  hasRequiredIsPlainObject$2 = 1;
  var u = require_baseGetTag$1(), l = require_getPrototype$1(), f = requireIsObjectLike$1(), p = "[object Object]", m = Function.prototype, b = Object.prototype, y = m.toString, v = b.hasOwnProperty, $ = y.call(Object);
  function w(P) {
    if (!f(P) || u(P) != p)
      return !1;
    var k = l(P);
    if (k === null)
      return !0;
    var x = v.call(k, "constructor") && k.constructor;
    return typeof x == "function" && x instanceof x && y.call(x) == $;
  }
  return isPlainObject_1$2 = w, isPlainObject_1$2;
}
var isPlainObjectExports = requireIsPlainObject$2();
const isPlainObject$2 = /* @__PURE__ */ getDefaultExportFromCjs$1(isPlainObjectExports);
var BasicOperator = /* @__PURE__ */ ((u) => (u.EQUAL = "equal", u.NOT_EQUAL = "notEqual", u.EMPTY = "empty", u.NOT_EMPTY = "notEmpty", u.FUZZY = "fuzzy", u.STRING = "string", u))(BasicOperator || {}), ArrayOperator = /* @__PURE__ */ ((u) => (u.CONTAINS = "contains", u.NOT_CONTAINS = "notContains", u.CONTAINS_ANY = "containsAny", u.ONE_OF = "oneOf", u))(ArrayOperator || {}), RangeOperator = /* @__PURE__ */ ((u) => (u.RANGE = "range", u))(RangeOperator || {}), LogicalOperator = /* @__PURE__ */ ((u) => (u.AND = "$and", u.OR = "$or", u))(LogicalOperator || {});
function isLogicalSearchOperator(u) {
  return Object.values(LogicalOperator).includes(u);
}
function isBasicSearchOperator(u) {
  return Object.values(BasicOperator).includes(u);
}
function isArraySearchOperator(u) {
  return Object.values(ArrayOperator).includes(u);
}
function isRangeSearchOperator(u) {
  return Object.values(RangeOperator).includes(u);
}
var EmptyFilterOption = /* @__PURE__ */ ((u) => (u.RETURN_ALL = "all", u.RETURN_NONE = "none", u))(EmptyFilterOption || {}), UILogicalOperator = /* @__PURE__ */ ((u) => (u.ALL = "all", u.ANY = "any", u))(UILogicalOperator || {}), MaintenanceType = /* @__PURE__ */ ((u) => (u.SQS_MISSING = "sqs_missing", u))(MaintenanceType || {});
const SEPARATOR$1 = "_", prefixed = (u) => `${u}${SEPARATOR$1}`;
var DocumentType = /* @__PURE__ */ ((u) => (u.USER = "us", u.GROUP = "gr", u.CONFIG = "config", u.TEMPLATE = "template", u.WORKSPACE = "app", u.DEV = "dev", u.WORKSPACE_DEV = "app_dev", u.WORKSPACE_METADATA = "app_metadata", u.ROLE = "role", u.DEV_INFO = "devinfo", u.AUTOMATION_LOG = "log_au", u.ACCOUNT_METADATA = "acc_metadata", u.PLUGIN = "plg", u.DATASOURCE = "datasource", u.DATASOURCE_PLUS = "datasource_plus", u.WORKSPACE_BACKUP = "backup", u.TABLE = "ta", u.ROW = "ro", u.AUTOMATION = "au", u.LINK = "li", u.WEBHOOK = "wh", u.INSTANCE = "inst", u.LAYOUT = "layout", u.SCREEN = "screen", u.QUERY = "query", u.DEPLOYMENTS = "deployments", u.METADATA = "metadata", u.MEM_VIEW = "view", u.USER_FLAG = "flag", u.AUTOMATION_METADATA = "meta_au", u.AUDIT_LOG = "al", u.SCIM_LOG = "scimlog", u.ROW_ACTIONS = "ra", u.OAUTH2_CONFIG = "oauth2", u.OAUTH2_CONFIG_LOG = "oauth2log", u.AGENT = "agent", u.CHAT_APP = "chatapp", u.CHAT_CONVERSATION = "chatconvo", u.CHAT_IDENTITY_LINK = "chatidentitylink", u.AGENT_TOOL_SOURCE = "agenttoolsource", u.AGENT_FILE = "agentfile", u.AGENT_LOG_SESSION = "agentlogsession", u.AGENT_LOG_REQUEST = "agentlogrequest", u.AGENT_KNOWLEDGE_SOURCE_SYNC_STATE = "agentknowledgesync", u.AGENT_KNOWLEDGE_SOURCE_CONNECTION = "agentknowledgeconn", u.KNOWLEDGE_BASE_FILE = "knowledgebasefile", u.AI_CONFIG = "aiconfig", u.LITELLM_KEY = "litellmkey", u.KNOWLEDGE_BASE = "knowledgebase", u.WORKSPACE_APP = "workspace_app", u.WORKSPACE_FAVOURITE = "workspace_favourite", u.AUTO_COLUMN_STATE = "autocolumn_state", u))(DocumentType || {}), InternalTable = /* @__PURE__ */ ((u) => (u.USER_METADATA = "ta_users", u))(InternalTable || {}), RelationshipType = /* @__PURE__ */ ((u) => (u.ONE_TO_MANY = "one-to-many", u.MANY_TO_ONE = "many-to-one", u.MANY_TO_MANY = "many-to-many", u))(RelationshipType || {}), FormulaType = /* @__PURE__ */ ((u) => (u.STATIC = "static", u.DYNAMIC = "dynamic", u.AI = "ai", u))(FormulaType || {}), BBReferenceFieldSubType = /* @__PURE__ */ ((u) => (u.USER = "user", u.USERS = "users", u))(BBReferenceFieldSubType || {}), StringFieldSubType = /* @__PURE__ */ ((u) => (u.ARRAY = "array", u))(StringFieldSubType || {});
function isRelationshipField(u) {
  return u.type === FieldType.LINK;
}
const EXTERNAL_ROW_REV = "rev";
var FieldType = /* @__PURE__ */ ((u) => (u.STRING = "string", u.LONGFORM = "longform", u.OPTIONS = "options", u.NUMBER = "number", u.BOOLEAN = "boolean", u.ARRAY = "array", u.DATETIME = "datetime", u.ATTACHMENTS = "attachment", u.ATTACHMENT_SINGLE = "attachment_single", u.LINK = "link", u.FORMULA = "formula", u.AUTO = "auto", u.AI = "ai", u.JSON = "json", u.INTERNAL = "internal", u.BARCODEQR = "barcodeqr", u.SIGNATURE_SINGLE = "signature_single", u.BIGINT = "bigint", u.BB_REFERENCE = "bb_reference", u.BB_REFERENCE_SINGLE = "bb_reference_single", u))(FieldType || {});
function isStaticFormula(u) {
  return u.type === "formula" && u.formulaType === FormulaType.STATIC;
}
var ScreenVariant = /* @__PURE__ */ ((u) => (u.PDF = "pdf", u))(ScreenVariant || {}), Theme = /* @__PURE__ */ ((u) => (u.LIGHTEST = "lightest", u.LIGHT = "light", u.DARK = "dark", u.DARKEST = "darkest", u.NORD = "nord", u.MIDNIGHT = "midnight", u))(Theme || {}), ViewV2Type = /* @__PURE__ */ ((u) => (u.CALCULATION = "calculation", u))(ViewV2Type || {}), AppFontFamily = /* @__PURE__ */ ((u) => (u.SOURCE_SANS = "sourceSans", u.INTER = "inter", u))(AppFontFamily || {}), ComponentContextScopes = /* @__PURE__ */ ((u) => (u.Local = "local", u.Global = "global", u))(ComponentContextScopes || {}), DropPosition = /* @__PURE__ */ ((u) => (u.ABOVE = "above", u.BELOW = "below", u.INSIDE = "inside", u))(DropPosition || {}), Header = /* @__PURE__ */ ((u) => (u.API_KEY = "x-budibase-api-key", u.LICENSE_KEY = "x-budibase-license-key", u.API_VER = "x-budibase-api-version", u.APP_ID = "x-budibase-app-id", u.SESSION_ID = "x-budibase-session-id", u.CLIENT = "x-budibase-client", u.TYPE = "x-budibase-type", u.PREVIEW_ROLE = "x-budibase-role", u.TENANT_ID = "x-budibase-tenant-id", u.VERIFICATION_CODE = "x-budibase-verification-code", u.RETURN_VERIFICATION_CODE = "x-budibase-return-verification-code", u.RESET_PASSWORD_CODE = "x-budibase-reset-password-code", u.RETURN_RESET_PASSWORD_CODE = "x-budibase-return-reset-password-code", u.TOKEN = "x-budibase-token", u.CSRF_TOKEN = "x-csrf-token", u.CORRELATION_ID = "x-budibase-correlation-id", u.AUTHORIZATION = "authorization", u.MIGRATING_APP = "x-budibase-migrating-app", u.SKIP_MIGRATING_WAIT = "x-budibase-migrating-app-skip-wait", u.COOKIE = "cookie", u))(Header || {});
const ThemeClassPrefix = "spectrum--";
Theme.DARKEST;
const DefaultAppTheme = Theme.LIGHT, ThemeOptions = [
  {
    id: Theme.LIGHT,
    name: "Light"
  },
  {
    // We call this dark for simplicity, but we want to use the spectrum darkest style
    id: Theme.DARKEST,
    name: "Dark"
  },
  {
    id: Theme.NORD,
    name: "Nord",
    base: Theme.DARKEST
  },
  {
    id: Theme.MIDNIGHT,
    name: "Midnight",
    base: Theme.DARKEST
  }
], DefaultExistingAppFontFamily = AppFontFamily.SOURCE_SANS, AppFontFamilyStacks = {
  [AppFontFamily.SOURCE_SANS]: '"Source Sans 3", -apple-system, BlinkMacSystemFont, Segoe UI, "Inter", "Helvetica Neue", Arial, "Noto Sans", sans-serif',
  [AppFontFamily.INTER]: '"Inter", -apple-system, BlinkMacSystemFont, Segoe UI, "Helvetica Neue", Arial, "Noto Sans", sans-serif'
}, ensureValidAppFontFamily = (u) => u && Object.prototype.hasOwnProperty.call(AppFontFamilyStacks, u) ? u : DefaultExistingAppFontFamily, getAppFontFamilyStack = (u) => AppFontFamilyStacks[ensureValidAppFontFamily(u)], OperatorOptions = {
  Equals: {
    value: "equal",
    label: "Equals"
  },
  NotEquals: {
    value: "notEqual",
    label: "Not equals"
  },
  Empty: {
    value: "empty",
    label: "Is empty"
  },
  NotEmpty: {
    value: "notEmpty",
    label: "Is not empty"
  },
  StartsWith: {
    value: "string",
    label: "Starts with"
  },
  Like: {
    value: "fuzzy",
    label: "Like"
  },
  MoreThan: {
    value: "rangeLow",
    label: "More than or equal to"
  },
  LessThan: {
    value: "rangeHigh",
    label: "Less than or equal to"
  },
  Contains: {
    value: "contains",
    label: "Contains"
  },
  NotContains: {
    value: "notContains",
    label: "Does not contain"
  },
  In: {
    value: "oneOf",
    label: "Is in"
  },
  ContainsAny: {
    value: "containsAny",
    label: "Has any"
  }
}, SqlNumberTypeRangeMap = {
  integer: {
    max: 2147483647,
    min: -2147483648
  },
  int: {
    max: 2147483647,
    min: -2147483648
  },
  smallint: {
    max: 32767,
    min: -32768
  },
  mediumint: {
    max: 8388607,
    min: -8388608
  }
};
var SocketEvent = /* @__PURE__ */ ((u) => (u.UserUpdate = "UserUpdate", u.UserDisconnect = "UserDisconnect", u.Heartbeat = "Heartbeat", u))(SocketEvent || {}), GridSocketEvent = /* @__PURE__ */ ((u) => (u.RowChange = "RowChange", u.DatasourceChange = "DatasourceChange", u.SelectDatasource = "SelectDatasource", u.SelectCell = "SelectCell", u.WorkspaceAppChange = "WorkspaceAppChange", u))(GridSocketEvent || {});
const SocketSessionTTL = 60, ValidColumnNameRegex = /^[_a-zA-Z0-9\s]*$/g;
var BpmCorrelationKey = /* @__PURE__ */ ((u) => (u.ONBOARDING = "budibase:onboarding:correlationkey", u.VERIFY_SSO_LOGIN = "budibase:verify_sso_login:correlationkey", u))(BpmCorrelationKey || {});
const DEFAULT_BB_DATASOURCE_ID = "datasource_internal_bb_default";
var dayjs_min$2 = { exports: {} }, dayjs_min$1 = dayjs_min$2.exports, hasRequiredDayjs_min;
function requireDayjs_min() {
  return hasRequiredDayjs_min || (hasRequiredDayjs_min = 1, (function(u, l) {
    (function(f, p) {
      u.exports = p();
    })(dayjs_min$1, (function() {
      var f = 1e3, p = 6e4, m = 36e5, b = "millisecond", y = "second", v = "minute", $ = "hour", w = "day", P = "week", k = "month", x = "quarter", S = "year", T = "date", M = "Invalid Date", E = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, R = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, O = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(X) {
        var B = ["th", "st", "nd", "rd"], H = X % 100;
        return "[" + X + (B[(H - 20) % 10] || B[H] || B[0]) + "]";
      } }, D = function(X, B, H) {
        var Y = String(X);
        return !Y || Y.length >= B ? X : "" + Array(B + 1 - Y.length).join(H) + X;
      }, q = { s: D, z: function(X) {
        var B = -X.utcOffset(), H = Math.abs(B), Y = Math.floor(H / 60), K = H % 60;
        return (B <= 0 ? "+" : "-") + D(Y, 2, "0") + ":" + D(K, 2, "0");
      }, m: function X(B, H) {
        if (B.date() < H.date()) return -X(H, B);
        var Y = 12 * (H.year() - B.year()) + (H.month() - B.month()), K = B.clone().add(Y, k), ee = H - K < 0, ae = B.clone().add(Y + (ee ? -1 : 1), k);
        return +(-(Y + (H - K) / (ee ? K - ae : ae - K)) || 0);
      }, a: function(X) {
        return X < 0 ? Math.ceil(X) || 0 : Math.floor(X);
      }, p: function(X) {
        return { M: k, y: S, w: P, d: w, D: T, h: $, m: v, s: y, ms: b, Q: x }[X] || String(X || "").toLowerCase().replace(/s$/, "");
      }, u: function(X) {
        return X === void 0;
      } }, F = "en", L = {};
      L[F] = O;
      var N = "$isDayjsObject", z = function(X) {
        return X instanceof U || !(!X || !X[N]);
      }, V = function X(B, H, Y) {
        var K;
        if (!B) return F;
        if (typeof B == "string") {
          var ee = B.toLowerCase();
          L[ee] && (K = ee), H && (L[ee] = H, K = ee);
          var ae = B.split("-");
          if (!K && ae.length > 1) return X(ae[0]);
        } else {
          var ne = B.name;
          L[ne] = B, K = ne;
        }
        return !Y && K && (F = K), K || !Y && F;
      }, W = function(X, B) {
        if (z(X)) return X.clone();
        var H = typeof B == "object" ? B : {};
        return H.date = X, H.args = arguments, new U(H);
      }, j = q;
      j.l = V, j.i = z, j.w = function(X, B) {
        return W(X, { locale: B.$L, utc: B.$u, x: B.$x, $offset: B.$offset });
      };
      var U = (function() {
        function X(H) {
          this.$L = V(H.locale, null, !0), this.parse(H), this.$x = this.$x || H.x || {}, this[N] = !0;
        }
        var B = X.prototype;
        return B.parse = function(H) {
          this.$d = (function(Y) {
            var K = Y.date, ee = Y.utc;
            if (K === null) return /* @__PURE__ */ new Date(NaN);
            if (j.u(K)) return /* @__PURE__ */ new Date();
            if (K instanceof Date) return new Date(K);
            if (typeof K == "string" && !/Z$/i.test(K)) {
              var ae = K.match(E);
              if (ae) {
                var ne = ae[2] - 1 || 0, me = (ae[7] || "0").substring(0, 3);
                return ee ? new Date(Date.UTC(ae[1], ne, ae[3] || 1, ae[4] || 0, ae[5] || 0, ae[6] || 0, me)) : new Date(ae[1], ne, ae[3] || 1, ae[4] || 0, ae[5] || 0, ae[6] || 0, me);
              }
            }
            return new Date(K);
          })(H), this.init();
        }, B.init = function() {
          var H = this.$d;
          this.$y = H.getFullYear(), this.$M = H.getMonth(), this.$D = H.getDate(), this.$W = H.getDay(), this.$H = H.getHours(), this.$m = H.getMinutes(), this.$s = H.getSeconds(), this.$ms = H.getMilliseconds();
        }, B.$utils = function() {
          return j;
        }, B.isValid = function() {
          return this.$d.toString() !== M;
        }, B.isSame = function(H, Y) {
          var K = W(H);
          return this.startOf(Y) <= K && K <= this.endOf(Y);
        }, B.isAfter = function(H, Y) {
          return W(H) < this.startOf(Y);
        }, B.isBefore = function(H, Y) {
          return this.endOf(Y) < W(H);
        }, B.$g = function(H, Y, K) {
          return j.u(H) ? this[Y] : this.set(K, H);
        }, B.unix = function() {
          return Math.floor(this.valueOf() / 1e3);
        }, B.valueOf = function() {
          return this.$d.getTime();
        }, B.startOf = function(H, Y) {
          var K = this, ee = !!j.u(Y) || Y, ae = j.p(H), ne = function(ie, oe) {
            var Q = j.w(K.$u ? Date.UTC(K.$y, oe, ie) : new Date(K.$y, oe, ie), K);
            return ee ? Q : Q.endOf(w);
          }, me = function(ie, oe) {
            return j.w(K.toDate()[ie].apply(K.toDate("s"), (ee ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(oe)), K);
          }, le = this.$W, ge = this.$M, pe = this.$D, J = "set" + (this.$u ? "UTC" : "");
          switch (ae) {
            case S:
              return ee ? ne(1, 0) : ne(31, 11);
            case k:
              return ee ? ne(1, ge) : ne(0, ge + 1);
            case P:
              var ce = this.$locale().weekStart || 0, ye = (le < ce ? le + 7 : le) - ce;
              return ne(ee ? pe - ye : pe + (6 - ye), ge);
            case w:
            case T:
              return me(J + "Hours", 0);
            case $:
              return me(J + "Minutes", 1);
            case v:
              return me(J + "Seconds", 2);
            case y:
              return me(J + "Milliseconds", 3);
            default:
              return this.clone();
          }
        }, B.endOf = function(H) {
          return this.startOf(H, !1);
        }, B.$set = function(H, Y) {
          var K, ee = j.p(H), ae = "set" + (this.$u ? "UTC" : ""), ne = (K = {}, K[w] = ae + "Date", K[T] = ae + "Date", K[k] = ae + "Month", K[S] = ae + "FullYear", K[$] = ae + "Hours", K[v] = ae + "Minutes", K[y] = ae + "Seconds", K[b] = ae + "Milliseconds", K)[ee], me = ee === w ? this.$D + (Y - this.$W) : Y;
          if (ee === k || ee === S) {
            var le = this.clone().set(T, 1);
            le.$d[ne](me), le.init(), this.$d = le.set(T, Math.min(this.$D, le.daysInMonth())).$d;
          } else ne && this.$d[ne](me);
          return this.init(), this;
        }, B.set = function(H, Y) {
          return this.clone().$set(H, Y);
        }, B.get = function(H) {
          return this[j.p(H)]();
        }, B.add = function(H, Y) {
          var K, ee = this;
          H = Number(H);
          var ae = j.p(Y), ne = function(ge) {
            var pe = W(ee);
            return j.w(pe.date(pe.date() + Math.round(ge * H)), ee);
          };
          if (ae === k) return this.set(k, this.$M + H);
          if (ae === S) return this.set(S, this.$y + H);
          if (ae === w) return ne(1);
          if (ae === P) return ne(7);
          var me = (K = {}, K[v] = p, K[$] = m, K[y] = f, K)[ae] || 1, le = this.$d.getTime() + H * me;
          return j.w(le, this);
        }, B.subtract = function(H, Y) {
          return this.add(-1 * H, Y);
        }, B.format = function(H) {
          var Y = this, K = this.$locale();
          if (!this.isValid()) return K.invalidDate || M;
          var ee = H || "YYYY-MM-DDTHH:mm:ssZ", ae = j.z(this), ne = this.$H, me = this.$m, le = this.$M, ge = K.weekdays, pe = K.months, J = K.meridiem, ce = function(oe, Q, ue, fe) {
            return oe && (oe[Q] || oe(Y, ee)) || ue[Q].slice(0, fe);
          }, ye = function(oe) {
            return j.s(ne % 12 || 12, oe, "0");
          }, ie = J || function(oe, Q, ue) {
            var fe = oe < 12 ? "AM" : "PM";
            return ue ? fe.toLowerCase() : fe;
          };
          return ee.replace(R, (function(oe, Q) {
            return Q || (function(ue) {
              switch (ue) {
                case "YY":
                  return String(Y.$y).slice(-2);
                case "YYYY":
                  return j.s(Y.$y, 4, "0");
                case "M":
                  return le + 1;
                case "MM":
                  return j.s(le + 1, 2, "0");
                case "MMM":
                  return ce(K.monthsShort, le, pe, 3);
                case "MMMM":
                  return ce(pe, le);
                case "D":
                  return Y.$D;
                case "DD":
                  return j.s(Y.$D, 2, "0");
                case "d":
                  return String(Y.$W);
                case "dd":
                  return ce(K.weekdaysMin, Y.$W, ge, 2);
                case "ddd":
                  return ce(K.weekdaysShort, Y.$W, ge, 3);
                case "dddd":
                  return ge[Y.$W];
                case "H":
                  return String(ne);
                case "HH":
                  return j.s(ne, 2, "0");
                case "h":
                  return ye(1);
                case "hh":
                  return ye(2);
                case "a":
                  return ie(ne, me, !0);
                case "A":
                  return ie(ne, me, !1);
                case "m":
                  return String(me);
                case "mm":
                  return j.s(me, 2, "0");
                case "s":
                  return String(Y.$s);
                case "ss":
                  return j.s(Y.$s, 2, "0");
                case "SSS":
                  return j.s(Y.$ms, 3, "0");
                case "Z":
                  return ae;
              }
              return null;
            })(oe) || ae.replace(":", "");
          }));
        }, B.utcOffset = function() {
          return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
        }, B.diff = function(H, Y, K) {
          var ee, ae = this, ne = j.p(Y), me = W(H), le = (me.utcOffset() - this.utcOffset()) * p, ge = this - me, pe = function() {
            return j.m(ae, me);
          };
          switch (ne) {
            case S:
              ee = pe() / 12;
              break;
            case k:
              ee = pe();
              break;
            case x:
              ee = pe() / 3;
              break;
            case P:
              ee = (ge - le) / 6048e5;
              break;
            case w:
              ee = (ge - le) / 864e5;
              break;
            case $:
              ee = ge / m;
              break;
            case v:
              ee = ge / p;
              break;
            case y:
              ee = ge / f;
              break;
            default:
              ee = ge;
          }
          return K ? ee : j.a(ee);
        }, B.daysInMonth = function() {
          return this.endOf(k).$D;
        }, B.$locale = function() {
          return L[this.$L];
        }, B.locale = function(H, Y) {
          if (!H) return this.$L;
          var K = this.clone(), ee = V(H, Y, !0);
          return ee && (K.$L = ee), K;
        }, B.clone = function() {
          return j.w(this.$d, this);
        }, B.toDate = function() {
          return new Date(this.valueOf());
        }, B.toJSON = function() {
          return this.isValid() ? this.toISOString() : null;
        }, B.toISOString = function() {
          return this.$d.toISOString();
        }, B.toString = function() {
          return this.$d.toUTCString();
        }, X;
      })(), Z = U.prototype;
      return W.prototype = Z, [["$ms", b], ["$s", y], ["$m", v], ["$H", $], ["$W", w], ["$M", k], ["$y", S], ["$D", T]].forEach((function(X) {
        Z[X[1]] = function(B) {
          return this.$g(B, X[0], X[1]);
        };
      })), W.extend = function(X, B) {
        return X.$i || (X(B, U, W), X.$i = !0), W;
      }, W.locale = V, W.isDayjs = z, W.unix = function(X) {
        return W(1e3 * X);
      }, W.en = L[F], W.Ls = L, W.p = {}, W;
    }));
  })(dayjs_min$2)), dayjs_min$2.exports;
}
var dayjs_minExports = requireDayjs_min();
const dayjs = /* @__PURE__ */ getDefaultExportFromCjs$1(dayjs_minExports);
var isArray_1$2, hasRequiredIsArray$1;
function requireIsArray$1() {
  if (hasRequiredIsArray$1) return isArray_1$2;
  hasRequiredIsArray$1 = 1;
  var u = Array.isArray;
  return isArray_1$2 = u, isArray_1$2;
}
var isSymbol_1$2, hasRequiredIsSymbol$1;
function requireIsSymbol$1() {
  if (hasRequiredIsSymbol$1) return isSymbol_1$2;
  hasRequiredIsSymbol$1 = 1;
  var u = require_baseGetTag$1(), l = requireIsObjectLike$1(), f = "[object Symbol]";
  function p(m) {
    return typeof m == "symbol" || l(m) && u(m) == f;
  }
  return isSymbol_1$2 = p, isSymbol_1$2;
}
var _isKey$2, hasRequired_isKey$1;
function require_isKey$1() {
  if (hasRequired_isKey$1) return _isKey$2;
  hasRequired_isKey$1 = 1;
  var u = requireIsArray$1(), l = requireIsSymbol$1(), f = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, p = /^\w*$/;
  function m(b, y) {
    if (u(b))
      return !1;
    var v = typeof b;
    return v == "number" || v == "symbol" || v == "boolean" || b == null || l(b) ? !0 : p.test(b) || !f.test(b) || y != null && b in Object(y);
  }
  return _isKey$2 = m, _isKey$2;
}
var isObject_1$2, hasRequiredIsObject$1;
function requireIsObject$1() {
  if (hasRequiredIsObject$1) return isObject_1$2;
  hasRequiredIsObject$1 = 1;
  function u(l) {
    var f = typeof l;
    return l != null && (f == "object" || f == "function");
  }
  return isObject_1$2 = u, isObject_1$2;
}
var isFunction_1$2, hasRequiredIsFunction$1;
function requireIsFunction$1() {
  if (hasRequiredIsFunction$1) return isFunction_1$2;
  hasRequiredIsFunction$1 = 1;
  var u = require_baseGetTag$1(), l = requireIsObject$1(), f = "[object AsyncFunction]", p = "[object Function]", m = "[object GeneratorFunction]", b = "[object Proxy]";
  function y(v) {
    if (!l(v))
      return !1;
    var $ = u(v);
    return $ == p || $ == m || $ == f || $ == b;
  }
  return isFunction_1$2 = y, isFunction_1$2;
}
var _coreJsData$2, hasRequired_coreJsData$1;
function require_coreJsData$1() {
  if (hasRequired_coreJsData$1) return _coreJsData$2;
  hasRequired_coreJsData$1 = 1;
  var u = require_root$1(), l = u["__core-js_shared__"];
  return _coreJsData$2 = l, _coreJsData$2;
}
var _isMasked$2, hasRequired_isMasked$1;
function require_isMasked$1() {
  if (hasRequired_isMasked$1) return _isMasked$2;
  hasRequired_isMasked$1 = 1;
  var u = require_coreJsData$1(), l = (function() {
    var p = /[^.]+$/.exec(u && u.keys && u.keys.IE_PROTO || "");
    return p ? "Symbol(src)_1." + p : "";
  })();
  function f(p) {
    return !!l && l in p;
  }
  return _isMasked$2 = f, _isMasked$2;
}
var _toSource$2, hasRequired_toSource$1;
function require_toSource$1() {
  if (hasRequired_toSource$1) return _toSource$2;
  hasRequired_toSource$1 = 1;
  var u = Function.prototype, l = u.toString;
  function f(p) {
    if (p != null) {
      try {
        return l.call(p);
      } catch {
      }
      try {
        return p + "";
      } catch {
      }
    }
    return "";
  }
  return _toSource$2 = f, _toSource$2;
}
var _baseIsNative$2, hasRequired_baseIsNative$1;
function require_baseIsNative$1() {
  if (hasRequired_baseIsNative$1) return _baseIsNative$2;
  hasRequired_baseIsNative$1 = 1;
  var u = requireIsFunction$1(), l = require_isMasked$1(), f = requireIsObject$1(), p = require_toSource$1(), m = /[\\^$.*+?()[\]{}|]/g, b = /^\[object .+?Constructor\]$/, y = Function.prototype, v = Object.prototype, $ = y.toString, w = v.hasOwnProperty, P = RegExp(
    "^" + $.call(w).replace(m, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function k(x) {
    if (!f(x) || l(x))
      return !1;
    var S = u(x) ? P : b;
    return S.test(p(x));
  }
  return _baseIsNative$2 = k, _baseIsNative$2;
}
var _getValue$2, hasRequired_getValue$1;
function require_getValue$1() {
  if (hasRequired_getValue$1) return _getValue$2;
  hasRequired_getValue$1 = 1;
  function u(l, f) {
    return l?.[f];
  }
  return _getValue$2 = u, _getValue$2;
}
var _getNative$2, hasRequired_getNative$1;
function require_getNative$1() {
  if (hasRequired_getNative$1) return _getNative$2;
  hasRequired_getNative$1 = 1;
  var u = require_baseIsNative$1(), l = require_getValue$1();
  function f(p, m) {
    var b = l(p, m);
    return u(b) ? b : void 0;
  }
  return _getNative$2 = f, _getNative$2;
}
var _nativeCreate$2, hasRequired_nativeCreate$1;
function require_nativeCreate$1() {
  if (hasRequired_nativeCreate$1) return _nativeCreate$2;
  hasRequired_nativeCreate$1 = 1;
  var u = require_getNative$1(), l = u(Object, "create");
  return _nativeCreate$2 = l, _nativeCreate$2;
}
var _hashClear$2, hasRequired_hashClear$1;
function require_hashClear$1() {
  if (hasRequired_hashClear$1) return _hashClear$2;
  hasRequired_hashClear$1 = 1;
  var u = require_nativeCreate$1();
  function l() {
    this.__data__ = u ? u(null) : {}, this.size = 0;
  }
  return _hashClear$2 = l, _hashClear$2;
}
var _hashDelete$2, hasRequired_hashDelete$1;
function require_hashDelete$1() {
  if (hasRequired_hashDelete$1) return _hashDelete$2;
  hasRequired_hashDelete$1 = 1;
  function u(l) {
    var f = this.has(l) && delete this.__data__[l];
    return this.size -= f ? 1 : 0, f;
  }
  return _hashDelete$2 = u, _hashDelete$2;
}
var _hashGet$2, hasRequired_hashGet$1;
function require_hashGet$1() {
  if (hasRequired_hashGet$1) return _hashGet$2;
  hasRequired_hashGet$1 = 1;
  var u = require_nativeCreate$1(), l = "__lodash_hash_undefined__", f = Object.prototype, p = f.hasOwnProperty;
  function m(b) {
    var y = this.__data__;
    if (u) {
      var v = y[b];
      return v === l ? void 0 : v;
    }
    return p.call(y, b) ? y[b] : void 0;
  }
  return _hashGet$2 = m, _hashGet$2;
}
var _hashHas$2, hasRequired_hashHas$1;
function require_hashHas$1() {
  if (hasRequired_hashHas$1) return _hashHas$2;
  hasRequired_hashHas$1 = 1;
  var u = require_nativeCreate$1(), l = Object.prototype, f = l.hasOwnProperty;
  function p(m) {
    var b = this.__data__;
    return u ? b[m] !== void 0 : f.call(b, m);
  }
  return _hashHas$2 = p, _hashHas$2;
}
var _hashSet$2, hasRequired_hashSet$1;
function require_hashSet$1() {
  if (hasRequired_hashSet$1) return _hashSet$2;
  hasRequired_hashSet$1 = 1;
  var u = require_nativeCreate$1(), l = "__lodash_hash_undefined__";
  function f(p, m) {
    var b = this.__data__;
    return this.size += this.has(p) ? 0 : 1, b[p] = u && m === void 0 ? l : m, this;
  }
  return _hashSet$2 = f, _hashSet$2;
}
var _Hash$2, hasRequired_Hash$1;
function require_Hash$1() {
  if (hasRequired_Hash$1) return _Hash$2;
  hasRequired_Hash$1 = 1;
  var u = require_hashClear$1(), l = require_hashDelete$1(), f = require_hashGet$1(), p = require_hashHas$1(), m = require_hashSet$1();
  function b(y) {
    var v = -1, $ = y == null ? 0 : y.length;
    for (this.clear(); ++v < $; ) {
      var w = y[v];
      this.set(w[0], w[1]);
    }
  }
  return b.prototype.clear = u, b.prototype.delete = l, b.prototype.get = f, b.prototype.has = p, b.prototype.set = m, _Hash$2 = b, _Hash$2;
}
var _listCacheClear$2, hasRequired_listCacheClear$1;
function require_listCacheClear$1() {
  if (hasRequired_listCacheClear$1) return _listCacheClear$2;
  hasRequired_listCacheClear$1 = 1;
  function u() {
    this.__data__ = [], this.size = 0;
  }
  return _listCacheClear$2 = u, _listCacheClear$2;
}
var eq_1$2, hasRequiredEq$1;
function requireEq$1() {
  if (hasRequiredEq$1) return eq_1$2;
  hasRequiredEq$1 = 1;
  function u(l, f) {
    return l === f || l !== l && f !== f;
  }
  return eq_1$2 = u, eq_1$2;
}
var _assocIndexOf$2, hasRequired_assocIndexOf$1;
function require_assocIndexOf$1() {
  if (hasRequired_assocIndexOf$1) return _assocIndexOf$2;
  hasRequired_assocIndexOf$1 = 1;
  var u = requireEq$1();
  function l(f, p) {
    for (var m = f.length; m--; )
      if (u(f[m][0], p))
        return m;
    return -1;
  }
  return _assocIndexOf$2 = l, _assocIndexOf$2;
}
var _listCacheDelete$2, hasRequired_listCacheDelete$1;
function require_listCacheDelete$1() {
  if (hasRequired_listCacheDelete$1) return _listCacheDelete$2;
  hasRequired_listCacheDelete$1 = 1;
  var u = require_assocIndexOf$1(), l = Array.prototype, f = l.splice;
  function p(m) {
    var b = this.__data__, y = u(b, m);
    if (y < 0)
      return !1;
    var v = b.length - 1;
    return y == v ? b.pop() : f.call(b, y, 1), --this.size, !0;
  }
  return _listCacheDelete$2 = p, _listCacheDelete$2;
}
var _listCacheGet$2, hasRequired_listCacheGet$1;
function require_listCacheGet$1() {
  if (hasRequired_listCacheGet$1) return _listCacheGet$2;
  hasRequired_listCacheGet$1 = 1;
  var u = require_assocIndexOf$1();
  function l(f) {
    var p = this.__data__, m = u(p, f);
    return m < 0 ? void 0 : p[m][1];
  }
  return _listCacheGet$2 = l, _listCacheGet$2;
}
var _listCacheHas$2, hasRequired_listCacheHas$1;
function require_listCacheHas$1() {
  if (hasRequired_listCacheHas$1) return _listCacheHas$2;
  hasRequired_listCacheHas$1 = 1;
  var u = require_assocIndexOf$1();
  function l(f) {
    return u(this.__data__, f) > -1;
  }
  return _listCacheHas$2 = l, _listCacheHas$2;
}
var _listCacheSet$2, hasRequired_listCacheSet$1;
function require_listCacheSet$1() {
  if (hasRequired_listCacheSet$1) return _listCacheSet$2;
  hasRequired_listCacheSet$1 = 1;
  var u = require_assocIndexOf$1();
  function l(f, p) {
    var m = this.__data__, b = u(m, f);
    return b < 0 ? (++this.size, m.push([f, p])) : m[b][1] = p, this;
  }
  return _listCacheSet$2 = l, _listCacheSet$2;
}
var _ListCache$2, hasRequired_ListCache$1;
function require_ListCache$1() {
  if (hasRequired_ListCache$1) return _ListCache$2;
  hasRequired_ListCache$1 = 1;
  var u = require_listCacheClear$1(), l = require_listCacheDelete$1(), f = require_listCacheGet$1(), p = require_listCacheHas$1(), m = require_listCacheSet$1();
  function b(y) {
    var v = -1, $ = y == null ? 0 : y.length;
    for (this.clear(); ++v < $; ) {
      var w = y[v];
      this.set(w[0], w[1]);
    }
  }
  return b.prototype.clear = u, b.prototype.delete = l, b.prototype.get = f, b.prototype.has = p, b.prototype.set = m, _ListCache$2 = b, _ListCache$2;
}
var _Map$2, hasRequired_Map$1;
function require_Map$1() {
  if (hasRequired_Map$1) return _Map$2;
  hasRequired_Map$1 = 1;
  var u = require_getNative$1(), l = require_root$1(), f = u(l, "Map");
  return _Map$2 = f, _Map$2;
}
var _mapCacheClear$2, hasRequired_mapCacheClear$1;
function require_mapCacheClear$1() {
  if (hasRequired_mapCacheClear$1) return _mapCacheClear$2;
  hasRequired_mapCacheClear$1 = 1;
  var u = require_Hash$1(), l = require_ListCache$1(), f = require_Map$1();
  function p() {
    this.size = 0, this.__data__ = {
      hash: new u(),
      map: new (f || l)(),
      string: new u()
    };
  }
  return _mapCacheClear$2 = p, _mapCacheClear$2;
}
var _isKeyable$2, hasRequired_isKeyable$1;
function require_isKeyable$1() {
  if (hasRequired_isKeyable$1) return _isKeyable$2;
  hasRequired_isKeyable$1 = 1;
  function u(l) {
    var f = typeof l;
    return f == "string" || f == "number" || f == "symbol" || f == "boolean" ? l !== "__proto__" : l === null;
  }
  return _isKeyable$2 = u, _isKeyable$2;
}
var _getMapData$2, hasRequired_getMapData$1;
function require_getMapData$1() {
  if (hasRequired_getMapData$1) return _getMapData$2;
  hasRequired_getMapData$1 = 1;
  var u = require_isKeyable$1();
  function l(f, p) {
    var m = f.__data__;
    return u(p) ? m[typeof p == "string" ? "string" : "hash"] : m.map;
  }
  return _getMapData$2 = l, _getMapData$2;
}
var _mapCacheDelete$2, hasRequired_mapCacheDelete$1;
function require_mapCacheDelete$1() {
  if (hasRequired_mapCacheDelete$1) return _mapCacheDelete$2;
  hasRequired_mapCacheDelete$1 = 1;
  var u = require_getMapData$1();
  function l(f) {
    var p = u(this, f).delete(f);
    return this.size -= p ? 1 : 0, p;
  }
  return _mapCacheDelete$2 = l, _mapCacheDelete$2;
}
var _mapCacheGet$2, hasRequired_mapCacheGet$1;
function require_mapCacheGet$1() {
  if (hasRequired_mapCacheGet$1) return _mapCacheGet$2;
  hasRequired_mapCacheGet$1 = 1;
  var u = require_getMapData$1();
  function l(f) {
    return u(this, f).get(f);
  }
  return _mapCacheGet$2 = l, _mapCacheGet$2;
}
var _mapCacheHas$2, hasRequired_mapCacheHas$1;
function require_mapCacheHas$1() {
  if (hasRequired_mapCacheHas$1) return _mapCacheHas$2;
  hasRequired_mapCacheHas$1 = 1;
  var u = require_getMapData$1();
  function l(f) {
    return u(this, f).has(f);
  }
  return _mapCacheHas$2 = l, _mapCacheHas$2;
}
var _mapCacheSet$2, hasRequired_mapCacheSet$1;
function require_mapCacheSet$1() {
  if (hasRequired_mapCacheSet$1) return _mapCacheSet$2;
  hasRequired_mapCacheSet$1 = 1;
  var u = require_getMapData$1();
  function l(f, p) {
    var m = u(this, f), b = m.size;
    return m.set(f, p), this.size += m.size == b ? 0 : 1, this;
  }
  return _mapCacheSet$2 = l, _mapCacheSet$2;
}
var _MapCache$2, hasRequired_MapCache$1;
function require_MapCache$1() {
  if (hasRequired_MapCache$1) return _MapCache$2;
  hasRequired_MapCache$1 = 1;
  var u = require_mapCacheClear$1(), l = require_mapCacheDelete$1(), f = require_mapCacheGet$1(), p = require_mapCacheHas$1(), m = require_mapCacheSet$1();
  function b(y) {
    var v = -1, $ = y == null ? 0 : y.length;
    for (this.clear(); ++v < $; ) {
      var w = y[v];
      this.set(w[0], w[1]);
    }
  }
  return b.prototype.clear = u, b.prototype.delete = l, b.prototype.get = f, b.prototype.has = p, b.prototype.set = m, _MapCache$2 = b, _MapCache$2;
}
var memoize_1$2, hasRequiredMemoize$1;
function requireMemoize$1() {
  if (hasRequiredMemoize$1) return memoize_1$2;
  hasRequiredMemoize$1 = 1;
  var u = require_MapCache$1(), l = "Expected a function";
  function f(p, m) {
    if (typeof p != "function" || m != null && typeof m != "function")
      throw new TypeError(l);
    var b = function() {
      var y = arguments, v = m ? m.apply(this, y) : y[0], $ = b.cache;
      if ($.has(v))
        return $.get(v);
      var w = p.apply(this, y);
      return b.cache = $.set(v, w) || $, w;
    };
    return b.cache = new (f.Cache || u)(), b;
  }
  return f.Cache = u, memoize_1$2 = f, memoize_1$2;
}
var _memoizeCapped$2, hasRequired_memoizeCapped$1;
function require_memoizeCapped$1() {
  if (hasRequired_memoizeCapped$1) return _memoizeCapped$2;
  hasRequired_memoizeCapped$1 = 1;
  var u = requireMemoize$1(), l = 500;
  function f(p) {
    var m = u(p, function(y) {
      return b.size === l && b.clear(), y;
    }), b = m.cache;
    return m;
  }
  return _memoizeCapped$2 = f, _memoizeCapped$2;
}
var _stringToPath$2, hasRequired_stringToPath$1;
function require_stringToPath$1() {
  if (hasRequired_stringToPath$1) return _stringToPath$2;
  hasRequired_stringToPath$1 = 1;
  var u = require_memoizeCapped$1(), l = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, f = /\\(\\)?/g, p = u(function(m) {
    var b = [];
    return m.charCodeAt(0) === 46 && b.push(""), m.replace(l, function(y, v, $, w) {
      b.push($ ? w.replace(f, "$1") : v || y);
    }), b;
  });
  return _stringToPath$2 = p, _stringToPath$2;
}
var _arrayMap$2, hasRequired_arrayMap$1;
function require_arrayMap$1() {
  if (hasRequired_arrayMap$1) return _arrayMap$2;
  hasRequired_arrayMap$1 = 1;
  function u(l, f) {
    for (var p = -1, m = l == null ? 0 : l.length, b = Array(m); ++p < m; )
      b[p] = f(l[p], p, l);
    return b;
  }
  return _arrayMap$2 = u, _arrayMap$2;
}
var _baseToString$2, hasRequired_baseToString$1;
function require_baseToString$1() {
  if (hasRequired_baseToString$1) return _baseToString$2;
  hasRequired_baseToString$1 = 1;
  var u = require_Symbol$1(), l = require_arrayMap$1(), f = requireIsArray$1(), p = requireIsSymbol$1(), m = u ? u.prototype : void 0, b = m ? m.toString : void 0;
  function y(v) {
    if (typeof v == "string")
      return v;
    if (f(v))
      return l(v, y) + "";
    if (p(v))
      return b ? b.call(v) : "";
    var $ = v + "";
    return $ == "0" && 1 / v == -1 / 0 ? "-0" : $;
  }
  return _baseToString$2 = y, _baseToString$2;
}
var toString_1$2, hasRequiredToString$1;
function requireToString$1() {
  if (hasRequiredToString$1) return toString_1$2;
  hasRequiredToString$1 = 1;
  var u = require_baseToString$1();
  function l(f) {
    return f == null ? "" : u(f);
  }
  return toString_1$2 = l, toString_1$2;
}
var _castPath$2, hasRequired_castPath$1;
function require_castPath$1() {
  if (hasRequired_castPath$1) return _castPath$2;
  hasRequired_castPath$1 = 1;
  var u = requireIsArray$1(), l = require_isKey$1(), f = require_stringToPath$1(), p = requireToString$1();
  function m(b, y) {
    return u(b) ? b : l(b, y) ? [b] : f(p(b));
  }
  return _castPath$2 = m, _castPath$2;
}
var _toKey$2, hasRequired_toKey$1;
function require_toKey$1() {
  if (hasRequired_toKey$1) return _toKey$2;
  hasRequired_toKey$1 = 1;
  var u = requireIsSymbol$1();
  function l(f) {
    if (typeof f == "string" || u(f))
      return f;
    var p = f + "";
    return p == "0" && 1 / f == -1 / 0 ? "-0" : p;
  }
  return _toKey$2 = l, _toKey$2;
}
var _baseGet$2, hasRequired_baseGet$1;
function require_baseGet$1() {
  if (hasRequired_baseGet$1) return _baseGet$2;
  hasRequired_baseGet$1 = 1;
  var u = require_castPath$1(), l = require_toKey$1();
  function f(p, m) {
    m = u(m, p);
    for (var b = 0, y = m.length; p != null && b < y; )
      p = p[l(m[b++])];
    return b && b == y ? p : void 0;
  }
  return _baseGet$2 = f, _baseGet$2;
}
var _defineProperty$2, hasRequired_defineProperty$1;
function require_defineProperty$1() {
  if (hasRequired_defineProperty$1) return _defineProperty$2;
  hasRequired_defineProperty$1 = 1;
  var u = require_getNative$1(), l = (function() {
    try {
      var f = u(Object, "defineProperty");
      return f({}, "", {}), f;
    } catch {
    }
  })();
  return _defineProperty$2 = l, _defineProperty$2;
}
var _baseAssignValue$2, hasRequired_baseAssignValue$1;
function require_baseAssignValue$1() {
  if (hasRequired_baseAssignValue$1) return _baseAssignValue$2;
  hasRequired_baseAssignValue$1 = 1;
  var u = require_defineProperty$1();
  function l(f, p, m) {
    p == "__proto__" && u ? u(f, p, {
      configurable: !0,
      enumerable: !0,
      value: m,
      writable: !0
    }) : f[p] = m;
  }
  return _baseAssignValue$2 = l, _baseAssignValue$2;
}
var _assignValue$2, hasRequired_assignValue$1;
function require_assignValue$1() {
  if (hasRequired_assignValue$1) return _assignValue$2;
  hasRequired_assignValue$1 = 1;
  var u = require_baseAssignValue$1(), l = requireEq$1(), f = Object.prototype, p = f.hasOwnProperty;
  function m(b, y, v) {
    var $ = b[y];
    (!(p.call(b, y) && l($, v)) || v === void 0 && !(y in b)) && u(b, y, v);
  }
  return _assignValue$2 = m, _assignValue$2;
}
var _isIndex$2, hasRequired_isIndex$1;
function require_isIndex$1() {
  if (hasRequired_isIndex$1) return _isIndex$2;
  hasRequired_isIndex$1 = 1;
  var u = 9007199254740991, l = /^(?:0|[1-9]\d*)$/;
  function f(p, m) {
    var b = typeof p;
    return m = m ?? u, !!m && (b == "number" || b != "symbol" && l.test(p)) && p > -1 && p % 1 == 0 && p < m;
  }
  return _isIndex$2 = f, _isIndex$2;
}
var _baseSet, hasRequired_baseSet;
function require_baseSet() {
  if (hasRequired_baseSet) return _baseSet;
  hasRequired_baseSet = 1;
  var u = require_assignValue$1(), l = require_castPath$1(), f = require_isIndex$1(), p = requireIsObject$1(), m = require_toKey$1();
  function b(y, v, $, w) {
    if (!p(y))
      return y;
    v = l(v, y);
    for (var P = -1, k = v.length, x = k - 1, S = y; S != null && ++P < k; ) {
      var T = m(v[P]), M = $;
      if (T === "__proto__" || T === "constructor" || T === "prototype")
        return y;
      if (P != x) {
        var E = S[T];
        M = w ? w(E, T, S) : void 0, M === void 0 && (M = p(E) ? E : f(v[P + 1]) ? [] : {});
      }
      u(S, T, M), S = S[T];
    }
    return y;
  }
  return _baseSet = b, _baseSet;
}
var _basePickBy, hasRequired_basePickBy;
function require_basePickBy() {
  if (hasRequired_basePickBy) return _basePickBy;
  hasRequired_basePickBy = 1;
  var u = require_baseGet$1(), l = require_baseSet(), f = require_castPath$1();
  function p(m, b, y) {
    for (var v = -1, $ = b.length, w = {}; ++v < $; ) {
      var P = b[v], k = u(m, P);
      y(k, P) && l(w, f(P, m), k);
    }
    return w;
  }
  return _basePickBy = p, _basePickBy;
}
var _baseHasIn$2, hasRequired_baseHasIn$1;
function require_baseHasIn$1() {
  if (hasRequired_baseHasIn$1) return _baseHasIn$2;
  hasRequired_baseHasIn$1 = 1;
  function u(l, f) {
    return l != null && f in Object(l);
  }
  return _baseHasIn$2 = u, _baseHasIn$2;
}
var _baseIsArguments$2, hasRequired_baseIsArguments$1;
function require_baseIsArguments$1() {
  if (hasRequired_baseIsArguments$1) return _baseIsArguments$2;
  hasRequired_baseIsArguments$1 = 1;
  var u = require_baseGetTag$1(), l = requireIsObjectLike$1(), f = "[object Arguments]";
  function p(m) {
    return l(m) && u(m) == f;
  }
  return _baseIsArguments$2 = p, _baseIsArguments$2;
}
var isArguments_1$2, hasRequiredIsArguments$1;
function requireIsArguments$1() {
  if (hasRequiredIsArguments$1) return isArguments_1$2;
  hasRequiredIsArguments$1 = 1;
  var u = require_baseIsArguments$1(), l = requireIsObjectLike$1(), f = Object.prototype, p = f.hasOwnProperty, m = f.propertyIsEnumerable, b = u(/* @__PURE__ */ (function() {
    return arguments;
  })()) ? u : function(y) {
    return l(y) && p.call(y, "callee") && !m.call(y, "callee");
  };
  return isArguments_1$2 = b, isArguments_1$2;
}
var isLength_1$2, hasRequiredIsLength$1;
function requireIsLength$1() {
  if (hasRequiredIsLength$1) return isLength_1$2;
  hasRequiredIsLength$1 = 1;
  var u = 9007199254740991;
  function l(f) {
    return typeof f == "number" && f > -1 && f % 1 == 0 && f <= u;
  }
  return isLength_1$2 = l, isLength_1$2;
}
var _hasPath$2, hasRequired_hasPath$1;
function require_hasPath$1() {
  if (hasRequired_hasPath$1) return _hasPath$2;
  hasRequired_hasPath$1 = 1;
  var u = require_castPath$1(), l = requireIsArguments$1(), f = requireIsArray$1(), p = require_isIndex$1(), m = requireIsLength$1(), b = require_toKey$1();
  function y(v, $, w) {
    $ = u($, v);
    for (var P = -1, k = $.length, x = !1; ++P < k; ) {
      var S = b($[P]);
      if (!(x = v != null && w(v, S)))
        break;
      v = v[S];
    }
    return x || ++P != k ? x : (k = v == null ? 0 : v.length, !!k && m(k) && p(S, k) && (f(v) || l(v)));
  }
  return _hasPath$2 = y, _hasPath$2;
}
var hasIn_1$2, hasRequiredHasIn$1;
function requireHasIn$1() {
  if (hasRequiredHasIn$1) return hasIn_1$2;
  hasRequiredHasIn$1 = 1;
  var u = require_baseHasIn$1(), l = require_hasPath$1();
  function f(p, m) {
    return p != null && l(p, m, u);
  }
  return hasIn_1$2 = f, hasIn_1$2;
}
var _basePick, hasRequired_basePick;
function require_basePick() {
  if (hasRequired_basePick) return _basePick;
  hasRequired_basePick = 1;
  var u = require_basePickBy(), l = requireHasIn$1();
  function f(p, m) {
    return u(p, m, function(b, y) {
      return l(p, y);
    });
  }
  return _basePick = f, _basePick;
}
var _arrayPush$2, hasRequired_arrayPush$1;
function require_arrayPush$1() {
  if (hasRequired_arrayPush$1) return _arrayPush$2;
  hasRequired_arrayPush$1 = 1;
  function u(l, f) {
    for (var p = -1, m = f.length, b = l.length; ++p < m; )
      l[b + p] = f[p];
    return l;
  }
  return _arrayPush$2 = u, _arrayPush$2;
}
var _isFlattenable$2, hasRequired_isFlattenable$1;
function require_isFlattenable$1() {
  if (hasRequired_isFlattenable$1) return _isFlattenable$2;
  hasRequired_isFlattenable$1 = 1;
  var u = require_Symbol$1(), l = requireIsArguments$1(), f = requireIsArray$1(), p = u ? u.isConcatSpreadable : void 0;
  function m(b) {
    return f(b) || l(b) || !!(p && b && b[p]);
  }
  return _isFlattenable$2 = m, _isFlattenable$2;
}
var _baseFlatten$2, hasRequired_baseFlatten$1;
function require_baseFlatten$1() {
  if (hasRequired_baseFlatten$1) return _baseFlatten$2;
  hasRequired_baseFlatten$1 = 1;
  var u = require_arrayPush$1(), l = require_isFlattenable$1();
  function f(p, m, b, y, v) {
    var $ = -1, w = p.length;
    for (b || (b = l), v || (v = []); ++$ < w; ) {
      var P = p[$];
      m > 0 && b(P) ? m > 1 ? f(P, m - 1, b, y, v) : u(v, P) : y || (v[v.length] = P);
    }
    return v;
  }
  return _baseFlatten$2 = f, _baseFlatten$2;
}
var flatten_1$2, hasRequiredFlatten$1;
function requireFlatten$1() {
  if (hasRequiredFlatten$1) return flatten_1$2;
  hasRequiredFlatten$1 = 1;
  var u = require_baseFlatten$1();
  function l(f) {
    var p = f == null ? 0 : f.length;
    return p ? u(f, 1) : [];
  }
  return flatten_1$2 = l, flatten_1$2;
}
var _apply$2, hasRequired_apply$1;
function require_apply$1() {
  if (hasRequired_apply$1) return _apply$2;
  hasRequired_apply$1 = 1;
  function u(l, f, p) {
    switch (p.length) {
      case 0:
        return l.call(f);
      case 1:
        return l.call(f, p[0]);
      case 2:
        return l.call(f, p[0], p[1]);
      case 3:
        return l.call(f, p[0], p[1], p[2]);
    }
    return l.apply(f, p);
  }
  return _apply$2 = u, _apply$2;
}
var _overRest$2, hasRequired_overRest$1;
function require_overRest$1() {
  if (hasRequired_overRest$1) return _overRest$2;
  hasRequired_overRest$1 = 1;
  var u = require_apply$1(), l = Math.max;
  function f(p, m, b) {
    return m = l(m === void 0 ? p.length - 1 : m, 0), function() {
      for (var y = arguments, v = -1, $ = l(y.length - m, 0), w = Array($); ++v < $; )
        w[v] = y[m + v];
      v = -1;
      for (var P = Array(m + 1); ++v < m; )
        P[v] = y[v];
      return P[m] = b(w), u(p, this, P);
    };
  }
  return _overRest$2 = f, _overRest$2;
}
var constant_1$2, hasRequiredConstant$1;
function requireConstant$1() {
  if (hasRequiredConstant$1) return constant_1$2;
  hasRequiredConstant$1 = 1;
  function u(l) {
    return function() {
      return l;
    };
  }
  return constant_1$2 = u, constant_1$2;
}
var identity_1$2, hasRequiredIdentity$1;
function requireIdentity$1() {
  if (hasRequiredIdentity$1) return identity_1$2;
  hasRequiredIdentity$1 = 1;
  function u(l) {
    return l;
  }
  return identity_1$2 = u, identity_1$2;
}
var _baseSetToString$2, hasRequired_baseSetToString$1;
function require_baseSetToString$1() {
  if (hasRequired_baseSetToString$1) return _baseSetToString$2;
  hasRequired_baseSetToString$1 = 1;
  var u = requireConstant$1(), l = require_defineProperty$1(), f = requireIdentity$1(), p = l ? function(m, b) {
    return l(m, "toString", {
      configurable: !0,
      enumerable: !1,
      value: u(b),
      writable: !0
    });
  } : f;
  return _baseSetToString$2 = p, _baseSetToString$2;
}
var _shortOut$2, hasRequired_shortOut$1;
function require_shortOut$1() {
  if (hasRequired_shortOut$1) return _shortOut$2;
  hasRequired_shortOut$1 = 1;
  var u = 800, l = 16, f = Date.now;
  function p(m) {
    var b = 0, y = 0;
    return function() {
      var v = f(), $ = l - (v - y);
      if (y = v, $ > 0) {
        if (++b >= u)
          return arguments[0];
      } else
        b = 0;
      return m.apply(void 0, arguments);
    };
  }
  return _shortOut$2 = p, _shortOut$2;
}
var _setToString$2, hasRequired_setToString$1;
function require_setToString$1() {
  if (hasRequired_setToString$1) return _setToString$2;
  hasRequired_setToString$1 = 1;
  var u = require_baseSetToString$1(), l = require_shortOut$1(), f = l(u);
  return _setToString$2 = f, _setToString$2;
}
var _flatRest$2, hasRequired_flatRest$1;
function require_flatRest$1() {
  if (hasRequired_flatRest$1) return _flatRest$2;
  hasRequired_flatRest$1 = 1;
  var u = requireFlatten$1(), l = require_overRest$1(), f = require_setToString$1();
  function p(m) {
    return f(l(m, void 0, u), m + "");
  }
  return _flatRest$2 = p, _flatRest$2;
}
var pick_1, hasRequiredPick;
function requirePick() {
  if (hasRequiredPick) return pick_1;
  hasRequiredPick = 1;
  var u = require_basePick(), l = require_flatRest$1(), f = l(function(p, m) {
    return p == null ? {} : u(p, m);
  });
  return pick_1 = f, pick_1;
}
var pickExports = requirePick();
const pick$1 = /* @__PURE__ */ getDefaultExportFromCjs$1(pickExports), FILTER_ALLOWED_KEYS = [
  "field",
  "operator",
  "value",
  "type",
  "externalType",
  "valueType",
  "noValue",
  "formulaType"
];
function hasSchema(u) {
  return typeof u == "object" && !Array.isArray(u) && u !== null && !(u instanceof Date) && Object.keys(u).length > 0;
}
function isSupportedUserSearch(u) {
  const l = [
    { op: BasicOperator.STRING, key: "email" },
    { op: BasicOperator.FUZZY, key: "email" },
    { op: BasicOperator.EQUAL, key: "_id" },
    { op: ArrayOperator.ONE_OF, key: "_id" }
  ], { allOr: f, onEmptyFilter: p, ...m } = u;
  for (const [b, y] of Object.entries(m)) {
    if (typeof y != "object")
      return !1;
    if (isLogicalSearchOperator(b)) {
      for (const w of u[b].conditions)
        if (!isSupportedUserSearch(w))
          return !1;
      return !0;
    }
    const v = Object.keys(y || {});
    if (v.length === 0)
      continue;
    if (!l.find(
      (w) => w.op === b && v.length === 1 && v[0] === w.key
    ))
      return !1;
  }
  return !0;
}
function processSearchFilters(u) {
  if (!u || u.length === 0)
    return;
  const { allOr: l, onEmptyFilter: f, filters: p } = splitFiltersArray(u);
  return {
    logicalOperator: UILogicalOperator.ALL,
    onEmptyFilter: f || EmptyFilterOption.RETURN_ALL,
    groups: [
      {
        logicalOperator: l ? UILogicalOperator.ANY : UILogicalOperator.ALL,
        filters: p.map((m) => {
          const b = pick$1(
            m,
            FILTER_ALLOWED_KEYS
          );
          return b.field = removeKeyNumbering(b.field), b;
        })
      }
    ]
  };
}
const deepGet$1 = (u, l) => {
  if (!u || !l)
    return null;
  if (Object.prototype.hasOwnProperty.call(u, l))
    return u[l];
  const f = l.split(".");
  for (let p = 0; p < f.length; p++)
    u = u?.[f[p]];
  return u;
}, getUserInitials = (u) => {
  if (!u)
    return "?";
  let l = "";
  return l += u.firstName ? u.firstName[0] : "", l += u.lastName ? u.lastName[0] : "", l !== "" ? l : u.email?.[0] || "U";
}, getUserColor = (u) => {
  let l = u?._id;
  if (!l)
    return "var(--spectrum-global-color-blue-400)";
  l = l.replace("ro_ta_users_", "");
  let f = 1;
  for (let p = 0; p < l.length; p++)
    f += l.charCodeAt(p), f = f % 36;
  return `hsl(${f * 10}, 50%, 40%)`;
}, getUserLabel = (u) => {
  if (!u)
    return "";
  const { firstName: l, lastName: f, email: p } = u;
  return l && f ? `${l} ${f}` : l || f || p;
};
function cancelableTimeout(u) {
  let l;
  return [
    new Promise((f, p) => {
      l = setTimeout(() => {
        p({
          status: 301,
          errno: "ETIME"
        });
      }, u);
    }),
    () => {
      clearTimeout(l);
    }
  ];
}
async function withTimeout(u, l) {
  const [f, p] = cancelableTimeout(u), m = await Promise.race([l(), f]);
  return p(), m;
}
const escapeHtml = (u) => u == null ? "" : String(u).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"), normalizeForComparison = (u) => u.toLowerCase().trim();
var _baseTimes$2, hasRequired_baseTimes$1;
function require_baseTimes$1() {
  if (hasRequired_baseTimes$1) return _baseTimes$2;
  hasRequired_baseTimes$1 = 1;
  function u(l, f) {
    for (var p = -1, m = Array(l); ++p < l; )
      m[p] = f(p);
    return m;
  }
  return _baseTimes$2 = u, _baseTimes$2;
}
var isBuffer$4 = { exports: {} }, stubFalse_1$2, hasRequiredStubFalse$1;
function requireStubFalse$1() {
  if (hasRequiredStubFalse$1) return stubFalse_1$2;
  hasRequiredStubFalse$1 = 1;
  function u() {
    return !1;
  }
  return stubFalse_1$2 = u, stubFalse_1$2;
}
isBuffer$4.exports;
var hasRequiredIsBuffer$1;
function requireIsBuffer$1() {
  return hasRequiredIsBuffer$1 || (hasRequiredIsBuffer$1 = 1, (function(u, l) {
    var f = require_root$1(), p = requireStubFalse$1(), m = l && !l.nodeType && l, b = m && !0 && u && !u.nodeType && u, y = b && b.exports === m, v = y ? f.Buffer : void 0, $ = v ? v.isBuffer : void 0, w = $ || p;
    u.exports = w;
  })(isBuffer$4, isBuffer$4.exports)), isBuffer$4.exports;
}
var _baseIsTypedArray$2, hasRequired_baseIsTypedArray$1;
function require_baseIsTypedArray$1() {
  if (hasRequired_baseIsTypedArray$1) return _baseIsTypedArray$2;
  hasRequired_baseIsTypedArray$1 = 1;
  var u = require_baseGetTag$1(), l = requireIsLength$1(), f = requireIsObjectLike$1(), p = "[object Arguments]", m = "[object Array]", b = "[object Boolean]", y = "[object Date]", v = "[object Error]", $ = "[object Function]", w = "[object Map]", P = "[object Number]", k = "[object Object]", x = "[object RegExp]", S = "[object Set]", T = "[object String]", M = "[object WeakMap]", E = "[object ArrayBuffer]", R = "[object DataView]", O = "[object Float32Array]", D = "[object Float64Array]", q = "[object Int8Array]", F = "[object Int16Array]", L = "[object Int32Array]", N = "[object Uint8Array]", z = "[object Uint8ClampedArray]", V = "[object Uint16Array]", W = "[object Uint32Array]", j = {};
  j[O] = j[D] = j[q] = j[F] = j[L] = j[N] = j[z] = j[V] = j[W] = !0, j[p] = j[m] = j[E] = j[b] = j[R] = j[y] = j[v] = j[$] = j[w] = j[P] = j[k] = j[x] = j[S] = j[T] = j[M] = !1;
  function U(Z) {
    return f(Z) && l(Z.length) && !!j[u(Z)];
  }
  return _baseIsTypedArray$2 = U, _baseIsTypedArray$2;
}
var _baseUnary$2, hasRequired_baseUnary$1;
function require_baseUnary$1() {
  if (hasRequired_baseUnary$1) return _baseUnary$2;
  hasRequired_baseUnary$1 = 1;
  function u(l) {
    return function(f) {
      return l(f);
    };
  }
  return _baseUnary$2 = u, _baseUnary$2;
}
var _nodeUtil$2 = { exports: {} };
_nodeUtil$2.exports;
var hasRequired_nodeUtil$1;
function require_nodeUtil$1() {
  return hasRequired_nodeUtil$1 || (hasRequired_nodeUtil$1 = 1, (function(u, l) {
    var f = require_freeGlobal$1(), p = l && !l.nodeType && l, m = p && !0 && u && !u.nodeType && u, b = m && m.exports === p, y = b && f.process, v = (function() {
      try {
        var $ = m && m.require && m.require("util").types;
        return $ || y && y.binding && y.binding("util");
      } catch {
      }
    })();
    u.exports = v;
  })(_nodeUtil$2, _nodeUtil$2.exports)), _nodeUtil$2.exports;
}
var isTypedArray_1$2, hasRequiredIsTypedArray$1;
function requireIsTypedArray$1() {
  if (hasRequiredIsTypedArray$1) return isTypedArray_1$2;
  hasRequiredIsTypedArray$1 = 1;
  var u = require_baseIsTypedArray$1(), l = require_baseUnary$1(), f = require_nodeUtil$1(), p = f && f.isTypedArray, m = p ? l(p) : u;
  return isTypedArray_1$2 = m, isTypedArray_1$2;
}
var _arrayLikeKeys$2, hasRequired_arrayLikeKeys$1;
function require_arrayLikeKeys$1() {
  if (hasRequired_arrayLikeKeys$1) return _arrayLikeKeys$2;
  hasRequired_arrayLikeKeys$1 = 1;
  var u = require_baseTimes$1(), l = requireIsArguments$1(), f = requireIsArray$1(), p = requireIsBuffer$1(), m = require_isIndex$1(), b = requireIsTypedArray$1(), y = Object.prototype, v = y.hasOwnProperty;
  function $(w, P) {
    var k = f(w), x = !k && l(w), S = !k && !x && p(w), T = !k && !x && !S && b(w), M = k || x || S || T, E = M ? u(w.length, String) : [], R = E.length;
    for (var O in w)
      (P || v.call(w, O)) && !(M && // Safari 9 has enumerable `arguments.length` in strict mode.
      (O == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      S && (O == "offset" || O == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      T && (O == "buffer" || O == "byteLength" || O == "byteOffset") || // Skip index properties.
      m(O, R))) && E.push(O);
    return E;
  }
  return _arrayLikeKeys$2 = $, _arrayLikeKeys$2;
}
var _isPrototype$2, hasRequired_isPrototype$1;
function require_isPrototype$1() {
  if (hasRequired_isPrototype$1) return _isPrototype$2;
  hasRequired_isPrototype$1 = 1;
  var u = Object.prototype;
  function l(f) {
    var p = f && f.constructor, m = typeof p == "function" && p.prototype || u;
    return f === m;
  }
  return _isPrototype$2 = l, _isPrototype$2;
}
var _nativeKeys$2, hasRequired_nativeKeys$1;
function require_nativeKeys$1() {
  if (hasRequired_nativeKeys$1) return _nativeKeys$2;
  hasRequired_nativeKeys$1 = 1;
  var u = require_overArg$1(), l = u(Object.keys, Object);
  return _nativeKeys$2 = l, _nativeKeys$2;
}
var _baseKeys$2, hasRequired_baseKeys$1;
function require_baseKeys$1() {
  if (hasRequired_baseKeys$1) return _baseKeys$2;
  hasRequired_baseKeys$1 = 1;
  var u = require_isPrototype$1(), l = require_nativeKeys$1(), f = Object.prototype, p = f.hasOwnProperty;
  function m(b) {
    if (!u(b))
      return l(b);
    var y = [];
    for (var v in Object(b))
      p.call(b, v) && v != "constructor" && y.push(v);
    return y;
  }
  return _baseKeys$2 = m, _baseKeys$2;
}
var isArrayLike_1$2, hasRequiredIsArrayLike$1;
function requireIsArrayLike$1() {
  if (hasRequiredIsArrayLike$1) return isArrayLike_1$2;
  hasRequiredIsArrayLike$1 = 1;
  var u = requireIsFunction$1(), l = requireIsLength$1();
  function f(p) {
    return p != null && l(p.length) && !u(p);
  }
  return isArrayLike_1$2 = f, isArrayLike_1$2;
}
var keys_1$2, hasRequiredKeys$1;
function requireKeys$1() {
  if (hasRequiredKeys$1) return keys_1$2;
  hasRequiredKeys$1 = 1;
  var u = require_arrayLikeKeys$1(), l = require_baseKeys$1(), f = requireIsArrayLike$1();
  function p(m) {
    return f(m) ? u(m) : l(m);
  }
  return keys_1$2 = p, keys_1$2;
}
var _stackClear$2, hasRequired_stackClear$1;
function require_stackClear$1() {
  if (hasRequired_stackClear$1) return _stackClear$2;
  hasRequired_stackClear$1 = 1;
  var u = require_ListCache$1();
  function l() {
    this.__data__ = new u(), this.size = 0;
  }
  return _stackClear$2 = l, _stackClear$2;
}
var _stackDelete$2, hasRequired_stackDelete$1;
function require_stackDelete$1() {
  if (hasRequired_stackDelete$1) return _stackDelete$2;
  hasRequired_stackDelete$1 = 1;
  function u(l) {
    var f = this.__data__, p = f.delete(l);
    return this.size = f.size, p;
  }
  return _stackDelete$2 = u, _stackDelete$2;
}
var _stackGet$2, hasRequired_stackGet$1;
function require_stackGet$1() {
  if (hasRequired_stackGet$1) return _stackGet$2;
  hasRequired_stackGet$1 = 1;
  function u(l) {
    return this.__data__.get(l);
  }
  return _stackGet$2 = u, _stackGet$2;
}
var _stackHas$2, hasRequired_stackHas$1;
function require_stackHas$1() {
  if (hasRequired_stackHas$1) return _stackHas$2;
  hasRequired_stackHas$1 = 1;
  function u(l) {
    return this.__data__.has(l);
  }
  return _stackHas$2 = u, _stackHas$2;
}
var _stackSet$2, hasRequired_stackSet$1;
function require_stackSet$1() {
  if (hasRequired_stackSet$1) return _stackSet$2;
  hasRequired_stackSet$1 = 1;
  var u = require_ListCache$1(), l = require_Map$1(), f = require_MapCache$1(), p = 200;
  function m(b, y) {
    var v = this.__data__;
    if (v instanceof u) {
      var $ = v.__data__;
      if (!l || $.length < p - 1)
        return $.push([b, y]), this.size = ++v.size, this;
      v = this.__data__ = new f($);
    }
    return v.set(b, y), this.size = v.size, this;
  }
  return _stackSet$2 = m, _stackSet$2;
}
var _Stack$2, hasRequired_Stack$1;
function require_Stack$1() {
  if (hasRequired_Stack$1) return _Stack$2;
  hasRequired_Stack$1 = 1;
  var u = require_ListCache$1(), l = require_stackClear$1(), f = require_stackDelete$1(), p = require_stackGet$1(), m = require_stackHas$1(), b = require_stackSet$1();
  function y(v) {
    var $ = this.__data__ = new u(v);
    this.size = $.size;
  }
  return y.prototype.clear = l, y.prototype.delete = f, y.prototype.get = p, y.prototype.has = m, y.prototype.set = b, _Stack$2 = y, _Stack$2;
}
var _setCacheAdd$2, hasRequired_setCacheAdd$1;
function require_setCacheAdd$1() {
  if (hasRequired_setCacheAdd$1) return _setCacheAdd$2;
  hasRequired_setCacheAdd$1 = 1;
  var u = "__lodash_hash_undefined__";
  function l(f) {
    return this.__data__.set(f, u), this;
  }
  return _setCacheAdd$2 = l, _setCacheAdd$2;
}
var _setCacheHas$2, hasRequired_setCacheHas$1;
function require_setCacheHas$1() {
  if (hasRequired_setCacheHas$1) return _setCacheHas$2;
  hasRequired_setCacheHas$1 = 1;
  function u(l) {
    return this.__data__.has(l);
  }
  return _setCacheHas$2 = u, _setCacheHas$2;
}
var _SetCache$2, hasRequired_SetCache$1;
function require_SetCache$1() {
  if (hasRequired_SetCache$1) return _SetCache$2;
  hasRequired_SetCache$1 = 1;
  var u = require_MapCache$1(), l = require_setCacheAdd$1(), f = require_setCacheHas$1();
  function p(m) {
    var b = -1, y = m == null ? 0 : m.length;
    for (this.__data__ = new u(); ++b < y; )
      this.add(m[b]);
  }
  return p.prototype.add = p.prototype.push = l, p.prototype.has = f, _SetCache$2 = p, _SetCache$2;
}
var _arraySome$2, hasRequired_arraySome$1;
function require_arraySome$1() {
  if (hasRequired_arraySome$1) return _arraySome$2;
  hasRequired_arraySome$1 = 1;
  function u(l, f) {
    for (var p = -1, m = l == null ? 0 : l.length; ++p < m; )
      if (f(l[p], p, l))
        return !0;
    return !1;
  }
  return _arraySome$2 = u, _arraySome$2;
}
var _cacheHas$2, hasRequired_cacheHas$1;
function require_cacheHas$1() {
  if (hasRequired_cacheHas$1) return _cacheHas$2;
  hasRequired_cacheHas$1 = 1;
  function u(l, f) {
    return l.has(f);
  }
  return _cacheHas$2 = u, _cacheHas$2;
}
var _equalArrays$2, hasRequired_equalArrays$1;
function require_equalArrays$1() {
  if (hasRequired_equalArrays$1) return _equalArrays$2;
  hasRequired_equalArrays$1 = 1;
  var u = require_SetCache$1(), l = require_arraySome$1(), f = require_cacheHas$1(), p = 1, m = 2;
  function b(y, v, $, w, P, k) {
    var x = $ & p, S = y.length, T = v.length;
    if (S != T && !(x && T > S))
      return !1;
    var M = k.get(y), E = k.get(v);
    if (M && E)
      return M == v && E == y;
    var R = -1, O = !0, D = $ & m ? new u() : void 0;
    for (k.set(y, v), k.set(v, y); ++R < S; ) {
      var q = y[R], F = v[R];
      if (w)
        var L = x ? w(F, q, R, v, y, k) : w(q, F, R, y, v, k);
      if (L !== void 0) {
        if (L)
          continue;
        O = !1;
        break;
      }
      if (D) {
        if (!l(v, function(N, z) {
          if (!f(D, z) && (q === N || P(q, N, $, w, k)))
            return D.push(z);
        })) {
          O = !1;
          break;
        }
      } else if (!(q === F || P(q, F, $, w, k))) {
        O = !1;
        break;
      }
    }
    return k.delete(y), k.delete(v), O;
  }
  return _equalArrays$2 = b, _equalArrays$2;
}
var _Uint8Array$2, hasRequired_Uint8Array$1;
function require_Uint8Array$1() {
  if (hasRequired_Uint8Array$1) return _Uint8Array$2;
  hasRequired_Uint8Array$1 = 1;
  var u = require_root$1(), l = u.Uint8Array;
  return _Uint8Array$2 = l, _Uint8Array$2;
}
var _mapToArray$2, hasRequired_mapToArray$1;
function require_mapToArray$1() {
  if (hasRequired_mapToArray$1) return _mapToArray$2;
  hasRequired_mapToArray$1 = 1;
  function u(l) {
    var f = -1, p = Array(l.size);
    return l.forEach(function(m, b) {
      p[++f] = [b, m];
    }), p;
  }
  return _mapToArray$2 = u, _mapToArray$2;
}
var _setToArray$2, hasRequired_setToArray$1;
function require_setToArray$1() {
  if (hasRequired_setToArray$1) return _setToArray$2;
  hasRequired_setToArray$1 = 1;
  function u(l) {
    var f = -1, p = Array(l.size);
    return l.forEach(function(m) {
      p[++f] = m;
    }), p;
  }
  return _setToArray$2 = u, _setToArray$2;
}
var _equalByTag$2, hasRequired_equalByTag$1;
function require_equalByTag$1() {
  if (hasRequired_equalByTag$1) return _equalByTag$2;
  hasRequired_equalByTag$1 = 1;
  var u = require_Symbol$1(), l = require_Uint8Array$1(), f = requireEq$1(), p = require_equalArrays$1(), m = require_mapToArray$1(), b = require_setToArray$1(), y = 1, v = 2, $ = "[object Boolean]", w = "[object Date]", P = "[object Error]", k = "[object Map]", x = "[object Number]", S = "[object RegExp]", T = "[object Set]", M = "[object String]", E = "[object Symbol]", R = "[object ArrayBuffer]", O = "[object DataView]", D = u ? u.prototype : void 0, q = D ? D.valueOf : void 0;
  function F(L, N, z, V, W, j, U) {
    switch (z) {
      case O:
        if (L.byteLength != N.byteLength || L.byteOffset != N.byteOffset)
          return !1;
        L = L.buffer, N = N.buffer;
      case R:
        return !(L.byteLength != N.byteLength || !j(new l(L), new l(N)));
      case $:
      case w:
      case x:
        return f(+L, +N);
      case P:
        return L.name == N.name && L.message == N.message;
      case S:
      case M:
        return L == N + "";
      case k:
        var Z = m;
      case T:
        var X = V & y;
        if (Z || (Z = b), L.size != N.size && !X)
          return !1;
        var B = U.get(L);
        if (B)
          return B == N;
        V |= v, U.set(L, N);
        var H = p(Z(L), Z(N), V, W, j, U);
        return U.delete(L), H;
      case E:
        if (q)
          return q.call(L) == q.call(N);
    }
    return !1;
  }
  return _equalByTag$2 = F, _equalByTag$2;
}
var _baseGetAllKeys$2, hasRequired_baseGetAllKeys$1;
function require_baseGetAllKeys$1() {
  if (hasRequired_baseGetAllKeys$1) return _baseGetAllKeys$2;
  hasRequired_baseGetAllKeys$1 = 1;
  var u = require_arrayPush$1(), l = requireIsArray$1();
  function f(p, m, b) {
    var y = m(p);
    return l(p) ? y : u(y, b(p));
  }
  return _baseGetAllKeys$2 = f, _baseGetAllKeys$2;
}
var _arrayFilter$2, hasRequired_arrayFilter$1;
function require_arrayFilter$1() {
  if (hasRequired_arrayFilter$1) return _arrayFilter$2;
  hasRequired_arrayFilter$1 = 1;
  function u(l, f) {
    for (var p = -1, m = l == null ? 0 : l.length, b = 0, y = []; ++p < m; ) {
      var v = l[p];
      f(v, p, l) && (y[b++] = v);
    }
    return y;
  }
  return _arrayFilter$2 = u, _arrayFilter$2;
}
var stubArray_1$2, hasRequiredStubArray$1;
function requireStubArray$1() {
  if (hasRequiredStubArray$1) return stubArray_1$2;
  hasRequiredStubArray$1 = 1;
  function u() {
    return [];
  }
  return stubArray_1$2 = u, stubArray_1$2;
}
var _getSymbols$2, hasRequired_getSymbols$1;
function require_getSymbols$1() {
  if (hasRequired_getSymbols$1) return _getSymbols$2;
  hasRequired_getSymbols$1 = 1;
  var u = require_arrayFilter$1(), l = requireStubArray$1(), f = Object.prototype, p = f.propertyIsEnumerable, m = Object.getOwnPropertySymbols, b = m ? function(y) {
    return y == null ? [] : (y = Object(y), u(m(y), function(v) {
      return p.call(y, v);
    }));
  } : l;
  return _getSymbols$2 = b, _getSymbols$2;
}
var _getAllKeys$2, hasRequired_getAllKeys$1;
function require_getAllKeys$1() {
  if (hasRequired_getAllKeys$1) return _getAllKeys$2;
  hasRequired_getAllKeys$1 = 1;
  var u = require_baseGetAllKeys$1(), l = require_getSymbols$1(), f = requireKeys$1();
  function p(m) {
    return u(m, f, l);
  }
  return _getAllKeys$2 = p, _getAllKeys$2;
}
var _equalObjects$2, hasRequired_equalObjects$1;
function require_equalObjects$1() {
  if (hasRequired_equalObjects$1) return _equalObjects$2;
  hasRequired_equalObjects$1 = 1;
  var u = require_getAllKeys$1(), l = 1, f = Object.prototype, p = f.hasOwnProperty;
  function m(b, y, v, $, w, P) {
    var k = v & l, x = u(b), S = x.length, T = u(y), M = T.length;
    if (S != M && !k)
      return !1;
    for (var E = S; E--; ) {
      var R = x[E];
      if (!(k ? R in y : p.call(y, R)))
        return !1;
    }
    var O = P.get(b), D = P.get(y);
    if (O && D)
      return O == y && D == b;
    var q = !0;
    P.set(b, y), P.set(y, b);
    for (var F = k; ++E < S; ) {
      R = x[E];
      var L = b[R], N = y[R];
      if ($)
        var z = k ? $(N, L, R, y, b, P) : $(L, N, R, b, y, P);
      if (!(z === void 0 ? L === N || w(L, N, v, $, P) : z)) {
        q = !1;
        break;
      }
      F || (F = R == "constructor");
    }
    if (q && !F) {
      var V = b.constructor, W = y.constructor;
      V != W && "constructor" in b && "constructor" in y && !(typeof V == "function" && V instanceof V && typeof W == "function" && W instanceof W) && (q = !1);
    }
    return P.delete(b), P.delete(y), q;
  }
  return _equalObjects$2 = m, _equalObjects$2;
}
var _DataView$2, hasRequired_DataView$1;
function require_DataView$1() {
  if (hasRequired_DataView$1) return _DataView$2;
  hasRequired_DataView$1 = 1;
  var u = require_getNative$1(), l = require_root$1(), f = u(l, "DataView");
  return _DataView$2 = f, _DataView$2;
}
var _Promise$2, hasRequired_Promise$1;
function require_Promise$1() {
  if (hasRequired_Promise$1) return _Promise$2;
  hasRequired_Promise$1 = 1;
  var u = require_getNative$1(), l = require_root$1(), f = u(l, "Promise");
  return _Promise$2 = f, _Promise$2;
}
var _Set$2, hasRequired_Set$1;
function require_Set$1() {
  if (hasRequired_Set$1) return _Set$2;
  hasRequired_Set$1 = 1;
  var u = require_getNative$1(), l = require_root$1(), f = u(l, "Set");
  return _Set$2 = f, _Set$2;
}
var _WeakMap$2, hasRequired_WeakMap$1;
function require_WeakMap$1() {
  if (hasRequired_WeakMap$1) return _WeakMap$2;
  hasRequired_WeakMap$1 = 1;
  var u = require_getNative$1(), l = require_root$1(), f = u(l, "WeakMap");
  return _WeakMap$2 = f, _WeakMap$2;
}
var _getTag$2, hasRequired_getTag$1;
function require_getTag$1() {
  if (hasRequired_getTag$1) return _getTag$2;
  hasRequired_getTag$1 = 1;
  var u = require_DataView$1(), l = require_Map$1(), f = require_Promise$1(), p = require_Set$1(), m = require_WeakMap$1(), b = require_baseGetTag$1(), y = require_toSource$1(), v = "[object Map]", $ = "[object Object]", w = "[object Promise]", P = "[object Set]", k = "[object WeakMap]", x = "[object DataView]", S = y(u), T = y(l), M = y(f), E = y(p), R = y(m), O = b;
  return (u && O(new u(new ArrayBuffer(1))) != x || l && O(new l()) != v || f && O(f.resolve()) != w || p && O(new p()) != P || m && O(new m()) != k) && (O = function(D) {
    var q = b(D), F = q == $ ? D.constructor : void 0, L = F ? y(F) : "";
    if (L)
      switch (L) {
        case S:
          return x;
        case T:
          return v;
        case M:
          return w;
        case E:
          return P;
        case R:
          return k;
      }
    return q;
  }), _getTag$2 = O, _getTag$2;
}
var _baseIsEqualDeep$2, hasRequired_baseIsEqualDeep$1;
function require_baseIsEqualDeep$1() {
  if (hasRequired_baseIsEqualDeep$1) return _baseIsEqualDeep$2;
  hasRequired_baseIsEqualDeep$1 = 1;
  var u = require_Stack$1(), l = require_equalArrays$1(), f = require_equalByTag$1(), p = require_equalObjects$1(), m = require_getTag$1(), b = requireIsArray$1(), y = requireIsBuffer$1(), v = requireIsTypedArray$1(), $ = 1, w = "[object Arguments]", P = "[object Array]", k = "[object Object]", x = Object.prototype, S = x.hasOwnProperty;
  function T(M, E, R, O, D, q) {
    var F = b(M), L = b(E), N = F ? P : m(M), z = L ? P : m(E);
    N = N == w ? k : N, z = z == w ? k : z;
    var V = N == k, W = z == k, j = N == z;
    if (j && y(M)) {
      if (!y(E))
        return !1;
      F = !0, V = !1;
    }
    if (j && !V)
      return q || (q = new u()), F || v(M) ? l(M, E, R, O, D, q) : f(M, E, N, R, O, D, q);
    if (!(R & $)) {
      var U = V && S.call(M, "__wrapped__"), Z = W && S.call(E, "__wrapped__");
      if (U || Z) {
        var X = U ? M.value() : M, B = Z ? E.value() : E;
        return q || (q = new u()), D(X, B, R, O, q);
      }
    }
    return j ? (q || (q = new u()), p(M, E, R, O, D, q)) : !1;
  }
  return _baseIsEqualDeep$2 = T, _baseIsEqualDeep$2;
}
var _baseIsEqual$2, hasRequired_baseIsEqual$1;
function require_baseIsEqual$1() {
  if (hasRequired_baseIsEqual$1) return _baseIsEqual$2;
  hasRequired_baseIsEqual$1 = 1;
  var u = require_baseIsEqualDeep$1(), l = requireIsObjectLike$1();
  function f(p, m, b, y, v) {
    return p === m ? !0 : p == null || m == null || !l(p) && !l(m) ? p !== p && m !== m : u(p, m, b, y, f, v);
  }
  return _baseIsEqual$2 = f, _baseIsEqual$2;
}
var _baseIsMatch$2, hasRequired_baseIsMatch$1;
function require_baseIsMatch$1() {
  if (hasRequired_baseIsMatch$1) return _baseIsMatch$2;
  hasRequired_baseIsMatch$1 = 1;
  var u = require_Stack$1(), l = require_baseIsEqual$1(), f = 1, p = 2;
  function m(b, y, v, $) {
    var w = v.length, P = w, k = !$;
    if (b == null)
      return !P;
    for (b = Object(b); w--; ) {
      var x = v[w];
      if (k && x[2] ? x[1] !== b[x[0]] : !(x[0] in b))
        return !1;
    }
    for (; ++w < P; ) {
      x = v[w];
      var S = x[0], T = b[S], M = x[1];
      if (k && x[2]) {
        if (T === void 0 && !(S in b))
          return !1;
      } else {
        var E = new u();
        if ($)
          var R = $(T, M, S, b, y, E);
        if (!(R === void 0 ? l(M, T, f | p, $, E) : R))
          return !1;
      }
    }
    return !0;
  }
  return _baseIsMatch$2 = m, _baseIsMatch$2;
}
var _isStrictComparable$2, hasRequired_isStrictComparable$1;
function require_isStrictComparable$1() {
  if (hasRequired_isStrictComparable$1) return _isStrictComparable$2;
  hasRequired_isStrictComparable$1 = 1;
  var u = requireIsObject$1();
  function l(f) {
    return f === f && !u(f);
  }
  return _isStrictComparable$2 = l, _isStrictComparable$2;
}
var _getMatchData$2, hasRequired_getMatchData$1;
function require_getMatchData$1() {
  if (hasRequired_getMatchData$1) return _getMatchData$2;
  hasRequired_getMatchData$1 = 1;
  var u = require_isStrictComparable$1(), l = requireKeys$1();
  function f(p) {
    for (var m = l(p), b = m.length; b--; ) {
      var y = m[b], v = p[y];
      m[b] = [y, v, u(v)];
    }
    return m;
  }
  return _getMatchData$2 = f, _getMatchData$2;
}
var _matchesStrictComparable$2, hasRequired_matchesStrictComparable$1;
function require_matchesStrictComparable$1() {
  if (hasRequired_matchesStrictComparable$1) return _matchesStrictComparable$2;
  hasRequired_matchesStrictComparable$1 = 1;
  function u(l, f) {
    return function(p) {
      return p == null ? !1 : p[l] === f && (f !== void 0 || l in Object(p));
    };
  }
  return _matchesStrictComparable$2 = u, _matchesStrictComparable$2;
}
var _baseMatches$2, hasRequired_baseMatches$1;
function require_baseMatches$1() {
  if (hasRequired_baseMatches$1) return _baseMatches$2;
  hasRequired_baseMatches$1 = 1;
  var u = require_baseIsMatch$1(), l = require_getMatchData$1(), f = require_matchesStrictComparable$1();
  function p(m) {
    var b = l(m);
    return b.length == 1 && b[0][2] ? f(b[0][0], b[0][1]) : function(y) {
      return y === m || u(y, m, b);
    };
  }
  return _baseMatches$2 = p, _baseMatches$2;
}
var get_1$2, hasRequiredGet$1;
function requireGet$1() {
  if (hasRequiredGet$1) return get_1$2;
  hasRequiredGet$1 = 1;
  var u = require_baseGet$1();
  function l(f, p, m) {
    var b = f == null ? void 0 : u(f, p);
    return b === void 0 ? m : b;
  }
  return get_1$2 = l, get_1$2;
}
var _baseMatchesProperty$2, hasRequired_baseMatchesProperty$1;
function require_baseMatchesProperty$1() {
  if (hasRequired_baseMatchesProperty$1) return _baseMatchesProperty$2;
  hasRequired_baseMatchesProperty$1 = 1;
  var u = require_baseIsEqual$1(), l = requireGet$1(), f = requireHasIn$1(), p = require_isKey$1(), m = require_isStrictComparable$1(), b = require_matchesStrictComparable$1(), y = require_toKey$1(), v = 1, $ = 2;
  function w(P, k) {
    return p(P) && m(k) ? b(y(P), k) : function(x) {
      var S = l(x, P);
      return S === void 0 && S === k ? f(x, P) : u(k, S, v | $);
    };
  }
  return _baseMatchesProperty$2 = w, _baseMatchesProperty$2;
}
var _baseProperty$2, hasRequired_baseProperty$1;
function require_baseProperty$1() {
  if (hasRequired_baseProperty$1) return _baseProperty$2;
  hasRequired_baseProperty$1 = 1;
  function u(l) {
    return function(f) {
      return f?.[l];
    };
  }
  return _baseProperty$2 = u, _baseProperty$2;
}
var _basePropertyDeep$2, hasRequired_basePropertyDeep$1;
function require_basePropertyDeep$1() {
  if (hasRequired_basePropertyDeep$1) return _basePropertyDeep$2;
  hasRequired_basePropertyDeep$1 = 1;
  var u = require_baseGet$1();
  function l(f) {
    return function(p) {
      return u(p, f);
    };
  }
  return _basePropertyDeep$2 = l, _basePropertyDeep$2;
}
var property_1$2, hasRequiredProperty$1;
function requireProperty$1() {
  if (hasRequiredProperty$1) return property_1$2;
  hasRequiredProperty$1 = 1;
  var u = require_baseProperty$1(), l = require_basePropertyDeep$1(), f = require_isKey$1(), p = require_toKey$1();
  function m(b) {
    return f(b) ? u(p(b)) : l(b);
  }
  return property_1$2 = m, property_1$2;
}
var _baseIteratee$2, hasRequired_baseIteratee$1;
function require_baseIteratee$1() {
  if (hasRequired_baseIteratee$1) return _baseIteratee$2;
  hasRequired_baseIteratee$1 = 1;
  var u = require_baseMatches$1(), l = require_baseMatchesProperty$1(), f = requireIdentity$1(), p = requireIsArray$1(), m = requireProperty$1();
  function b(y) {
    return typeof y == "function" ? y : y == null ? f : typeof y == "object" ? p(y) ? l(y[0], y[1]) : u(y) : m(y);
  }
  return _baseIteratee$2 = b, _baseIteratee$2;
}
const __viteBrowserExternal = {}, __viteBrowserExternal$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: __viteBrowserExternal
}, Symbol.toStringTag, { value: "Module" })), require$$0 = /* @__PURE__ */ getAugmentedNamespace(__viteBrowserExternal$1);
function isDeprecatedSingleUserColumn(u) {
  return u.type === FieldType.BB_REFERENCE && u.subtype === BBReferenceFieldSubType.USER && u.constraints?.type !== "array";
}
function isRequired(u) {
  return !!u && (typeof u.presence != "boolean" && u.presence?.allowEmpty === !1 || u.presence === !0);
}
function encodeNonAscii(u) {
  return u.split("").map((l) => l.charCodeAt(0) > 127 ? "\\u" + l.charCodeAt(0).toString(16).padStart(4, "0") : l).join("");
}
function decodeNonAscii(u) {
  return u.replace(
    /\\u([0-9a-fA-F]{4})/g,
    (l, f) => String.fromCharCode(parseInt(f, 16))
  );
}
function isNumeric(u) {
  return u.type === FieldType.NUMBER || u.type === FieldType.BIGINT;
}
const schema = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  decodeNonAscii,
  encodeNonAscii,
  isDeprecatedSingleUserColumn,
  isNumeric,
  isRequired
}, Symbol.toStringTag, { value: "Module" }));
var _getSymbolsIn$2, hasRequired_getSymbolsIn$1;
function require_getSymbolsIn$1() {
  if (hasRequired_getSymbolsIn$1) return _getSymbolsIn$2;
  hasRequired_getSymbolsIn$1 = 1;
  var u = require_arrayPush$1(), l = require_getPrototype$1(), f = require_getSymbols$1(), p = requireStubArray$1(), m = Object.getOwnPropertySymbols, b = m ? function(y) {
    for (var v = []; y; )
      u(v, f(y)), y = l(y);
    return v;
  } : p;
  return _getSymbolsIn$2 = b, _getSymbolsIn$2;
}
var _nativeKeysIn$2, hasRequired_nativeKeysIn$1;
function require_nativeKeysIn$1() {
  if (hasRequired_nativeKeysIn$1) return _nativeKeysIn$2;
  hasRequired_nativeKeysIn$1 = 1;
  function u(l) {
    var f = [];
    if (l != null)
      for (var p in Object(l))
        f.push(p);
    return f;
  }
  return _nativeKeysIn$2 = u, _nativeKeysIn$2;
}
var _baseKeysIn$2, hasRequired_baseKeysIn$1;
function require_baseKeysIn$1() {
  if (hasRequired_baseKeysIn$1) return _baseKeysIn$2;
  hasRequired_baseKeysIn$1 = 1;
  var u = requireIsObject$1(), l = require_isPrototype$1(), f = require_nativeKeysIn$1(), p = Object.prototype, m = p.hasOwnProperty;
  function b(y) {
    if (!u(y))
      return f(y);
    var v = l(y), $ = [];
    for (var w in y)
      w == "constructor" && (v || !m.call(y, w)) || $.push(w);
    return $;
  }
  return _baseKeysIn$2 = b, _baseKeysIn$2;
}
var keysIn_1$2, hasRequiredKeysIn$1;
function requireKeysIn$1() {
  if (hasRequiredKeysIn$1) return keysIn_1$2;
  hasRequiredKeysIn$1 = 1;
  var u = require_arrayLikeKeys$1(), l = require_baseKeysIn$1(), f = requireIsArrayLike$1();
  function p(m) {
    return f(m) ? u(m, !0) : l(m);
  }
  return keysIn_1$2 = p, keysIn_1$2;
}
var _getAllKeysIn$2, hasRequired_getAllKeysIn$1;
function require_getAllKeysIn$1() {
  if (hasRequired_getAllKeysIn$1) return _getAllKeysIn$2;
  hasRequired_getAllKeysIn$1 = 1;
  var u = require_baseGetAllKeys$1(), l = require_getSymbolsIn$1(), f = requireKeysIn$1();
  function p(m) {
    return u(m, f, l);
  }
  return _getAllKeysIn$2 = p, _getAllKeysIn$2;
}
var pickBy_1, hasRequiredPickBy;
function requirePickBy() {
  if (hasRequiredPickBy) return pickBy_1;
  hasRequiredPickBy = 1;
  var u = require_arrayMap$1(), l = require_baseIteratee$1(), f = require_basePickBy(), p = require_getAllKeysIn$1();
  function m(b, y) {
    if (b == null)
      return {};
    var v = u(p(b), function($) {
      return [$];
    });
    return y = l(y), f(b, v, function($, w) {
      return y($, w[0]);
    });
  }
  return pickBy_1 = m, pickBy_1;
}
var pickByExports = requirePickBy();
const pickBy = /* @__PURE__ */ getDefaultExportFromCjs$1(pickByExports);
function isCalculationField(u) {
  return "calculationType" in u;
}
function isBasicViewField(u) {
  return !isCalculationField(u);
}
function isCalculationView(u) {
  return u.type === ViewV2Type.CALCULATION;
}
function hasCalculationFields(u) {
  return Object.values(u.schema || {}).some(isCalculationField);
}
function calculationFields(u) {
  return pickBy(u.schema || {}, isCalculationField);
}
function isVisible(u) {
  return u.visible !== !1;
}
function basicFields(u, l) {
  const { visible: f = !0 } = l || {};
  return pickBy(u.schema || {}, (p) => !isCalculationField(p) && (!f || isVisible(p)));
}
function isV2(u) {
  return u.version === 2;
}
const views = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  basicFields,
  calculationFields,
  hasCalculationFields,
  isBasicViewField,
  isCalculationField,
  isCalculationView,
  isV2,
  isVisible
}, Symbol.toStringTag, { value: "Module" })), PREVIEW_DEVICE_ORDER = ["desktop", "tablet", "mobile"], getNextPreviewDevice = (u) => {
  const l = PREVIEW_DEVICE_ORDER.indexOf(u || "desktop"), p = ((l === -1 ? 0 : l) + 1) % PREVIEW_DEVICE_ORDER.length;
  return PREVIEW_DEVICE_ORDER[p];
}, getPreviewDeviceIcon = (u) => u === "mobile" ? "device-mobile-camera" : u === "tablet" ? "device-tablet-camera" : "monitor", getPreviewModalDevice = (u) => u && u !== "desktop" ? u : null;
var isEmpty_1, hasRequiredIsEmpty;
function requireIsEmpty() {
  if (hasRequiredIsEmpty) return isEmpty_1;
  hasRequiredIsEmpty = 1;
  var u = require_baseKeys$1(), l = require_getTag$1(), f = requireIsArguments$1(), p = requireIsArray$1(), m = requireIsArrayLike$1(), b = requireIsBuffer$1(), y = require_isPrototype$1(), v = requireIsTypedArray$1(), $ = "[object Map]", w = "[object Set]", P = Object.prototype, k = P.hasOwnProperty;
  function x(S) {
    if (S == null)
      return !0;
    if (m(S) && (p(S) || typeof S == "string" || typeof S.splice == "function" || b(S) || v(S) || f(S)))
      return !S.length;
    var T = l(S);
    if (T == $ || T == w)
      return !S.size;
    if (y(S))
      return !u(S).length;
    for (var M in S)
      if (k.call(S, M))
        return !1;
    return !0;
  }
  return isEmpty_1 = x, isEmpty_1;
}
var isEmptyExports = requireIsEmpty();
const isEmpty = /* @__PURE__ */ getDefaultExportFromCjs$1(isEmptyExports), HBS_REGEX = /{{([^{].*?)}}/g, LOGICAL_OPERATORS = Object.values(LogicalOperator), SEARCH_OPERATORS = [
  ...Object.values(BasicOperator),
  ...Object.values(ArrayOperator),
  ...Object.values(RangeOperator)
], getValidOperatorsForType = (u, l, f) => {
  const p = OperatorOptions, m = [
    p.Equals,
    p.NotEquals,
    p.StartsWith,
    p.Like,
    p.Empty,
    p.NotEmpty,
    p.In
  ], b = [
    p.Equals,
    p.NotEquals,
    p.MoreThan,
    p.LessThan,
    p.Empty,
    p.NotEmpty,
    p.In
  ], y = [
    p.Contains,
    p.NotContains,
    p.ContainsAny,
    p.Empty,
    p.NotEmpty
  ];
  let v = [];
  const { type: $, formulaType: w, subtype: P } = u;
  $ === FieldType.STRING ? P === StringFieldSubType.ARRAY ? v = y : v = m : $ === FieldType.NUMBER || $ === FieldType.BIGINT ? v = b : $ === FieldType.OPTIONS ? v = [p.Equals, p.NotEquals, p.Empty, p.NotEmpty, p.In] : $ === FieldType.ARRAY ? v = y : $ === FieldType.BOOLEAN ? v = [p.Equals, p.NotEquals, p.Empty, p.NotEmpty] : $ === FieldType.LONGFORM ? v = m : $ === FieldType.DATETIME ? v = b : $ === FieldType.FORMULA && w === FormulaType.STATIC ? v = m.concat([p.MoreThan, p.LessThan]) : $ === FieldType.AI ? v = m.concat([p.MoreThan, p.LessThan]) : $ === FieldType.BB_REFERENCE_SINGLE || isDeprecatedSingleUserColumn(u) ? v = [p.Equals, p.NotEquals, p.Empty, p.NotEmpty, p.In] : $ === FieldType.BB_REFERENCE ? v = y : $ === FieldType.BARCODEQR ? v = m : $ === FieldType.LINK && (v = [p.Empty, p.NotEmpty]);
  const k = f?.tableId?.includes("datasource_plus");
  return l === "_id" && k && (v = [p.Equals, p.NotEquals, p.In]), v;
}, NoEmptyFilterStrings = [
  OperatorOptions.StartsWith.value,
  OperatorOptions.Like.value,
  OperatorOptions.Equals.value,
  OperatorOptions.NotEquals.value,
  OperatorOptions.Contains.value,
  OperatorOptions.NotContains.value,
  OperatorOptions.ContainsAny.value,
  OperatorOptions.In.value
];
function recurseLogicalOperators(u, l) {
  for (const f of LOGICAL_OPERATORS)
    u[f] && (u[f].conditions = u[f].conditions.map(
      (p) => l(p)
    ));
  return u;
}
const cleanupQuery = (u) => {
  for (let l of NoEmptyFilterStrings)
    if (u[l])
      for (let f of Object.keys(u)) {
        if (f !== l)
          continue;
        if (typeof u[f] == "object")
          for (let [m, b] of Object.entries(u[f]))
            (b == null || b === "" || isEmptyArray(b)) && delete u[l][m];
      }
  return u = recurseLogicalOperators(u, cleanupQuery), u;
};
function isEmptyArray(u) {
  return Array.isArray(u) && u.length === 0;
}
const removeKeyNumbering = (u) => getKeyNumbering(u).key, getKeyNumbering = (u) => {
  if (typeof u == "string" && u.match(/\d[0-9]*:/g) != null) {
    const l = u.split(":");
    return { prefix: `${l.shift()}:`, key: l.join(":") };
  } else
    return { key: u };
};
class ColumnSplitter {
  constructor(l, f) {
    if (this.tableNames = l.map((p) => p.name), this.tableIds = l.map((p) => p._id), this.relationshipColumnNames = l.flatMap(
      (p) => Object.keys(p.schema).filter(
        (m) => p.schema[m].type === FieldType.LINK
      )
    ), this.relationships = this.tableNames.concat(this.tableIds).concat(this.relationshipColumnNames).sort((p, m) => m.length - p.length), f?.aliases) {
      this.aliases = {};
      for (const [p, m] of Object.entries(f.aliases))
        this.aliases[m] = p;
    }
    this.columnPrefix = f?.columnPrefix;
  }
  run(l) {
    let { prefix: f, key: p } = getKeyNumbering(l), m;
    if (this.aliases)
      for (const y of Object.keys(this.aliases || {})) {
        const v = `${y}.`;
        p.startsWith(v) && (m = this.aliases[y], p = p.slice(v.length));
      }
    let b;
    for (const y of this.relationships) {
      const v = `${y}.`;
      if (p.startsWith(v)) {
        const $ = p.split(v);
        $.shift(), b = v, p = $.join(".");
        break;
      }
    }
    return this.columnPrefix && p.startsWith(this.columnPrefix) && (p = decodeNonAscii(p.slice(this.columnPrefix.length))), {
      tableName: m,
      numberPrefix: f,
      relationshipPrefix: b,
      column: p
    };
  }
}
function buildCondition(u) {
  if (!u || !u?.operator || !u?.field)
    return;
  const l = {}, { operator: f, field: p, type: m, externalType: b } = u;
  let { value: y } = u;
  (f === "empty" || f === "notEmpty") && (y = null);
  const v = typeof y == "string" && (y.match(HBS_REGEX) || []).length > 0;
  switch (m) {
    case FieldType.DATETIME:
      if (!v && f !== "empty" && f !== "notEmpty") {
        if (!y)
          return;
        if (typeof y == "string")
          y = new Date(y).toISOString();
        else if (isRangeSearchOperator(f))
          return l[f] ??= {}, l[f][p] = y, l;
      }
      break;
    case FieldType.NUMBER:
      typeof y == "string" && !v && (f === "oneOf" ? y = y.split(",").map(parseFloat) : y = parseFloat(y));
      break;
    case FieldType.BOOLEAN:
      y = `${y}`.toLowerCase() === "true";
      break;
    case FieldType.ARRAY:
      ["contains", "notContains", "containsAny"].includes(
        f.toLocaleString()
      ) && typeof y == "string" && (y = y.split(","));
      break;
  }
  if (isRangeSearchOperator(f)) {
    const w = SqlNumberTypeRangeMap[b] || {
      min: Number.MIN_SAFE_INTEGER,
      max: Number.MAX_SAFE_INTEGER
    };
    l[f] ??= {}, l[f][p] = {
      low: m === "number" ? w.min : "0000-00-00T00:00:00.000Z",
      high: m === "number" ? w.max : "9999-00-00T00:00:00.000Z"
    };
  } else if (f === "rangeHigh" && y != null && y !== "")
    l.range ??= {}, l.range[p] = {
      ...l.range[p],
      high: y
    };
  else if (f === "rangeLow" && y != null && y !== "")
    l.range ??= {}, l.range[p] = {
      ...l.range[p],
      low: y
    };
  else if (isBasicSearchOperator(f) || isArraySearchOperator(f) || isRangeSearchOperator(f))
    m === "boolean" ? f === "equal" && y === !1 ? (l.notEqual = l.notEqual || {}, l.notEqual[p] = !0) : f === "notEqual" && y === !1 ? (l.equal = l.equal || {}, l.equal[p] = !0) : (l[f] ??= {}, l[f][p] = y) : (l[f] ??= {}, l[f][p] = y);
  else
    throw new Error(`Unsupported operator: ${f}`);
  return l;
}
function splitFiltersArray(u) {
  const l = {
    filters: []
  };
  for (const f of u)
    "operator" in f && f.operator === "allOr" ? l.allOr = !0 : "onEmptyFilter" in f ? l.onEmptyFilter = f.onEmptyFilter : l.filters.push(f);
  return l;
}
function buildQuery$1(u) {
  if (!u)
    return {};
  if (Array.isArray(u) && (u = processSearchFilters(u), !u))
    return {};
  const l = {};
  u.onEmptyFilter ? l.onEmptyFilter = u.onEmptyFilter : l.onEmptyFilter = EmptyFilterOption.RETURN_ALL;
  const f = logicalOperatorFromUI(
    u.logicalOperator || UILogicalOperator.ALL
  );
  return l[f] = {
    conditions: (u.groups || []).map((p) => {
      if (p.groups) {
        const $ = buildQuery$1(p);
        return delete $.onEmptyFilter, $;
      }
      const { allOr: m, onEmptyFilter: b, filters: y } = splitFiltersArray(
        p.filters || []
      );
      b && (l.onEmptyFilter = b);
      let v = m ? LogicalOperator.OR : LogicalOperator.AND;
      return p.logicalOperator && (v = logicalOperatorFromUI(p.logicalOperator)), {
        [v]: { conditions: y.map(buildCondition).filter(($) => $) }
      };
    })
  }, l;
}
function logicalOperatorFromUI(u) {
  return u === UILogicalOperator.ALL ? LogicalOperator.AND : LogicalOperator.OR;
}
function fixupFilterArrays(u) {
  if (!u)
    return u;
  for (const l of Object.values(ArrayOperator)) {
    const f = u[l];
    if (!(f == null || !isPlainObject$2(f)))
      for (const p of Object.keys(f)) {
        if (Array.isArray(f[p]))
          continue;
        const m = f[p];
        typeof m == "string" ? f[p] = m.split(",").map((b) => b.trim()) : f[p] = [m];
      }
  }
  return recurseLogicalOperators(u, fixupFilterArrays), u;
}
function search(u, l) {
  let f = runQuery$1(u, l.query);
  l.sort && (f = sort$1(
    f,
    l.sort,
    l.sortOrder || SortOrder.ASCENDING,
    l.sortType
  ));
  const p = f.length;
  l.limit && (f = limit(f, l.limit.toString()));
  const m = { rows: f };
  return l.countRows && (m.totalRows = p), m;
}
function runQuery$1(u, l) {
  if (!u || !Array.isArray(u))
    return [];
  if (!l)
    return u;
  if (l = cleanupQuery(l), l = fixupFilterArrays(l), !hasFilters(l) && l.onEmptyFilter === EmptyFilterOption.RETURN_NONE)
    return [];
  const f = (F, L) => (N) => {
    for (const [z, V] of Object.entries(l[F] || {})) {
      const W = isLogicalSearchOperator(F) ? N : deepGet$1(N, removeKeyNumbering(z)), j = L(W, V);
      if (l.allOr && j)
        return !0;
      if (!l.allOr && !j)
        return !1;
    }
    return !l.allOr;
  }, p = f(
    BasicOperator.STRING,
    (F, L) => typeof F != "string" || typeof L != "string" ? !1 : F.toLowerCase().startsWith(L.toLowerCase())
  ), m = f(
    BasicOperator.FUZZY,
    (F, L) => typeof F != "string" || typeof L != "string" ? !1 : F.toLowerCase().includes(L.toLowerCase())
  ), b = f(
    RangeOperator.RANGE,
    (F, L) => {
      if (F == null || F === "" || (isPlainObject$2(L.low) && isEmpty(L.low) && (L.low = void 0), isPlainObject$2(L.high) && isEmpty(L.high) && (L.high = void 0), L.low == null && L.high == null))
        return !1;
      const N = +F;
      if (!isNaN(N)) {
        const V = +L.low, W = +L.high;
        if (!isNaN(V) && !isNaN(W))
          return N >= V && N <= W;
        if (isNaN(V)) {
          if (!isNaN(W))
            return N <= W;
        } else return N >= V;
      }
      const z = dayjs(F);
      if (z.isValid()) {
        const V = dayjs(L.low || "0000-00-00T00:00:00.000Z"), W = dayjs(L.high || "9999-00-00T00:00:00.000Z");
        if (V.isValid() && W.isValid())
          return z.isAfter(V) && z.isBefore(W) || z.isSame(V) || z.isSame(W);
        if (V.isValid())
          return z.isAfter(V) || z.isSame(V);
        if (W.isValid())
          return z.isBefore(W) || z.isSame(W);
      }
      return L.low != null && L.high != null ? F >= L.low && F <= L.high : L.low != null ? F >= L.low : L.high != null ? F <= L.high : !1;
    }
  ), y = (F, L) => {
    if (Array.isArray(F)) {
      for (const z of F)
        if (y(z, L))
          return !0;
      return !1;
    }
    if (F && typeof F == "object" && typeof L == "string")
      return F._id === L;
    if (F === L)
      return !0;
    if (F == null && L != null || F != null && L == null)
      return !1;
    const N = dayjs(F);
    if (N.isValid()) {
      const z = dayjs(L);
      if (z.isValid())
        return N.isSame(z);
    }
    return !1;
  }, v = (F) => (...L) => !F(...L), $ = f(BasicOperator.EQUAL, y), w = f(BasicOperator.NOT_EQUAL, v(y)), P = (F) => typeof F == "string" ? F === "" : Array.isArray(F) ? F.length === 0 : F && typeof F == "object" ? Object.keys(F).length === 0 : F == null, k = f(BasicOperator.EMPTY, P), x = f(BasicOperator.NOT_EMPTY, v(P)), S = f(ArrayOperator.ONE_OF, (F, L) => (typeof L == "string" && (L = L.split(",")), typeof F == "number" && (L = L.map((N) => parseFloat(N))), Array.isArray(L) ? L.some((N) => y(F, N)) : !1)), T = (F) => (L, N) => !Array.isArray(L) || (typeof N == "string" && (N = N.split(","), typeof L[0] == "number" && (N = N.map((z) => parseFloat(z)))), !Array.isArray(N)) ? !1 : N.length === 0 ? !0 : N[F]((z) => y(L, z)), M = f(
    ArrayOperator.CONTAINS,
    (F, L) => Array.isArray(L) && L.length === 0 ? !0 : T("every")(F, L)
  ), E = f(
    ArrayOperator.NOT_CONTAINS,
    (F, L) => Array.isArray(L) && L.length === 0 ? !0 : v(T("every"))(F, L)
  ), R = f(ArrayOperator.CONTAINS_ANY, T("some")), O = f(
    LogicalOperator.AND,
    (F, L) => {
      if (!L.length)
        return !1;
      for (const N of L)
        if (!runQuery$1([F], N).length)
          return !1;
      return !0;
    }
  ), D = f(
    LogicalOperator.OR,
    (F, L) => {
      if (!L.length)
        return !1;
      for (const N of L)
        if (runQuery$1([F], {
          ...N,
          allOr: !0
        }).length)
          return !0;
      return !1;
    }
  ), q = (F) => {
    const L = {
      string: p,
      fuzzy: m,
      range: b,
      equal: $,
      notEqual: w,
      empty: k,
      notEmpty: x,
      oneOf: S,
      contains: M,
      containsAny: R,
      notContains: E,
      [LogicalOperator.AND]: O,
      [LogicalOperator.OR]: D
    }, N = Object.entries(l || {}).filter(
      ([z, V]) => !["allOr", "onEmptyFilter"].includes(z) && V && Object.keys(V).length > 0
    ).map(([z]) => L[z]?.(F) ?? !1);
    return hasFilters(l) ? l.allOr ? N.some((z) => z === !0) : N.every((z) => z === !0) : !0;
  };
  return u.filter(q);
}
function sort$1(u, l, f, p = SortType.STRING) {
  if (!l || !f || !p)
    return u;
  const m = (b) => b == null ? b : p === "string" ? `${b}` : parseFloat(b);
  return u.slice().sort((b, y) => {
    const v = m(b[l]), $ = m(y[l]), w = $ == null || v > $ ? 1 : -1;
    return f.toLowerCase() === "descending" ? w * -1 : w;
  });
}
function limit(u, l) {
  const f = typeof l == "number" ? l : parseFloat(l);
  return isNaN(f) ? u : u.slice(0, f);
}
const hasFilters = (u) => {
  if (!u)
    return !1;
  const l = (f) => {
    for (const p of LOGICAL_OPERATORS)
      if (f[p])
        for (const m of f[p]?.conditions || []) {
          const b = l(m);
          if (b)
            return b;
        }
    for (const p of SEARCH_OPERATORS) {
      const m = f[p];
      if (!m || typeof m != "object")
        continue;
      if (Object.entries(m).filter((y) => {
        const v = y[1] !== void 0 || y[1] !== null || y[1] !== "";
        return p === BasicOperator.NOT_EMPTY || v;
      }).length !== 0)
        return !0;
    }
    return !1;
  };
  return l(u);
}, QueryUtils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ColumnSplitter,
  NoEmptyFilterStrings,
  buildQuery: buildQuery$1,
  cleanupQuery,
  fixupFilterArrays,
  getKeyNumbering,
  getValidOperatorsForType,
  hasFilters,
  limit,
  recurseLogicalOperators,
  removeKeyNumbering,
  runQuery: runQuery$1,
  search,
  sort: sort$1,
  splitFiltersArray
}, Symbol.toStringTag, { value: "Module" })), APP_PREFIX = prefixed(DocumentType.WORKSPACE), APP_DEV_PREFIX = prefixed(DocumentType.WORKSPACE_DEV);
function getDevAppID(u) {
  if (!u)
    throw new Error("No app ID provided");
  if (u.startsWith(APP_DEV_PREFIX))
    return u;
  const l = u.split(APP_PREFIX);
  l.shift();
  const f = l.join(APP_PREFIX);
  return `${APP_DEV_PREFIX}${f}`;
}
const getThemeClassNames = (u) => {
  u = ensureValidTheme(u);
  let l = `${ThemeClassPrefix}${u}`;
  const f = ThemeOptions.find((p) => p.id === u)?.base;
  return f && (l = `${ThemeClassPrefix}${f} ${l}`), l;
}, ensureValidTheme = (u, l = Theme.DARKEST) => u ? (u.startsWith(ThemeClassPrefix) && (u = u.split(ThemeClassPrefix)[1]), ThemeOptions.some((f) => f.id === u) ? u : u === Theme.LIGHTEST ? Theme.LIGHT : u === Theme.DARK ? Theme.DARKEST : l) : l, MAX_SESSIONS_PER_USER = 3;
function convertRowsToCsv(u, l, f = ",") {
  const p = l.join(f), m = u.map(
    (b) => l.map((y) => escapeCsvValue(b[y], f)).join(f)
  );
  return [p, ...m].join(`
`);
}
function convertRowsToJson(u) {
  return JSON.stringify(u, null, 2);
}
function escapeCsvValue(u, l = ",") {
  if (u == null) return "";
  typeof u == "object" && (u = JSON.stringify(u));
  let f = String(u);
  return f = f.replace(/[\r\n]+/g, " "), f.includes(l) || f.includes('"') ? (f = f.replace(/"/g, '""'), `"${f}"`) : f;
}
function convertDataToExportFormat(u, l, f, p = ",") {
  const m = f?.length ? f.map((y) => y.name) : Array.from(new Set(u.flatMap((y) => Object.keys(y)))), b = u.map(
    (y) => m.reduce((v, $) => (v[$] = $ in y ? y[$] : "", v), {})
  );
  switch (l) {
    case "csv":
      return convertRowsToCsv(b, m, p);
    case "json":
      return convertRowsToJson(b);
    default:
      throw new Error(`Unsupported format: ${l}`);
  }
}
const createTranslationDefinitions = (u, l) => l.map((f) => {
  const p = f.fullKey ?? (f.key.includes(".") ? f.key : `${u}.${f.key}`);
  return {
    key: f.key,
    name: f.name,
    defaultValue: f.defaultValue,
    category: u,
    fullKey: p
  };
}), category$8 = "userMenu", userMenuTranslations = createTranslationDefinitions(category$8, [
  {
    key: "profile",
    fullKey: "profile",
    name: "User menu profile label",
    defaultValue: "My profile"
  },
  {
    key: "password",
    fullKey: "password",
    name: "User menu password label",
    defaultValue: "Update password"
  },
  {
    key: "portal",
    fullKey: "portal",
    name: "User menu portal label",
    defaultValue: "Go to portal"
  },
  {
    key: "logout",
    fullKey: "logout",
    name: "User menu logout label",
    defaultValue: "Log out"
  }
]), category$7 = "profileModal", profileModalTranslations = createTranslationDefinitions(category$7, [
  {
    key: "title",
    fullKey: "profileModalTitle",
    name: "Profile modal title",
    defaultValue: "My profile"
  },
  {
    key: "body",
    fullKey: "profileModalBody",
    name: "Profile modal body",
    defaultValue: "Personalise the platform by adding your first name and last name."
  },
  {
    key: "emailLabel",
    fullKey: "profileModalEmailLabel",
    name: "Profile email label",
    defaultValue: "Email"
  },
  {
    key: "firstNameLabel",
    fullKey: "profileModalFirstNameLabel",
    name: "Profile first name label",
    defaultValue: "First name"
  },
  {
    key: "lastNameLabel",
    fullKey: "profileModalLastNameLabel",
    name: "Profile last name label",
    defaultValue: "Last name"
  },
  {
    key: "saveText",
    fullKey: "profileModalSaveButton",
    name: "Profile save button",
    defaultValue: "Save"
  },
  {
    key: "cancelText",
    fullKey: "profileModalCancelButton",
    name: "Profile cancel button",
    defaultValue: "Cancel"
  },
  {
    key: "successText",
    fullKey: "profileModalSuccess",
    name: "Profile update success notification",
    defaultValue: "Information updated successfully"
  },
  {
    key: "errorText",
    fullKey: "profileModalError",
    name: "Profile update error notification",
    defaultValue: "Failed to update information"
  }
]), category$6 = "passwordModal", passwordModalTranslations = createTranslationDefinitions(
  category$6,
  [
    {
      key: "title",
      fullKey: "passwordTitle",
      name: "Password title",
      defaultValue: "Update password"
    },
    {
      key: "body",
      fullKey: "passwordBody",
      name: "Password body",
      defaultValue: "Enter your new password below."
    },
    {
      key: "passwordLabel",
      fullKey: "passwordModalLabel",
      name: "Password password label",
      defaultValue: "Password"
    },
    {
      key: "repeatLabel",
      fullKey: "passwordModalRepeatLabel",
      name: "Password repeat label",
      defaultValue: "Repeat password"
    },
    {
      key: "saveText",
      fullKey: "passwordModalSaveButton",
      name: "Password save button",
      defaultValue: "Update password"
    },
    {
      key: "cancelText",
      fullKey: "passwordModalCancelButton",
      name: "Password modal cancel button",
      defaultValue: "Cancel"
    },
    {
      key: "minLengthText",
      fullKey: "passwordModalMinLength",
      name: "Password minimum length copy",
      defaultValue: "Please enter at least 12 characters. We recommend using machine generated or random passwords."
    },
    {
      key: "mismatchText",
      fullKey: "passwordModalMismatchText",
      name: "Password mismatch copy",
      defaultValue: "Passwords must match"
    },
    {
      key: "successText",
      fullKey: "passwordModalSuccess",
      name: "Password success notification",
      defaultValue: "Password changed successfully"
    },
    {
      key: "errorText",
      fullKey: "passwordModalError",
      name: "Password error notification",
      defaultValue: "Failed to update password"
    }
  ]
), category$5 = "picker", pickerTranslations = createTranslationDefinitions(category$5, [
  {
    key: "searchPlaceholder",
    name: "Picker search placeholder",
    defaultValue: "Search"
  },
  {
    key: "searchByFieldPlaceholder",
    name: "Picker search by field placeholder",
    defaultValue: "Search by {field}"
  }
]), category$4 = "recaptcha", recaptchaTranslations = createTranslationDefinitions(category$4, [
  {
    key: "prompt",
    name: "Prompt",
    defaultValue: "Human verification step required to continue."
  },
  {
    key: "submit",
    name: "Submit button",
    defaultValue: "Submit"
  },
  {
    key: "error",
    name: "Error message",
    defaultValue: "Recaptcha verification failed, please try again"
  }
]), category$3 = "portal", portalTranslations = createTranslationDefinitions(category$3, [
  {
    key: "greeting",
    name: "Greeting heading",
    defaultValue: "Hey {{name}}"
  },
  {
    key: "intro",
    name: "Introductory body",
    defaultValue: "Welcome to the {{company}} portal. Below you'll find the list of apps that you have access to."
  },
  {
    key: "offlineHeading",
    name: "Offline heading",
    defaultValue: "Your apps are currently offline."
  },
  {
    key: "offlineDescription",
    name: "Offline description",
    defaultValue: "Please contact the account holder to get them back online."
  },
  {
    key: "appsHeading",
    name: "Apps heading",
    defaultValue: "Apps"
  },
  {
    key: "updatedAgo",
    name: "Updated duration label",
    defaultValue: "Updated {{ duration time 'millisecond' }} ago"
  },
  {
    key: "neverUpdated",
    name: "Never updated label",
    defaultValue: "Never updated"
  },
  {
    key: "noAppsHeading",
    name: "No apps heading",
    defaultValue: "You don't have access to any apps yet."
  },
  {
    key: "noAppsDescription",
    name: "No apps description",
    defaultValue: "The apps you have access to will be listed here."
  }
]), category$2 = "login", loginTranslations = createTranslationDefinitions(category$2, [
  {
    key: "emailLabel",
    name: "Login email label",
    defaultValue: "Your work email"
  },
  {
    key: "emailError",
    name: "Login email error",
    defaultValue: "Please enter a valid email"
  },
  {
    key: "passwordLabel",
    name: "Login password label",
    defaultValue: "Password"
  },
  {
    key: "passwordIncorrectError",
    name: "Login password incorrect error",
    defaultValue: "Incorrect password"
  },
  {
    key: "passwordError",
    name: "Login password error",
    defaultValue: "Please enter your password"
  },
  {
    key: "invalidCredentials",
    name: "Login invalid credentials message",
    defaultValue: "Invalid credentials"
  },
  {
    key: "forgotPassword",
    name: "Forgot password link",
    defaultValue: "Forgot password?"
  },
  {
    key: "loginWith",
    name: "Login with label",
    defaultValue: "Log in with"
  }
]), category$1 = "forgotPassword", forgotPasswordTranslations = createTranslationDefinitions(
  category$1,
  [
    {
      key: "heading",
      name: "Forgot password heading",
      defaultValue: "Forgot your password?"
    },
    {
      key: "description",
      name: "Forgot password description",
      defaultValue: "Enter your email to receive reset instructions."
    },
    {
      key: "emailLabel",
      name: "Forgot password email label",
      defaultValue: "Your work email"
    },
    {
      key: "emailError",
      name: "Forgot password email error",
      defaultValue: "Please enter a valid email"
    },
    {
      key: "submit",
      name: "Forgot password submit button",
      defaultValue: "Send reset email"
    },
    {
      key: "success",
      name: "Forgot password success notification",
      defaultValue: "If that account exists, we'll send a reset email shortly."
    }
  ]
), category = "validation", validationTranslations = createTranslationDefinitions(category, [
  {
    key: "required",
    name: "Required field error",
    defaultValue: "Required"
  }
]), translationModules = [
  userMenuTranslations,
  profileModalTranslations,
  passwordModalTranslations,
  pickerTranslations,
  recaptchaTranslations,
  portalTranslations,
  loginTranslations,
  forgotPasswordTranslations,
  validationTranslations
], translations$2 = translationModules.flat(), translationsByCategory = translations$2.reduce(
  (u, l) => (u[l.category] || (u[l.category] = []), u[l.category].push(l), u),
  {}
), translationLookup = translations$2.reduce((u, l) => (u.set(l.fullKey, l), u), /* @__PURE__ */ new Map()), filterValidTranslationOverrides = (u) => u ? Object.entries(u).reduce((l, [f, p]) => (typeof p != "string" || !translationLookup.has(f) || (l[f] = p), l), {}) : {}, resolveWorkspaceTranslations = (u) => filterValidTranslationOverrides(u), resolveTranslationGroup = (u, l) => {
  const f = translationsByCategory[u] || [], p = l ? Object.entries(l).every(([b, y]) => translationLookup.has(b) && typeof y == "string") ? l : filterValidTranslationOverrides(l) : {};
  return f.reduce(
    (m, b) => {
      const y = p[b.fullKey];
      return m[b.key] = y ?? b.defaultValue, m;
    },
    {}
  );
}, deepGet = deepGet$1;
function uuid() {
  return "cxxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, (u) => {
    const l = Math.random() * 16 | 0;
    return (u === "x" ? l : l & 3 | 8).toString(16);
  });
}
const capitalise = (u) => u ? u.substring(0, 1).toUpperCase() + u.substring(1) : "", hashString = (u) => {
  if (!u)
    return "0";
  let l = 0;
  for (let f = 0; f < u.length; f++) {
    let p = u.charCodeAt(f);
    l = (l << 5) - l + p, l = l & l;
  }
  return l.toString();
}, deepSet = (u, l, f) => {
  if (!u || !l)
    return;
  if (Object.prototype.hasOwnProperty.call(u, l)) {
    u[l] = f;
    return;
  }
  const p = l.split(".");
  for (let m = 0; m < p.length - 1; m++) {
    const b = p[m];
    u && u[b] == null && (u[b] = {}), u = u?.[b];
  }
  u && (u[p[p.length - 1]] = f);
}, cloneDeep$4 = (u) => u && JSON.parse(JSON.stringify(u)), copyToClipboard = (u) => new Promise((l) => {
  if (navigator.clipboard && window.isSecureContext)
    navigator.clipboard.writeText(u).then(l);
  else {
    let f = document.createElement("textarea");
    f.value = u, f.style.position = "fixed", f.style.left = "-9999px", f.style.top = "-9999px", document.body.appendChild(f), f.focus(), f.select(), document.execCommand("copy"), f.remove(), l();
  }
}), parseDate = (u, { enableTime: l = !0 }) => {
  if (!u)
    return null;
  typeof u == "string" && (isNaN((/* @__PURE__ */ new Date(`0-${u}`)).valueOf()) ? !l && u.endsWith("Z") && (u = u.split("Z")[0]) : u = `0-${u}`);
  const f = dayjs(u);
  return f.isValid() ? dayjs(Math.floor(f.valueOf() / 1e3) * 1e3) : null;
}, stringifyDate = (u, { enableTime: l = !0, timeOnly: f = !1, ignoreTimezones: p = !1 } = {}) => {
  if (!u)
    return null;
  if (l && p || f) {
    const y = u.toDate().getTimezoneOffset() * 6e4, v = new Date(u.valueOf() - y);
    return f ? v.toISOString().slice(11, 16) : v.toISOString().slice(0, -1);
  } else {
    if (l)
      return u.toISOString();
    {
      const b = u.year(), y = `${u.month() + 1}`.padStart(2, "0"), v = `${u.date()}`.padStart(2, "0");
      return `${b}-${y}-${v}`;
    }
  }
}, getPatternForPart = (u) => {
  switch (u.type) {
    case "day":
      return "D".repeat(u.value.length);
    case "month":
      return "M".repeat(u.value.length);
    case "year":
      return "Y".repeat(u.value.length);
    case "literal":
      return u.value;
    default:
      return console.log("Unsupported date part", u), "";
  }
}, localeDateFormat = new Intl.DateTimeFormat().formatToParts(/* @__PURE__ */ new Date("2021-01-01")).map(getPatternForPart).join(""), getDateDisplayValue = (u, { enableTime: l = !0, timeOnly: f = !1 } = {}) => (typeof u == "string" && (u = dayjs(u)), u?.isValid() ? f ? u.format("HH:mm") : l ? u.format(`${localeDateFormat} HH:mm`) : u.format(localeDateFormat) : ""), hexToRGBA = (u, l) => {
  u.includes("#") && (u = u.replace("#", ""));
  const f = parseInt(u.substring(0, 2), 16), p = parseInt(u.substring(2, 4), 16), m = parseInt(u.substring(4, 6), 16);
  return `rgba(${f}, ${p}, ${m}, ${l})`;
}, SpectrumIconMap = {
  123: "list-numbers",
  "3DMaterials": "cube",
  ABC: "text-aa",
  AEMScreens: "desktop-tower",
  Actions: "cursor-click",
  AdDisplay: "monitor",
  AdPrint: "printer",
  Add: "plus",
  AddCircle: "plus-circle",
  AddTo: "plus",
  AddToSelection: "selection-plus",
  Airplane: "airplane",
  Alert: "warning",
  AlertAdd: "warning-circle",
  AlertCheck: "warning-circle",
  AlertCircle: "warning-circle",
  AlertCircleFilled: "warning-circle",
  Algorithm: "flow-arrow",
  Alias: "link-simple",
  AlignBottom: "align-bottom",
  AlignCenter: "align-center-horizontal",
  AlignLeft: "align-left",
  AlignMiddle: "align-center-vertical",
  AlignRight: "align-right",
  AlignTop: "align-top",
  Amusementpark: "ferris-wheel",
  Anchor: "anchor",
  AnchorSelect: "anchor",
  Annotate: "pencil",
  AnnotatePen: "pen-nib",
  Answer: "chat-circle-dots",
  AnswerFavorite: "chat-circle-dots",
  App: "squares-four",
  AppRefresh: "arrow-clockwise",
  AppleFiles: "apple-logo",
  ApplicationDelivery: "truck",
  ApproveReject: "checks",
  Apps: "squares-four",
  Archive: "archive-tray",
  ArchiveRemove: "tray-arrow-up",
  Arrow: "arrow-right",
  ArrowDown: "arrow-down",
  ArrowLeft: "arrow-left",
  ArrowRight: "arrow-right",
  ArrowUp: "arrow-up",
  ArrowUpRight: "arrow-up-right",
  Artboard: "square",
  Article: "newspaper",
  Asset: "stack",
  AssetCheck: "stack",
  AssetsAdded: "stack",
  AssetsDownloaded: "stack",
  AssetsExpired: "stack",
  AssetsLinkedPublished: "stack",
  AssetsModified: "stack",
  AssetsPublished: "stack",
  Asterisk: "asterisk",
  At: "at",
  Attach: "paperclip",
  AttachmentExclude: "paperclip",
  Attributes: "list-bullets",
  Audio: "music-note",
  AutomatedSegment: "funnel",
  Back: "rotate-counter-clockwise",
  Back30Seconds: "rewind",
  BackAndroid: "backspace",
  Beaker: "beaker",
  BeakerCheck: "beaker",
  BeakerShare: "beaker",
  Bell: "bell",
  BidRule: "sliders-horizontal",
  BidRuleAdd: "sliders-horizontal",
  Blower: "wind",
  Blur: "drop-half",
  Book: "book",
  Bookmark: "bookmark",
  BookmarkSingle: "bookmark",
  BookmarkSingleOutline: "bookmark",
  BookmarkSmall: "bookmark-simple",
  BookmarkSmallOutline: "bookmark-simple",
  Boolean: "intersect",
  Border: "square",
  Box: "cube",
  BoxAdd: "cube",
  BoxExport: "cube",
  BoxImport: "cube",
  Brackets: "brackets-angle",
  BracketsSquare: "brackets-square",
  Branch1: "git-branch",
  Branch2: "git-branch",
  Branch3: "git-branch",
  BranchCircle: "git-branch",
  BreadcrumbNavigation: "dots-three-outline",
  Breakdown: "chart-line",
  BreakdownAdd: "chart-line",
  Briefcase: "briefcase",
  Browse: "folder-open",
  Brush: "paint-brush",
  Bug: "bug",
  Building: "buildings",
  BulkEditUsers: "users-three",
  Button: "square",
  CCLibrary: "books",
  Calculator: "calculator",
  Calendar: "calendar",
  CalendarAdd: "calendar-plus",
  CalendarLocked: "calendar",
  CalendarUnlocked: "calendar",
  CallCenter: "headset",
  Camera: "camera",
  CameraFlip: "camera-rotate",
  CameraRefresh: "camera",
  Campaign: "megaphone",
  CampaignAdd: "megaphone",
  CampaignClose: "megaphone",
  CampaignDelete: "megaphone",
  CampaignEdit: "megaphone",
  Cancel: "x",
  Capitals: "text-aa",
  Captcha: "puzzle-piece",
  Car: "car",
  Card: "credit-card",
  Channel: "share-network",
  Chat: "chat-circle",
  ChatAdd: "chat-circle",
  CheckPause: "pause-circle",
  Checkmark: "check",
  CheckmarkCircle: "check-circle",
  CheckmarkCircleOutline: "check-circle",
  Chevron: "caret-right",
  ChevronDoubleLeft: "caret-double-left",
  ChevronDoubleRight: "caret-double-right",
  ChevronDown: "caret-down",
  ChevronLeft: "caret-left",
  ChevronRight: "caret-right",
  ChevronUp: "caret-up",
  ChevronUpDown: "arrows-vertical",
  Circle: "circle",
  ClassicGridView: "squares-four",
  Clock: "clock",
  ClockCheck: "clock-check",
  CloneStamp: "stamp",
  Close: "x",
  CloseCaptions: "closed-captioning",
  CloseCircle: "xcircle",
  Cloud: "cloud",
  CloudDisconnected: "cloud-slash",
  CloudError: "cloud-warning",
  CloudOutline: "cloud",
  Code: "code",
  Collection: "stack",
  CollectionAdd: "stack",
  CollectionAddTo: "stack",
  CollectionCheck: "stack",
  CollectionEdit: "stack",
  CollectionExclude: "stack",
  CollectionLink: "stack",
  ColorFill: "paint-bucket",
  ColorPalette: "palette",
  ColorWheel: "circle-half-tilt",
  ColumnSettings: "columns",
  ColumnTwoA: "columns",
  ColumnTwoB: "columns",
  ColumnTwoC: "columns",
  Comment: "chat-circle",
  Compare: "swap",
  Compass: "compass",
  Condition: "git-merge",
  ConfidenceFour: "cell-signal-full",
  ConfidenceOne: "cell-signal-low",
  ConfidenceThree: "cell-signal-high",
  ConfidenceTwo: "cell-signal-medium",
  Connect: "link",
  ConnectedObjects: "link",
  ContactInfo: "address-book",
  ContrastFill: "circle-half-tilt",
  ConversionFunnel: "funnel",
  ConvertAnchorPoint: "anchor",
  Copy: "copy",
  CornerRadius: "square",
  CreatePDF: "file-pdf",
  Crop: "crop",
  CropLighten: "crop",
  CropRotate: "crop",
  CrossSize: "plus",
  CurveTool: "bezier-curve",
  Cut: "scissors",
  Data: "database",
  DataAdd: "database",
  DataBook: "database",
  DataCheck: "database",
  DataCorrelated: "database",
  DataDownload: "database",
  DataEdit: "database",
  DataMapping: "database",
  DataRefresh: "database",
  DataRemove: "database",
  DataSettings: "database",
  DataUpload: "database",
  DataUser: "database",
  DataUnavailable: "database-slash",
  Date: "calendar",
  DateInput: "calendar",
  Deduplication: "copy",
  Delete: "trash",
  DeleteOutline: "trash",
  Demographic: "users-three",
  DeselectCircular: "circle-dashed",
  Desktop: "desktop",
  DeviceDesktop: "desktop",
  DeviceLaptop: "laptop",
  DevicePhone: "device-mobile",
  DevicePreview: "devices",
  DeviceRotateLandscape: "device-rotate",
  DeviceRotatePortrait: "device-rotate",
  DeviceTablet: "device-tablet",
  DeviceTV: "television",
  Devices: "devices",
  Dimensions: "ruler",
  DirectRight: "arrow-right",
  DistributeBottomEdge: "align-bottom",
  DistributeHorizontalCenter: "align-center-horizontal",
  DistributeLeftEdge: "align-left",
  DistributeRightEdge: "align-right",
  DistributeSpaceHoriz: "align-horizontal",
  DistributeSpaceVert: "align-vertical",
  DistributeTopEdge: "align-top",
  DistributeVerticalCenter: "align-center-vertical",
  DistributeVertically: "align-vertical",
  Document: "file-text",
  DocumentFragment: "file-text",
  DocumentFragmentGroup: "files",
  DocumentOutline: "file-text",
  DocumentRefresh: "file-text",
  Download: "download",
  DownloadFromCloud: "cloud-arrow-down",
  DownloadFromCloudOutline: "cloud-arrow-down",
  Draft: "note-pencil",
  DragHandle: "dots-six",
  Draw: "pencil",
  Dropdown: "caret-down",
  Duplicate: "copy",
  Edit: "pencil",
  EditCircle: "pencil-circle",
  EditExclude: "pencil",
  EditIn: "pencil",
  Education: "graduation-cap",
  Effect: "sparkle",
  Email: "envelope",
  EmailCancel: "envelope",
  EmailCheck: "envelope",
  EmailExclude: "envelope",
  EmailGear: "envelope",
  EmailKey: "envelope",
  EmailLightning: "envelope",
  EmailOutline: "envelope",
  EmailRefresh: "envelope",
  EmailReject: "envelope",
  EmailSchedule: "envelope",
  Engagement: "handshake",
  Enterprise: "buildings",
  Erase: "eraser",
  Event: "calendar",
  EventExclude: "calendar",
  EventShare: "calendar",
  Events: "calendar",
  ExcludeOverlap: "intersect",
  Experience: "star",
  ExperienceAdd: "star",
  ExperienceAddTo: "star",
  ExperienceExport: "star",
  ExperienceImport: "star",
  Export: "export",
  ExportOriginal: "export",
  Exposure: "circle-half-tilt",
  Extension: "puzzle-piece",
  FaceHappy: "smiley",
  FaceSad: "smiley-sad",
  FastForward: "fast-forward",
  FastForwardCircle: "fast-forward-circle",
  Feature: "star",
  Feed: "rss",
  FeedAdd: "rss",
  FeedManagement: "rss",
  File: "file",
  FileAdd: "file-plus",
  FileCSV: "file-csv",
  FileCode: "file-code",
  FileData: "file-text",
  FileEmail: "file-text",
  FileGear: "file-text",
  FileHTML: "file-html",
  FileImportant: "file-text",
  FileKey: "file-text",
  FilePDF: "file-pdf",
  FileSingleWebPage: "file-html",
  FileTemplate: "file-text",
  FileTxt: "file-text",
  FileUser: "file-text",
  FileWorkflow: "file-text",
  FileZip: "file-zip",
  FilingCabinet: "filing-cabinet",
  Filter: "funnel",
  FilterAdd: "funnel",
  FilterCheck: "funnel",
  FilterColored: "funnel",
  FilterDelete: "funnel",
  FilterEdit: "funnel",
  FilterHeart: "funnel",
  FilterRemove: "funnel",
  FilterStar: "funnel",
  FindAndReplace: "magnifying-glass",
  Flag: "flag",
  FlagExclude: "flag",
  Flashlight: "flashlight",
  FlashlightOff: "flashlight",
  FlashlightOn: "flashlight",
  FlashOn: "lightning",
  Flight: "airplane",
  Flip: "flip-horizontal",
  FlipHorizontal: "flip-horizontal",
  FlipVertical: "flip-vertical",
  Folder: "folder",
  Folder2Color: "folder",
  FolderAdd: "folder-plus",
  FolderAddTo: "folder-plus",
  FolderArchive: "folder",
  FolderBreadcrumb: "folder",
  FolderDelete: "folder-minus",
  FolderGear: "folder",
  FolderLocked: "folder-lock",
  FolderOpen: "folder-open",
  FolderOpenOutline: "folder-open",
  FolderOutline: "folder",
  FolderRemove: "folder-minus",
  FolderSearch: "folder",
  FolderUser: "folder",
  Follow: "plus",
  FontDecrease: "text-size",
  FontIncrease: "text-size",
  FontSize: "text-size",
  Form: "list",
  Forward: "arrow-right",
  Forward30Seconds: "fast-forward",
  FullScreen: "arrows-out",
  FullScreenExit: "arrows-in",
  Function: "function",
  Gauge1: "gauge",
  Gauge2: "gauge",
  Gauge3: "gauge",
  Gauge4: "gauge",
  Gauge5: "gauge",
  Gears: "gears",
  GearsAdd: "gears",
  GearsDelete: "gears",
  GearsEdit: "gears",
  Gift: "gift",
  Globe: "globe",
  GlobeCheck: "globe",
  GlobeClock: "globe",
  GlobeEnter: "globe",
  GlobeExit: "globe",
  GlobeGrid: "globe",
  GlobeOutline: "globe",
  GlobeRemove: "globe",
  GlobeSearch: "globe",
  GlobeStrike: "globe",
  GlobeStrikeThrough: "globe",
  GovernmentBuilding: "bank",
  Gradient: "gradient",
  GraphArea: "chart-line",
  GraphAreaStacked: "chart-line",
  GraphBarHorizontal: "chart-bar-horizontal",
  GraphBarHorizontalAdd: "chart-bar-horizontal",
  GraphBarHorizontalStacked: "chart-bar-horizontal",
  GraphBarVertical: "chart-bar",
  GraphBarVerticalAdd: "chart-bar",
  GraphBarVerticalStacked: "chart-bar",
  GraphBubble: "chart-scatter",
  GraphBullet: "chart-bar",
  GraphConfidenceBand: "chart-line",
  GraphDonut: "chart-donut",
  GraphDonutAdd: "chart-donut",
  GraphGantt: "chart-bar",
  GraphHistogram: "chart-bar",
  GraphLine: "chart-line",
  GraphPie: "chart-pie",
  GraphProfitCurve: "chart-line",
  GraphScatter: "chart-scatter",
  GraphStream: "chart-line",
  GraphStreamRanked: "chart-line",
  GraphSunburst: "chart-donut",
  GraphTree: "tree-structure",
  GraphTrend: "trend-up",
  GraphTrendAdd: "trend-up",
  Graphic: "image",
  GraphicCircle: "circle",
  GraphicRectangle: "rectangle",
  Grid: "grid-four",
  GridView: "grid-four",
  Group: "squares-four",
  GroupedBarChart: "chart-bar",
  Hand: "hand",
  Hand0: "hand",
  Hand1: "hand",
  Hand2: "hand",
  Hand3: "hand",
  Hand4: "hand",
  HangingIndent: "text-indent",
  HardDrive: "hard-drive",
  Hashtag: "hash",
  Heal: "bandage",
  Heart: "heart",
  HeartOutline: "heart",
  Help: "question",
  HelpOutline: "question",
  Hide: "eye-slash",
  Histogram: "chart-bar",
  History: "clock-counter-clockwise",
  Home: "house",
  HomeFilled: "house",
  HomePage: "house",
  HorizontalContainer: "rectangle",
  HotSpot: "target",
  Hotel: "bed",
  Hourglass: "hourglass",
  House: "house",
  IdentityService: "identification-card",
  Image: "image",
  ImageAdd: "image",
  ImageAlbum: "images",
  ImageAutoMode: "image",
  ImageCarousel: "images",
  ImageCheck: "image",
  ImageCheckedOut: "image",
  ImageMapCircle: "image",
  ImageMapPolygon: "image",
  ImageMapRectangle: "image",
  ImageNext: "image",
  ImageProfile: "image",
  ImageSearch: "image",
  ImageText: "image",
  Images: "images",
  Import: "download",
  ImportantDetail: "warning",
  Inbox: "tray",
  IndentDecrease: "text-indent",
  IndentIncrease: "text-indent",
  Individual: "user",
  Info: "info",
  InfoOutline: "info",
  InkDrop: "drop",
  Insert: "plus",
  Insights: "chart-line",
  Intersect: "intersect",
  IntersectOverlap: "intersect",
  Invite: "user-plus",
  ItalicText: "text-italic",
  Journey: "path",
  JourneyAction: "path",
  JourneyData: "path",
  JourneyEvent: "path",
  JourneyVoyager: "path",
  JumpToTop: "arrow-up",
  Key: "key",
  KeyClock: "key",
  KeyExclude: "key",
  KeyMetrics: "key",
  Keyboard: "keyboard",
  Label: "tag",
  LabelExclude: "tag",
  Landscape: "mountains",
  Launch: "rocket-launch",
  Layer: "stack",
  LayerBackward: "stack",
  LayerForward: "stack",
  LayersBackward: "stack",
  LayersForward: "stack",
  LayersSendToBack: "stack",
  Layout: "layout",
  Learn: "graduation-cap",
  Light: "lightbulb",
  Line: "line-segment",
  LineHeight: "text-line-spacing",
  Link: "link",
  LinkCheck: "link",
  LinkGlobe: "link",
  LinkNav: "link",
  LinkOff: "link-break",
  LinkOut: "arrow-square-out",
  LinkOutLight: "arrow-square-out",
  LinkPage: "link",
  LinkUser: "link",
  Location: "map-pin",
  LocationBasedDate: "map-pin",
  LocationBasedEvent: "map-pin",
  LocationContribution: "map-pin",
  Lock: "lock",
  LockClosed: "lock",
  LockOpen: "lock-open",
  LogOut: "sign-out",
  Login: "sign-in",
  Look: "eye",
  LookupObjects: "magnifying-glass",
  Loupe: "magnifying-glass",
  LoupeView: "magnifying-glass",
  MBox: "envelope",
  MagicWand: "magic-wand",
  Magnify: "magnifying-glass",
  MailTo: "envelope",
  MapView: "map",
  MarginBottom: "align-bottom",
  MarginLeft: "align-left",
  MarginRight: "align-right",
  MarginTop: "align-top",
  MarketingActivities: "megaphone",
  Maximize: "arrows-out",
  Measure: "ruler",
  MediaRefresh: "arrow-clockwise",
  Megaphone: "megaphone",
  Merge: "git-merge",
  MergeLayers: "stack",
  Message: "chat-circle",
  Minimize: "arrows-in",
  Mobile: "device-mobile",
  ModernGridView: "grid-four",
  Money: "money",
  Monitor: "monitor",
  Monitoring: "monitor",
  More: "dots-three",
  MoreCircle: "dots-three-circle",
  MoreSmallList: "dots-three",
  MoreSmallListVert: "dots-three-vertical",
  MoreVertical: "dots-three-vertical",
  Move: "arrows-four",
  MoveLeftRight: "arrows-horizontal",
  MoveTo: "arrow-right",
  MoveUpDown: "arrows-vertical",
  MultipleAdd: "plus",
  MultipleCheck: "check",
  MultipleExclude: "minus",
  Music: "music-note",
  MusicNote: "music-note",
  NewItem: "plus",
  News: "newspaper",
  NewsAdd: "newspaper",
  Next: "arrow-right",
  NoDuplicate: "copy",
  NoEdit: "pencil-slash",
  Note: "note",
  NoteAdd: "note",
  Notification: "bell",
  NotificationImportant: "bell",
  Number: "hash",
  Number0: "number-zero",
  Number1: "number-one",
  Number2: "number-two",
  Number3: "number-three",
  Number4: "number-four",
  Number5: "number-five",
  Number6: "number-six",
  Number7: "number-seven",
  Number8: "number-eight",
  Number9: "number-nine",
  OpenIn: "arrow-square-out",
  OpenInLight: "arrow-square-out",
  OpenRecent: "clock-counter-clockwise",
  OpenRecentOutline: "clock-counter-clockwise",
  Operations: "gears",
  Orbit: "planet",
  OrderedList: "list-numbers",
  Organize: "squares-four",
  Orientation: "device-rotate",
  Outline: "square",
  Output: "export",
  Overlap: "intersect",
  Package: "package",
  PaddingBottom: "align-bottom",
  PaddingLeft: "align-left",
  PaddingRight: "align-right",
  PaddingTop: "align-top",
  Page: "file-text",
  PageBreak: "file-text",
  PageExclude: "file-text",
  PageGear: "file-text",
  PageRule: "file-text",
  PageShare: "file-text",
  PageTag: "file-text",
  Pages: "files",
  PagesExclude: "files",
  Pan: "hand",
  Panel: "sidebar",
  Paste: "clipboard",
  PasteHTML: "clipboard",
  PasteList: "clipboard",
  PasteText: "clipboard",
  PatternFill: "pattern",
  Pause: "pause",
  PauseCircle: "pause-circle",
  Paypal: "currency-dollar",
  Pen: "pen",
  Pencil: "pencil",
  PendingItems: "clock",
  People: "users-three",
  PersonalizationField: "user",
  Perspective: "cube",
  Phone: "phone",
  PhoneVerification: "phone",
  PieChart: "chart-pie",
  Pin: "push-pin",
  PinOff: "push-pin-slash",
  PinOn: "push-pin",
  Pivot: "arrows-clockwise",
  Play: "play",
  PlayCircle: "play-circle",
  Playlist: "playlist",
  PlaylistAdd: "playlist",
  PlaylistRemove: "playlist",
  Plugin: "puzzle-piece",
  PolarGrid: "grid-nine",
  Polygon: "polygon",
  PopIn: "arrow-square-in",
  Portrait: "user",
  Preferences: "gear",
  Preview: "eye",
  Previous: "arrow-left",
  Print: "printer",
  PrintPreview: "printer",
  Privacy: "lock",
  Project: "folder",
  ProjectAdd: "folder-plus",
  ProjectEdit: "folder",
  ProjectNameEdit: "folder",
  Properties: "list-bullets",
  PropertiesCopy: "list-bullets",
  Publish: "upload",
  PublishCheck: "upload",
  PublishPending: "upload",
  PublishReject: "upload",
  PublishRemove: "upload",
  PublishSchedule: "upload",
  PushNotification: "bell",
  QRCode: "qr-code",
  Question: "question",
  QuestionMarkCircle: "question",
  Queue: "queue",
  QuickSelect: "cursor-click",
  RadioButton: "radio-button",
  Rail: "sidebar",
  RailBottom: "align-bottom",
  RailLeft: "align-left",
  RailRight: "align-right",
  RailRightClose: "align-right",
  RailRightOpen: "align-right",
  RailTop: "align-top",
  RapidGrowth: "trend-up",
  RealTime: "clock",
  RealTimeCustomerProfile: "user",
  Receipt: "receipt",
  RecentItems: "clock-counter-clockwise",
  Rectangle: "rectangle",
  RectangleSelect: "rectangle",
  Redo: "arrow-clockwise",
  Refresh: "arrow-clockwise",
  RegionSelect: "selection",
  Reject: "x",
  Remove: "minus",
  RemoveCircle: "minus-circle",
  Rename: "pencil",
  Reorder: "list-bullets",
  Replay: "arrow-clockwise",
  Reply: "arrow-bend-up-left",
  ReplyAll: "arrow-bend-up-left",
  Report: "chart-bar",
  ReportAdd: "chart-bar",
  Resize: "arrows-out",
  ResourceFork: "git-fork",
  Restore: "arrow-counter-clockwise",
  Retweet: "repeat",
  Reuse: "recycle",
  Revert: "arrow-counter-clockwise",
  Rewind: "rewind",
  RewindCircle: "rewind-circle",
  Ribbon: "medal",
  Rotate: "arrow-clockwise",
  RotateLeft: "arrow-counter-clockwise",
  RotateLeftOutline: "arrow-counter-clockwise",
  RotateRight: "arrow-clockwise",
  RotateRightOutline: "arrow-clockwise",
  RotateCW: "arrow-clockwise",
  SMS: "chat-circle",
  SQLQuery: "database",
  Sandbox: "columns",
  Save: "floppy-disk",
  SaveAsFloppy: "floppy-disk",
  SaveFloppy: "floppy-disk",
  SaveTo: "floppy-disk",
  SaveToLight: "floppy-disk",
  Scale: "resize",
  Scribble: "scribble-loop",
  Search: "magnifying-glass",
  SearchExclude: "magnifying-glass",
  Seat: "chair",
  SeatAdd: "chair",
  Segmentation: "funnel",
  Select: "cursor-click",
  SelectAdd: "selection-plus",
  SelectBox: "selection",
  SelectBoxAll: "selection",
  SelectCircular: "circle-dashed",
  SelectContainer: "selection",
  SelectGear: "selection",
  SelectIntersect: "intersect",
  SelectSubtract: "minus",
  Selection: "selection",
  SelectionChecked: "selection",
  SelectionMove: "selection",
  Send: "paper-plane-tilt",
  SendBackward: "arrow-down",
  SendToBack: "arrow-line-down",
  Sentiment: "smiley",
  SentimentNegative: "smiley-sad",
  SentimentNeutral: "smiley-meh",
  SentimentPositive: "smiley",
  SequenceAfter: "arrow-right",
  SequenceBefore: "arrow-left",
  Server: "server",
  ServiceRequest: "headset",
  Settings: "gear",
  Share: "share",
  ShareAndroid: "share",
  ShareCheck: "share",
  ShareLight: "share",
  Shield: "shield",
  ShieldCheck: "shield-check",
  Ship: "boat",
  Shop: "storefront",
  ShoppingCart: "shopping-cart",
  ShowAllLayers: "stack",
  ShowMenu: "list-bullets",
  ShowOneLayer: "stack",
  Shuffle: "shuffle",
  SideKick: "robot",
  Slice: "scissors",
  Slow: "hourglass",
  SmallCaps: "text-aa",
  Snapshot: "camera",
  SocialNetwork: "share-network",
  SortOrderDown: "sort-descending",
  SortOrderUp: "sort-ascending",
  Spam: "prohibit",
  Spellcheck: "check",
  Spin: "spinner-gap",
  SplitView: "columns",
  SpotHeal: "bandage",
  Stadium: "circle",
  Stage: "square",
  Stamp: "stamp",
  Star: "star",
  StarOutline: "star",
  Starburst: "sparkle",
  StatusLight: "circle",
  StepBackward: "skip-back",
  StepBackwardCircle: "skip-back-circle",
  StepForward: "skip-forward",
  StepForwardCircle: "skip-forward-circle",
  Stop: "stop",
  StopCircle: "stop-circle",
  Stopwatch: "stopwatch",
  Straighten: "ruler",
  StraightenOutline: "ruler",
  StrokeWidth: "minus",
  Subscribe: "bell",
  SubstractBackPath: "minus",
  SubstractFromSelection: "minus",
  SubtractBackPath: "minus",
  SubtractFromSelection: "minus",
  SubtractFrontPath: "minus",
  SuccessMetric: "trend-up",
  Summarize: "list-checks",
  Survey: "clipboard-text",
  Switch: "toggle-left",
  Sync: "arrows-clockwise",
  SyncRemove: "arrows-clockwise",
  Table: "table",
  TableAdd: "table",
  TableAndChart: "table",
  TableColumnAddLeft: "table",
  TableColumnAddRight: "table",
  TableColumnMerge: "table",
  TableColumnRemoveCenter: "table",
  TableColumnSplit: "table",
  TableEdit: "table",
  TableHistogram: "table",
  TableMergeCells: "table",
  TableRowAddBottom: "table",
  TableRowAddTop: "table",
  TableRowMerge: "table",
  TableRowRemoveCenter: "table",
  TableRowSplit: "table",
  TableSelectColumn: "table",
  TableSelectRow: "table",
  Tableau: "chart-bar",
  TagBold: "text-bolder",
  TagItalic: "text-italic",
  TagUnderline: "text-underline",
  Target: "target",
  Targeted: "target",
  TaskList: "list-checks",
  Teapot: "coffee",
  Temperature: "thermometer",
  TestAB: "flask",
  TestABEdit: "flask",
  TestABGear: "flask",
  TestABRemove: "flask",
  TestProfile: "flask",
  Text: "article",
  TextAdd: "article",
  TextAlignCenter: "text-align-center",
  TextAlignJustify: "text-align-justify",
  TextAlignLeft: "text-align-left",
  TextAlignRight: "text-align-right",
  TextBaselineShift: "text-line-spacing",
  TextBold: "text-bolder",
  TextBulleted: "list-bullets",
  TextBulletedAttach: "list-bullets",
  TextBulletedHierarchy: "list-bullets",
  TextBulletedHierarchyExclude: "list-bullets",
  TextColor: "paint-bucket",
  TextDecrease: "text-line-spacing",
  TextEdit: "article",
  TextExclude: "article",
  TextIncrease: "text-line-spacing",
  TextIndentDecrease: "text-indent",
  TextIndentIncrease: "text-indent",
  TextItalic: "text-italic",
  TextKerning: "text-line-spacing",
  TextLetteredLowerCase: "text-aa",
  TextLetteredUpperCase: "text-aa",
  TextNumbered: "list-numbers",
  TextParagraph: "text-align-justify",
  TextRomanLowercase: "text-aa",
  TextRomanUppercase: "text-aa",
  TextSize: "text-size",
  TextSizeAdd: "text-size",
  TextSpaceAfter: "text-line-spacing",
  TextSpaceBefore: "text-line-spacing",
  TextStrikethrough: "text-strikethrough",
  TextStroke: "text",
  TextStyle: "sparkle",
  TextSubscript: "text-subscript",
  TextSuperscript: "text-superscript",
  TextTracking: "text-line-spacing",
  TextUnderline: "text-underline",
  ThumbDown: "thumbs-down",
  ThumbDownOutline: "thumbs-down",
  ThumbUp: "thumbs-up",
  ThumbUpOutline: "thumbs-up",
  Tips: "lightbulb",
  Train: "train",
  TransferToPlatform: "arrow-up-tray",
  Transparency: "squares-four",
  Trap: "target",
  TreeCollapse: "caret-right",
  TreeCollapseAll: "caret-double-right",
  TreeExpand: "caret-down",
  TreeExpandAll: "caret-double-down",
  TrendInspect: "chart-line",
  TrimPath: "crop",
  TripleGripper: "list-bullets",
  Trophy: "trophy",
  Type: "text-t",
  USA: "flag",
  Underline: "text-underline",
  Undo: "arrow-counter-clockwise",
  Ungroup: "squares-four",
  Unlink: "link-break",
  Unmerge: "intersect",
  UploadToCloud: "cloud-arrow-up",
  UploadToCloudOutline: "cloud-arrow-up",
  User: "user",
  UserActivity: "graph-line",
  UserAdd: "user-plus",
  UserAdmin: "user-gear",
  UserArrow: "user-switch",
  UserCheckedOut: "user-circle-minus",
  UserDeveloper: "user-gear",
  UserEdit: "user-circle-gear",
  UserExclude: "user-minus",
  UserGroup: "users-three",
  UserLock: "user-lock",
  UserShare: "share-network",
  UsersAdd: "users-three",
  UsersExclude: "users-three",
  UsersLock: "users-three",
  UsersShare: "users-three",
  Variable: "function",
  VectorDraw: "bezier-curve",
  VideoCheckedOut: "film-slate",
  VideoFilled: "film-slate",
  VideoOutline: "film-slate",
  ViewAllTags: "tags",
  ViewBiWeek: "calendar",
  ViewCard: "squares-four",
  ViewColumn: "columns",
  ViewDay: "calendar",
  ViewDetail: "list-dashes",
  ViewGrid: "squares-four",
  ViewList: "list-bullets",
  ViewRow: "rows",
  ViewSingle: "square",
  ViewStack: "stack",
  ViewWeek: "calendar",
  ViewedMarkAs: "eye",
  Vignette: "circle-half-tilt",
  Visibility: "eye",
  VisibilityOff: "eye-slash",
  Visit: "arrow-square-out",
  VisitShare: "arrow-square-out",
  VoiceOver: "microphone",
  VolumeMute: "speaker-none",
  VolumeOne: "speaker-low",
  VolumeThree: "speaker-high",
  VolumeTwo: "speaker-high",
  Watch: "watch",
  WebPage: "browser",
  WebPages: "browsers",
  Workflow: "tree-structure",
  WorkflowAdd: "tree-structure",
  Brain: "brain",
  Wrench: "wrench",
  ZoomIn: "magnifying-glass-plus",
  ZoomOut: "magnifying-glass-minus"
};
function getPhosphorIcon(u) {
  return SpectrumIconMap[u] || u;
}
var root$14 = /* @__PURE__ */ from_html("<i></i>");
function InnerIcon(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source(), p = /* @__PURE__ */ mutable_source(), m = /* @__PURE__ */ mutable_source();
  let b = prop(l, "size", 8, "M"), y = prop(l, "name", 8, "plus"), v = prop(l, "hidden", 8, !1), $ = prop(l, "hoverable", 8, !1), w = prop(l, "disabled", 8, !1), P = prop(l, "color", 24, () => {
  }), k = prop(l, "hoverColor", 24, () => {
  }), x = prop(l, "tooltip", 24, () => {
  }), S = prop(l, "weight", 8, "regular");
  const T = {
    XXS: "12px",
    XS: "14px",
    S: "16px",
    M: "18px",
    L: "22px",
    XL: "28px",
    XXL: "36px",
    XXXL: "72px"
  }, M = (O, D, q) => {
    let F = `--size:${T[O]};`;
    return D && (F += `--color:${D};`), q && (F += `--hover-color:${q};`), F;
  };
  legacy_pre_effect(() => deep_read_state(y()), () => {
    set(f, getPhosphorIcon(y()));
  }), legacy_pre_effect(() => (deep_read_state(S()), get$2(f)), () => {
    set(p, `ph ph-${S()} ph-${get$2(f)}`);
  }), legacy_pre_effect(
    () => (deep_read_state(b()), deep_read_state(P()), deep_read_state(k())),
    () => {
      set(m, M(b(), P(), k()));
    }
  ), legacy_pre_effect_reset(), init$2();
  var E = root$14();
  let R;
  template_effect(
    (O) => {
      R = set_class(E, 1, clsx(get$2(p)), "svelte-8fxcej", R, O), set_style$1(E, get$2(m)), set_attribute(E, "aria-hidden", v() ? "true" : "false"), set_attribute(E, "aria-label", x() || y()), set_attribute(E, "title", x());
    },
    [() => ({ hoverable: $(), disabled: w() })]
  ), event("contextmenu", E, function(O) {
    bubble_event.call(this, l, O);
  }), event("click", E, function(O) {
    bubble_event.call(this, l, O);
  }), event("mouseover", E, function(O) {
    bubble_event.call(this, l, O);
  }), event("mouseleave", E, function(O) {
    bubble_event.call(this, l, O);
  }), event("focus", E, function(O) {
    bubble_event.call(this, l, O);
  }), append$2(u, E), pop();
}
function Icon(u, l) {
  push$2(l, !1);
  let f = prop(l, "size", 8, "M"), p = prop(l, "name", 8, "plus"), m = prop(l, "hidden", 8, !1), b = prop(l, "hoverable", 8, !1), y = prop(l, "disabled", 8, !1), v = prop(l, "color", 24, () => {
  }), $ = prop(l, "hoverColor", 24, () => {
  }), w = prop(l, "tooltip", 24, () => {
  }), P = prop(l, "tooltipPosition", 24, () => TooltipPosition.Bottom), k = prop(l, "tooltipType", 24, () => TooltipType.Default), x = prop(l, "tooltipColor", 24, () => {
  }), S = prop(l, "tooltipWrap", 8, !0), T = prop(l, "weight", 8, "regular");
  init$2();
  var M = comment$2(), E = first_child(M);
  {
    var R = (D) => {
      AbsTooltip(D, {
        get text() {
          return w();
        },
        get type() {
          return k();
        },
        get position() {
          return P();
        },
        get color() {
          return x();
        },
        get noWrap() {
          return S();
        },
        children: (q, F) => {
          InnerIcon(q, {
            get size() {
              return f();
            },
            get name() {
              return p();
            },
            get hidden() {
              return m();
            },
            get hoverable() {
              return b();
            },
            get disabled() {
              return y();
            },
            get color() {
              return v();
            },
            get hoverColor() {
              return $();
            },
            get weight() {
              return T();
            },
            $$events: {
              contextmenu(L) {
                bubble_event.call(this, l, L);
              },
              click(L) {
                bubble_event.call(this, l, L);
              },
              mouseover(L) {
                bubble_event.call(this, l, L);
              },
              mouseleave(L) {
                bubble_event.call(this, l, L);
              },
              focus(L) {
                bubble_event.call(this, l, L);
              }
            }
          });
        },
        $$slots: { default: !0 }
      });
    }, O = (D) => {
      InnerIcon(D, {
        get size() {
          return f();
        },
        get name() {
          return p();
        },
        get hidden() {
          return m();
        },
        get hoverable() {
          return b();
        },
        get disabled() {
          return y();
        },
        get color() {
          return v();
        },
        get hoverColor() {
          return $();
        },
        get weight() {
          return T();
        },
        $$events: {
          contextmenu(q) {
            bubble_event.call(this, l, q);
          },
          click(q) {
            bubble_event.call(this, l, q);
          },
          mouseover(q) {
            bubble_event.call(this, l, q);
          },
          mouseleave(q) {
            bubble_event.call(this, l, q);
          },
          focus(q) {
            bubble_event.call(this, l, q);
          }
        }
      });
    };
    if_block(E, (D) => {
      w() ? D(R) : D(O, !1);
    });
  }
  append$2(u, M), pop();
}
var root_2$x = /* @__PURE__ */ from_html("<div><!></div>"), root_1$D = /* @__PURE__ */ from_html('<div class="icon-container svelte-1qqk1xa"><!></div>'), root$13 = /* @__PURE__ */ from_html("<div><!> <!></div>");
function TooltipWrapper(u, l) {
  let f = prop(l, "tooltip", 8, ""), p = prop(l, "size", 8, "M"), m = prop(l, "disabled", 8, !0), b = prop(l, "position", 24, () => {
  });
  var y = root$13();
  let v;
  var $ = child(y);
  slot($, l, "default", {}, null);
  var w = sibling($, 2);
  {
    var P = (k) => {
      var x = root_1$D(), S = child(x);
      AbsTooltip(S, {
        get text() {
          return f();
        },
        get position() {
          return b();
        },
        children: (T, M) => {
          var E = root_2$x();
          let R;
          var O = child(E);
          Icon(O, {
            name: "info",
            size: "S",
            get disabled() {
              return m();
            },
            hoverable: !0
          }), reset(E), template_effect((D) => R = set_class(E, 1, "icon svelte-1qqk1xa", null, R, D), [() => ({ "icon-small": p() === "M" || p() === "S" })]), event("focus", E, function(D) {
            bubble_event.call(this, l, D);
          }), append$2(T, E);
        },
        $$slots: { default: !0 }
      }), reset(x), append$2(k, x);
    };
    if_block(w, (k) => {
      f() && k(P);
    });
  }
  reset(y), template_effect((k) => v = set_class(y, 1, "svelte-1qqk1xa", null, v, k), [() => ({ container: !!f() })]), append$2(u, y);
}
var root_2$w = /* @__PURE__ */ from_html('<sup class="required-asterisk svelte-17olp6b">*</sup>'), root_1$C = /* @__PURE__ */ from_html("<label> <!></label>");
function FieldLabel(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source();
  let p = prop(l, "forId", 24, () => {
  }), m = prop(l, "label", 8), b = prop(l, "position", 8, "above"), y = prop(l, "tooltip", 8, ""), v = prop(l, "required", 8, !1);
  legacy_pre_effect(() => deep_read_state(b()), () => {
    set(f, b() === "above" ? "" : `spectrum-FieldLabel--${b()}`);
  }), legacy_pre_effect_reset(), TooltipWrapper(u, {
    get tooltip() {
      return y();
    },
    size: "S",
    children: ($, w) => {
      var P = root_1$C(), k = child(P), x = sibling(k);
      {
        var S = (T) => {
          var M = root_2$w();
          append$2(T, M);
        };
        if_block(x, (T) => {
          v() && T(S);
        });
      }
      reset(P), template_effect(() => {
        set_attribute(P, "for", p()), set_class(P, 1, `spectrum-FieldLabel spectrum-FieldLabel--sizeM spectrum-Form-itemLabel ${get$2(f)}`, "svelte-17olp6b"), set_text(k, `${(m() || "") ?? ""} `);
      }), append$2($, P);
    },
    $$slots: { default: !0 }
  }), pop();
}
var root_1$B = /* @__PURE__ */ from_html('<label data-testid="label" for=""><!></label>');
function Label(u, l) {
  let f = prop(l, "size", 8, "M"), p = prop(l, "tooltip", 8, ""), m = prop(l, "muted", 24, () => {
  });
  TooltipWrapper(u, {
    get tooltip() {
      return p();
    },
    get size() {
      return f();
    },
    children: (b, y) => {
      var v = root_1$B();
      let $;
      var w = child(v);
      slot(w, l, "default", {}, null), reset(v), template_effect((P) => $ = set_class(v, 1, `spectrum-FieldLabel spectrum-FieldLabel--size${f()}`, "svelte-lf415l", $, P), [() => ({ muted: m() })]), append$2(b, v);
    },
    $$slots: { default: !0 }
  });
}
var root_2$v = /* @__PURE__ */ from_html('<div class="description svelte-1t3vuex"><!></div>'), root_4$g = /* @__PURE__ */ from_html('<div class="error svelte-1t3vuex"> </div>'), root_6$5 = /* @__PURE__ */ from_html('<div class="helpText svelte-1t3vuex"><!> <span class="svelte-1t3vuex"> </span></div>'), root$12 = /* @__PURE__ */ from_html('<div><!> <!> <div class="spectrum-Form-itemField svelte-1t3vuex"><!> <!></div></div>');
function Field(u, l) {
  let f = prop(l, "id", 24, () => {
  }), p = prop(l, "label", 24, () => {
  }), m = prop(l, "labelPosition", 8, "above"), b = prop(l, "error", 24, () => {
  }), y = prop(l, "description", 24, () => {
  }), v = prop(l, "helpText", 24, () => {
  }), $ = prop(l, "tooltip", 24, () => {
  }), w = prop(l, "required", 8, !1);
  var P = root$12();
  let k;
  var x = child(P);
  {
    var S = (F) => {
      FieldLabel(F, {
        get forId() {
          return f();
        },
        get label() {
          return p();
        },
        get position() {
          return m();
        },
        get tooltip() {
          return $();
        },
        get required() {
          return w();
        }
      });
    };
    if_block(x, (F) => {
      p() && F(S);
    });
  }
  var T = sibling(x, 2);
  {
    var M = (F) => {
      var L = root_2$v(), N = child(L);
      Label(N, {
        muted: !0,
        children: (z, V) => {
          next();
          var W = text$4();
          template_effect(() => set_text(W, y())), append$2(z, W);
        },
        $$slots: { default: !0 }
      }), reset(L), append$2(F, L);
    };
    if_block(T, (F) => {
      y() && F(M);
    });
  }
  var E = sibling(T, 2), R = child(E);
  slot(R, l, "default", {}, null);
  var O = sibling(R, 2);
  {
    var D = (F) => {
      var L = root_4$g(), N = child(L, !0);
      reset(L), template_effect(() => set_text(N, b())), append$2(F, L);
    }, q = (F) => {
      var L = comment$2(), N = first_child(L);
      {
        var z = (V) => {
          var W = root_6$5(), j = child(W);
          Icon(j, { name: "question" });
          var U = sibling(j, 2), Z = child(U, !0);
          reset(U), reset(W), template_effect(() => set_text(Z, v())), append$2(V, W);
        };
        if_block(
          N,
          (V) => {
            v() && V(z);
          },
          !0
        );
      }
      append$2(F, L);
    };
    if_block(O, (F) => {
      b() ? F(D) : F(q, !1);
    });
  }
  reset(E), reset(P), template_effect((F) => k = set_class(P, 1, "spectrum-Form-item svelte-1t3vuex", null, k, F), [() => ({ above: m() === "above" })]), append$2(u, P);
}
var root_1$A = /* @__PURE__ */ from_html('<span class="icon svelte-1hbushs"><!></span>'), root_3$o = /* @__PURE__ */ from_html('<span class="icon svelte-1hbushs"><!></span>'), root_4$f = /* @__PURE__ */ from_html('<span class="spectrum-Checkbox-label"> </span>'), root$11 = /* @__PURE__ */ from_html('<label><input type="checkbox" class="spectrum-Checkbox-input svelte-1hbushs"/> <span class="spectrum-Checkbox-box"><!></span> <!></label>');
function Checkbox(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source();
  let p = prop(l, "value", 8, !1), m = prop(l, "id", 24, () => {
  }), b = prop(l, "text", 24, () => {
  }), y = prop(l, "disabled", 8, !1), v = prop(l, "readonly", 8, !1), $ = prop(l, "quiet", 8, !1), w = prop(l, "size", 8, "M"), P = prop(l, "indeterminate", 8, !1);
  const k = createEventDispatcher$1(), x = (L) => {
    k("change", L.currentTarget.checked);
  };
  legacy_pre_effect(() => deep_read_state(w()), () => {
    set(f, `spectrum-Checkbox--size${w()}`);
  }), legacy_pre_effect_reset(), init$2();
  var S = root$11();
  let T;
  var M = child(S);
  remove_input_defaults(M);
  var E = sibling(M, 2), R = child(E);
  {
    var O = (L) => {
      var N = root_1$A(), z = child(N);
      Icon(z, {
        name: "minus",
        weight: "bold",
        color: "var(--spectrum-global-color-gray-50)"
      }), reset(N), append$2(L, N);
    }, D = (L) => {
      var N = comment$2(), z = first_child(N);
      {
        var V = (W) => {
          var j = root_3$o(), U = child(j);
          Icon(U, {
            name: "check",
            weight: "bold",
            color: "var(--spectrum-global-color-gray-50)"
          }), reset(j), append$2(W, j);
        };
        if_block(
          z,
          (W) => {
            p() && W(V);
          },
          !0
        );
      }
      append$2(L, N);
    };
    if_block(R, (L) => {
      P() ? L(O) : L(D, !1);
    });
  }
  reset(E);
  var q = sibling(E, 2);
  {
    var F = (L) => {
      var N = root_4$f(), z = child(N, !0);
      reset(N), template_effect(() => set_text(z, b())), append$2(L, N);
    };
    if_block(q, (L) => {
      b() && L(F);
    });
  }
  reset(S), template_effect(
    (L) => {
      T = set_class(S, 1, `spectrum-Checkbox ${get$2(f) ?? ""}`, "svelte-1hbushs", T, L), set_checked(M, p()), M.indeterminate = P(), M.disabled = y(), set_attribute(M, "id", m());
    },
    [
      () => ({
        "spectrum-Checkbox--emphasized": !y() && !$(),
        "is-indeterminate": P(),
        "is-disabled": y(),
        readonly: v()
      })
    ]
  ), event("change", M, x), append$2(u, S), pop();
}
function Checkbox_1(u, l) {
  push$2(l, !1);
  let f = prop(l, "value", 28, () => {
  }), p = prop(l, "indeterminate", 24, () => {
  }), m = prop(l, "label", 24, () => {
  }), b = prop(l, "labelPosition", 8, "above"), y = prop(l, "text", 24, () => {
  }), v = prop(l, "disabled", 8, !1), $ = prop(l, "error", 24, () => {
  }), w = prop(l, "size", 8, "M"), P = prop(l, "helpText", 24, () => {
  });
  const k = createEventDispatcher$1(), x = (S) => {
    f(S.detail), k("change", S.detail);
  };
  init$2(), Field(u, {
    get helpText() {
      return P();
    },
    get label() {
      return m();
    },
    get labelPosition() {
      return b();
    },
    get error() {
      return $();
    },
    children: (S, T) => {
      Checkbox(S, {
        get disabled() {
          return v();
        },
        get text() {
          return y();
        },
        get value() {
          return f();
        },
        get size() {
          return w();
        },
        get indeterminate() {
          return p();
        },
        $$events: { change: x }
      });
    },
    $$slots: { default: !0 }
  }), pop();
}
const ignoredClasses = [
  ".download-js-link",
  ".spectrum-Menu",
  ".date-time-popover"
], conditionallyIgnoredClasses = [
  ".spectrum-Underlay",
  ".drawer-wrapper",
  ".spectrum-Popover"
];
let clickHandlers = [], candidateTarget;
const handleClick = (u) => {
  const l = u.target || u.relatedTarget;
  if (!l.closest('[data-ignore-click-outside="true"]')) {
    for (let f of ignoredClasses)
      if (l.closest(f))
        return;
    clickHandlers.forEach((f) => {
      if (!f.element.contains(l)) {
        for (let p of conditionallyIgnoredClasses) {
          const m = f.anchor.closest(p) != null;
          if (l.closest(p) != null && !m)
            return;
        }
        f.callback?.(u);
      }
    });
  }
}, handleMouseUp = (u) => {
  candidateTarget === u.target && handleClick(u), candidateTarget = void 0;
}, handleMouseDown = (u) => {
  u.button === 0 && (candidateTarget = u.target, document.removeEventListener("click", handleMouseUp), document.addEventListener("click", handleMouseUp, !0));
}, handleBlur = () => {
  document.activeElement && ["IFRAME", "BODY"].includes(document.activeElement.tagName) && handleClick(
    new MouseEvent("click", { relatedTarget: document.activeElement })
  );
};
document.addEventListener("mousedown", handleMouseDown);
document.addEventListener("contextmenu", handleClick);
window.addEventListener("blur", handleBlur);
const updateHandler = (u, l, f, p) => {
  let m = clickHandlers.find((b) => b.id === u);
  m ? m.callback = p : clickHandlers.push({ id: u, element: l, anchor: f, callback: p });
}, removeHandler = (u) => {
  clickHandlers = clickHandlers.filter((l) => l.id !== u);
}, clickOutside = (u, l) => {
  const f = Math.random(), p = (y) => typeof y == "function", m = (y) => y != null && typeof y == "object", b = (y) => {
    let v, $ = u;
    p(y) ? v = y : m(y) && (v = y.callback, y.anchor && ($ = y.anchor)), updateHandler(f, u, $, v);
  };
  return b(l), {
    update: b,
    destroy: () => removeHandler(f)
  };
};
function positionDropdown(u, l) {
  let f, p = l;
  const m = (v) => {
    if (!(v.target instanceof Node && u.contains(v.target))) {
      if (p.onScroll) {
        p.onScroll();
        return;
      }
      b(p);
    }
  }, b = (v) => {
    const {
      anchor: $,
      align: w,
      maxHeight: P,
      maxWidth: k,
      minWidth: x,
      widthMode: S,
      offset: T = 5,
      customUpdate: M,
      resizable: E,
      wrap: R
    } = v;
    if (!$)
      return;
    const O = $.getBoundingClientRect(), D = u.getBoundingClientRect(), q = window.innerWidth, F = window.innerHeight, L = 8, N = S === "fixed-to-anchor";
    let V = {
      maxHeight: P,
      minWidth: N || S === "min-to-anchor" ? O.width : x,
      maxWidth: N ? O.width : k,
      widthMode: S,
      left: 0,
      top: 0
    };
    if (typeof M == "function")
      V = M(O, D, {
        ...V,
        offset: v.offset
      });
    else {
      const W = () => V.left + D.width > q && O.left > q - O.right, j = () => V.top + D.height > F && O.top > F - O.bottom, U = () => V.top < L && O.bottom < F - O.top, Z = (Y) => {
        !V.maxHeight && E && (V.maxHeight = Y);
      }, X = (Y) => {
        switch (Y) {
          case "StartToStart":
          default:
            V.left = O.left;
            break;
          case "EndToEnd":
            V.left = O.right - D.width;
            break;
          case "StartToEnd":
            V.left = O.right + T;
            break;
          case "EndToStart":
            V.left = O.left - D.width - T;
            break;
          case "MidPoint":
            V.left = O.left + O.width / 2 - D.width / 2;
            break;
          case "ScreenEdge":
            V.left = q - D.width - L;
            break;
        }
      }, B = (Y) => {
        switch (Y) {
          case "StartToStart":
            V.top = O.top, Z(F - O.top - L);
            break;
          case "EndToEnd":
            V.top = O.bottom - D.height, Z(O.bottom - L);
            break;
          case "StartToEnd":
          default:
            V.top = O.bottom + T, Z(F - O.bottom - L);
            break;
          case "EndToStart":
            V.top = O.top - D.height - T, Z(O.top - L);
            break;
          case "MidPoint":
            V.top = O.top + O.height / 2 - D.height / 2;
            break;
          case "ScreenEdge":
            V.top = F - D.height - L, Z(F - 2 * L);
            break;
        }
      }, H = () => {
        V.top = L, Z(F - 2 * L);
      };
      w === PopoverAlignment.Right ? X("EndToEnd") : w === PopoverAlignment.RightOutside || w === PopoverAlignment.RightContextMenu ? X("StartToEnd") : w === PopoverAlignment.LeftOutside || w === PopoverAlignment.LeftContextMenu ? X("EndToStart") : w === PopoverAlignment.Center ? X("MidPoint") : X("StartToStart"), w === PopoverAlignment.RightOutside || w === PopoverAlignment.LeftOutside ? B("MidPoint") : w === PopoverAlignment.RightContextMenu || w === PopoverAlignment.LeftContextMenu ? (B("StartToStart"), V.top && (V.top -= 5)) : B("StartToEnd"), W() && (w === PopoverAlignment.Left ? X("EndToEnd") : w === PopoverAlignment.RightOutside && X("EndToStart")), j() && (R ? (B("MidPoint"), j() && B("ScreenEdge"), X("StartToEnd"), W() && X("EndToStart")) : w === PopoverAlignment.LeftOutside || w === PopoverAlignment.RightOutside ? B("ScreenEdge") : B("EndToStart")), U() && (w === PopoverAlignment.LeftOutside || w === PopoverAlignment.RightOutside) && H();
    }
    for (const [W, j] of Object.entries(V)) {
      const U = W;
      U !== "widthMode" && (j != null ? u.style[U] = `${j}px` : u.style[U] = "");
    }
  }, y = (v) => {
    p = v, f && f.disconnect();
    const { anchor: $ } = v;
    $ && (f = new ResizeObserver(() => b(v)), f.observe($), f.observe(u), f.observe(document.body));
  };
  return u.style.position = "fixed", u.style.zIndex = "9999", document.addEventListener("scroll", m, !0), y(l), {
    update: y,
    destroy() {
      f && f.disconnect(), document.removeEventListener("scroll", m, !0);
    }
  };
}
const Context$1 = {
  Modal: "bbui-modal",
  PopoverRoot: "bbui-popover-root",
  PopoverPortalOverride: "bbui-popover-portal-override"
};
var root_2$u = /* @__PURE__ */ from_html('<div tabindex="0" role="presentation"><!></div>');
function Popover(u, l) {
  push$2(l, !1);
  const f = () => store_get(B, "$popoverPortalOverride", p), [p, m] = setup_stores(), b = /* @__PURE__ */ mutable_source();
  let y = prop(l, "anchor", 8), v = prop(l, "align", 24, () => PopoverAlignment.Right), $ = prop(l, "portalTarget", 24, () => {
  }), w = prop(l, "minWidth", 24, () => {
  }), P = prop(l, "maxWidth", 24, () => {
  }), k = prop(l, "maxHeight", 24, () => {
  }), x = prop(l, "borderRadius", 24, () => {
  }), S = prop(l, "open", 12, !1), T = prop(l, "widthMode", 8, "no-anchor"), M = prop(l, "dismissible", 8, !0), E = prop(l, "offset", 8, 4), R = prop(l, "customHeight", 24, () => {
  }), O = prop(l, "animate", 8, !0), D = prop(l, "customZIndex", 24, () => {
  }), q = prop(l, "handlePositionUpdate", 24, () => {
  }), F = prop(l, "showPopover", 8, !0), L = prop(l, "clickOutsideOverride", 8, !1), N = prop(l, "resizable", 8, !0), z = prop(l, "wrap", 8, !1), V = prop(l, "closeOnScroll", 8, !1);
  const W = createEventDispatcher$1(), j = 260;
  let U = /* @__PURE__ */ mutable_source(), Z = /* @__PURE__ */ mutable_source(!1);
  const X = getContext$2(Context$1.PopoverRoot), B = getContext$2(Context$1.PopoverPortalOverride), H = () => {
    W("open"), S(!0);
  }, Y = () => {
    W("close"), S(!1);
  }, K = () => {
    S() ? Y() : H();
  }, ee = (J) => {
    if (!L() && S()) {
      let ce = J.target, ye = !1;
      for (; !ye && ce && ce.parentNode; )
        ye = ce === y(), ce = ce.parentNode;
      ye && J.stopPropagation(), Y();
    }
  }, ae = (J) => {
    L() && S() && J.key === "Escape" && Y();
  };
  onDestroy$1(() => {
    clearTimeout(get$2(U));
  }), legacy_pre_effect(() => (deep_read_state($()), f()), () => {
    set(b, $() || f() || X || ".spectrum");
  }), legacy_pre_effect(
    () => (deep_read_state(S()), deep_read_state(O()), get$2(U)),
    () => {
      S() && O() && (set(Z, !0), clearTimeout(get$2(U)), set(U, setTimeout(
        () => {
          set(Z, !1);
        },
        j / 2
      )));
    }
  ), legacy_pre_effect_reset();
  var ne = { show: H, hide: Y, toggle: K };
  init$2();
  var me = comment$2(), le = first_child(me);
  {
    var ge = (J) => {
      Portal(J, {
        get target() {
          return get$2(b);
        },
        children: (ce, ye) => {
          var ie = root_2$u();
          let oe;
          var Q = child(ie);
          slot(Q, l, "default", {}, null), reset(ie), action(ie, (ue, fe) => positionDropdown?.(ue, fe), () => ({
            anchor: y(),
            align: v(),
            maxHeight: k(),
            maxWidth: P(),
            minWidth: w(),
            widthMode: T(),
            offset: E(),
            customUpdate: q(),
            resizable: N(),
            wrap: z(),
            onScroll: V() ? Y : void 0
          })), action(ie, (ue, fe) => clickOutside?.(ue, fe), () => ({
            callback: M() ? ee : () => {
            },
            anchor: y()
          })), effect(() => event("keydown", ie, ae)), effect(() => event("mouseenter", ie, function(ue) {
            bubble_event.call(this, l, ue);
          })), effect(() => event("mouseleave", ie, function(ue) {
            bubble_event.call(this, l, ue);
          })), template_effect(
            (ue) => {
              oe = set_class(ie, 1, "spectrum-Popover is-open svelte-5o6q45", null, oe, ue), set_style$1(ie, `height: ${R() ?? ""}; --customZIndex: ${D() ?? ""}; ${x() ? `border-radius: ${x()}` : ""}`);
            },
            [
              () => ({
                customZIndex: D(),
                hidden: !F(),
                blockPointerEvents: get$2(Z)
              })
            ]
          ), transition(3, ie, () => fly$1, () => ({ y: -20, duration: O() ? j : 0 })), append$2(ce, ie);
        },
        $$slots: { default: !0 }
      });
    };
    if_block(le, (J) => {
      S() && J(ge);
    });
  }
  append$2(u, me), bind_prop(l, "show", H), bind_prop(l, "hide", Y), bind_prop(l, "toggle", K);
  var pe = pop(ne);
  return m(), pe;
}
var root$10 = /* @__PURE__ */ from_html("<input/>");
function NumberInput(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source();
  let p = prop(l, "value", 8), m = prop(l, "min", 8), b = prop(l, "max", 8), y = prop(l, "hideArrows", 8, !1), v = prop(l, "width", 8), $ = prop(l, "type", 8, "number");
  const w = (x) => x.target.select();
  legacy_pre_effect(() => deep_read_state(v()), () => {
    set(f, v() ? `width:${v()}px;` : "");
  }), legacy_pre_effect_reset();
  var P = root$10();
  remove_input_defaults(P);
  let k;
  template_effect(
    (x) => {
      set_attribute(P, "type", $()), set_style$1(P, get$2(f)), set_value(P, p()), set_attribute(P, "min", m()), set_attribute(P, "max", b()), k = set_class(P, 1, "svelte-250tuz", null, k, x);
    },
    [() => ({ "hide-arrows": y() })]
  ), event("click", P, w), event("change", P, function(x) {
    bubble_event.call(this, l, x);
  }), event("input", P, function(x) {
    bubble_event.call(this, l, x);
  }), append$2(u, P), pop();
}
var root$$ = /* @__PURE__ */ from_html('<div class="time-picker svelte-1b0ajp9"><!></div>');
function TimePicker(u, l) {
  push$2(l, !1);
  const f = /* @__PURE__ */ mutable_source();
  let p = prop(l, "value", 8);
  const m = createEventDispatcher$1(), b = ($) => {
    if (!$.target.value) {
      m("change", void 0);
      return;
    }
    const [w, P] = $.target.value.split(":").map((k) => parseInt(k));
    m("change", (p() || dayjs()).hour(w).minute(P));
  };
  legacy_pre_effect(() => deep_read_state(p()), () => {
    set(f, p()?.format("HH:mm"));
  }), legacy_pre_effect_reset(), init$2();
  var y = root$$(), v = child(y);
  NumberInput(v, {
    hideArrows: !0,
    type: "time",
    get value() {
      return get$2(f);
    },
    $$events: { input: b, change: b }
  }), reset(y), append$2(u, y), pop();
}
const formatDistanceLocale$1j = {
  lessThanXSeconds: {
    one: "minder as 'n sekonde",
    other: "minder as {{count}} sekondes"
  },
  xSeconds: {
    one: "1 sekonde",
    other: "{{count}} sekondes"
  },
  halfAMinute: "'n halwe minuut",
  lessThanXMinutes: {
    one: "minder as 'n minuut",
    other: "minder as {{count}} minute"
  },
  xMinutes: {
    one: "'n minuut",
    other: "{{count}} minute"
  },
  aboutXHours: {
    one: "ongeveer 1 uur",
    other: "ongeveer {{count}} ure"
  },
  xHours: {
    one: "1 uur",
    other: "{{count}} ure"
  },
  xDays: {
    one: "1 dag",
    other: "{{count}} dae"
  },
  aboutXWeeks: {
    one: "ongeveer 1 week",
    other: "ongeveer {{count}} weke"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weke"
  },
  aboutXMonths: {
    one: "ongeveer 1 maand",
    other: "ongeveer {{count}} maande"
  },
  xMonths: {
    one: "1 maand",
    other: "{{count}} maande"
  },
  aboutXYears: {
    one: "ongeveer 1 jaar",
    other: "ongeveer {{count}} jaar"
  },
  xYears: {
    one: "1 jaar",
    other: "{{count}} jaar"
  },
  overXYears: {
    one: "meer as 1 jaar",
    other: "meer as {{count}} jaar"
  },
  almostXYears: {
    one: "byna 1 jaar",
    other: "byna {{count}} jaar"
  }
}, formatDistance$1k = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$1j[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "oor " + p : p + " gelede" : p;
};
function buildFormatLongFn(u) {
  return (l = {}) => {
    const f = l.width ? String(l.width) : u.defaultWidth;
    return u.formats[f] || u.formats[u.defaultWidth];
  };
}
const dateFormats$1s = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "yyyy/MM/dd"
}, timeFormats$1s = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1s = {
  full: "{{date}} 'om' {{time}}",
  long: "{{date}} 'om' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1s = {
  date: buildFormatLongFn({
    formats: dateFormats$1s,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1s,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1s,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1k = {
  lastWeek: "'verlede' eeee 'om' p",
  yesterday: "'gister om' p",
  today: "'vandag om' p",
  tomorrow: "'môre om' p",
  nextWeek: "eeee 'om' p",
  other: "P"
}, formatRelative$1k = (u, l, f, p) => formatRelativeLocale$1k[u];
function buildLocalizeFn(u) {
  return (l, f) => {
    const p = f?.context ? String(f.context) : "standalone";
    let m;
    if (p === "formatting" && u.formattingValues) {
      const y = u.defaultFormattingWidth || u.defaultWidth, v = f?.width ? String(f.width) : y;
      m = u.formattingValues[v] || u.formattingValues[y];
    } else {
      const y = u.defaultWidth, v = f?.width ? String(f.width) : u.defaultWidth;
      m = u.values[v] || u.values[y];
    }
    const b = u.argumentCallback ? u.argumentCallback(l) : l;
    return m[b];
  };
}
const eraValues$1k = {
  narrow: ["vC", "nC"],
  abbreviated: ["vC", "nC"],
  wide: ["voor Christus", "na Christus"]
}, quarterValues$1k = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: ["1ste kwartaal", "2de kwartaal", "3de kwartaal", "4de kwartaal"]
}, monthValues$1k = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mrt",
    "Apr",
    "Mei",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Okt",
    "Nov",
    "Des"
  ],
  wide: [
    "Januarie",
    "Februarie",
    "Maart",
    "April",
    "Mei",
    "Junie",
    "Julie",
    "Augustus",
    "September",
    "Oktober",
    "November",
    "Desember"
  ]
}, dayValues$1k = {
  narrow: ["S", "M", "D", "W", "D", "V", "S"],
  short: ["So", "Ma", "Di", "Wo", "Do", "Vr", "Sa"],
  abbreviated: ["Son", "Maa", "Din", "Woe", "Don", "Vry", "Sat"],
  wide: [
    "Sondag",
    "Maandag",
    "Dinsdag",
    "Woensdag",
    "Donderdag",
    "Vrydag",
    "Saterdag"
  ]
}, dayPeriodValues$1k = {
  narrow: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "middaguur",
    morning: "oggend",
    afternoon: "middag",
    evening: "laat middag",
    night: "aand"
  },
  abbreviated: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "middaguur",
    morning: "oggend",
    afternoon: "middag",
    evening: "laat middag",
    night: "aand"
  },
  wide: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "middaguur",
    morning: "oggend",
    afternoon: "middag",
    evening: "laat middag",
    night: "aand"
  }
}, formattingDayPeriodValues$14 = {
  narrow: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "uur die middag",
    morning: "uur die oggend",
    afternoon: "uur die middag",
    evening: "uur die aand",
    night: "uur die aand"
  },
  abbreviated: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "uur die middag",
    morning: "uur die oggend",
    afternoon: "uur die middag",
    evening: "uur die aand",
    night: "uur die aand"
  },
  wide: {
    am: "vm",
    pm: "nm",
    midnight: "middernag",
    noon: "uur die middag",
    morning: "uur die oggend",
    afternoon: "uur die middag",
    evening: "uur die aand",
    night: "uur die aand"
  }
}, ordinalNumber$1k = (u) => {
  const l = Number(u), f = l % 100;
  if (f < 20)
    switch (f) {
      case 1:
      case 8:
        return l + "ste";
      default:
        return l + "de";
    }
  return l + "ste";
}, localize$1k = {
  ordinalNumber: ordinalNumber$1k,
  era: buildLocalizeFn({
    values: eraValues$1k,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1k,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1k,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1k,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1k,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$14,
    defaultFormattingWidth: "wide"
  })
};
function buildMatchFn(u) {
  return (l, f = {}) => {
    const p = f.width, m = p && u.matchPatterns[p] || u.matchPatterns[u.defaultMatchWidth], b = l.match(m);
    if (!b)
      return null;
    const y = b[0], v = p && u.parsePatterns[p] || u.parsePatterns[u.defaultParseWidth], $ = Array.isArray(v) ? findIndex(v, (k) => k.test(y)) : (
      // [TODO] -- I challenge you to fix the type
      findKey(v, (k) => k.test(y))
    );
    let w;
    w = u.valueCallback ? u.valueCallback($) : $, w = f.valueCallback ? (
      // [TODO] -- I challenge you to fix the type
      f.valueCallback(w)
    ) : w;
    const P = l.slice(y.length);
    return { value: w, rest: P };
  };
}
function findKey(u, l) {
  for (const f in u)
    if (Object.prototype.hasOwnProperty.call(u, f) && l(u[f]))
      return f;
}
function findIndex(u, l) {
  for (let f = 0; f < u.length; f++)
    if (l(u[f]))
      return f;
}
function buildMatchPatternFn(u) {
  return (l, f = {}) => {
    const p = l.match(u.matchPattern);
    if (!p) return null;
    const m = p[0], b = l.match(u.parsePattern);
    if (!b) return null;
    let y = u.valueCallback ? u.valueCallback(b[0]) : b[0];
    y = f.valueCallback ? f.valueCallback(y) : y;
    const v = l.slice(m.length);
    return { value: y, rest: v };
  };
}
const matchOrdinalNumberPattern$1j = /^(\d+)(ste|de)?/i, parseOrdinalNumberPattern$1j = /\d+/i, matchEraPatterns$1j = {
  narrow: /^([vn]\.? ?C\.?)/,
  abbreviated: /^([vn]\. ?C\.?)/,
  wide: /^((voor|na) Christus)/
}, parseEraPatterns$1j = {
  any: [/^v/, /^n/]
}, matchQuarterPatterns$1j = {
  narrow: /^[1234]/i,
  abbreviated: /^K[1234]/i,
  wide: /^[1234](st|d)e kwartaal/i
}, parseQuarterPatterns$1j = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1j = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(Jan|Feb|Mrt|Apr|Mei|Jun|Jul|Aug|Sep|Okt|Nov|Dec)\.?/i,
  wide: /^(Januarie|Februarie|Maart|April|Mei|Junie|Julie|Augustus|September|Oktober|November|Desember)/i
}, parseMonthPatterns$1j = {
  narrow: [
    /^J/i,
    /^F/i,
    /^M/i,
    /^A/i,
    /^M/i,
    /^J/i,
    /^J/i,
    /^A/i,
    /^S/i,
    /^O/i,
    /^N/i,
    /^D/i
  ],
  any: [
    /^Jan/i,
    /^Feb/i,
    /^Mrt/i,
    /^Apr/i,
    /^Mei/i,
    /^Jun/i,
    /^Jul/i,
    /^Aug/i,
    /^Sep/i,
    /^Okt/i,
    /^Nov/i,
    /^Dec/i
  ]
}, matchDayPatterns$1j = {
  narrow: /^[smdwv]/i,
  short: /^(So|Ma|Di|Wo|Do|Vr|Sa)/i,
  abbreviated: /^(Son|Maa|Din|Woe|Don|Vry|Sat)/i,
  wide: /^(Sondag|Maandag|Dinsdag|Woensdag|Donderdag|Vrydag|Saterdag)/i
}, parseDayPatterns$1j = {
  narrow: [/^S/i, /^M/i, /^D/i, /^W/i, /^D/i, /^V/i, /^S/i],
  any: [/^So/i, /^Ma/i, /^Di/i, /^Wo/i, /^Do/i, /^Vr/i, /^Sa/i]
}, matchDayPeriodPatterns$1j = {
  any: /^(vm|nm|middernag|(?:uur )?die (oggend|middag|aand))/i
}, parseDayPeriodPatterns$1j = {
  any: {
    am: /^vm/i,
    pm: /^nm/i,
    midnight: /^middernag/i,
    noon: /^middaguur/i,
    morning: /oggend/i,
    afternoon: /middag/i,
    evening: /laat middag/i,
    night: /aand/i
  }
}, match$1k = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1j,
    parsePattern: parseOrdinalNumberPattern$1j,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1j,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1j,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1j,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1j,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1j,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1j,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1j,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1j,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1j,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1j,
    defaultParseWidth: "any"
  })
}, af = {
  code: "af",
  formatDistance: formatDistance$1k,
  formatLong: formatLong$1s,
  formatRelative: formatRelative$1k,
  localize: localize$1k,
  match: match$1k,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1i = {
  lessThanXSeconds: {
    one: "أقل من ثانية",
    two: "أقل من ثانيتين",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية واحدة",
    two: "ثانيتان",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نصف دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقائق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة واحدة",
    two: "دقيقتان",
    threeToTen: "{{count}} دقائق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "ساعة واحدة تقريباً",
    two: "ساعتين تقريبا",
    threeToTen: "{{count}} ساعات تقريباً",
    other: "{{count}} ساعة تقريباً"
  },
  xHours: {
    one: "ساعة واحدة",
    two: "ساعتان",
    threeToTen: "{{count}} ساعات",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "يوم واحد",
    two: "يومان",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "أسبوع واحد تقريبا",
    two: "أسبوعين تقريبا",
    threeToTen: "{{count}} أسابيع تقريبا",
    other: "{{count}} أسبوعا تقريبا"
  },
  xWeeks: {
    one: "أسبوع واحد",
    two: "أسبوعان",
    threeToTen: "{{count}} أسابيع",
    other: "{{count}} أسبوعا"
  },
  aboutXMonths: {
    one: "شهر واحد تقريباً",
    two: "شهرين تقريبا",
    threeToTen: "{{count}} أشهر تقريبا",
    other: "{{count}} شهرا تقريباً"
  },
  xMonths: {
    one: "شهر واحد",
    two: "شهران",
    threeToTen: "{{count}} أشهر",
    other: "{{count}} شهرا"
  },
  aboutXYears: {
    one: "سنة واحدة تقريباً",
    two: "سنتين تقريبا",
    threeToTen: "{{count}} سنوات تقريباً",
    other: "{{count}} سنة تقريباً"
  },
  xYears: {
    one: "سنة واحد",
    two: "سنتان",
    threeToTen: "{{count}} سنوات",
    other: "{{count}} سنة"
  },
  overXYears: {
    one: "أكثر من سنة",
    two: "أكثر من سنتين",
    threeToTen: "أكثر من {{count}} سنوات",
    other: "أكثر من {{count}} سنة"
  },
  almostXYears: {
    one: "ما يقارب سنة واحدة",
    two: "ما يقارب سنتين",
    threeToTen: "ما يقارب {{count}} سنوات",
    other: "ما يقارب {{count}} سنة"
  }
}, formatDistance$1j = (u, l, f) => {
  const p = formatDistanceLocale$1i[u];
  let m;
  return typeof p == "string" ? m = p : l === 1 ? m = p.one : l === 2 ? m = p.two : l <= 10 ? m = p.threeToTen.replace("{{count}}", String(l)) : m = p.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "خلال " + m : "منذ " + m : m;
}, dateFormats$1r = {
  full: "EEEE، do MMMM y",
  long: "do MMMM y",
  medium: "d MMM y",
  short: "dd/MM/yyyy"
}, timeFormats$1r = {
  full: "HH:mm:ss",
  long: "HH:mm:ss",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1r = {
  full: "{{date}} 'عند الساعة' {{time}}",
  long: "{{date}} 'عند الساعة' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1r = {
  date: buildFormatLongFn({
    formats: dateFormats$1r,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1r,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1r,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1j = {
  lastWeek: "eeee 'الماضي عند الساعة' p",
  yesterday: "'الأمس عند الساعة' p",
  today: "'اليوم عند الساعة' p",
  tomorrow: "'غدا عند الساعة' p",
  nextWeek: "eeee 'القادم عند الساعة' p",
  other: "P"
}, formatRelative$1j = (u) => formatRelativeLocale$1j[u], eraValues$1j = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1j = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1j = {
  narrow: ["ي", "ف", "م", "أ", "م", "ي", "ي", "أ", "س", "أ", "ن", "د"],
  abbreviated: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ],
  wide: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ]
}, dayValues$1j = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1j = {
  narrow: {
    am: "ص",
    pm: "م",
    morning: "الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "المساء",
    night: "الليل",
    midnight: "منتصف الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    morning: "الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "المساء",
    night: "الليل",
    midnight: "منتصف الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    morning: "الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "المساء",
    night: "الليل",
    midnight: "منتصف الليل"
  }
}, formattingDayPeriodValues$13 = {
  narrow: {
    am: "ص",
    pm: "م",
    morning: "في الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل",
    midnight: "منتصف الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    morning: "في الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل",
    midnight: "منتصف الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    morning: "في الصباح",
    noon: "الظهر",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل",
    midnight: "منتصف الليل"
  }
}, ordinalNumber$1j = (u) => String(u), localize$1j = {
  ordinalNumber: ordinalNumber$1j,
  era: buildLocalizeFn({
    values: eraValues$1j,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1j,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1j,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1j,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1j,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$13,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1i = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$1i = /\d+/i, matchEraPatterns$1i = {
  narrow: /[قب]/,
  abbreviated: /[قب]\.م\./,
  wide: /(قبل|بعد) الميلاد/
}, parseEraPatterns$1i = {
  any: [/قبل/, /بعد/]
}, matchQuarterPatterns$1i = {
  narrow: /^[1234]/i,
  abbreviated: /ر[1234]/,
  wide: /الربع (الأول|الثاني|الثالث|الرابع)/
}, parseQuarterPatterns$1i = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1i = {
  narrow: /^[أيفمسند]/,
  abbreviated: /^(يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/,
  wide: /^(يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/
}, parseMonthPatterns$1i = {
  narrow: [
    /^ي/i,
    /^ف/i,
    /^م/i,
    /^أ/i,
    /^م/i,
    /^ي/i,
    /^ي/i,
    /^أ/i,
    /^س/i,
    /^أ/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^يناير/i,
    /^فبراير/i,
    /^مارس/i,
    /^أبريل/i,
    /^مايو/i,
    /^يونيو/i,
    /^يوليو/i,
    /^أغسطس/i,
    /^سبتمبر/i,
    /^أكتوبر/i,
    /^نوفمبر/i,
    /^ديسمبر/i
  ]
}, matchDayPatterns$1i = {
  narrow: /^[حنثرخجس]/i,
  short: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  abbreviated: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  wide: /^(الأحد|الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/i
}, parseDayPatterns$1i = {
  narrow: [/^ح/i, /^ن/i, /^ث/i, /^ر/i, /^خ/i, /^ج/i, /^س/i],
  wide: [
    /^الأحد/i,
    /^الاثنين/i,
    /^الثلاثاء/i,
    /^الأربعاء/i,
    /^الخميس/i,
    /^الجمعة/i,
    /^السبت/i
  ],
  any: [/^أح/i, /^اث/i, /^ث/i, /^أر/i, /^خ/i, /^ج/i, /^س/i]
}, matchDayPeriodPatterns$1i = {
  narrow: /^(ص|م|منتصف الليل|الظهر|بعد الظهر|في الصباح|في المساء|في الليل)/,
  any: /^(ص|م|منتصف الليل|الظهر|بعد الظهر|في الصباح|في المساء|في الليل)/
}, parseDayPeriodPatterns$1i = {
  any: {
    am: /^ص/,
    pm: /^م/,
    midnight: /منتصف الليل/,
    noon: /الظهر/,
    afternoon: /بعد الظهر/,
    morning: /في الصباح/,
    evening: /في المساء/,
    night: /في الليل/
  }
}, match$1j = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1i,
    parsePattern: parseOrdinalNumberPattern$1i,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1i,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1i,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1i,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1i,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1i,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1i,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1i,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1i,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1i,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1i,
    defaultParseWidth: "any"
  })
}, ar = {
  code: "ar",
  formatDistance: formatDistance$1j,
  formatLong: formatLong$1r,
  formatRelative: formatRelative$1j,
  localize: localize$1j,
  match: match$1j,
  options: {
    weekStartsOn: 6,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1h = {
  lessThanXSeconds: {
    one: "أقل من ثانية واحدة",
    two: "أقل من ثانتين",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية واحدة",
    two: "ثانتين",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نصف دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقائق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة واحدة",
    two: "دقيقتين",
    threeToTen: "{{count}} دقائق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "ساعة واحدة تقريباً",
    two: "ساعتين تقريباً",
    threeToTen: "{{count}} ساعات تقريباً",
    other: "{{count}} ساعة تقريباً"
  },
  xHours: {
    one: "ساعة واحدة",
    two: "ساعتين",
    threeToTen: "{{count}} ساعات",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "يوم واحد",
    two: "يومين",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "أسبوع واحد تقريباً",
    two: "أسبوعين تقريباً",
    threeToTen: "{{count}} أسابيع تقريباً",
    other: "{{count}} أسبوع تقريباً"
  },
  xWeeks: {
    one: "أسبوع واحد",
    two: "أسبوعين",
    threeToTen: "{{count}} أسابيع",
    other: "{{count}} أسبوع"
  },
  aboutXMonths: {
    one: "شهر واحد تقريباً",
    two: "شهرين تقريباً",
    threeToTen: "{{count}} أشهر تقريباً",
    other: "{{count}} شهر تقريباً"
  },
  xMonths: {
    one: "شهر واحد",
    two: "شهرين",
    threeToTen: "{{count}} أشهر",
    other: "{{count}} شهر"
  },
  aboutXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  },
  xYears: {
    one: "عام واحد",
    two: "عامين",
    threeToTen: "{{count}} أعوام",
    other: "{{count}} عام"
  },
  overXYears: {
    one: "أكثر من عام",
    two: "أكثر من عامين",
    threeToTen: "أكثر من {{count}} أعوام",
    other: "أكثر من {{count}} عام"
  },
  almostXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  }
}, formatDistance$1i = (u, l, f) => {
  f = f || {};
  const p = formatDistanceLocale$1h[u];
  let m;
  return typeof p == "string" ? m = p : l === 1 ? m = p.one : l === 2 ? m = p.two : l <= 10 ? m = p.threeToTen.replace("{{count}}", String(l)) : m = p.other.replace("{{count}}", String(l)), f.addSuffix ? f.comparison && f.comparison > 0 ? "في خلال " + m : "منذ " + m : m;
}, dateFormats$1q = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$1q = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1q = {
  full: "{{date}} 'عند' {{time}}",
  long: "{{date}} 'عند' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1q = {
  date: buildFormatLongFn({
    formats: dateFormats$1q,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1q,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1q,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1i = {
  lastWeek: "'أخر' eeee 'عند' p",
  yesterday: "'أمس عند' p",
  today: "'اليوم عند' p",
  tomorrow: "'غداً عند' p",
  nextWeek: "eeee 'عند' p",
  other: "P"
}, formatRelative$1i = (u, l, f, p) => formatRelativeLocale$1i[u], eraValues$1i = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1i = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1i = {
  narrow: ["ج", "ف", "م", "أ", "م", "ج", "ج", "أ", "س", "أ", "ن", "د"],
  abbreviated: [
    "جانـ",
    "فيفـ",
    "مارس",
    "أفريل",
    "مايـ",
    "جوانـ",
    "جويـ",
    "أوت",
    "سبتـ",
    "أكتـ",
    "نوفـ",
    "ديسـ"
  ],
  wide: [
    "جانفي",
    "فيفري",
    "مارس",
    "أفريل",
    "ماي",
    "جوان",
    "جويلية",
    "أوت",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ]
}, dayValues$1i = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنـ", "ثلا", "أربـ", "خميـ", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1i = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  }
}, formattingDayPeriodValues$12 = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "في الصباح",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "في الصباح",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  }
}, ordinalNumber$1i = (u) => String(u), localize$1i = {
  ordinalNumber: ordinalNumber$1i,
  era: buildLocalizeFn({
    values: eraValues$1i,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1i,
    defaultWidth: "wide",
    argumentCallback: (u) => Number(u) - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1i,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1i,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1i,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$12,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1h = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$1h = /\d+/i, matchEraPatterns$1h = {
  narrow: /^(ق|ب)/i,
  abbreviated: /^(ق\.?\s?م\.?|ق\.?\s?م\.?\s?|a\.?\s?d\.?|c\.?\s?)/i,
  wide: /^(قبل الميلاد|قبل الميلاد|بعد الميلاد|بعد الميلاد)/i
}, parseEraPatterns$1h = {
  any: [/^قبل/i, /^بعد/i]
}, matchQuarterPatterns$1h = {
  narrow: /^[1234]/i,
  abbreviated: /^ر[1234]/i,
  wide: /^الربع [1234]/i
}, parseQuarterPatterns$1h = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1h = {
  narrow: /^[جفمأسند]/i,
  abbreviated: /^(جان|فيف|مار|أفر|ماي|جوا|جوي|أوت|سبت|أكت|نوف|ديس)/i,
  wide: /^(جانفي|فيفري|مارس|أفريل|ماي|جوان|جويلية|أوت|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/i
}, parseMonthPatterns$1h = {
  narrow: [
    /^ج/i,
    /^ف/i,
    /^م/i,
    /^أ/i,
    /^م/i,
    /^ج/i,
    /^ج/i,
    /^أ/i,
    /^س/i,
    /^أ/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^جان/i,
    /^فيف/i,
    /^مار/i,
    /^أفر/i,
    /^ماي/i,
    /^جوا/i,
    /^جوي/i,
    /^أوت/i,
    /^سبت/i,
    /^أكت/i,
    /^نوف/i,
    /^ديس/i
  ]
}, matchDayPatterns$1h = {
  narrow: /^[حنثرخجس]/i,
  short: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  abbreviated: /^(أحد|اثن|ثلا|أرب|خمي|جمعة|سبت)/i,
  wide: /^(الأحد|الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/i
}, parseDayPatterns$1h = {
  narrow: [/^ح/i, /^ن/i, /^ث/i, /^ر/i, /^خ/i, /^ج/i, /^س/i],
  wide: [
    /^الأحد/i,
    /^الاثنين/i,
    /^الثلاثاء/i,
    /^الأربعاء/i,
    /^الخميس/i,
    /^الجمعة/i,
    /^السبت/i
  ],
  any: [/^أح/i, /^اث/i, /^ث/i, /^أر/i, /^خ/i, /^ج/i, /^س/i]
}, matchDayPeriodPatterns$1h = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, parseDayPeriodPatterns$1h = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, match$1i = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1h,
    parsePattern: parseOrdinalNumberPattern$1h,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1h,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1h,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1h,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1h,
    defaultParseWidth: "any",
    valueCallback: (u) => Number(u) + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1h,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1h,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1h,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1h,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1h,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1h,
    defaultParseWidth: "any"
  })
}, arDZ = {
  code: "ar-DZ",
  formatDistance: formatDistance$1i,
  formatLong: formatLong$1q,
  formatRelative: formatRelative$1i,
  localize: localize$1i,
  match: match$1i,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1g = {
  lessThanXSeconds: {
    one: "أقل من ثانية",
    two: "أقل من ثانيتين",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية",
    two: "ثانيتين",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نص دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقايق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة",
    two: "دقيقتين",
    threeToTen: "{{count}} دقايق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "حوالي ساعة",
    two: "حوالي ساعتين",
    threeToTen: "حوالي {{count}} ساعات",
    other: "حوالي {{count}} ساعة"
  },
  xHours: {
    one: "ساعة",
    two: "ساعتين",
    threeToTen: "{{count}} ساعات",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "يوم",
    two: "يومين",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "حوالي أسبوع",
    two: "حوالي أسبوعين",
    threeToTen: "حوالي {{count}} أسابيع",
    other: "حوالي {{count}} أسبوع"
  },
  xWeeks: {
    one: "أسبوع",
    two: "أسبوعين",
    threeToTen: "{{count}} أسابيع",
    other: "{{count}} أسبوع"
  },
  aboutXMonths: {
    one: "حوالي شهر",
    two: "حوالي شهرين",
    threeToTen: "حوالي {{count}} أشهر",
    other: "حوالي {{count}} شهر"
  },
  xMonths: {
    one: "شهر",
    two: "شهرين",
    threeToTen: "{{count}} أشهر",
    other: "{{count}} شهر"
  },
  aboutXYears: {
    one: "حوالي سنة",
    two: "حوالي سنتين",
    threeToTen: "حوالي {{count}} سنين",
    other: "حوالي {{count}} سنة"
  },
  xYears: {
    one: "عام",
    two: "عامين",
    threeToTen: "{{count}} أعوام",
    other: "{{count}} عام"
  },
  overXYears: {
    one: "أكثر من سنة",
    two: "أكثر من سنتين",
    threeToTen: "أكثر من {{count}} سنين",
    other: "أكثر من {{count}} سنة"
  },
  almostXYears: {
    one: "عام تقريبًا",
    two: "عامين تقريبًا",
    threeToTen: "{{count}} أعوام تقريبًا",
    other: "{{count}} عام تقريبًا"
  }
}, formatDistance$1h = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$1g[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 2 ? p = m.two : l <= 10 ? p = m.threeToTen.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? `في خلال ${p}` : `منذ ${p}` : p;
}, dateFormats$1p = {
  full: "EEEE، do MMMM y",
  long: "do MMMM y",
  medium: "dd/MMM/y",
  short: "d/MM/y"
}, timeFormats$1p = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1p = {
  full: "{{date}} 'الساعة' {{time}}",
  long: "{{date}} 'الساعة' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1p = {
  date: buildFormatLongFn({
    formats: dateFormats$1p,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1p,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1p,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1h = {
  lastWeek: "eeee 'اللي جاي الساعة' p",
  yesterday: "'إمبارح الساعة' p",
  today: "'النهاردة الساعة' p",
  tomorrow: "'بكرة الساعة' p",
  nextWeek: "eeee 'الساعة' p",
  other: "P"
}, formatRelative$1h = (u, l, f, p) => formatRelativeLocale$1h[u], eraValues$1h = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م", "ب.م"],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1h = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1h = {
  narrow: ["ي", "ف", "م", "أ", "م", "ي", "ي", "أ", "س", "أ", "ن", "د"],
  abbreviated: [
    "ينا",
    "فبر",
    "مارس",
    "أبريل",
    "مايو",
    "يونـ",
    "يولـ",
    "أغسـ",
    "سبتـ",
    "أكتـ",
    "نوفـ",
    "ديسـ"
  ],
  wide: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ]
}, dayValues$1h = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1h = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءً",
    night: "ليلاً"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهراً",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءً",
    night: "ليلاً"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهراً",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءً",
    night: "ليلاً"
  }
}, formattingDayPeriodValues$11 = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "في الصباح",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهراً",
    morning: "في الصباح",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    morning: "في الصباح",
    noon: "ظهراً",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  }
}, ordinalNumber$1h = (u, l) => String(u), localize$1h = {
  ordinalNumber: ordinalNumber$1h,
  era: buildLocalizeFn({
    values: eraValues$1h,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1h,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1h,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1h,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1h,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$11,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1g = /^(\d+)/, parseOrdinalNumberPattern$1g = /\d+/i, matchEraPatterns$1g = {
  narrow: /^(ق|ب)/g,
  abbreviated: /^(ق.م|ب.م)/g,
  wide: /^(قبل الميلاد|بعد الميلاد)/g
}, parseEraPatterns$1g = {
  any: [/^ق/g, /^ب/g]
}, matchQuarterPatterns$1g = {
  narrow: /^[1234]/,
  abbreviated: /^ر[1234]/,
  wide: /^الربع (الأول|الثاني|الثالث|الرابع)/
}, parseQuarterPatterns$1g = {
  wide: [/الربع الأول/, /الربع الثاني/, /الربع الثالث/, /الربع الرابع/],
  any: [/1/, /2/, /3/, /4/]
}, matchMonthPatterns$1g = {
  narrow: /^(ي|ف|م|أ|س|ن|د)/,
  abbreviated: /^(ينا|فبر|مارس|أبريل|مايو|يونـ|يولـ|أغسـ|سبتـ|أكتـ|نوفـ|ديسـ)/,
  wide: /^(يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/
}, parseMonthPatterns$1g = {
  narrow: [
    /^ي/,
    /^ف/,
    /^م/,
    /^أ/,
    /^م/,
    /^ي/,
    /^ي/,
    /^أ/,
    /^س/,
    /^أ/,
    /^ن/,
    /^د/
  ],
  any: [
    /^ينا/,
    /^فبر/,
    /^مارس/,
    /^أبريل/,
    /^مايو/,
    /^يون/,
    /^يول/,
    /^أغس/,
    /^سبت/,
    /^أكت/,
    /^نوف/,
    /^ديس/
  ]
}, matchDayPatterns$1g = {
  narrow: /^(ح|ن|ث|ر|خ|ج|س)/,
  short: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/,
  abbreviated: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/,
  wide: /^(الأحد|الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/
}, parseDayPatterns$1g = {
  narrow: [/^ح/, /^ن/, /^ث/, /^ر/, /^خ/, /^ج/, /^س/],
  any: [/أحد/, /اثنين/, /ثلاثاء/, /أربعاء/, /خميس/, /جمعة/, /سبت/]
}, matchDayPeriodPatterns$1g = {
  narrow: /^(ص|م|ن|ظ|في الصباح|بعد الظهر|في المساء|في الليل)/,
  abbreviated: /^(ص|م|نصف الليل|ظهراً|في الصباح|بعد الظهر|في المساء|في الليل)/,
  wide: /^(ص|م|نصف الليل|في الصباح|ظهراً|بعد الظهر|في المساء|في الليل)/,
  any: /^(ص|م|صباح|ظهر|مساء|ليل)/
}, parseDayPeriodPatterns$1g = {
  any: {
    am: /^ص/,
    pm: /^م/,
    midnight: /^ن/,
    noon: /^ظ/,
    morning: /^ص/,
    afternoon: /^بعد/,
    evening: /^م/,
    night: /^ل/
  }
}, match$1h = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1g,
    parsePattern: parseOrdinalNumberPattern$1g,
    valueCallback: function(u) {
      return parseInt(u, 10);
    }
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1g,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1g,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1g,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1g,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1g,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1g,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1g,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1g,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1g,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1g,
    defaultParseWidth: "any"
  })
}, arEG = {
  code: "ar-EG",
  formatDistance: formatDistance$1h,
  formatLong: formatLong$1p,
  formatRelative: formatRelative$1h,
  localize: localize$1h,
  match: match$1h,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1f = {
  lessThanXSeconds: {
    one: "أقل من ثانية واحدة",
    two: "أقل من ثانتين",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية واحدة",
    two: "ثانتين",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نصف دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقائق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة واحدة",
    two: "دقيقتين",
    threeToTen: "{{count}} دقائق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "ساعة واحدة تقريباً",
    two: "ساعتين تقريباً",
    threeToTen: "{{count}} ساعات تقريباً",
    other: "{{count}} ساعة تقريباً"
  },
  xHours: {
    one: "ساعة واحدة",
    two: "ساعتين",
    threeToTen: "{{count}} ساعات",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "يوم واحد",
    two: "يومين",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "أسبوع واحد تقريباً",
    two: "أسبوعين تقريباً",
    threeToTen: "{{count}} أسابيع تقريباً",
    other: "{{count}} أسبوع تقريباً"
  },
  xWeeks: {
    one: "أسبوع واحد",
    two: "أسبوعين",
    threeToTen: "{{count}} أسابيع",
    other: "{{count}} أسبوع"
  },
  aboutXMonths: {
    one: "شهر واحد تقريباً",
    two: "شهرين تقريباً",
    threeToTen: "{{count}} أشهر تقريباً",
    other: "{{count}} شهر تقريباً"
  },
  xMonths: {
    one: "شهر واحد",
    two: "شهرين",
    threeToTen: "{{count}} أشهر",
    other: "{{count}} شهر"
  },
  aboutXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  },
  xYears: {
    one: "عام واحد",
    two: "عامين",
    threeToTen: "{{count}} أعوام",
    other: "{{count}} عام"
  },
  overXYears: {
    one: "أكثر من عام",
    two: "أكثر من عامين",
    threeToTen: "أكثر من {{count}} أعوام",
    other: "أكثر من {{count}} عام"
  },
  almostXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  }
}, formatDistance$1g = (u, l, f) => {
  f = f || {};
  const p = formatDistanceLocale$1f[u];
  let m;
  return typeof p == "string" ? m = p : l === 1 ? m = p.one : l === 2 ? m = p.two : l <= 10 ? m = p.threeToTen.replace("{{count}}", String(l)) : m = p.other.replace("{{count}}", String(l)), f.addSuffix ? f.comparison && f.comparison > 0 ? "في خلال " + m : "منذ " + m : m;
}, dateFormats$1o = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$1o = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1o = {
  full: "{{date}} 'عند' {{time}}",
  long: "{{date}} 'عند' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1o = {
  date: buildFormatLongFn({
    formats: dateFormats$1o,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1o,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1o,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1g = {
  lastWeek: "'أخر' eeee 'عند' p",
  yesterday: "'أمس عند' p",
  today: "'اليوم عند' p",
  tomorrow: "'غداً عند' p",
  nextWeek: "eeee 'عند' p",
  other: "P"
}, formatRelative$1g = (u, l, f, p) => formatRelativeLocale$1g[u], eraValues$1g = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1g = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1g = {
  narrow: ["ي", "ف", "م", "أ", "م", "ي", "ي", "غ", "ش", "أ", "ن", "د"],
  abbreviated: [
    "ينا",
    "فبر",
    "مارس",
    "أبريل",
    "ماي",
    "يونـ",
    "يولـ",
    "غشت",
    "شتنـ",
    "أكتـ",
    "نونـ",
    "دجنـ"
  ],
  wide: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "ماي",
    "يونيو",
    "يوليوز",
    "غشت",
    "شتنبر",
    "أكتوبر",
    "نونبر",
    "دجنبر"
  ]
}, dayValues$1g = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنـ", "ثلا", "أربـ", "خميـ", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الإثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1g = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  }
}, formattingDayPeriodValues$10 = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "في الصباح",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "في الصباح",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  }
}, ordinalNumber$1g = (u) => String(u), localize$1g = {
  ordinalNumber: ordinalNumber$1g,
  era: buildLocalizeFn({
    values: eraValues$1g,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1g,
    defaultWidth: "wide",
    argumentCallback: (u) => Number(u) - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1g,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1g,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1g,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$10,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1f = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$1f = /\d+/i, matchEraPatterns$1f = {
  narrow: /^(ق|ب)/i,
  abbreviated: /^(ق\.?\s?م\.?|ق\.?\s?م\.?\s?|a\.?\s?d\.?|c\.?\s?)/i,
  wide: /^(قبل الميلاد|قبل الميلاد|بعد الميلاد|بعد الميلاد)/i
}, parseEraPatterns$1f = {
  any: [/^قبل/i, /^بعد/i]
}, matchQuarterPatterns$1f = {
  narrow: /^[1234]/i,
  abbreviated: /^ر[1234]/i,
  wide: /^الربع [1234]/i
}, parseQuarterPatterns$1f = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1f = {
  narrow: /^[يفمأمسند]/i,
  abbreviated: /^(ين|ف|مار|أب|ماي|يون|يول|غش|شت|أك|ن|د)/i,
  wide: /^(ين|ف|مار|أب|ماي|يون|يول|غش|شت|أك|ن|د)/i
}, parseMonthPatterns$1f = {
  narrow: [
    /^ي/i,
    /^ف/i,
    /^م/i,
    /^أ/i,
    /^م/i,
    /^ي/i,
    /^ي/i,
    /^غ/i,
    /^ش/i,
    /^أ/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^ين/i,
    /^فب/i,
    /^مار/i,
    /^أب/i,
    /^ماي/i,
    /^يون/i,
    /^يول/i,
    /^غشت/i,
    /^ش/i,
    /^أك/i,
    /^ن/i,
    /^د/i
  ]
}, matchDayPatterns$1f = {
  narrow: /^[حنثرخجس]/i,
  short: /^(أحد|إثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  abbreviated: /^(أحد|إثن|ثلا|أرب|خمي|جمعة|سبت)/i,
  wide: /^(الأحد|الإثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/i
}, parseDayPatterns$1f = {
  narrow: [/^ح/i, /^ن/i, /^ث/i, /^ر/i, /^خ/i, /^ج/i, /^س/i],
  wide: [
    /^الأحد/i,
    /^الإثنين/i,
    /^الثلاثاء/i,
    /^الأربعاء/i,
    /^الخميس/i,
    /^الجمعة/i,
    /^السبت/i
  ],
  any: [/^أح/i, /^إث/i, /^ث/i, /^أر/i, /^خ/i, /^ج/i, /^س/i]
}, matchDayPeriodPatterns$1f = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, parseDayPeriodPatterns$1f = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, match$1g = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1f,
    parsePattern: parseOrdinalNumberPattern$1f,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1f,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1f,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1f,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1f,
    defaultParseWidth: "any",
    valueCallback: (u) => Number(u) + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1f,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1f,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1f,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1f,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1f,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1f,
    defaultParseWidth: "any"
  })
}, arMA = {
  code: "ar-MA",
  formatDistance: formatDistance$1g,
  formatLong: formatLong$1o,
  formatRelative: formatRelative$1g,
  localize: localize$1g,
  match: match$1g,
  options: {
    // Monday is 1
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1e = {
  lessThanXSeconds: {
    one: "أقل من ثانية واحدة",
    two: "أقل من ثانتين",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية واحدة",
    two: "ثانتين",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نصف دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقائق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة واحدة",
    two: "دقيقتين",
    threeToTen: "{{count}} دقائق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "ساعة واحدة تقريباً",
    two: "ساعتين تقريباً",
    threeToTen: "{{count}} ساعات تقريباً",
    other: "{{count}} ساعة تقريباً"
  },
  xHours: {
    one: "ساعة واحدة",
    two: "ساعتين",
    threeToTen: "{{count}} ساعات",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "يوم واحد",
    two: "يومين",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "أسبوع واحد تقريباً",
    two: "أسبوعين تقريباً",
    threeToTen: "{{count}} أسابيع تقريباً",
    other: "{{count}} أسبوع تقريباً"
  },
  xWeeks: {
    one: "أسبوع واحد",
    two: "أسبوعين",
    threeToTen: "{{count}} أسابيع",
    other: "{{count}} أسبوع"
  },
  aboutXMonths: {
    one: "شهر واحد تقريباً",
    two: "شهرين تقريباً",
    threeToTen: "{{count}} أشهر تقريباً",
    other: "{{count}} شهر تقريباً"
  },
  xMonths: {
    one: "شهر واحد",
    two: "شهرين",
    threeToTen: "{{count}} أشهر",
    other: "{{count}} شهر"
  },
  aboutXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  },
  xYears: {
    one: "عام واحد",
    two: "عامين",
    threeToTen: "{{count}} أعوام",
    other: "{{count}} عام"
  },
  overXYears: {
    one: "أكثر من عام",
    two: "أكثر من عامين",
    threeToTen: "أكثر من {{count}} أعوام",
    other: "أكثر من {{count}} عام"
  },
  almostXYears: {
    one: "عام واحد تقريباً",
    two: "عامين تقريباً",
    threeToTen: "{{count}} أعوام تقريباً",
    other: "{{count}} عام تقريباً"
  }
}, formatDistance$1f = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$1e[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 2 ? p = m.two : l <= 10 ? p = m.threeToTen.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "في خلال " + p : "منذ " + p : p;
}, dateFormats$1n = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$1n = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1n = {
  full: "{{date}} 'عند' {{time}}",
  long: "{{date}} 'عند' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1n = {
  date: buildFormatLongFn({
    formats: dateFormats$1n,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1n,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1n,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1f = {
  lastWeek: "'أخر' eeee 'عند' p",
  yesterday: "'أمس عند' p",
  today: "'اليوم عند' p",
  tomorrow: "'غداً عند' p",
  nextWeek: "eeee 'عند' p",
  other: "P"
}, formatRelative$1f = (u, l, f, p) => formatRelativeLocale$1f[u], eraValues$1f = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1f = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1f = {
  narrow: ["ي", "ف", "م", "أ", "م", "ي", "ي", "أ", "س", "أ", "ن", "د"],
  abbreviated: [
    "ينا",
    "فبر",
    "مارس",
    "أبريل",
    "مايو",
    "يونـ",
    "يولـ",
    "أغسـ",
    "سبتـ",
    "أكتـ",
    "نوفـ",
    "ديسـ"
  ],
  wide: [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ]
}, dayValues$1f = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنـ", "ثلا", "أربـ", "خميـ", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1f = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظهر",
    evening: "مساءاً",
    night: "ليلاً"
  }
}, formattingDayPeriodValues$$ = {
  narrow: {
    am: "ص",
    pm: "م",
    midnight: "ن",
    noon: "ظ",
    morning: "في الصباح",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "في الصباح",
    afternoon: "بعد الظهر",
    evening: "في المساء",
    night: "في الليل"
  },
  wide: {
    am: "ص",
    pm: "م",
    midnight: "نصف الليل",
    noon: "ظهر",
    morning: "صباحاً",
    afternoon: "بعد الظـهر",
    evening: "في المساء",
    night: "في الليل"
  }
}, ordinalNumber$1f = (u) => String(u), localize$1f = {
  ordinalNumber: ordinalNumber$1f,
  era: buildLocalizeFn({
    values: eraValues$1f,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1f,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1f,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1f,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1f,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$$,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1e = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$1e = /\d+/i, matchEraPatterns$1e = {
  narrow: /^(ق|ب)/i,
  abbreviated: /^(ق\.?\s?م\.?|ق\.?\s?م\.?\s?|a\.?\s?d\.?|c\.?\s?)/i,
  wide: /^(قبل الميلاد|قبل الميلاد|بعد الميلاد|بعد الميلاد)/i
}, parseEraPatterns$1e = {
  any: [/^قبل/i, /^بعد/i]
}, matchQuarterPatterns$1e = {
  narrow: /^[1234]/i,
  abbreviated: /^ر[1234]/i,
  wide: /^الربع [1234]/i
}, parseQuarterPatterns$1e = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1e = {
  narrow: /^[يفمأمسند]/i,
  abbreviated: /^(ين|ف|مار|أب|ماي|يون|يول|أغ|س|أك|ن|د)/i,
  wide: /^(ين|ف|مار|أب|ماي|يون|يول|أغ|س|أك|ن|د)/i
}, parseMonthPatterns$1e = {
  narrow: [
    /^ي/i,
    /^ف/i,
    /^م/i,
    /^أ/i,
    /^م/i,
    /^ي/i,
    /^ي/i,
    /^أ/i,
    /^س/i,
    /^أ/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^ين/i,
    /^ف/i,
    /^مار/i,
    /^أب/i,
    /^ماي/i,
    /^يون/i,
    /^يول/i,
    /^أغ/i,
    /^س/i,
    /^أك/i,
    /^ن/i,
    /^د/i
  ]
}, matchDayPatterns$1e = {
  narrow: /^[حنثرخجس]/i,
  short: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  abbreviated: /^(أحد|اثن|ثلا|أرب|خمي|جمعة|سبت)/i,
  wide: /^(الأحد|الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/i
}, parseDayPatterns$1e = {
  narrow: [/^ح/i, /^ن/i, /^ث/i, /^ر/i, /^خ/i, /^ج/i, /^س/i],
  wide: [
    /^الأحد/i,
    /^الاثنين/i,
    /^الثلاثاء/i,
    /^الأربعاء/i,
    /^الخميس/i,
    /^الجمعة/i,
    /^السبت/i
  ],
  any: [/^أح/i, /^اث/i, /^ث/i, /^أر/i, /^خ/i, /^ج/i, /^س/i]
}, matchDayPeriodPatterns$1e = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, parseDayPeriodPatterns$1e = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, match$1f = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1e,
    parsePattern: parseOrdinalNumberPattern$1e,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1e,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1e,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1e,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1e,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1e,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1e,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1e,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1e,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1e,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1e,
    defaultParseWidth: "any"
  })
}, arSA = {
  code: "ar-SA",
  formatDistance: formatDistance$1f,
  formatLong: formatLong$1n,
  formatRelative: formatRelative$1f,
  localize: localize$1f,
  match: match$1f,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1d = {
  lessThanXSeconds: {
    one: "أقل من ثانية",
    two: "أقل من زوز ثواني",
    threeToTen: "أقل من {{count}} ثواني",
    other: "أقل من {{count}} ثانية"
  },
  xSeconds: {
    one: "ثانية",
    two: "زوز ثواني",
    threeToTen: "{{count}} ثواني",
    other: "{{count}} ثانية"
  },
  halfAMinute: "نص دقيقة",
  lessThanXMinutes: {
    one: "أقل من دقيقة",
    two: "أقل من دقيقتين",
    threeToTen: "أقل من {{count}} دقايق",
    other: "أقل من {{count}} دقيقة"
  },
  xMinutes: {
    one: "دقيقة",
    two: "دقيقتين",
    threeToTen: "{{count}} دقايق",
    other: "{{count}} دقيقة"
  },
  aboutXHours: {
    one: "ساعة تقريب",
    two: "ساعتين تقريب",
    threeToTen: "{{count}} سوايع تقريب",
    other: "{{count}} ساعة تقريب"
  },
  xHours: {
    one: "ساعة",
    two: "ساعتين",
    threeToTen: "{{count}} سوايع",
    other: "{{count}} ساعة"
  },
  xDays: {
    one: "نهار",
    two: "نهارين",
    threeToTen: "{{count}} أيام",
    other: "{{count}} يوم"
  },
  aboutXWeeks: {
    one: "جمعة تقريب",
    two: "جمعتين تقريب",
    threeToTen: "{{count}} جماع تقريب",
    other: "{{count}} جمعة تقريب"
  },
  xWeeks: {
    one: "جمعة",
    two: "جمعتين",
    threeToTen: "{{count}} جماع",
    other: "{{count}} جمعة"
  },
  aboutXMonths: {
    one: "شهر تقريب",
    two: "شهرين تقريب",
    threeToTen: "{{count}} أشهرة تقريب",
    other: "{{count}} شهر تقريب"
  },
  xMonths: {
    one: "شهر",
    two: "شهرين",
    threeToTen: "{{count}} أشهرة",
    other: "{{count}} شهر"
  },
  aboutXYears: {
    one: "عام تقريب",
    two: "عامين تقريب",
    threeToTen: "{{count}} أعوام تقريب",
    other: "{{count}} عام تقريب"
  },
  xYears: {
    one: "عام",
    two: "عامين",
    threeToTen: "{{count}} أعوام",
    other: "{{count}} عام"
  },
  overXYears: {
    one: "أكثر من عام",
    two: "أكثر من عامين",
    threeToTen: "أكثر من {{count}} أعوام",
    other: "أكثر من {{count}} عام"
  },
  almostXYears: {
    one: "عام تقريب",
    two: "عامين تقريب",
    threeToTen: "{{count}} أعوام تقريب",
    other: "{{count}} عام تقريب"
  }
}, formatDistance$1e = (u, l, f) => {
  const p = formatDistanceLocale$1d[u];
  let m;
  return typeof p == "string" ? m = p : l === 1 ? m = p.one : l === 2 ? m = p.two : l <= 10 ? m = p.threeToTen.replace("{{count}}", String(l)) : m = p.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "في " + m : "عندو " + m : m;
}, dateFormats$1m = {
  full: "EEEE، do MMMM y",
  long: "do MMMM y",
  medium: "d MMM y",
  short: "dd/MM/yyyy"
}, timeFormats$1m = {
  full: "HH:mm:ss",
  long: "HH:mm:ss",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1m = {
  full: "{{date}} 'مع' {{time}}",
  long: "{{date}} 'مع' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1m = {
  date: buildFormatLongFn({
    formats: dateFormats$1m,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1m,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1m,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1e = {
  lastWeek: "eeee 'إلي فات مع' p",
  yesterday: "'البارح مع' p",
  today: "'اليوم مع' p",
  tomorrow: "'غدوة مع' p",
  nextWeek: "eeee 'الجمعة الجاية مع' p 'نهار'",
  other: "P"
}, formatRelative$1e = (u) => formatRelativeLocale$1e[u], eraValues$1e = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل الميلاد", "بعد الميلاد"]
}, quarterValues$1e = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ر1", "ر2", "ر3", "ر4"],
  wide: ["الربع الأول", "الربع الثاني", "الربع الثالث", "الربع الرابع"]
}, monthValues$1e = {
  narrow: ["د", "ن", "أ", "س", "أ", "ج", "ج", "م", "أ", "م", "ف", "ج"],
  abbreviated: [
    "جانفي",
    "فيفري",
    "مارس",
    "أفريل",
    "ماي",
    "جوان",
    "جويلية",
    "أوت",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ],
  wide: [
    "جانفي",
    "فيفري",
    "مارس",
    "أفريل",
    "ماي",
    "جوان",
    "جويلية",
    "أوت",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
  ]
}, dayValues$1e = {
  narrow: ["ح", "ن", "ث", "ر", "خ", "ج", "س"],
  short: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  abbreviated: ["أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"],
  wide: [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
  ]
}, dayPeriodValues$1e = {
  narrow: {
    am: "ص",
    pm: "ع",
    morning: "الصباح",
    noon: "القايلة",
    afternoon: "بعد القايلة",
    evening: "العشية",
    night: "الليل",
    midnight: "نص الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "ع",
    morning: "الصباح",
    noon: "القايلة",
    afternoon: "بعد القايلة",
    evening: "العشية",
    night: "الليل",
    midnight: "نص الليل"
  },
  wide: {
    am: "ص",
    pm: "ع",
    morning: "الصباح",
    noon: "القايلة",
    afternoon: "بعد القايلة",
    evening: "العشية",
    night: "الليل",
    midnight: "نص الليل"
  }
}, formattingDayPeriodValues$_ = {
  narrow: {
    am: "ص",
    pm: "ع",
    morning: "في الصباح",
    noon: "في القايلة",
    afternoon: "بعد القايلة",
    evening: "في العشية",
    night: "في الليل",
    midnight: "نص الليل"
  },
  abbreviated: {
    am: "ص",
    pm: "ع",
    morning: "في الصباح",
    noon: "في القايلة",
    afternoon: "بعد القايلة",
    evening: "في العشية",
    night: "في الليل",
    midnight: "نص الليل"
  },
  wide: {
    am: "ص",
    pm: "ع",
    morning: "في الصباح",
    noon: "في القايلة",
    afternoon: "بعد القايلة",
    evening: "في العشية",
    night: "في الليل",
    midnight: "نص الليل"
  }
}, ordinalNumber$1e = (u) => String(u), localize$1e = {
  ordinalNumber: ordinalNumber$1e,
  era: buildLocalizeFn({
    values: eraValues$1e,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1e,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1e,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1e,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1e,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$_,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1d = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$1d = /\d+/i, matchEraPatterns$1d = {
  narrow: /[قب]/,
  abbreviated: /[قب]\.م\./,
  wide: /(قبل|بعد) الميلاد/
}, parseEraPatterns$1d = {
  any: [/قبل/, /بعد/]
}, matchQuarterPatterns$1d = {
  narrow: /^[1234]/i,
  abbreviated: /ر[1234]/,
  wide: /الربع (الأول|الثاني|الثالث|الرابع)/
}, parseQuarterPatterns$1d = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1d = {
  narrow: /^[جفمأسند]/,
  abbreviated: /^(جانفي|فيفري|مارس|أفريل|ماي|جوان|جويلية|أوت|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/,
  wide: /^(جانفي|فيفري|مارس|أفريل|ماي|جوان|جويلية|أوت|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/
}, parseMonthPatterns$1d = {
  narrow: [
    /^ج/i,
    /^ف/i,
    /^م/i,
    /^أ/i,
    /^م/i,
    /^ج/i,
    /^ج/i,
    /^أ/i,
    /^س/i,
    /^أ/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^جانفي/i,
    /^فيفري/i,
    /^مارس/i,
    /^أفريل/i,
    /^ماي/i,
    /^جوان/i,
    /^جويلية/i,
    /^أوت/i,
    /^سبتمبر/i,
    /^أكتوبر/i,
    /^نوفمبر/i,
    /^ديسمبر/i
  ]
}, matchDayPatterns$1d = {
  narrow: /^[حنثرخجس]/i,
  short: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  abbreviated: /^(أحد|اثنين|ثلاثاء|أربعاء|خميس|جمعة|سبت)/i,
  wide: /^(الأحد|الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت)/i
}, parseDayPatterns$1d = {
  narrow: [/^ح/i, /^ن/i, /^ث/i, /^ر/i, /^خ/i, /^ج/i, /^س/i],
  wide: [
    /^الأحد/i,
    /^الاثنين/i,
    /^الثلاثاء/i,
    /^الأربعاء/i,
    /^الخميس/i,
    /^الجمعة/i,
    /^السبت/i
  ],
  any: [/^أح/i, /^اث/i, /^ث/i, /^أر/i, /^خ/i, /^ج/i, /^س/i]
}, matchDayPeriodPatterns$1d = {
  narrow: /^(ص|ع|ن ل|ل|(في|مع) (صباح|قايلة|عشية|ليل))/,
  any: /^([صع]|نص الليل|قايلة|(في|مع) (صباح|قايلة|عشية|ليل))/
}, parseDayPeriodPatterns$1d = {
  any: {
    am: /^ص/,
    pm: /^ع/,
    midnight: /نص الليل/,
    noon: /قايلة/,
    afternoon: /بعد القايلة/,
    morning: /صباح/,
    evening: /عشية/,
    night: /ليل/
  }
}, match$1e = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1d,
    parsePattern: parseOrdinalNumberPattern$1d,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1d,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1d,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1d,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1d,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1d,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1d,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1d,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1d,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1d,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1d,
    defaultParseWidth: "any"
  })
}, arTN = {
  code: "ar-TN",
  formatDistance: formatDistance$1e,
  formatLong: formatLong$1m,
  formatRelative: formatRelative$1e,
  localize: localize$1e,
  match: match$1e,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$1c = {
  lessThanXSeconds: {
    one: "bir saniyədən az",
    other: "{{count}} bir saniyədən az"
  },
  xSeconds: {
    one: "1 saniyə",
    other: "{{count}} saniyə"
  },
  halfAMinute: "yarım dəqiqə",
  lessThanXMinutes: {
    one: "bir dəqiqədən az",
    other: "{{count}} bir dəqiqədən az"
  },
  xMinutes: {
    one: "bir dəqiqə",
    other: "{{count}} dəqiqə"
  },
  aboutXHours: {
    one: "təxminən 1 saat",
    other: "təxminən {{count}} saat"
  },
  xHours: {
    one: "1 saat",
    other: "{{count}} saat"
  },
  xDays: {
    one: "1 gün",
    other: "{{count}} gün"
  },
  aboutXWeeks: {
    one: "təxminən 1 həftə",
    other: "təxminən {{count}} həftə"
  },
  xWeeks: {
    one: "1 həftə",
    other: "{{count}} həftə"
  },
  aboutXMonths: {
    one: "təxminən 1 ay",
    other: "təxminən {{count}} ay"
  },
  xMonths: {
    one: "1 ay",
    other: "{{count}} ay"
  },
  aboutXYears: {
    one: "təxminən 1 il",
    other: "təxminən {{count}} il"
  },
  xYears: {
    one: "1 il",
    other: "{{count}} il"
  },
  overXYears: {
    one: "1 ildən çox",
    other: "{{count}} ildən çox"
  },
  almostXYears: {
    one: "demək olar ki 1 il",
    other: "demək olar ki {{count}} il"
  }
}, formatDistance$1d = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$1c[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? p + " sonra" : p + " əvvəl" : p;
}, dateFormats$1l = {
  full: "EEEE, do MMMM y 'il'",
  long: "do MMMM y 'il'",
  medium: "d MMM y 'il'",
  short: "dd.MM.yyyy"
}, timeFormats$1l = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$1l = {
  full: "{{date}} {{time}} - 'də'",
  long: "{{date}} {{time}} - 'də'",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1l = {
  date: buildFormatLongFn({
    formats: dateFormats$1l,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1l,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1l,
    defaultWidth: "full"
  })
}, formatRelativeLocale$1d = {
  lastWeek: "'sonuncu' eeee p -'də'",
  yesterday: "'dünən' p -'də'",
  today: "'bugün' p -'də'",
  tomorrow: "'sabah' p -'də'",
  nextWeek: "eeee p -'də'",
  other: "P"
}, formatRelative$1d = (u, l, f, p) => formatRelativeLocale$1d[u], eraValues$1d = {
  narrow: ["e.ə", "b.e"],
  abbreviated: ["e.ə", "b.e"],
  wide: ["eramızdan əvvəl", "bizim era"]
}, quarterValues$1d = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: ["1ci kvartal", "2ci kvartal", "3cü kvartal", "4cü kvartal"]
}, monthValues$1d = {
  narrow: ["Y", "F", "M", "A", "M", "İ", "İ", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Yan",
    "Fev",
    "Mar",
    "Apr",
    "May",
    "İyun",
    "İyul",
    "Avq",
    "Sen",
    "Okt",
    "Noy",
    "Dek"
  ],
  wide: [
    "Yanvar",
    "Fevral",
    "Mart",
    "Aprel",
    "May",
    "İyun",
    "İyul",
    "Avqust",
    "Sentyabr",
    "Oktyabr",
    "Noyabr",
    "Dekabr"
  ]
}, dayValues$1d = {
  narrow: ["B.", "B.e", "Ç.a", "Ç.", "C.a", "C.", "Ş."],
  short: ["B.", "B.e", "Ç.a", "Ç.", "C.a", "C.", "Ş."],
  abbreviated: ["Baz", "Baz.e", "Çər.a", "Çər", "Cüm.a", "Cüm", "Şə"],
  wide: [
    "Bazar",
    "Bazar ertəsi",
    "Çərşənbə axşamı",
    "Çərşənbə",
    "Cümə axşamı",
    "Cümə",
    "Şənbə"
  ]
}, dayPeriodValues$1d = {
  narrow: {
    am: "am",
    pm: "pm",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  }
}, formattingDayPeriodValues$Z = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "gecəyarı",
    noon: "gün",
    morning: "səhər",
    afternoon: "gündüz",
    evening: "axşam",
    night: "gecə"
  }
}, suffixes$1 = {
  1: "-inci",
  5: "-inci",
  8: "-inci",
  70: "-inci",
  80: "-inci",
  2: "-nci",
  7: "-nci",
  20: "-nci",
  50: "-nci",
  3: "-üncü",
  4: "-üncü",
  100: "-üncü",
  6: "-ncı",
  9: "-uncu",
  10: "-uncu",
  30: "-uncu",
  60: "-ıncı",
  90: "-ıncı"
}, getSuffix = (u) => {
  if (u === 0)
    return u + "-ıncı";
  const l = u % 10, f = u % 100 - l, p = u >= 100 ? 100 : null;
  return suffixes$1[l] ? suffixes$1[l] : suffixes$1[f] ? suffixes$1[f] : p !== null ? suffixes$1[p] : "";
}, ordinalNumber$1d = (u, l) => {
  const f = Number(u), p = getSuffix(f);
  return f + p;
}, localize$1d = {
  ordinalNumber: ordinalNumber$1d,
  era: buildLocalizeFn({
    values: eraValues$1d,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1d,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1d,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1d,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1d,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$Z,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1c = /^(\d+)(-?(ci|inci|nci|uncu|üncü|ncı))?/i, parseOrdinalNumberPattern$1c = /\d+/i, matchEraPatterns$1c = {
  narrow: /^(b|a)$/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)$/i,
  wide: /^(bizim eradan əvvəl|bizim era)$/i
}, parseEraPatterns$1c = {
  any: [/^b$/i, /^(a|c)$/i]
}, matchQuarterPatterns$1c = {
  narrow: /^[1234]$/i,
  abbreviated: /^K[1234]$/i,
  wide: /^[1234](ci)? kvartal$/i
}, parseQuarterPatterns$1c = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1c = {
  narrow: /^[(?-i)yfmaisond]$/i,
  abbreviated: /^(Yan|Fev|Mar|Apr|May|İyun|İyul|Avq|Sen|Okt|Noy|Dek)$/i,
  wide: /^(Yanvar|Fevral|Mart|Aprel|May|İyun|İyul|Avgust|Sentyabr|Oktyabr|Noyabr|Dekabr)$/i
}, parseMonthPatterns$1c = {
  narrow: [
    /^[(?-i)y]$/i,
    /^[(?-i)f]$/i,
    /^[(?-i)m]$/i,
    /^[(?-i)a]$/i,
    /^[(?-i)m]$/i,
    /^[(?-i)i]$/i,
    /^[(?-i)i]$/i,
    /^[(?-i)a]$/i,
    /^[(?-i)s]$/i,
    /^[(?-i)o]$/i,
    /^[(?-i)n]$/i,
    /^[(?-i)d]$/i
  ],
  abbreviated: [
    /^Yan$/i,
    /^Fev$/i,
    /^Mar$/i,
    /^Apr$/i,
    /^May$/i,
    /^İyun$/i,
    /^İyul$/i,
    /^Avg$/i,
    /^Sen$/i,
    /^Okt$/i,
    /^Noy$/i,
    /^Dek$/i
  ],
  wide: [
    /^Yanvar$/i,
    /^Fevral$/i,
    /^Mart$/i,
    /^Aprel$/i,
    /^May$/i,
    /^İyun$/i,
    /^İyul$/i,
    /^Avgust$/i,
    /^Sentyabr$/i,
    /^Oktyabr$/i,
    /^Noyabr$/i,
    /^Dekabr$/i
  ]
}, matchDayPatterns$1c = {
  narrow: /^(B\.|B\.e|Ç\.a|Ç\.|C\.a|C\.|Ş\.)$/i,
  short: /^(B\.|B\.e|Ç\.a|Ç\.|C\.a|C\.|Ş\.)$/i,
  abbreviated: /^(Baz\.e|Çər|Çər\.a|Cüm|Cüm\.a|Şə)$/i,
  wide: /^(Bazar|Bazar ertəsi|Çərşənbə axşamı|Çərşənbə|Cümə axşamı|Cümə|Şənbə)$/i
}, parseDayPatterns$1c = {
  narrow: [
    /^B\.$/i,
    /^B\.e$/i,
    /^Ç\.a$/i,
    /^Ç\.$/i,
    /^C\.a$/i,
    /^C\.$/i,
    /^Ş\.$/i
  ],
  abbreviated: [
    /^Baz$/i,
    /^Baz\.e$/i,
    /^Çər\.a$/i,
    /^Çər$/i,
    /^Cüm\.a$/i,
    /^Cüm$/i,
    /^Şə$/i
  ],
  wide: [
    /^Bazar$/i,
    /^Bazar ertəsi$/i,
    /^Çərşənbə axşamı$/i,
    /^Çərşənbə$/i,
    /^Cümə axşamı$/i,
    /^Cümə$/i,
    /^Şənbə$/i
  ],
  any: [
    /^B\.$/i,
    /^B\.e$/i,
    /^Ç\.a$/i,
    /^Ç\.$/i,
    /^C\.a$/i,
    /^C\.$/i,
    /^Ş\.$/i
  ]
}, matchDayPeriodPatterns$1c = {
  narrow: /^(a|p|gecəyarı|gün|səhər|gündüz|axşam|gecə)$/i,
  any: /^(am|pm|a\.m\.|p\.m\.|AM|PM|gecəyarı|gün|səhər|gündüz|axşam|gecə)$/i
}, parseDayPeriodPatterns$1c = {
  any: {
    am: /^a$/i,
    pm: /^p$/i,
    midnight: /^gecəyarı$/i,
    noon: /^gün$/i,
    morning: /səhər$/i,
    afternoon: /gündüz$/i,
    evening: /axşam$/i,
    night: /gecə$/i
  }
}, match$1d = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1c,
    parsePattern: parseOrdinalNumberPattern$1c,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1c,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1c,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1c,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1c,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1c,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1c,
    defaultParseWidth: "narrow"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1c,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1c,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1c,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$1c,
    defaultParseWidth: "any"
  })
}, az = {
  code: "az",
  formatDistance: formatDistance$1d,
  formatLong: formatLong$1l,
  formatRelative: formatRelative$1d,
  localize: localize$1d,
  match: match$1d,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
};
function declension$6(u, l) {
  if (u.one !== void 0 && l === 1)
    return u.one;
  const f = l % 10, p = l % 100;
  return f === 1 && p !== 11 ? u.singularNominative.replace("{{count}}", String(l)) : f >= 2 && f <= 4 && (p < 10 || p > 20) ? u.singularGenitive.replace("{{count}}", String(l)) : u.pluralGenitive.replace("{{count}}", String(l));
}
function buildLocalizeTokenFn$4(u) {
  return (l, f) => f && f.addSuffix ? f.comparison && f.comparison > 0 ? u.future ? declension$6(u.future, l) : "праз " + declension$6(u.regular, l) : u.past ? declension$6(u.past, l) : declension$6(u.regular, l) + " таму" : declension$6(u.regular, l);
}
const halfAMinute$1 = (u, l) => l && l.addSuffix ? l.comparison && l.comparison > 0 ? "праз паўхвіліны" : "паўхвіліны таму" : "паўхвіліны", formatDistanceLocale$1b = {
  lessThanXSeconds: buildLocalizeTokenFn$4({
    regular: {
      one: "менш за секунду",
      singularNominative: "менш за {{count}} секунду",
      singularGenitive: "менш за {{count}} секунды",
      pluralGenitive: "менш за {{count}} секунд"
    },
    future: {
      one: "менш, чым праз секунду",
      singularNominative: "менш, чым праз {{count}} секунду",
      singularGenitive: "менш, чым праз {{count}} секунды",
      pluralGenitive: "менш, чым праз {{count}} секунд"
    }
  }),
  xSeconds: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} секунда",
      singularGenitive: "{{count}} секунды",
      pluralGenitive: "{{count}} секунд"
    },
    past: {
      singularNominative: "{{count}} секунду таму",
      singularGenitive: "{{count}} секунды таму",
      pluralGenitive: "{{count}} секунд таму"
    },
    future: {
      singularNominative: "праз {{count}} секунду",
      singularGenitive: "праз {{count}} секунды",
      pluralGenitive: "праз {{count}} секунд"
    }
  }),
  halfAMinute: halfAMinute$1,
  lessThanXMinutes: buildLocalizeTokenFn$4({
    regular: {
      one: "менш за хвіліну",
      singularNominative: "менш за {{count}} хвіліну",
      singularGenitive: "менш за {{count}} хвіліны",
      pluralGenitive: "менш за {{count}} хвілін"
    },
    future: {
      one: "менш, чым праз хвіліну",
      singularNominative: "менш, чым праз {{count}} хвіліну",
      singularGenitive: "менш, чым праз {{count}} хвіліны",
      pluralGenitive: "менш, чым праз {{count}} хвілін"
    }
  }),
  xMinutes: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} хвіліна",
      singularGenitive: "{{count}} хвіліны",
      pluralGenitive: "{{count}} хвілін"
    },
    past: {
      singularNominative: "{{count}} хвіліну таму",
      singularGenitive: "{{count}} хвіліны таму",
      pluralGenitive: "{{count}} хвілін таму"
    },
    future: {
      singularNominative: "праз {{count}} хвіліну",
      singularGenitive: "праз {{count}} хвіліны",
      pluralGenitive: "праз {{count}} хвілін"
    }
  }),
  aboutXHours: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "каля {{count}} гадзіны",
      singularGenitive: "каля {{count}} гадзін",
      pluralGenitive: "каля {{count}} гадзін"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} гадзіну",
      singularGenitive: "прыблізна праз {{count}} гадзіны",
      pluralGenitive: "прыблізна праз {{count}} гадзін"
    }
  }),
  xHours: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} гадзіна",
      singularGenitive: "{{count}} гадзіны",
      pluralGenitive: "{{count}} гадзін"
    },
    past: {
      singularNominative: "{{count}} гадзіну таму",
      singularGenitive: "{{count}} гадзіны таму",
      pluralGenitive: "{{count}} гадзін таму"
    },
    future: {
      singularNominative: "праз {{count}} гадзіну",
      singularGenitive: "праз {{count}} гадзіны",
      pluralGenitive: "праз {{count}} гадзін"
    }
  }),
  xDays: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} дзень",
      singularGenitive: "{{count}} дні",
      pluralGenitive: "{{count}} дзён"
    }
  }),
  aboutXWeeks: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "каля {{count}} тыдні",
      singularGenitive: "каля {{count}} тыдняў",
      pluralGenitive: "каля {{count}} тыдняў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} тыдзень",
      singularGenitive: "прыблізна праз {{count}} тыдні",
      pluralGenitive: "прыблізна праз {{count}} тыдняў"
    }
  }),
  xWeeks: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} тыдзень",
      singularGenitive: "{{count}} тыдні",
      pluralGenitive: "{{count}} тыдняў"
    }
  }),
  aboutXMonths: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "каля {{count}} месяца",
      singularGenitive: "каля {{count}} месяцаў",
      pluralGenitive: "каля {{count}} месяцаў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} месяц",
      singularGenitive: "прыблізна праз {{count}} месяцы",
      pluralGenitive: "прыблізна праз {{count}} месяцаў"
    }
  }),
  xMonths: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} месяц",
      singularGenitive: "{{count}} месяцы",
      pluralGenitive: "{{count}} месяцаў"
    }
  }),
  aboutXYears: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "каля {{count}} года",
      singularGenitive: "каля {{count}} гадоў",
      pluralGenitive: "каля {{count}} гадоў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} год",
      singularGenitive: "прыблізна праз {{count}} гады",
      pluralGenitive: "прыблізна праз {{count}} гадоў"
    }
  }),
  xYears: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "{{count}} год",
      singularGenitive: "{{count}} гады",
      pluralGenitive: "{{count}} гадоў"
    }
  }),
  overXYears: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "больш за {{count}} год",
      singularGenitive: "больш за {{count}} гады",
      pluralGenitive: "больш за {{count}} гадоў"
    },
    future: {
      singularNominative: "больш, чым праз {{count}} год",
      singularGenitive: "больш, чым праз {{count}} гады",
      pluralGenitive: "больш, чым праз {{count}} гадоў"
    }
  }),
  almostXYears: buildLocalizeTokenFn$4({
    regular: {
      singularNominative: "амаль {{count}} год",
      singularGenitive: "амаль {{count}} гады",
      pluralGenitive: "амаль {{count}} гадоў"
    },
    future: {
      singularNominative: "амаль праз {{count}} год",
      singularGenitive: "амаль праз {{count}} гады",
      pluralGenitive: "амаль праз {{count}} гадоў"
    }
  })
}, formatDistance$1c = (u, l, f) => (f = f || {}, formatDistanceLocale$1b[u](l, f)), dateFormats$1k = {
  full: "EEEE, d MMMM y 'г.'",
  long: "d MMMM y 'г.'",
  medium: "d MMM y 'г.'",
  short: "dd.MM.y"
}, timeFormats$1k = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$1k = {
  any: "{{date}}, {{time}}"
}, formatLong$1k = {
  date: buildFormatLongFn({
    formats: dateFormats$1k,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1k,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1k,
    defaultWidth: "any"
  })
}, constructFromSymbol = /* @__PURE__ */ Symbol.for("constructDateFrom");
function constructFrom(u, l) {
  return typeof u == "function" ? u(l) : u && typeof u == "object" && constructFromSymbol in u ? u[constructFromSymbol](l) : u instanceof Date ? new u.constructor(l) : new Date(l);
}
function normalizeDates(u, ...l) {
  const f = constructFrom.bind(
    null,
    u || l.find((p) => typeof p == "object")
  );
  return l.map(f);
}
let defaultOptions$1 = {};
function getDefaultOptions$1() {
  return defaultOptions$1;
}
function toDate(u, l) {
  return constructFrom(l || u, u);
}
function startOfWeek(u, l) {
  const f = getDefaultOptions$1(), p = l?.weekStartsOn ?? l?.locale?.options?.weekStartsOn ?? f.weekStartsOn ?? f.locale?.options?.weekStartsOn ?? 0, m = toDate(u, l?.in), b = m.getDay(), y = (b < p ? 7 : 0) + b - p;
  return m.setDate(m.getDate() - y), m.setHours(0, 0, 0, 0), m;
}
function isSameWeek(u, l, f) {
  const [p, m] = normalizeDates(
    f?.in,
    u,
    l
  );
  return +startOfWeek(p, f) == +startOfWeek(m, f);
}
const accusativeWeekdays$7 = [
  "нядзелю",
  "панядзелак",
  "аўторак",
  "сераду",
  "чацвер",
  "пятніцу",
  "суботу"
];
function lastWeek$8(u) {
  const l = accusativeWeekdays$7[u];
  switch (u) {
    case 0:
    case 3:
    case 5:
    case 6:
      return "'у мінулую " + l + " а' p";
    case 1:
    case 2:
    case 4:
      return "'у мінулы " + l + " а' p";
  }
}
function thisWeek$8(u) {
  return "'у " + accusativeWeekdays$7[u] + " а' p";
}
function nextWeek$8(u) {
  const l = accusativeWeekdays$7[u];
  switch (u) {
    case 0:
    case 3:
    case 5:
    case 6:
      return "'у наступную " + l + " а' p";
    case 1:
    case 2:
    case 4:
      return "'у наступны " + l + " а' p";
  }
}
const lastWeekFormat$2 = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$8(m) : lastWeek$8(m);
}, nextWeekFormat$2 = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$8(m) : nextWeek$8(m);
}, formatRelativeLocale$1c = {
  lastWeek: lastWeekFormat$2,
  yesterday: "'учора а' p",
  today: "'сёння а' p",
  tomorrow: "'заўтра а' p",
  nextWeek: nextWeekFormat$2,
  other: "P"
}, formatRelative$1c = (u, l, f, p) => {
  const m = formatRelativeLocale$1c[u];
  return typeof m == "function" ? m(l, f, p) : m;
}, eraValues$1c = {
  narrow: ["да н.э.", "н.э."],
  abbreviated: ["да н. э.", "н. э."],
  wide: ["да нашай эры", "нашай эры"]
}, quarterValues$1c = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1-ы кв.", "2-і кв.", "3-і кв.", "4-ы кв."],
  wide: ["1-ы квартал", "2-і квартал", "3-і квартал", "4-ы квартал"]
}, monthValues$1c = {
  narrow: ["С", "Л", "С", "К", "М", "Ч", "Л", "Ж", "В", "К", "Л", "С"],
  abbreviated: [
    "студз.",
    "лют.",
    "сак.",
    "крас.",
    "май",
    "чэрв.",
    "ліп.",
    "жн.",
    "вер.",
    "кастр.",
    "ліст.",
    "снеж."
  ],
  wide: [
    "студзень",
    "люты",
    "сакавік",
    "красавік",
    "май",
    "чэрвень",
    "ліпень",
    "жнівень",
    "верасень",
    "кастрычнік",
    "лістапад",
    "снежань"
  ]
}, formattingMonthValues$i = {
  narrow: ["С", "Л", "С", "К", "М", "Ч", "Л", "Ж", "В", "К", "Л", "С"],
  abbreviated: [
    "студз.",
    "лют.",
    "сак.",
    "крас.",
    "мая",
    "чэрв.",
    "ліп.",
    "жн.",
    "вер.",
    "кастр.",
    "ліст.",
    "снеж."
  ],
  wide: [
    "студзеня",
    "лютага",
    "сакавіка",
    "красавіка",
    "мая",
    "чэрвеня",
    "ліпеня",
    "жніўня",
    "верасня",
    "кастрычніка",
    "лістапада",
    "снежня"
  ]
}, dayValues$1c = {
  narrow: ["Н", "П", "А", "С", "Ч", "П", "С"],
  short: ["нд", "пн", "аў", "ср", "чц", "пт", "сб"],
  abbreviated: ["нядз", "пан", "аўт", "сер", "чац", "пят", "суб"],
  wide: [
    "нядзеля",
    "панядзелак",
    "аўторак",
    "серада",
    "чацвер",
    "пятніца",
    "субота"
  ]
}, dayPeriodValues$1c = {
  narrow: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дзень",
    evening: "веч.",
    night: "ноч"
  },
  abbreviated: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дзень",
    evening: "веч.",
    night: "ноч"
  },
  wide: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўнач",
    noon: "поўдзень",
    morning: "раніца",
    afternoon: "дзень",
    evening: "вечар",
    night: "ноч"
  }
}, formattingDayPeriodValues$Y = {
  narrow: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дня",
    evening: "веч.",
    night: "ночы"
  },
  abbreviated: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дня",
    evening: "веч.",
    night: "ночы"
  },
  wide: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўнач",
    noon: "поўдзень",
    morning: "раніцы",
    afternoon: "дня",
    evening: "вечара",
    night: "ночы"
  }
}, ordinalNumber$1c = (u, l) => {
  const f = String(l?.unit), p = Number(u);
  let m;
  return f === "date" ? m = "-га" : f === "hour" || f === "minute" || f === "second" ? m = "-я" : m = (p % 10 === 2 || p % 10 === 3) && p % 100 !== 12 && p % 100 !== 13 ? "-і" : "-ы", p + m;
}, localize$1c = {
  ordinalNumber: ordinalNumber$1c,
  era: buildLocalizeFn({
    values: eraValues$1c,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1c,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1c,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$i,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1c,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1c,
    defaultWidth: "any",
    formattingValues: formattingDayPeriodValues$Y,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1b = /^(\d+)(-?(е|я|га|і|ы|ае|ая|яя|шы|гі|ці|ты|мы))?/i, parseOrdinalNumberPattern$1b = /\d+/i, matchEraPatterns$1b = {
  narrow: /^((да )?н\.?\s?э\.?)/i,
  abbreviated: /^((да )?н\.?\s?э\.?)/i,
  wide: /^(да нашай эры|нашай эры|наша эра)/i
}, parseEraPatterns$1b = {
  any: [/^д/i, /^н/i]
}, matchQuarterPatterns$1b = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234](-?[ыі]?)? кв.?/i,
  wide: /^[1234](-?[ыі]?)? квартал/i
}, parseQuarterPatterns$1b = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1b = {
  narrow: /^[слкмчжв]/i,
  abbreviated: /^(студз|лют|сак|крас|ма[йя]|чэрв|ліп|жн|вер|кастр|ліст|снеж)\.?/i,
  wide: /^(студзен[ья]|лют(ы|ага)|сакавіка?|красавіка?|ма[йя]|чэрвен[ья]|ліпен[ья]|жні(вень|ўня)|верас(ень|ня)|кастрычніка?|лістапада?|снеж(ань|ня))/i
}, parseMonthPatterns$1b = {
  narrow: [
    /^с/i,
    /^л/i,
    /^с/i,
    /^к/i,
    /^м/i,
    /^ч/i,
    /^л/i,
    /^ж/i,
    /^в/i,
    /^к/i,
    /^л/i,
    /^с/i
  ],
  any: [
    /^ст/i,
    /^лю/i,
    /^са/i,
    /^кр/i,
    /^ма/i,
    /^ч/i,
    /^ліп/i,
    /^ж/i,
    /^в/i,
    /^ка/i,
    /^ліс/i,
    /^сн/i
  ]
}, matchDayPatterns$1b = {
  narrow: /^[нпасч]/i,
  short: /^(нд|ня|пн|па|аў|ат|ср|се|чц|ча|пт|пя|сб|су)\.?/i,
  abbreviated: /^(нядз?|ндз|пнд|пан|аўт|срд|сер|чцв|чац|птн|пят|суб).?/i,
  wide: /^(нядзел[яі]|панядзел(ак|ка)|аўтор(ак|ка)|серад[аы]|чацв(ер|ярга)|пятніц[аы]|субот[аы])/i
}, parseDayPatterns$1b = {
  narrow: [/^н/i, /^п/i, /^а/i, /^с/i, /^ч/i, /^п/i, /^с/i],
  any: [/^н/i, /^п[ан]/i, /^а/i, /^с[ер]/i, /^ч/i, /^п[ят]/i, /^с[уб]/i]
}, matchDayPeriodPatterns$1b = {
  narrow: /^([дп]п|поўн\.?|поўд\.?|ран\.?|дзень|дня|веч\.?|ночы?)/i,
  abbreviated: /^([дп]п|поўн\.?|поўд\.?|ран\.?|дзень|дня|веч\.?|ночы?)/i,
  wide: /^([дп]п|поўнач|поўдзень|раніц[аы]|дзень|дня|вечара?|ночы?)/i
}, parseDayPeriodPatterns$1b = {
  any: {
    am: /^дп/i,
    pm: /^пп/i,
    midnight: /^поўн/i,
    noon: /^поўд/i,
    morning: /^р/i,
    afternoon: /^д[зн]/i,
    evening: /^в/i,
    night: /^н/i
  }
}, match$1c = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1b,
    parsePattern: parseOrdinalNumberPattern$1b,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1b,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1b,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1b,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1b,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1b,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1b,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1b,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1b,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1b,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$1b,
    defaultParseWidth: "any"
  })
}, be = {
  code: "be",
  formatDistance: formatDistance$1c,
  formatLong: formatLong$1k,
  formatRelative: formatRelative$1c,
  localize: localize$1c,
  match: match$1c,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
};
function declension$5(u, l) {
  if (u.one !== void 0 && l === 1)
    return u.one;
  const f = l % 10, p = l % 100;
  return f === 1 && p !== 11 ? u.singularNominative.replace("{{count}}", String(l)) : f >= 2 && f <= 4 && (p < 10 || p > 20) ? u.singularGenitive.replace("{{count}}", String(l)) : u.pluralGenitive.replace("{{count}}", String(l));
}
function buildLocalizeTokenFn$3(u) {
  return (l, f) => f && f.addSuffix ? f.comparison && f.comparison > 0 ? u.future ? declension$5(u.future, l) : "праз " + declension$5(u.regular, l) : u.past ? declension$5(u.past, l) : declension$5(u.regular, l) + " таму" : declension$5(u.regular, l);
}
const halfAMinute = (u, l) => l && l.addSuffix ? l.comparison && l.comparison > 0 ? "праз паўхвіліны" : "паўхвіліны таму" : "паўхвіліны", formatDistanceLocale$1a = {
  lessThanXSeconds: buildLocalizeTokenFn$3({
    regular: {
      one: "менш за секунду",
      singularNominative: "менш за {{count}} секунду",
      singularGenitive: "менш за {{count}} секунды",
      pluralGenitive: "менш за {{count}} секунд"
    },
    future: {
      one: "менш, чым праз секунду",
      singularNominative: "менш, чым праз {{count}} секунду",
      singularGenitive: "менш, чым праз {{count}} секунды",
      pluralGenitive: "менш, чым праз {{count}} секунд"
    }
  }),
  xSeconds: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} секунда",
      singularGenitive: "{{count}} секунды",
      pluralGenitive: "{{count}} секунд"
    },
    past: {
      singularNominative: "{{count}} секунду таму",
      singularGenitive: "{{count}} секунды таму",
      pluralGenitive: "{{count}} секунд таму"
    },
    future: {
      singularNominative: "праз {{count}} секунду",
      singularGenitive: "праз {{count}} секунды",
      pluralGenitive: "праз {{count}} секунд"
    }
  }),
  halfAMinute,
  lessThanXMinutes: buildLocalizeTokenFn$3({
    regular: {
      one: "менш за хвіліну",
      singularNominative: "менш за {{count}} хвіліну",
      singularGenitive: "менш за {{count}} хвіліны",
      pluralGenitive: "менш за {{count}} хвілін"
    },
    future: {
      one: "менш, чым праз хвіліну",
      singularNominative: "менш, чым праз {{count}} хвіліну",
      singularGenitive: "менш, чым праз {{count}} хвіліны",
      pluralGenitive: "менш, чым праз {{count}} хвілін"
    }
  }),
  xMinutes: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} хвіліна",
      singularGenitive: "{{count}} хвіліны",
      pluralGenitive: "{{count}} хвілін"
    },
    past: {
      singularNominative: "{{count}} хвіліну таму",
      singularGenitive: "{{count}} хвіліны таму",
      pluralGenitive: "{{count}} хвілін таму"
    },
    future: {
      singularNominative: "праз {{count}} хвіліну",
      singularGenitive: "праз {{count}} хвіліны",
      pluralGenitive: "праз {{count}} хвілін"
    }
  }),
  aboutXHours: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "каля {{count}} гадзіны",
      singularGenitive: "каля {{count}} гадзін",
      pluralGenitive: "каля {{count}} гадзін"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} гадзіну",
      singularGenitive: "прыблізна праз {{count}} гадзіны",
      pluralGenitive: "прыблізна праз {{count}} гадзін"
    }
  }),
  xHours: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} гадзіна",
      singularGenitive: "{{count}} гадзіны",
      pluralGenitive: "{{count}} гадзін"
    },
    past: {
      singularNominative: "{{count}} гадзіну таму",
      singularGenitive: "{{count}} гадзіны таму",
      pluralGenitive: "{{count}} гадзін таму"
    },
    future: {
      singularNominative: "праз {{count}} гадзіну",
      singularGenitive: "праз {{count}} гадзіны",
      pluralGenitive: "праз {{count}} гадзін"
    }
  }),
  xDays: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} дзень",
      singularGenitive: "{{count}} дні",
      pluralGenitive: "{{count}} дзён"
    }
  }),
  aboutXWeeks: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "каля {{count}} тыдні",
      singularGenitive: "каля {{count}} тыдняў",
      pluralGenitive: "каля {{count}} тыдняў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} тыдзень",
      singularGenitive: "прыблізна праз {{count}} тыдні",
      pluralGenitive: "прыблізна праз {{count}} тыдняў"
    }
  }),
  xWeeks: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} тыдзень",
      singularGenitive: "{{count}} тыдні",
      pluralGenitive: "{{count}} тыдняў"
    }
  }),
  aboutXMonths: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "каля {{count}} месяца",
      singularGenitive: "каля {{count}} месяцаў",
      pluralGenitive: "каля {{count}} месяцаў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} месяц",
      singularGenitive: "прыблізна праз {{count}} месяцы",
      pluralGenitive: "прыблізна праз {{count}} месяцаў"
    }
  }),
  xMonths: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} месяц",
      singularGenitive: "{{count}} месяцы",
      pluralGenitive: "{{count}} месяцаў"
    }
  }),
  aboutXYears: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "каля {{count}} года",
      singularGenitive: "каля {{count}} гадоў",
      pluralGenitive: "каля {{count}} гадоў"
    },
    future: {
      singularNominative: "прыблізна праз {{count}} год",
      singularGenitive: "прыблізна праз {{count}} гады",
      pluralGenitive: "прыблізна праз {{count}} гадоў"
    }
  }),
  xYears: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "{{count}} год",
      singularGenitive: "{{count}} гады",
      pluralGenitive: "{{count}} гадоў"
    }
  }),
  overXYears: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "больш за {{count}} год",
      singularGenitive: "больш за {{count}} гады",
      pluralGenitive: "больш за {{count}} гадоў"
    },
    future: {
      singularNominative: "больш, чым праз {{count}} год",
      singularGenitive: "больш, чым праз {{count}} гады",
      pluralGenitive: "больш, чым праз {{count}} гадоў"
    }
  }),
  almostXYears: buildLocalizeTokenFn$3({
    regular: {
      singularNominative: "амаль {{count}} год",
      singularGenitive: "амаль {{count}} гады",
      pluralGenitive: "амаль {{count}} гадоў"
    },
    future: {
      singularNominative: "амаль праз {{count}} год",
      singularGenitive: "амаль праз {{count}} гады",
      pluralGenitive: "амаль праз {{count}} гадоў"
    }
  })
}, formatDistance$1b = (u, l, f) => (f = f || {}, formatDistanceLocale$1a[u](l, f)), dateFormats$1j = {
  full: "EEEE, d MMMM y 'г.'",
  long: "d MMMM y 'г.'",
  medium: "d MMM y 'г.'",
  short: "dd.MM.y"
}, timeFormats$1j = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$1j = {
  any: "{{date}}, {{time}}"
}, formatLong$1j = {
  date: buildFormatLongFn({
    formats: dateFormats$1j,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1j,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1j,
    defaultWidth: "any"
  })
}, accusativeWeekdays$6 = [
  "нядзелю",
  "панядзелак",
  "аўторак",
  "сераду",
  "чацьвер",
  "пятніцу",
  "суботу"
];
function lastWeek$7(u) {
  const l = accusativeWeekdays$6[u];
  switch (u) {
    case 0:
    case 3:
    case 5:
    case 6:
      return "'у мінулую " + l + " а' p";
    case 1:
    case 2:
    case 4:
      return "'у мінулы " + l + " а' p";
  }
}
function thisWeek$7(u) {
  return "'у " + accusativeWeekdays$6[u] + " а' p";
}
function nextWeek$7(u) {
  const l = accusativeWeekdays$6[u];
  switch (u) {
    case 0:
    case 3:
    case 5:
    case 6:
      return "'у наступную " + l + " а' p";
    case 1:
    case 2:
    case 4:
      return "'у наступны " + l + " а' p";
  }
}
const lastWeekFormat$1 = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$7(m) : lastWeek$7(m);
}, nextWeekFormat$1 = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$7(m) : nextWeek$7(m);
}, formatRelativeLocale$1b = {
  lastWeek: lastWeekFormat$1,
  yesterday: "'учора а' p",
  today: "'сёньня а' p",
  tomorrow: "'заўтра а' p",
  nextWeek: nextWeekFormat$1,
  other: "P"
}, formatRelative$1b = (u, l, f, p) => {
  const m = formatRelativeLocale$1b[u];
  return typeof m == "function" ? m(l, f, p) : m;
}, eraValues$1b = {
  narrow: ["да н.э.", "н.э."],
  abbreviated: ["да н. э.", "н. э."],
  wide: ["да нашай эры", "нашай эры"]
}, quarterValues$1b = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1-ы кв.", "2-і кв.", "3-і кв.", "4-ы кв."],
  wide: ["1-ы квартал", "2-і квартал", "3-і квартал", "4-ы квартал"]
}, monthValues$1b = {
  narrow: ["С", "Л", "С", "К", "Т", "Ч", "Л", "Ж", "В", "К", "Л", "С"],
  abbreviated: [
    "студз.",
    "лют.",
    "сак.",
    "крас.",
    "трав.",
    "чэрв.",
    "ліп.",
    "жн.",
    "вер.",
    "кастр.",
    "ліст.",
    "сьнеж."
  ],
  wide: [
    "студзень",
    "люты",
    "сакавік",
    "красавік",
    "травень",
    "чэрвень",
    "ліпень",
    "жнівень",
    "верасень",
    "кастрычнік",
    "лістапад",
    "сьнежань"
  ]
}, formattingMonthValues$h = {
  narrow: ["С", "Л", "С", "К", "Т", "Ч", "Л", "Ж", "В", "К", "Л", "С"],
  abbreviated: [
    "студз.",
    "лют.",
    "сак.",
    "крас.",
    "трав.",
    "чэрв.",
    "ліп.",
    "жн.",
    "вер.",
    "кастр.",
    "ліст.",
    "сьнеж."
  ],
  wide: [
    "студзеня",
    "лютага",
    "сакавіка",
    "красавіка",
    "траўня",
    "чэрвеня",
    "ліпеня",
    "жніўня",
    "верасня",
    "кастрычніка",
    "лістапада",
    "сьнежня"
  ]
}, dayValues$1b = {
  narrow: ["Н", "П", "А", "С", "Ч", "П", "С"],
  short: ["нд", "пн", "аў", "ср", "чц", "пт", "сб"],
  abbreviated: ["нядз", "пан", "аўт", "сер", "чаць", "пят", "суб"],
  wide: [
    "нядзеля",
    "панядзелак",
    "аўторак",
    "серада",
    "чацьвер",
    "пятніца",
    "субота"
  ]
}, dayPeriodValues$1b = {
  narrow: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дзень",
    evening: "веч.",
    night: "ноч"
  },
  abbreviated: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дзень",
    evening: "веч.",
    night: "ноч"
  },
  wide: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўнач",
    noon: "поўдзень",
    morning: "раніца",
    afternoon: "дзень",
    evening: "вечар",
    night: "ноч"
  }
}, formattingDayPeriodValues$X = {
  narrow: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дня",
    evening: "веч.",
    night: "ночы"
  },
  abbreviated: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўн.",
    noon: "поўд.",
    morning: "ран.",
    afternoon: "дня",
    evening: "веч.",
    night: "ночы"
  },
  wide: {
    am: "ДП",
    pm: "ПП",
    midnight: "поўнач",
    noon: "поўдзень",
    morning: "раніцы",
    afternoon: "дня",
    evening: "вечара",
    night: "ночы"
  }
}, ordinalNumber$1b = (u, l) => {
  const f = String(l?.unit), p = Number(u);
  let m;
  return f === "date" ? m = "-га" : f === "hour" || f === "minute" || f === "second" ? m = "-я" : m = (p % 10 === 2 || p % 10 === 3) && p % 100 !== 12 && p % 100 !== 13 ? "-і" : "-ы", p + m;
}, localize$1b = {
  ordinalNumber: ordinalNumber$1b,
  era: buildLocalizeFn({
    values: eraValues$1b,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1b,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1b,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$h,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1b,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1b,
    defaultWidth: "any",
    formattingValues: formattingDayPeriodValues$X,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$1a = /^(\d+)(-?(е|я|га|і|ы|ае|ая|яя|шы|гі|ці|ты|мы))?/i, parseOrdinalNumberPattern$1a = /\d+/i, matchEraPatterns$1a = {
  narrow: /^((да )?н\.?\s?э\.?)/i,
  abbreviated: /^((да )?н\.?\s?э\.?)/i,
  wide: /^(да нашай эры|нашай эры|наша эра)/i
}, parseEraPatterns$1a = {
  any: [/^д/i, /^н/i]
}, matchQuarterPatterns$1a = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234](-?[ыі]?)? кв.?/i,
  wide: /^[1234](-?[ыі]?)? квартал/i
}, parseQuarterPatterns$1a = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$1a = {
  narrow: /^[слкмчжв]/i,
  abbreviated: /^(студз|лют|сак|крас|тр(ав)?|чэрв|ліп|жн|вер|кастр|ліст|сьнеж)\.?/i,
  wide: /^(студзен[ья]|лют(ы|ага)|сакавіка?|красавіка?|тра(вень|ўня)|чэрвен[ья]|ліпен[ья]|жні(вень|ўня)|верас(ень|ня)|кастрычніка?|лістапада?|сьнеж(ань|ня))/i
}, parseMonthPatterns$1a = {
  narrow: [
    /^с/i,
    /^л/i,
    /^с/i,
    /^к/i,
    /^т/i,
    /^ч/i,
    /^л/i,
    /^ж/i,
    /^в/i,
    /^к/i,
    /^л/i,
    /^с/i
  ],
  any: [
    /^ст/i,
    /^лю/i,
    /^са/i,
    /^кр/i,
    /^тр/i,
    /^ч/i,
    /^ліп/i,
    /^ж/i,
    /^в/i,
    /^ка/i,
    /^ліс/i,
    /^сн/i
  ]
}, matchDayPatterns$1a = {
  narrow: /^[нпасч]/i,
  short: /^(нд|ня|пн|па|аў|ат|ср|се|чц|ча|пт|пя|сб|су)\.?/i,
  abbreviated: /^(нядз?|ндз|пнд|пан|аўт|срд|сер|чцьв|чаць|птн|пят|суб).?/i,
  wide: /^(нядзел[яі]|панядзел(ак|ка)|аўтор(ак|ка)|серад[аы]|чацьв(ер|ярга)|пятніц[аы]|субот[аы])/i
}, parseDayPatterns$1a = {
  narrow: [/^н/i, /^п/i, /^а/i, /^с/i, /^ч/i, /^п/i, /^с/i],
  any: [/^н/i, /^п[ан]/i, /^а/i, /^с[ер]/i, /^ч/i, /^п[ят]/i, /^с[уб]/i]
}, matchDayPeriodPatterns$1a = {
  narrow: /^([дп]п|поўн\.?|поўд\.?|ран\.?|дзень|дня|веч\.?|ночы?)/i,
  abbreviated: /^([дп]п|поўн\.?|поўд\.?|ран\.?|дзень|дня|веч\.?|ночы?)/i,
  wide: /^([дп]п|поўнач|поўдзень|раніц[аы]|дзень|дня|вечара?|ночы?)/i
}, parseDayPeriodPatterns$1a = {
  any: {
    am: /^дп/i,
    pm: /^пп/i,
    midnight: /^поўн/i,
    noon: /^поўд/i,
    morning: /^р/i,
    afternoon: /^д[зн]/i,
    evening: /^в/i,
    night: /^н/i
  }
}, match$1b = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$1a,
    parsePattern: parseOrdinalNumberPattern$1a,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$1a,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$1a,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$1a,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$1a,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$1a,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$1a,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$1a,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$1a,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$1a,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$1a,
    defaultParseWidth: "any"
  })
}, beTarask = {
  code: "be-tarask",
  formatDistance: formatDistance$1b,
  formatLong: formatLong$1j,
  formatRelative: formatRelative$1b,
  localize: localize$1b,
  match: match$1b,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$19 = {
  lessThanXSeconds: {
    one: "по-малко от секунда",
    other: "по-малко от {{count}} секунди"
  },
  xSeconds: {
    one: "1 секунда",
    other: "{{count}} секунди"
  },
  halfAMinute: "половин минута",
  lessThanXMinutes: {
    one: "по-малко от минута",
    other: "по-малко от {{count}} минути"
  },
  xMinutes: {
    one: "1 минута",
    other: "{{count}} минути"
  },
  aboutXHours: {
    one: "около час",
    other: "около {{count}} часа"
  },
  xHours: {
    one: "1 час",
    other: "{{count}} часа"
  },
  xDays: {
    one: "1 ден",
    other: "{{count}} дни"
  },
  aboutXWeeks: {
    one: "около седмица",
    other: "около {{count}} седмици"
  },
  xWeeks: {
    one: "1 седмица",
    other: "{{count}} седмици"
  },
  aboutXMonths: {
    one: "около месец",
    other: "около {{count}} месеца"
  },
  xMonths: {
    one: "1 месец",
    other: "{{count}} месеца"
  },
  aboutXYears: {
    one: "около година",
    other: "около {{count}} години"
  },
  xYears: {
    one: "1 година",
    other: "{{count}} години"
  },
  overXYears: {
    one: "над година",
    other: "над {{count}} години"
  },
  almostXYears: {
    one: "почти година",
    other: "почти {{count}} години"
  }
}, formatDistance$1a = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$19[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "след " + p : "преди " + p : p;
}, dateFormats$1i = {
  full: "EEEE, dd MMMM yyyy",
  long: "dd MMMM yyyy",
  medium: "dd MMM yyyy",
  short: "dd.MM.yyyy"
}, timeFormats$1i = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "H:mm"
}, dateTimeFormats$1i = {
  any: "{{date}} {{time}}"
}, formatLong$1i = {
  date: buildFormatLongFn({
    formats: dateFormats$1i,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1i,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1i,
    defaultWidth: "any"
  })
}, weekdays$3 = [
  "неделя",
  "понеделник",
  "вторник",
  "сряда",
  "четвъртък",
  "петък",
  "събота"
];
function lastWeek$6(u) {
  const l = weekdays$3[u];
  switch (u) {
    case 0:
    case 3:
    case 6:
      return "'миналата " + l + " в' p";
    case 1:
    case 2:
    case 4:
    case 5:
      return "'миналия " + l + " в' p";
  }
}
function thisWeek$6(u) {
  const l = weekdays$3[u];
  return u === 2 ? "'във " + l + " в' p" : "'в " + l + " в' p";
}
function nextWeek$6(u) {
  const l = weekdays$3[u];
  switch (u) {
    case 0:
    case 3:
    case 6:
      return "'следващата " + l + " в' p";
    case 1:
    case 2:
    case 4:
    case 5:
      return "'следващия " + l + " в' p";
  }
}
const lastWeekFormatToken = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$6(m) : lastWeek$6(m);
}, nextWeekFormatToken = (u, l, f) => {
  const p = toDate(u), m = p.getDay();
  return isSameWeek(p, l, f) ? thisWeek$6(m) : nextWeek$6(m);
}, formatRelativeLocale$1a = {
  lastWeek: lastWeekFormatToken,
  yesterday: "'вчера в' p",
  today: "'днес в' p",
  tomorrow: "'утре в' p",
  nextWeek: nextWeekFormatToken,
  other: "P"
}, formatRelative$1a = (u, l, f, p) => {
  const m = formatRelativeLocale$1a[u];
  return typeof m == "function" ? m(l, f, p) : m;
}, eraValues$1a = {
  narrow: ["пр.н.е.", "н.е."],
  abbreviated: ["преди н. е.", "н. е."],
  wide: ["преди новата ера", "новата ера"]
}, quarterValues$1a = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1-во тримес.", "2-ро тримес.", "3-то тримес.", "4-то тримес."],
  wide: [
    "1-во тримесечие",
    "2-ро тримесечие",
    "3-то тримесечие",
    "4-то тримесечие"
  ]
}, monthValues$1a = {
  abbreviated: [
    "яну",
    "фев",
    "мар",
    "апр",
    "май",
    "юни",
    "юли",
    "авг",
    "сеп",
    "окт",
    "ное",
    "дек"
  ],
  wide: [
    "януари",
    "февруари",
    "март",
    "април",
    "май",
    "юни",
    "юли",
    "август",
    "септември",
    "октомври",
    "ноември",
    "декември"
  ]
}, dayValues$1a = {
  narrow: ["Н", "П", "В", "С", "Ч", "П", "С"],
  short: ["нд", "пн", "вт", "ср", "чт", "пт", "сб"],
  abbreviated: ["нед", "пон", "вто", "сря", "чет", "пет", "съб"],
  wide: [
    "неделя",
    "понеделник",
    "вторник",
    "сряда",
    "четвъртък",
    "петък",
    "събота"
  ]
}, dayPeriodValues$1a = {
  wide: {
    am: "преди обяд",
    pm: "след обяд",
    midnight: "в полунощ",
    noon: "на обяд",
    morning: "сутринта",
    afternoon: "следобед",
    evening: "вечерта",
    night: "през нощта"
  }
};
function isFeminine(u) {
  return u === "year" || u === "week" || u === "minute" || u === "second";
}
function isNeuter(u) {
  return u === "quarter";
}
function numberWithSuffix(u, l, f, p, m) {
  const b = isNeuter(l) ? m : isFeminine(l) ? p : f;
  return u + "-" + b;
}
const ordinalNumber$1a = (u, l) => {
  const f = Number(u), p = l?.unit;
  if (f === 0)
    return numberWithSuffix(0, p, "ев", "ева", "ево");
  if (f % 1e3 === 0)
    return numberWithSuffix(f, p, "ен", "на", "но");
  if (f % 100 === 0)
    return numberWithSuffix(f, p, "тен", "тна", "тно");
  const m = f % 100;
  if (m > 20 || m < 10)
    switch (m % 10) {
      case 1:
        return numberWithSuffix(f, p, "ви", "ва", "во");
      case 2:
        return numberWithSuffix(f, p, "ри", "ра", "ро");
      case 7:
      case 8:
        return numberWithSuffix(f, p, "ми", "ма", "мо");
    }
  return numberWithSuffix(f, p, "ти", "та", "то");
}, localize$1a = {
  ordinalNumber: ordinalNumber$1a,
  era: buildLocalizeFn({
    values: eraValues$1a,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$1a,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$1a,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$1a,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$1a,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$19 = /^(\d+)(-?[врмт][аи]|-?т?(ен|на)|-?(ев|ева))?/i, parseOrdinalNumberPattern$19 = /\d+/i, matchEraPatterns$19 = {
  narrow: /^((пр)?н\.?\s?е\.?)/i,
  abbreviated: /^((пр)?н\.?\s?е\.?)/i,
  wide: /^(преди новата ера|новата ера|нова ера)/i
}, parseEraPatterns$19 = {
  any: [/^п/i, /^н/i]
}, matchQuarterPatterns$19 = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234](-?[врт]?o?)? тримес.?/i,
  wide: /^[1234](-?[врт]?о?)? тримесечие/i
}, parseQuarterPatterns$19 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchDayPatterns$19 = {
  narrow: /^[нпвсч]/i,
  short: /^(нд|пн|вт|ср|чт|пт|сб)/i,
  abbreviated: /^(нед|пон|вто|сря|чет|пет|съб)/i,
  wide: /^(неделя|понеделник|вторник|сряда|четвъртък|петък|събота)/i
}, parseDayPatterns$19 = {
  narrow: [/^н/i, /^п/i, /^в/i, /^с/i, /^ч/i, /^п/i, /^с/i],
  any: [/^н[ед]/i, /^п[он]/i, /^вт/i, /^ср/i, /^ч[ет]/i, /^п[ет]/i, /^с[ъб]/i]
}, matchMonthPatterns$19 = {
  abbreviated: /^(яну|фев|мар|апр|май|юни|юли|авг|сеп|окт|ное|дек)/i,
  wide: /^(януари|февруари|март|април|май|юни|юли|август|септември|октомври|ноември|декември)/i
}, parseMonthPatterns$19 = {
  any: [
    /^я/i,
    /^ф/i,
    /^мар/i,
    /^ап/i,
    /^май/i,
    /^юн/i,
    /^юл/i,
    /^ав/i,
    /^се/i,
    /^окт/i,
    /^но/i,
    /^де/i
  ]
}, matchDayPeriodPatterns$19 = {
  any: /^(преди о|след о|в по|на о|през|веч|сут|следо)/i
}, parseDayPeriodPatterns$19 = {
  any: {
    am: /^преди о/i,
    pm: /^след о/i,
    midnight: /^в пол/i,
    noon: /^на об/i,
    morning: /^сут/i,
    afternoon: /^следо/i,
    evening: /^веч/i,
    night: /^през н/i
  }
}, match$1a = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$19,
    parsePattern: parseOrdinalNumberPattern$19,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$19,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$19,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$19,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$19,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$19,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$19,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$19,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$19,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$19,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$19,
    defaultParseWidth: "any"
  })
}, bg = {
  code: "bg",
  formatDistance: formatDistance$1a,
  formatLong: formatLong$1i,
  formatRelative: formatRelative$1a,
  localize: localize$1a,
  match: match$1a,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, numberValues$1 = {
  locale: {
    1: "১",
    2: "২",
    3: "৩",
    4: "৪",
    5: "৫",
    6: "৬",
    7: "৭",
    8: "৮",
    9: "৯",
    0: "০"
  }
}, eraValues$19 = {
  narrow: ["খ্রিঃপূঃ", "খ্রিঃ"],
  abbreviated: ["খ্রিঃপূর্ব", "খ্রিঃ"],
  wide: ["খ্রিস্টপূর্ব", "খ্রিস্টাব্দ"]
}, quarterValues$19 = {
  narrow: ["১", "২", "৩", "৪"],
  abbreviated: ["১ত্রৈ", "২ত্রৈ", "৩ত্রৈ", "৪ত্রৈ"],
  wide: ["১ম ত্রৈমাসিক", "২য় ত্রৈমাসিক", "৩য় ত্রৈমাসিক", "৪র্থ ত্রৈমাসিক"]
}, monthValues$19 = {
  narrow: [
    "জানু",
    "ফেব্রু",
    "মার্চ",
    "এপ্রিল",
    "মে",
    "জুন",
    "জুলাই",
    "আগস্ট",
    "সেপ্ট",
    "অক্টো",
    "নভে",
    "ডিসে"
  ],
  abbreviated: [
    "জানু",
    "ফেব্রু",
    "মার্চ",
    "এপ্রিল",
    "মে",
    "জুন",
    "জুলাই",
    "আগস্ট",
    "সেপ্ট",
    "অক্টো",
    "নভে",
    "ডিসে"
  ],
  wide: [
    "জানুয়ারি",
    "ফেব্রুয়ারি",
    "মার্চ",
    "এপ্রিল",
    "মে",
    "জুন",
    "জুলাই",
    "আগস্ট",
    "সেপ্টেম্বর",
    "অক্টোবর",
    "নভেম্বর",
    "ডিসেম্বর"
  ]
}, dayValues$19 = {
  narrow: ["র", "সো", "ম", "বু", "বৃ", "শু", "শ"],
  short: ["রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"],
  abbreviated: ["রবি", "সোম", "মঙ্গল", "বুধ", "বৃহ", "শুক্র", "শনি"],
  wide: [
    "রবিবার",
    "সোমবার",
    "মঙ্গলবার",
    "বুধবার",
    "বৃহস্পতিবার ",
    "শুক্রবার",
    "শনিবার"
  ]
}, dayPeriodValues$19 = {
  narrow: {
    am: "পূ",
    pm: "অপ",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  },
  abbreviated: {
    am: "পূর্বাহ্ন",
    pm: "অপরাহ্ন",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  },
  wide: {
    am: "পূর্বাহ্ন",
    pm: "অপরাহ্ন",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  }
}, formattingDayPeriodValues$W = {
  narrow: {
    am: "পূ",
    pm: "অপ",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  },
  abbreviated: {
    am: "পূর্বাহ্ন",
    pm: "অপরাহ্ন",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  },
  wide: {
    am: "পূর্বাহ্ন",
    pm: "অপরাহ্ন",
    midnight: "মধ্যরাত",
    noon: "মধ্যাহ্ন",
    morning: "সকাল",
    afternoon: "বিকাল",
    evening: "সন্ধ্যা",
    night: "রাত"
  }
};
function dateOrdinalNumber(u, l) {
  if (u > 18 && u <= 31)
    return l + "শে";
  switch (u) {
    case 1:
      return l + "লা";
    case 2:
    case 3:
      return l + "রা";
    case 4:
      return l + "ঠা";
    default:
      return l + "ই";
  }
}
const ordinalNumber$19 = (u, l) => {
  const f = Number(u), p = numberToLocale$1(f);
  if (l?.unit === "date")
    return dateOrdinalNumber(f, p);
  if (f > 10 || f === 0) return p + "তম";
  switch (f % 10) {
    case 2:
    case 3:
      return p + "য়";
    case 4:
      return p + "র্থ";
    case 6:
      return p + "ষ্ঠ";
    default:
      return p + "ম";
  }
};
function numberToLocale$1(u) {
  return u.toString().replace(/\d/g, function(l) {
    return numberValues$1.locale[l];
  });
}
const localize$19 = {
  ordinalNumber: ordinalNumber$19,
  era: buildLocalizeFn({
    values: eraValues$19,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$19,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$19,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$19,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$19,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$W,
    defaultFormattingWidth: "wide"
  })
}, formatDistanceLocale$18 = {
  lessThanXSeconds: {
    one: "প্রায় ১ সেকেন্ড",
    other: "প্রায় {{count}} সেকেন্ড"
  },
  xSeconds: {
    one: "১ সেকেন্ড",
    other: "{{count}} সেকেন্ড"
  },
  halfAMinute: "আধ মিনিট",
  lessThanXMinutes: {
    one: "প্রায় ১ মিনিট",
    other: "প্রায় {{count}} মিনিট"
  },
  xMinutes: {
    one: "১ মিনিট",
    other: "{{count}} মিনিট"
  },
  aboutXHours: {
    one: "প্রায় ১ ঘন্টা",
    other: "প্রায় {{count}} ঘন্টা"
  },
  xHours: {
    one: "১ ঘন্টা",
    other: "{{count}} ঘন্টা"
  },
  xDays: {
    one: "১ দিন",
    other: "{{count}} দিন"
  },
  aboutXWeeks: {
    one: "প্রায় ১ সপ্তাহ",
    other: "প্রায় {{count}} সপ্তাহ"
  },
  xWeeks: {
    one: "১ সপ্তাহ",
    other: "{{count}} সপ্তাহ"
  },
  aboutXMonths: {
    one: "প্রায় ১ মাস",
    other: "প্রায় {{count}} মাস"
  },
  xMonths: {
    one: "১ মাস",
    other: "{{count}} মাস"
  },
  aboutXYears: {
    one: "প্রায় ১ বছর",
    other: "প্রায় {{count}} বছর"
  },
  xYears: {
    one: "১ বছর",
    other: "{{count}} বছর"
  },
  overXYears: {
    one: "১ বছরের বেশি",
    other: "{{count}} বছরের বেশি"
  },
  almostXYears: {
    one: "প্রায় ১ বছর",
    other: "প্রায় {{count}} বছর"
  }
}, formatDistance$19 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$18[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", numberToLocale$1(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? p + " এর মধ্যে" : p + " আগে" : p;
}, dateFormats$1h = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$1h = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1h = {
  full: "{{date}} {{time}} 'সময়'",
  long: "{{date}} {{time}} 'সময়'",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1h = {
  date: buildFormatLongFn({
    formats: dateFormats$1h,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1h,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1h,
    defaultWidth: "full"
  })
}, formatRelativeLocale$19 = {
  lastWeek: "'গত' eeee 'সময়' p",
  yesterday: "'গতকাল' 'সময়' p",
  today: "'আজ' 'সময়' p",
  tomorrow: "'আগামীকাল' 'সময়' p",
  nextWeek: "eeee 'সময়' p",
  other: "P"
}, formatRelative$19 = (u, l, f, p) => formatRelativeLocale$19[u], matchOrdinalNumberPattern$18 = /^(\d+)(ম|য়|র্থ|ষ্ঠ|শে|ই|তম)?/i, parseOrdinalNumberPattern$18 = /\d+/i, matchEraPatterns$18 = {
  narrow: /^(খ্রিঃপূঃ|খ্রিঃ)/i,
  abbreviated: /^(খ্রিঃপূর্ব|খ্রিঃ)/i,
  wide: /^(খ্রিস্টপূর্ব|খ্রিস্টাব্দ)/i
}, parseEraPatterns$18 = {
  narrow: [/^খ্রিঃপূঃ/i, /^খ্রিঃ/i],
  abbreviated: [/^খ্রিঃপূর্ব/i, /^খ্রিঃ/i],
  wide: [/^খ্রিস্টপূর্ব/i, /^খ্রিস্টাব্দ/i]
}, matchQuarterPatterns$18 = {
  narrow: /^[১২৩৪]/i,
  abbreviated: /^[১২৩৪]ত্রৈ/i,
  wide: /^[১২৩৪](ম|য়|র্থ)? ত্রৈমাসিক/i
}, parseQuarterPatterns$18 = {
  any: [/১/i, /২/i, /৩/i, /৪/i]
}, matchMonthPatterns$18 = {
  narrow: /^(জানু|ফেব্রু|মার্চ|এপ্রিল|মে|জুন|জুলাই|আগস্ট|সেপ্ট|অক্টো|নভে|ডিসে)/i,
  abbreviated: /^(জানু|ফেব্রু|মার্চ|এপ্রিল|মে|জুন|জুলাই|আগস্ট|সেপ্ট|অক্টো|নভে|ডিসে)/i,
  wide: /^(জানুয়ারি|ফেব্রুয়ারি|মার্চ|এপ্রিল|মে|জুন|জুলাই|আগস্ট|সেপ্টেম্বর|অক্টোবর|নভেম্বর|ডিসেম্বর)/i
}, parseMonthPatterns$18 = {
  any: [
    /^জানু/i,
    /^ফেব্রু/i,
    /^মার্চ/i,
    /^এপ্রিল/i,
    /^মে/i,
    /^জুন/i,
    /^জুলাই/i,
    /^আগস্ট/i,
    /^সেপ্ট/i,
    /^অক্টো/i,
    /^নভে/i,
    /^ডিসে/i
  ]
}, matchDayPatterns$18 = {
  narrow: /^(র|সো|ম|বু|বৃ|শু|শ)+/i,
  short: /^(রবি|সোম|মঙ্গল|বুধ|বৃহ|শুক্র|শনি)+/i,
  abbreviated: /^(রবি|সোম|মঙ্গল|বুধ|বৃহ|শুক্র|শনি)+/i,
  wide: /^(রবিবার|সোমবার|মঙ্গলবার|বুধবার|বৃহস্পতিবার |শুক্রবার|শনিবার)+/i
}, parseDayPatterns$18 = {
  narrow: [/^র/i, /^সো/i, /^ম/i, /^বু/i, /^বৃ/i, /^শু/i, /^শ/i],
  short: [/^রবি/i, /^সোম/i, /^মঙ্গল/i, /^বুধ/i, /^বৃহ/i, /^শুক্র/i, /^শনি/i],
  abbreviated: [
    /^রবি/i,
    /^সোম/i,
    /^মঙ্গল/i,
    /^বুধ/i,
    /^বৃহ/i,
    /^শুক্র/i,
    /^শনি/i
  ],
  wide: [
    /^রবিবার/i,
    /^সোমবার/i,
    /^মঙ্গলবার/i,
    /^বুধবার/i,
    /^বৃহস্পতিবার /i,
    /^শুক্রবার/i,
    /^শনিবার/i
  ]
}, matchDayPeriodPatterns$18 = {
  narrow: /^(পূ|অপ|মধ্যরাত|মধ্যাহ্ন|সকাল|বিকাল|সন্ধ্যা|রাত)/i,
  abbreviated: /^(পূর্বাহ্ন|অপরাহ্ন|মধ্যরাত|মধ্যাহ্ন|সকাল|বিকাল|সন্ধ্যা|রাত)/i,
  wide: /^(পূর্বাহ্ন|অপরাহ্ন|মধ্যরাত|মধ্যাহ্ন|সকাল|বিকাল|সন্ধ্যা|রাত)/i
}, parseDayPeriodPatterns$18 = {
  any: {
    am: /^পূ/i,
    pm: /^অপ/i,
    midnight: /^মধ্যরাত/i,
    noon: /^মধ্যাহ্ন/i,
    morning: /সকাল/i,
    afternoon: /বিকাল/i,
    evening: /সন্ধ্যা/i,
    night: /রাত/i
  }
}, match$19 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$18,
    parsePattern: parseOrdinalNumberPattern$18,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$18,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$18,
    defaultParseWidth: "wide"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$18,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$18,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$18,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$18,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$18,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$18,
    defaultParseWidth: "wide"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$18,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$18,
    defaultParseWidth: "any"
  })
}, bn = {
  code: "bn",
  formatDistance: formatDistance$19,
  formatLong: formatLong$1h,
  formatRelative: formatRelative$19,
  localize: localize$19,
  match: match$19,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$17 = {
  lessThanXSeconds: {
    one: {
      standalone: "manje od 1 sekunde",
      withPrepositionAgo: "manje od 1 sekunde",
      withPrepositionIn: "manje od 1 sekundu"
    },
    dual: "manje od {{count}} sekunde",
    other: "manje od {{count}} sekundi"
  },
  xSeconds: {
    one: {
      standalone: "1 sekunda",
      withPrepositionAgo: "1 sekunde",
      withPrepositionIn: "1 sekundu"
    },
    dual: "{{count}} sekunde",
    other: "{{count}} sekundi"
  },
  halfAMinute: "pola minute",
  lessThanXMinutes: {
    one: {
      standalone: "manje od 1 minute",
      withPrepositionAgo: "manje od 1 minute",
      withPrepositionIn: "manje od 1 minutu"
    },
    dual: "manje od {{count}} minute",
    other: "manje od {{count}} minuta"
  },
  xMinutes: {
    one: {
      standalone: "1 minuta",
      withPrepositionAgo: "1 minute",
      withPrepositionIn: "1 minutu"
    },
    dual: "{{count}} minute",
    other: "{{count}} minuta"
  },
  aboutXHours: {
    one: {
      standalone: "oko 1 sat",
      withPrepositionAgo: "oko 1 sat",
      withPrepositionIn: "oko 1 sat"
    },
    dual: "oko {{count}} sata",
    other: "oko {{count}} sati"
  },
  xHours: {
    one: {
      standalone: "1 sat",
      withPrepositionAgo: "1 sat",
      withPrepositionIn: "1 sat"
    },
    dual: "{{count}} sata",
    other: "{{count}} sati"
  },
  xDays: {
    one: {
      standalone: "1 dan",
      withPrepositionAgo: "1 dan",
      withPrepositionIn: "1 dan"
    },
    dual: "{{count}} dana",
    other: "{{count}} dana"
  },
  aboutXWeeks: {
    one: {
      standalone: "oko 1 sedmicu",
      withPrepositionAgo: "oko 1 sedmicu",
      withPrepositionIn: "oko 1 sedmicu"
    },
    dual: "oko {{count}} sedmice",
    other: "oko {{count}} sedmice"
  },
  xWeeks: {
    one: {
      standalone: "1 sedmicu",
      withPrepositionAgo: "1 sedmicu",
      withPrepositionIn: "1 sedmicu"
    },
    dual: "{{count}} sedmice",
    other: "{{count}} sedmice"
  },
  aboutXMonths: {
    one: {
      standalone: "oko 1 mjesec",
      withPrepositionAgo: "oko 1 mjesec",
      withPrepositionIn: "oko 1 mjesec"
    },
    dual: "oko {{count}} mjeseca",
    other: "oko {{count}} mjeseci"
  },
  xMonths: {
    one: {
      standalone: "1 mjesec",
      withPrepositionAgo: "1 mjesec",
      withPrepositionIn: "1 mjesec"
    },
    dual: "{{count}} mjeseca",
    other: "{{count}} mjeseci"
  },
  aboutXYears: {
    one: {
      standalone: "oko 1 godinu",
      withPrepositionAgo: "oko 1 godinu",
      withPrepositionIn: "oko 1 godinu"
    },
    dual: "oko {{count}} godine",
    other: "oko {{count}} godina"
  },
  xYears: {
    one: {
      standalone: "1 godina",
      withPrepositionAgo: "1 godine",
      withPrepositionIn: "1 godinu"
    },
    dual: "{{count}} godine",
    other: "{{count}} godina"
  },
  overXYears: {
    one: {
      standalone: "preko 1 godinu",
      withPrepositionAgo: "preko 1 godinu",
      withPrepositionIn: "preko 1 godinu"
    },
    dual: "preko {{count}} godine",
    other: "preko {{count}} godina"
  },
  almostXYears: {
    one: {
      standalone: "gotovo 1 godinu",
      withPrepositionAgo: "gotovo 1 godinu",
      withPrepositionIn: "gotovo 1 godinu"
    },
    dual: "gotovo {{count}} godine",
    other: "gotovo {{count}} godina"
  }
}, formatDistance$18 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$17[u];
  return typeof m == "string" ? p = m : l === 1 ? f?.addSuffix ? f.comparison && f.comparison > 0 ? p = m.one.withPrepositionIn : p = m.one.withPrepositionAgo : p = m.one.standalone : l % 10 > 1 && l % 10 < 5 && // if last digit is between 2 and 4
  String(l).substr(-2, 1) !== "1" ? p = m.dual.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "za " + p : "prije " + p : p;
}, dateFormats$1g = {
  full: "EEEE, d. MMMM yyyy.",
  long: "d. MMMM yyyy.",
  medium: "d. MMM yy.",
  short: "dd. MM. yy."
}, timeFormats$1g = {
  full: "HH:mm:ss (zzzz)",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1g = {
  full: "{{date}} 'u' {{time}}",
  long: "{{date}} 'u' {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$1g = {
  date: buildFormatLongFn({
    formats: dateFormats$1g,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1g,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1g,
    defaultWidth: "full"
  })
}, formatRelativeLocale$18 = {
  lastWeek: (u) => {
    switch (u.getDay()) {
      case 0:
        return "'prošle nedjelje u' p";
      case 3:
        return "'prošle srijede u' p";
      case 6:
        return "'prošle subote u' p";
      default:
        return "'prošli' EEEE 'u' p";
    }
  },
  yesterday: "'juče u' p",
  today: "'danas u' p",
  tomorrow: "'sutra u' p",
  nextWeek: (u) => {
    switch (u.getDay()) {
      case 0:
        return "'sljedeće nedjelje u' p";
      case 3:
        return "'sljedeću srijedu u' p";
      case 6:
        return "'sljedeću subotu u' p";
      default:
        return "'sljedeći' EEEE 'u' p";
    }
  },
  other: "P"
}, formatRelative$18 = (u, l, f, p) => {
  const m = formatRelativeLocale$18[u];
  return typeof m == "function" ? m(l) : m;
}, eraValues$18 = {
  narrow: ["pr.n.e.", "AD"],
  abbreviated: ["pr. Hr.", "po. Hr."],
  wide: ["Prije Hrista", "Poslije Hrista"]
}, quarterValues$18 = {
  narrow: ["1.", "2.", "3.", "4."],
  abbreviated: ["1. kv.", "2. kv.", "3. kv.", "4. kv."],
  wide: ["1. kvartal", "2. kvartal", "3. kvartal", "4. kvartal"]
}, monthValues$18 = {
  narrow: [
    "1.",
    "2.",
    "3.",
    "4.",
    "5.",
    "6.",
    "7.",
    "8.",
    "9.",
    "10.",
    "11.",
    "12."
  ],
  abbreviated: [
    "jan",
    "feb",
    "mar",
    "apr",
    "maj",
    "jun",
    "jul",
    "avg",
    "sep",
    "okt",
    "nov",
    "dec"
  ],
  wide: [
    "januar",
    "februar",
    "mart",
    "april",
    "maj",
    "juni",
    "juli",
    "avgust",
    "septembar",
    "oktobar",
    "novembar",
    "decembar"
  ]
}, formattingMonthValues$g = {
  narrow: [
    "1.",
    "2.",
    "3.",
    "4.",
    "5.",
    "6.",
    "7.",
    "8.",
    "9.",
    "10.",
    "11.",
    "12."
  ],
  abbreviated: [
    "jan",
    "feb",
    "mar",
    "apr",
    "maj",
    "jun",
    "jul",
    "avg",
    "sep",
    "okt",
    "nov",
    "dec"
  ],
  wide: [
    "januar",
    "februar",
    "mart",
    "april",
    "maj",
    "juni",
    "juli",
    "avgust",
    "septembar",
    "oktobar",
    "novembar",
    "decembar"
  ]
}, dayValues$18 = {
  narrow: ["N", "P", "U", "S", "Č", "P", "S"],
  short: ["ned", "pon", "uto", "sre", "čet", "pet", "sub"],
  abbreviated: ["ned", "pon", "uto", "sre", "čet", "pet", "sub"],
  wide: [
    "nedjelja",
    "ponedjeljak",
    "utorak",
    "srijeda",
    "četvrtak",
    "petak",
    "subota"
  ]
}, dayPeriodValues$18 = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "popodne",
    evening: "uveče",
    night: "noću"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "popodne",
    evening: "uveče",
    night: "noću"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "poslije podne",
    evening: "uveče",
    night: "noću"
  }
}, formattingDayPeriodValues$V = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "popodne",
    evening: "uveče",
    night: "noću"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "popodne",
    evening: "uveče",
    night: "noću"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutru",
    afternoon: "poslije podne",
    evening: "uveče",
    night: "noću"
  }
}, ordinalNumber$18 = (u, l) => {
  const f = Number(u);
  return String(f) + ".";
}, localize$18 = {
  ordinalNumber: ordinalNumber$18,
  era: buildLocalizeFn({
    values: eraValues$18,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$18,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$18,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$g,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$18,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$18,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$V,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$17 = /^(\d+)\./i, parseOrdinalNumberPattern$17 = /\d+/i, matchEraPatterns$17 = {
  narrow: /^(pr\.n\.e\.|AD)/i,
  abbreviated: /^(pr\.\s?Hr\.|po\.\s?Hr\.)/i,
  wide: /^(Prije Hrista|prije nove ere|Poslije Hrista|nova era)/i
}, parseEraPatterns$17 = {
  any: [/^pr/i, /^(po|nova)/i]
}, matchQuarterPatterns$17 = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]\.\s?kv\.?/i,
  wide: /^[1234]\. kvartal/i
}, parseQuarterPatterns$17 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$17 = {
  narrow: /^(10|11|12|[123456789])\./i,
  abbreviated: /^(jan|feb|mar|apr|maj|jun|jul|avg|sep|okt|nov|dec)/i,
  wide: /^((januar|januara)|(februar|februara)|(mart|marta)|(april|aprila)|(maj|maja)|(juni|juna)|(juli|jula)|(avgust|avgusta)|(septembar|septembra)|(oktobar|oktobra)|(novembar|novembra)|(decembar|decembra))/i
}, parseMonthPatterns$17 = {
  narrow: [
    /^1/i,
    /^2/i,
    /^3/i,
    /^4/i,
    /^5/i,
    /^6/i,
    /^7/i,
    /^8/i,
    /^9/i,
    /^10/i,
    /^11/i,
    /^12/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^maj/i,
    /^jun/i,
    /^jul/i,
    /^avg/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$17 = {
  narrow: /^[npusčc]/i,
  short: /^(ned|pon|uto|sre|(čet|cet)|pet|sub)/i,
  abbreviated: /^(ned|pon|uto|sre|(čet|cet)|pet|sub)/i,
  wide: /^(nedjelja|ponedjeljak|utorak|srijeda|(četvrtak|cetvrtak)|petak|subota)/i
}, parseDayPatterns$17 = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, matchDayPeriodPatterns$17 = {
  any: /^(am|pm|ponoc|ponoć|(po)?podne|uvece|uveče|noću|poslije podne|ujutru)/i
}, parseDayPeriodPatterns$17 = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^pono/i,
    noon: /^pod/i,
    morning: /jutro/i,
    afternoon: /(poslije\s|po)+podne/i,
    evening: /(uvece|uveče)/i,
    night: /(nocu|noću)/i
  }
}, match$18 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$17,
    parsePattern: parseOrdinalNumberPattern$17,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$17,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$17,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$17,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$17,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$17,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$17,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$17,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$17,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$17,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$17,
    defaultParseWidth: "any"
  })
}, bs = {
  code: "bs",
  formatDistance: formatDistance$18,
  formatLong: formatLong$1g,
  formatRelative: formatRelative$18,
  localize: localize$18,
  match: match$18,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$16 = {
  lessThanXSeconds: {
    one: "menys d'un segon",
    eleven: "menys d'onze segons",
    other: "menys de {{count}} segons"
  },
  xSeconds: {
    one: "1 segon",
    other: "{{count}} segons"
  },
  halfAMinute: "mig minut",
  lessThanXMinutes: {
    one: "menys d'un minut",
    eleven: "menys d'onze minuts",
    other: "menys de {{count}} minuts"
  },
  xMinutes: {
    one: "1 minut",
    other: "{{count}} minuts"
  },
  aboutXHours: {
    one: "aproximadament una hora",
    other: "aproximadament {{count}} hores"
  },
  xHours: {
    one: "1 hora",
    other: "{{count}} hores"
  },
  xDays: {
    one: "1 dia",
    other: "{{count}} dies"
  },
  aboutXWeeks: {
    one: "aproximadament una setmana",
    other: "aproximadament {{count}} setmanes"
  },
  xWeeks: {
    one: "1 setmana",
    other: "{{count}} setmanes"
  },
  aboutXMonths: {
    one: "aproximadament un mes",
    other: "aproximadament {{count}} mesos"
  },
  xMonths: {
    one: "1 mes",
    other: "{{count}} mesos"
  },
  aboutXYears: {
    one: "aproximadament un any",
    other: "aproximadament {{count}} anys"
  },
  xYears: {
    one: "1 any",
    other: "{{count}} anys"
  },
  overXYears: {
    one: "més d'un any",
    eleven: "més d'onze anys",
    other: "més de {{count}} anys"
  },
  almostXYears: {
    one: "gairebé un any",
    other: "gairebé {{count}} anys"
  }
}, formatDistance$17 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$16[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 11 && m.eleven ? p = m.eleven : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "en " + p : "fa " + p : p;
}, dateFormats$1f = {
  full: "EEEE, d 'de' MMMM y",
  long: "d 'de' MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$1f = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1f = {
  full: "{{date}} 'a les' {{time}}",
  long: "{{date}} 'a les' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1f = {
  date: buildFormatLongFn({
    formats: dateFormats$1f,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1f,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1f,
    defaultWidth: "full"
  })
}, formatRelativeLocale$17 = {
  lastWeek: "'el' eeee 'passat a la' LT",
  yesterday: "'ahir a la' p",
  today: "'avui a la' p",
  tomorrow: "'demà a la' p",
  nextWeek: "eeee 'a la' p",
  other: "P"
}, formatRelativeLocalePlural$3 = {
  lastWeek: "'el' eeee 'passat a les' p",
  yesterday: "'ahir a les' p",
  today: "'avui a les' p",
  tomorrow: "'demà a les' p",
  nextWeek: "eeee 'a les' p",
  other: "P"
}, formatRelative$17 = (u, l, f, p) => l.getHours() !== 1 ? formatRelativeLocalePlural$3[u] : formatRelativeLocale$17[u], eraValues$17 = {
  narrow: ["aC", "dC"],
  abbreviated: ["a. de C.", "d. de C."],
  wide: ["abans de Crist", "després de Crist"]
}, quarterValues$17 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1r trimestre", "2n trimestre", "3r trimestre", "4t trimestre"]
}, monthValues$17 = {
  narrow: [
    "GN",
    "FB",
    "MÇ",
    "AB",
    "MG",
    "JN",
    "JL",
    "AG",
    "ST",
    "OC",
    "NV",
    "DS"
  ],
  /**
   * Les abreviatures dels mesos de l'any es formen seguint una de les normes generals de formació d'abreviatures.
   * S'escriu la primera síl·laba i les consonants de la síl·laba següent anteriors a la primera vocal.
   * Els mesos de març, maig i juny no s'abreugen perquè són paraules d'una sola síl·laba.
   */
  abbreviated: [
    "gen.",
    "febr.",
    "març",
    "abr.",
    "maig",
    "juny",
    "jul.",
    "ag.",
    "set.",
    "oct.",
    "nov.",
    "des."
  ],
  wide: [
    "gener",
    "febrer",
    "març",
    "abril",
    "maig",
    "juny",
    "juliol",
    "agost",
    "setembre",
    "octubre",
    "novembre",
    "desembre"
  ]
}, dayValues$17 = {
  narrow: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  short: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  abbreviated: ["dg.", "dl.", "dt.", "dm.", "dj.", "dv.", "ds."],
  wide: [
    "diumenge",
    "dilluns",
    "dimarts",
    "dimecres",
    "dijous",
    "divendres",
    "dissabte"
  ]
}, dayPeriodValues$17 = {
  narrow: {
    am: "am",
    pm: "pm",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "matí",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  },
  abbreviated: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "matí",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  },
  wide: {
    am: "ante meridiem",
    pm: "post meridiem",
    midnight: "mitjanit",
    noon: "migdia",
    morning: "matí",
    afternoon: "tarda",
    evening: "vespre",
    night: "nit"
  }
}, formattingDayPeriodValues$U = {
  narrow: {
    am: "am",
    pm: "pm",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del matí",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del matí",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  },
  wide: {
    am: "ante meridiem",
    pm: "post meridiem",
    midnight: "de la mitjanit",
    noon: "del migdia",
    morning: "del matí",
    afternoon: "de la tarda",
    evening: "del vespre",
    night: "de la nit"
  }
}, ordinalNumber$17 = (u, l) => {
  const f = Number(u), p = f % 100;
  if (p > 20 || p < 10)
    switch (p % 10) {
      case 1:
        return f + "r";
      case 2:
        return f + "n";
      case 3:
        return f + "r";
      case 4:
        return f + "t";
    }
  return f + "è";
}, localize$17 = {
  ordinalNumber: ordinalNumber$17,
  era: buildLocalizeFn({
    values: eraValues$17,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$17,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$17,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$17,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$17,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$U,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$16 = /^(\d+)(è|r|n|r|t)?/i, parseOrdinalNumberPattern$16 = /\d+/i, matchEraPatterns$16 = {
  narrow: /^(aC|dC)/i,
  abbreviated: /^(a. de C.|d. de C.)/i,
  wide: /^(abans de Crist|despr[eé]s de Crist)/i
}, parseEraPatterns$16 = {
  narrow: [/^aC/i, /^dC/i],
  abbreviated: [/^(a. de C.)/i, /^(d. de C.)/i],
  wide: [/^(abans de Crist)/i, /^(despr[eé]s de Crist)/i]
}, matchQuarterPatterns$16 = {
  narrow: /^[1234]/i,
  abbreviated: /^T[1234]/i,
  wide: /^[1234](è|r|n|r|t)? trimestre/i
}, parseQuarterPatterns$16 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$16 = {
  narrow: /^(GN|FB|MÇ|AB|MG|JN|JL|AG|ST|OC|NV|DS)/i,
  abbreviated: /^(gen.|febr.|març|abr.|maig|juny|jul.|ag.|set.|oct.|nov.|des.)/i,
  wide: /^(gener|febrer|març|abril|maig|juny|juliol|agost|setembre|octubre|novembre|desembre)/i
}, parseMonthPatterns$16 = {
  narrow: [
    /^GN/i,
    /^FB/i,
    /^MÇ/i,
    /^AB/i,
    /^MG/i,
    /^JN/i,
    /^JL/i,
    /^AG/i,
    /^ST/i,
    /^OC/i,
    /^NV/i,
    /^DS/i
  ],
  abbreviated: [
    /^gen./i,
    /^febr./i,
    /^març/i,
    /^abr./i,
    /^maig/i,
    /^juny/i,
    /^jul./i,
    /^ag./i,
    /^set./i,
    /^oct./i,
    /^nov./i,
    /^des./i
  ],
  wide: [
    /^gener/i,
    /^febrer/i,
    /^març/i,
    /^abril/i,
    /^maig/i,
    /^juny/i,
    /^juliol/i,
    /^agost/i,
    /^setembre/i,
    /^octubre/i,
    /^novembre/i,
    /^desembre/i
  ]
}, matchDayPatterns$16 = {
  narrow: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  short: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  abbreviated: /^(dg\.|dl\.|dt\.|dm\.|dj\.|dv\.|ds\.)/i,
  wide: /^(diumenge|dilluns|dimarts|dimecres|dijous|divendres|dissabte)/i
}, parseDayPatterns$16 = {
  narrow: [/^dg./i, /^dl./i, /^dt./i, /^dm./i, /^dj./i, /^dv./i, /^ds./i],
  abbreviated: [/^dg./i, /^dl./i, /^dt./i, /^dm./i, /^dj./i, /^dv./i, /^ds./i],
  wide: [
    /^diumenge/i,
    /^dilluns/i,
    /^dimarts/i,
    /^dimecres/i,
    /^dijous/i,
    /^divendres/i,
    /^disssabte/i
  ]
}, matchDayPeriodPatterns$16 = {
  narrow: /^(a|p|mn|md|(del|de la) (matí|tarda|vespre|nit))/i,
  abbreviated: /^([ap]\.?\s?m\.?|mitjanit|migdia|(del|de la) (matí|tarda|vespre|nit))/i,
  wide: /^(ante meridiem|post meridiem|mitjanit|migdia|(del|de la) (matí|tarda|vespre|nit))/i
}, parseDayPeriodPatterns$16 = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mitjanit/i,
    noon: /^migdia/i,
    morning: /matí/i,
    afternoon: /tarda/i,
    evening: /vespre/i,
    night: /nit/i
  }
}, match$17 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$16,
    parsePattern: parseOrdinalNumberPattern$16,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$16,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$16,
    defaultParseWidth: "wide"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$16,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$16,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$16,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$16,
    defaultParseWidth: "wide"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$16,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$16,
    defaultParseWidth: "wide"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$16,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$16,
    defaultParseWidth: "any"
  })
}, ca = {
  code: "ca",
  formatDistance: formatDistance$17,
  formatLong: formatLong$1f,
  formatRelative: formatRelative$17,
  localize: localize$17,
  match: match$17,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$15 = {
  lessThanXSeconds: {
    one: "کەمتر لە یەک چرکە",
    other: "کەمتر لە {{count}} چرکە"
  },
  xSeconds: {
    one: "1 چرکە",
    other: "{{count}} چرکە"
  },
  halfAMinute: "نیو کاتژمێر",
  lessThanXMinutes: {
    one: "کەمتر لە یەک خولەک",
    other: "کەمتر لە {{count}} خولەک"
  },
  xMinutes: {
    one: "1 خولەک",
    other: "{{count}} خولەک"
  },
  aboutXHours: {
    one: "دەوروبەری 1 کاتژمێر",
    other: "دەوروبەری {{count}} کاتژمێر"
  },
  xHours: {
    one: "1 کاتژمێر",
    other: "{{count}} کاتژمێر"
  },
  xDays: {
    one: "1 ڕۆژ",
    other: "{{count}} ژۆژ"
  },
  aboutXWeeks: {
    one: "دەوروبەری 1 هەفتە",
    other: "دوروبەری {{count}} هەفتە"
  },
  xWeeks: {
    one: "1 هەفتە",
    other: "{{count}} هەفتە"
  },
  aboutXMonths: {
    one: "داوروبەری 1 مانگ",
    other: "دەوروبەری {{count}} مانگ"
  },
  xMonths: {
    one: "1 مانگ",
    other: "{{count}} مانگ"
  },
  aboutXYears: {
    one: "دەوروبەری  1 ساڵ",
    other: "دەوروبەری {{count}} ساڵ"
  },
  xYears: {
    one: "1 ساڵ",
    other: "{{count}} ساڵ"
  },
  overXYears: {
    one: "زیاتر لە ساڵێک",
    other: "زیاتر لە {{count}} ساڵ"
  },
  almostXYears: {
    one: "بەنزیکەیی ساڵێک  ",
    other: "بەنزیکەیی {{count}} ساڵ"
  }
}, formatDistance$16 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$15[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "لە ماوەی " + p + "دا" : p + "پێش ئێستا" : p;
}, dateFormats$1e = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$1e = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1e = {
  full: "{{date}} 'کاتژمێر' {{time}}",
  long: "{{date}} 'کاتژمێر' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1e = {
  date: buildFormatLongFn({
    formats: dateFormats$1e,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1e,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1e,
    defaultWidth: "full"
  })
}, formatRelativeLocale$16 = {
  lastWeek: "'هەفتەی ڕابردوو' eeee 'کاتژمێر' p",
  yesterday: "'دوێنێ کاتژمێر' p",
  today: "'ئەمڕۆ کاتژمێر' p",
  tomorrow: "'بەیانی کاتژمێر' p",
  nextWeek: "eeee 'کاتژمێر' p",
  other: "P"
}, formatRelative$16 = (u, l, f, p) => formatRelativeLocale$16[u], eraValues$16 = {
  narrow: ["پ", "د"],
  abbreviated: ["پ-ز", "د-ز"],
  wide: ["پێش زاین", "دوای زاین"]
}, quarterValues$16 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["چ1م", "چ2م", "چ3م", "چ4م"],
  wide: ["چارەگی یەکەم", "چارەگی دووەم", "چارەگی سێیەم", "چارەگی چوارەم"]
}, monthValues$16 = {
  narrow: [
    "ک-د",
    "ش",
    "ئا",
    "ن",
    "م",
    "ح",
    "ت",
    "ئا",
    "ئە",
    "تش-ی",
    "تش-د",
    "ک-ی"
  ],
  abbreviated: [
    "کان-دوو",
    "شوب",
    "ئاد",
    "نیس",
    "مایس",
    "حوز",
    "تەم",
    "ئاب",
    "ئەل",
    "تش-یەک",
    "تش-دوو",
    "کان-یەک"
  ],
  wide: [
    "کانوونی دووەم",
    "شوبات",
    "ئادار",
    "نیسان",
    "مایس",
    "حوزەیران",
    "تەمموز",
    "ئاب",
    "ئەیلول",
    "تشرینی یەکەم",
    "تشرینی دووەم",
    "کانوونی یەکەم"
  ]
}, dayValues$16 = {
  narrow: ["ی-ش", "د-ش", "س-ش", "چ-ش", "پ-ش", "هە", "ش"],
  short: ["یە-شە", "دوو-شە", "سێ-شە", "چو-شە", "پێ-شە", "هەی", "شە"],
  abbreviated: [
    "یەک-شەم",
    "دوو-شەم",
    "سێ-شەم",
    "چوار-شەم",
    "پێنج-شەم",
    "هەینی",
    "شەمە"
  ],
  wide: [
    "یەک شەمە",
    "دوو شەمە",
    "سێ شەمە",
    "چوار شەمە",
    "پێنج شەمە",
    "هەینی",
    "شەمە"
  ]
}, dayPeriodValues$16 = {
  narrow: {
    am: "پ",
    pm: "د",
    midnight: "ن-ش",
    noon: "ن",
    morning: "بەیانی",
    afternoon: "دوای نیوەڕۆ",
    evening: "ئێوارە",
    night: "شەو"
  },
  abbreviated: {
    am: "پ-ن",
    pm: "د-ن",
    midnight: "نیوە شەو",
    noon: "نیوەڕۆ",
    morning: "بەیانی",
    afternoon: "دوای نیوەڕۆ",
    evening: "ئێوارە",
    night: "شەو"
  },
  wide: {
    am: "پێش نیوەڕۆ",
    pm: "دوای نیوەڕۆ",
    midnight: "نیوە شەو",
    noon: "نیوەڕۆ",
    morning: "بەیانی",
    afternoon: "دوای نیوەڕۆ",
    evening: "ئێوارە",
    night: "شەو"
  }
}, formattingDayPeriodValues$T = {
  narrow: {
    am: "پ",
    pm: "د",
    midnight: "ن-ش",
    noon: "ن",
    morning: "لە بەیانیدا",
    afternoon: "لە دوای نیوەڕۆدا",
    evening: "لە ئێوارەدا",
    night: "لە شەودا"
  },
  abbreviated: {
    am: "پ-ن",
    pm: "د-ن",
    midnight: "نیوە شەو",
    noon: "نیوەڕۆ",
    morning: "لە بەیانیدا",
    afternoon: "لە دوای نیوەڕۆدا",
    evening: "لە ئێوارەدا",
    night: "لە شەودا"
  },
  wide: {
    am: "پێش نیوەڕۆ",
    pm: "دوای نیوەڕۆ",
    midnight: "نیوە شەو",
    noon: "نیوەڕۆ",
    morning: "لە بەیانیدا",
    afternoon: "لە دوای نیوەڕۆدا",
    evening: "لە ئێوارەدا",
    night: "لە شەودا"
  }
}, ordinalNumber$16 = (u, l) => String(u), localize$16 = {
  ordinalNumber: ordinalNumber$16,
  era: buildLocalizeFn({
    values: eraValues$16,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$16,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$16,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$16,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$16,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$T,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$15 = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$15 = /\d+/i, matchEraPatterns$15 = {
  narrow: /^(پ|د)/i,
  abbreviated: /^(پ-ز|د.ز)/i,
  wide: /^(پێش زاین| دوای زاین)/i
}, parseEraPatterns$15 = {
  any: [/^د/g, /^پ/g]
}, matchQuarterPatterns$15 = {
  narrow: /^[1234]/i,
  abbreviated: /^م[1234]چ/i,
  wide: /^(یەکەم|دووەم|سێیەم| چوارەم) (چارەگی)? quarter/i
}, parseQuarterPatterns$15 = {
  wide: [/چارەگی یەکەم/, /چارەگی دووەم/, /چارەگی سيیەم/, /چارەگی چوارەم/],
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$15 = {
  narrow: /^(ک-د|ش|ئا|ن|م|ح|ت|ئە|تش-ی|تش-د|ک-ی)/i,
  abbreviated: /^(کان-دوو|شوب|ئاد|نیس|مایس|حوز|تەم|ئاب|ئەل|تش-یەک|تش-دوو|کان-یەک)/i,
  wide: /^(کانوونی دووەم|شوبات|ئادار|نیسان|مایس|حوزەیران|تەمموز|ئاب|ئەیلول|تشرینی یەکەم|تشرینی دووەم|کانوونی یەکەم)/i
}, parseMonthPatterns$15 = {
  narrow: [
    /^ک-د/i,
    /^ش/i,
    /^ئا/i,
    /^ن/i,
    /^م/i,
    /^ح/i,
    /^ت/i,
    /^ئا/i,
    /^ئە/i,
    /^تش-ی/i,
    /^تش-د/i,
    /^ک-ی/i
  ],
  any: [
    /^کان-دوو/i,
    /^شوب/i,
    /^ئاد/i,
    /^نیس/i,
    /^مایس/i,
    /^حوز/i,
    /^تەم/i,
    /^ئاب/i,
    /^ئەل/i,
    /^تش-یەک/i,
    /^تش-دوو/i,
    /^|کان-یەک/i
  ]
}, matchDayPatterns$15 = {
  narrow: /^(ش|ی|د|س|چ|پ|هە)/i,
  short: /^(یە-شە|دوو-شە|سێ-شە|چو-شە|پێ-شە|هە|شە)/i,
  abbreviated: /^(یەک-شەم|دوو-شەم|سێ-شەم|چوار-شەم|پێنخ-شەم|هەینی|شەمە)/i,
  wide: /^(یەک شەمە|دوو شەمە|سێ شەمە|چوار شەمە|پێنج شەمە|هەینی|شەمە)/i
}, parseDayPatterns$15 = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, matchDayPeriodPatterns$15 = {
  narrow: /^(پ|د|ن-ش|ن| (بەیانی|دوای نیوەڕۆ|ئێوارە|شەو))/i,
  abbreviated: /^(پ-ن|د-ن|نیوە شەو|نیوەڕۆ|بەیانی|دوای نیوەڕۆ|ئێوارە|شەو)/,
  wide: /^(پێش نیوەڕۆ|دوای نیوەڕۆ|نیوەڕۆ|نیوە شەو|لەبەیانیدا|لەدواینیوەڕۆدا|لە ئێوارەدا|لە شەودا)/,
  any: /^(پ|د|بەیانی|نیوەڕۆ|ئێوارە|شەو)/
}, parseDayPeriodPatterns$15 = {
  any: {
    am: /^د/i,
    pm: /^پ/i,
    midnight: /^ن-ش/i,
    noon: /^ن/i,
    morning: /بەیانی/i,
    afternoon: /دواینیوەڕۆ/i,
    evening: /ئێوارە/i,
    night: /شەو/i
  }
}, match$16 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$15,
    parsePattern: parseOrdinalNumberPattern$15,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$15,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$15,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$15,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$15,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$15,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$15,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$15,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$15,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$15,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$15,
    defaultParseWidth: "any"
  })
}, ckb = {
  code: "ckb",
  formatDistance: formatDistance$16,
  formatLong: formatLong$1e,
  formatRelative: formatRelative$16,
  localize: localize$16,
  match: match$16,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$14 = {
  lessThanXSeconds: {
    one: {
      regular: "méně než 1 sekunda",
      past: "před méně než 1 sekundou",
      future: "za méně než 1 sekundu"
    },
    few: {
      regular: "méně než {{count}} sekundy",
      past: "před méně než {{count}} sekundami",
      future: "za méně než {{count}} sekundy"
    },
    many: {
      regular: "méně než {{count}} sekund",
      past: "před méně než {{count}} sekundami",
      future: "za méně než {{count}} sekund"
    }
  },
  xSeconds: {
    one: {
      regular: "1 sekunda",
      past: "před 1 sekundou",
      future: "za 1 sekundu"
    },
    few: {
      regular: "{{count}} sekundy",
      past: "před {{count}} sekundami",
      future: "za {{count}} sekundy"
    },
    many: {
      regular: "{{count}} sekund",
      past: "před {{count}} sekundami",
      future: "za {{count}} sekund"
    }
  },
  halfAMinute: {
    type: "other",
    other: {
      regular: "půl minuty",
      past: "před půl minutou",
      future: "za půl minuty"
    }
  },
  lessThanXMinutes: {
    one: {
      regular: "méně než 1 minuta",
      past: "před méně než 1 minutou",
      future: "za méně než 1 minutu"
    },
    few: {
      regular: "méně než {{count}} minuty",
      past: "před méně než {{count}} minutami",
      future: "za méně než {{count}} minuty"
    },
    many: {
      regular: "méně než {{count}} minut",
      past: "před méně než {{count}} minutami",
      future: "za méně než {{count}} minut"
    }
  },
  xMinutes: {
    one: {
      regular: "1 minuta",
      past: "před 1 minutou",
      future: "za 1 minutu"
    },
    few: {
      regular: "{{count}} minuty",
      past: "před {{count}} minutami",
      future: "za {{count}} minuty"
    },
    many: {
      regular: "{{count}} minut",
      past: "před {{count}} minutami",
      future: "za {{count}} minut"
    }
  },
  aboutXHours: {
    one: {
      regular: "přibližně 1 hodina",
      past: "přibližně před 1 hodinou",
      future: "přibližně za 1 hodinu"
    },
    few: {
      regular: "přibližně {{count}} hodiny",
      past: "přibližně před {{count}} hodinami",
      future: "přibližně za {{count}} hodiny"
    },
    many: {
      regular: "přibližně {{count}} hodin",
      past: "přibližně před {{count}} hodinami",
      future: "přibližně za {{count}} hodin"
    }
  },
  xHours: {
    one: {
      regular: "1 hodina",
      past: "před 1 hodinou",
      future: "za 1 hodinu"
    },
    few: {
      regular: "{{count}} hodiny",
      past: "před {{count}} hodinami",
      future: "za {{count}} hodiny"
    },
    many: {
      regular: "{{count}} hodin",
      past: "před {{count}} hodinami",
      future: "za {{count}} hodin"
    }
  },
  xDays: {
    one: {
      regular: "1 den",
      past: "před 1 dnem",
      future: "za 1 den"
    },
    few: {
      regular: "{{count}} dny",
      past: "před {{count}} dny",
      future: "za {{count}} dny"
    },
    many: {
      regular: "{{count}} dní",
      past: "před {{count}} dny",
      future: "za {{count}} dní"
    }
  },
  aboutXWeeks: {
    one: {
      regular: "přibližně 1 týden",
      past: "přibližně před 1 týdnem",
      future: "přibližně za 1 týden"
    },
    few: {
      regular: "přibližně {{count}} týdny",
      past: "přibližně před {{count}} týdny",
      future: "přibližně za {{count}} týdny"
    },
    many: {
      regular: "přibližně {{count}} týdnů",
      past: "přibližně před {{count}} týdny",
      future: "přibližně za {{count}} týdnů"
    }
  },
  xWeeks: {
    one: {
      regular: "1 týden",
      past: "před 1 týdnem",
      future: "za 1 týden"
    },
    few: {
      regular: "{{count}} týdny",
      past: "před {{count}} týdny",
      future: "za {{count}} týdny"
    },
    many: {
      regular: "{{count}} týdnů",
      past: "před {{count}} týdny",
      future: "za {{count}} týdnů"
    }
  },
  aboutXMonths: {
    one: {
      regular: "přibližně 1 měsíc",
      past: "přibližně před 1 měsícem",
      future: "přibližně za 1 měsíc"
    },
    few: {
      regular: "přibližně {{count}} měsíce",
      past: "přibližně před {{count}} měsíci",
      future: "přibližně za {{count}} měsíce"
    },
    many: {
      regular: "přibližně {{count}} měsíců",
      past: "přibližně před {{count}} měsíci",
      future: "přibližně za {{count}} měsíců"
    }
  },
  xMonths: {
    one: {
      regular: "1 měsíc",
      past: "před 1 měsícem",
      future: "za 1 měsíc"
    },
    few: {
      regular: "{{count}} měsíce",
      past: "před {{count}} měsíci",
      future: "za {{count}} měsíce"
    },
    many: {
      regular: "{{count}} měsíců",
      past: "před {{count}} měsíci",
      future: "za {{count}} měsíců"
    }
  },
  aboutXYears: {
    one: {
      regular: "přibližně 1 rok",
      past: "přibližně před 1 rokem",
      future: "přibližně za 1 rok"
    },
    few: {
      regular: "přibližně {{count}} roky",
      past: "přibližně před {{count}} roky",
      future: "přibližně za {{count}} roky"
    },
    many: {
      regular: "přibližně {{count}} roků",
      past: "přibližně před {{count}} roky",
      future: "přibližně za {{count}} roků"
    }
  },
  xYears: {
    one: {
      regular: "1 rok",
      past: "před 1 rokem",
      future: "za 1 rok"
    },
    few: {
      regular: "{{count}} roky",
      past: "před {{count}} roky",
      future: "za {{count}} roky"
    },
    many: {
      regular: "{{count}} roků",
      past: "před {{count}} roky",
      future: "za {{count}} roků"
    }
  },
  overXYears: {
    one: {
      regular: "více než 1 rok",
      past: "před více než 1 rokem",
      future: "za více než 1 rok"
    },
    few: {
      regular: "více než {{count}} roky",
      past: "před více než {{count}} roky",
      future: "za více než {{count}} roky"
    },
    many: {
      regular: "více než {{count}} roků",
      past: "před více než {{count}} roky",
      future: "za více než {{count}} roků"
    }
  },
  almostXYears: {
    one: {
      regular: "skoro 1 rok",
      past: "skoro před 1 rokem",
      future: "skoro za 1 rok"
    },
    few: {
      regular: "skoro {{count}} roky",
      past: "skoro před {{count}} roky",
      future: "skoro za {{count}} roky"
    },
    many: {
      regular: "skoro {{count}} roků",
      past: "skoro před {{count}} roky",
      future: "skoro za {{count}} roků"
    }
  }
}, formatDistance$15 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$14[u];
  m.type === "other" ? p = m.other : l === 1 ? p = m.one : l > 1 && l < 5 ? p = m.few : p = m.many;
  const b = f?.addSuffix === !0, y = f?.comparison;
  let v;
  return b && y === -1 ? v = p.past : b && y === 1 ? v = p.future : v = p.regular, v.replace("{{count}}", String(l));
}, dateFormats$1d = {
  full: "EEEE, d. MMMM yyyy",
  long: "d. MMMM yyyy",
  medium: "d. M. yyyy",
  short: "dd.MM.yyyy"
}, timeFormats$1d = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$1d = {
  full: "{{date}} 'v' {{time}}",
  long: "{{date}} 'v' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1d = {
  date: buildFormatLongFn({
    formats: dateFormats$1d,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1d,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1d,
    defaultWidth: "full"
  })
}, accusativeWeekdays$5 = [
  "neděli",
  "pondělí",
  "úterý",
  "středu",
  "čtvrtek",
  "pátek",
  "sobotu"
], formatRelativeLocale$15 = {
  lastWeek: "'poslední' eeee 've' p",
  yesterday: "'včera v' p",
  today: "'dnes v' p",
  tomorrow: "'zítra v' p",
  nextWeek: (u) => {
    const l = u.getDay();
    return "'v " + accusativeWeekdays$5[l] + " o' p";
  },
  other: "P"
}, formatRelative$15 = (u, l) => {
  const f = formatRelativeLocale$15[u];
  return typeof f == "function" ? f(l) : f;
}, eraValues$15 = {
  narrow: ["př. n. l.", "n. l."],
  abbreviated: ["př. n. l.", "n. l."],
  wide: ["před naším letopočtem", "našeho letopočtu"]
}, quarterValues$15 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1. čtvrtletí", "2. čtvrtletí", "3. čtvrtletí", "4. čtvrtletí"],
  wide: ["1. čtvrtletí", "2. čtvrtletí", "3. čtvrtletí", "4. čtvrtletí"]
}, monthValues$15 = {
  narrow: ["L", "Ú", "B", "D", "K", "Č", "Č", "S", "Z", "Ř", "L", "P"],
  abbreviated: [
    "led",
    "úno",
    "bře",
    "dub",
    "kvě",
    "čvn",
    "čvc",
    "srp",
    "zář",
    "říj",
    "lis",
    "pro"
  ],
  wide: [
    "leden",
    "únor",
    "březen",
    "duben",
    "květen",
    "červen",
    "červenec",
    "srpen",
    "září",
    "říjen",
    "listopad",
    "prosinec"
  ]
}, formattingMonthValues$f = {
  narrow: ["L", "Ú", "B", "D", "K", "Č", "Č", "S", "Z", "Ř", "L", "P"],
  abbreviated: [
    "led",
    "úno",
    "bře",
    "dub",
    "kvě",
    "čvn",
    "čvc",
    "srp",
    "zář",
    "říj",
    "lis",
    "pro"
  ],
  wide: [
    "ledna",
    "února",
    "března",
    "dubna",
    "května",
    "června",
    "července",
    "srpna",
    "září",
    "října",
    "listopadu",
    "prosince"
  ]
}, dayValues$15 = {
  narrow: ["ne", "po", "út", "st", "čt", "pá", "so"],
  short: ["ne", "po", "út", "st", "čt", "pá", "so"],
  abbreviated: ["ned", "pon", "úte", "stř", "čtv", "pát", "sob"],
  wide: ["neděle", "pondělí", "úterý", "středa", "čtvrtek", "pátek", "sobota"]
}, dayPeriodValues$15 = {
  narrow: {
    am: "dop.",
    pm: "odp.",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  },
  abbreviated: {
    am: "dop.",
    pm: "odp.",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  },
  wide: {
    am: "dopoledne",
    pm: "odpoledne",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  }
}, formattingDayPeriodValues$S = {
  narrow: {
    am: "dop.",
    pm: "odp.",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  },
  abbreviated: {
    am: "dop.",
    pm: "odp.",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  },
  wide: {
    am: "dopoledne",
    pm: "odpoledne",
    midnight: "půlnoc",
    noon: "poledne",
    morning: "ráno",
    afternoon: "odpoledne",
    evening: "večer",
    night: "noc"
  }
}, ordinalNumber$15 = (u, l) => Number(u) + ".", localize$15 = {
  ordinalNumber: ordinalNumber$15,
  era: buildLocalizeFn({
    values: eraValues$15,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$15,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$15,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$f,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$15,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$15,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$S,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$14 = /^(\d+)\.?/i, parseOrdinalNumberPattern$14 = /\d+/i, matchEraPatterns$14 = {
  narrow: /^(p[řr](\.|ed) Kr\.|p[řr](\.|ed) n\. l\.|po Kr\.|n\. l\.)/i,
  abbreviated: /^(p[řr](\.|ed) Kr\.|p[řr](\.|ed) n\. l\.|po Kr\.|n\. l\.)/i,
  wide: /^(p[řr](\.|ed) Kristem|p[řr](\.|ed) na[šs][íi]m letopo[čc]tem|po Kristu|na[šs]eho letopo[čc]tu)/i
}, parseEraPatterns$14 = {
  any: [/^p[řr]/i, /^(po|n)/i]
}, matchQuarterPatterns$14 = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]\. [čc]tvrtlet[íi]/i,
  wide: /^[1234]\. [čc]tvrtlet[íi]/i
}, parseQuarterPatterns$14 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$14 = {
  narrow: /^[lúubdkčcszřrlp]/i,
  abbreviated: /^(led|[úu]no|b[řr]e|dub|kv[ěe]|[čc]vn|[čc]vc|srp|z[áa][řr]|[řr][íi]j|lis|pro)/i,
  wide: /^(leden|ledna|[úu]nora?|b[řr]ezen|b[řr]ezna|duben|dubna|kv[ěe]ten|kv[ěe]tna|[čc]erven(ec|ce)?|[čc]ervna|srpen|srpna|z[áa][řr][íi]|[řr][íi]jen|[řr][íi]jna|listopad(a|u)?|prosinec|prosince)/i
}, parseMonthPatterns$14 = {
  narrow: [
    /^l/i,
    /^[úu]/i,
    /^b/i,
    /^d/i,
    /^k/i,
    /^[čc]/i,
    /^[čc]/i,
    /^s/i,
    /^z/i,
    /^[řr]/i,
    /^l/i,
    /^p/i
  ],
  any: [
    /^led/i,
    /^[úu]n/i,
    /^b[řr]e/i,
    /^dub/i,
    /^kv[ěe]/i,
    /^[čc]vn|[čc]erven(?!\w)|[čc]ervna/i,
    /^[čc]vc|[čc]erven(ec|ce)/i,
    /^srp/i,
    /^z[áa][řr]/i,
    /^[řr][íi]j/i,
    /^lis/i,
    /^pro/i
  ]
}, matchDayPatterns$14 = {
  narrow: /^[npuúsčps]/i,
  short: /^(ne|po|[úu]t|st|[čc]t|p[áa]|so)/i,
  abbreviated: /^(ned|pon|[úu]te|st[rř]|[čc]tv|p[áa]t|sob)/i,
  wide: /^(ned[ěe]le|pond[ěe]l[íi]|[úu]ter[ýy]|st[řr]eda|[čc]tvrtek|p[áa]tek|sobota)/i
}, parseDayPatterns$14 = {
  narrow: [/^n/i, /^p/i, /^[úu]/i, /^s/i, /^[čc]/i, /^p/i, /^s/i],
  any: [/^ne/i, /^po/i, /^[úu]t/i, /^st/i, /^[čc]t/i, /^p[áa]/i, /^so/i]
}, matchDayPeriodPatterns$14 = {
  any: /^dopoledne|dop\.?|odpoledne|odp\.?|p[ůu]lnoc|poledne|r[áa]no|odpoledne|ve[čc]er|(v )?noci?/i
}, parseDayPeriodPatterns$14 = {
  any: {
    am: /^dop/i,
    pm: /^odp/i,
    midnight: /^p[ůu]lnoc/i,
    noon: /^poledne/i,
    morning: /r[áa]no/i,
    afternoon: /odpoledne/i,
    evening: /ve[čc]er/i,
    night: /noc/i
  }
}, match$15 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$14,
    parsePattern: parseOrdinalNumberPattern$14,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$14,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$14,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$14,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$14,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$14,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$14,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$14,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$14,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$14,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$14,
    defaultParseWidth: "any"
  })
}, cs = {
  code: "cs",
  formatDistance: formatDistance$15,
  formatLong: formatLong$1d,
  formatRelative: formatRelative$15,
  localize: localize$15,
  match: match$15,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$13 = {
  lessThanXSeconds: {
    one: "llai na eiliad",
    other: "llai na {{count}} eiliad"
  },
  xSeconds: {
    one: "1 eiliad",
    other: "{{count}} eiliad"
  },
  halfAMinute: "hanner munud",
  lessThanXMinutes: {
    one: "llai na munud",
    two: "llai na 2 funud",
    other: "llai na {{count}} munud"
  },
  xMinutes: {
    one: "1 munud",
    two: "2 funud",
    other: "{{count}} munud"
  },
  aboutXHours: {
    one: "tua 1 awr",
    other: "tua {{count}} awr"
  },
  xHours: {
    one: "1 awr",
    other: "{{count}} awr"
  },
  xDays: {
    one: "1 diwrnod",
    two: "2 ddiwrnod",
    other: "{{count}} diwrnod"
  },
  aboutXWeeks: {
    one: "tua 1 wythnos",
    two: "tua pythefnos",
    other: "tua {{count}} wythnos"
  },
  xWeeks: {
    one: "1 wythnos",
    two: "pythefnos",
    other: "{{count}} wythnos"
  },
  aboutXMonths: {
    one: "tua 1 mis",
    two: "tua 2 fis",
    other: "tua {{count}} mis"
  },
  xMonths: {
    one: "1 mis",
    two: "2 fis",
    other: "{{count}} mis"
  },
  aboutXYears: {
    one: "tua 1 flwyddyn",
    two: "tua 2 flynedd",
    other: "tua {{count}} mlynedd"
  },
  xYears: {
    one: "1 flwyddyn",
    two: "2 flynedd",
    other: "{{count}} mlynedd"
  },
  overXYears: {
    one: "dros 1 flwyddyn",
    two: "dros 2 flynedd",
    other: "dros {{count}} mlynedd"
  },
  almostXYears: {
    one: "bron 1 flwyddyn",
    two: "bron 2 flynedd",
    other: "bron {{count}} mlynedd"
  }
}, formatDistance$14 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$13[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 2 && m.two ? p = m.two : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "mewn " + p : p + " yn ôl" : p;
}, dateFormats$1c = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "dd/MM/yyyy"
}, timeFormats$1c = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$1c = {
  full: "{{date}} 'am' {{time}}",
  long: "{{date}} 'am' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$1c = {
  date: buildFormatLongFn({
    formats: dateFormats$1c,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1c,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1c,
    defaultWidth: "full"
  })
}, formatRelativeLocale$14 = {
  lastWeek: "eeee 'diwethaf am' p",
  yesterday: "'ddoe am' p",
  today: "'heddiw am' p",
  tomorrow: "'yfory am' p",
  nextWeek: "eeee 'am' p",
  other: "P"
}, formatRelative$14 = (u, l, f, p) => formatRelativeLocale$14[u], eraValues$14 = {
  narrow: ["C", "O"],
  abbreviated: ["CC", "OC"],
  wide: ["Cyn Crist", "Ar ôl Crist"]
}, quarterValues$14 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Ch1", "Ch2", "Ch3", "Ch4"],
  wide: ["Chwarter 1af", "2ail chwarter", "3ydd chwarter", "4ydd chwarter"]
}, monthValues$14 = {
  narrow: ["I", "Ch", "Ma", "E", "Mi", "Me", "G", "A", "Md", "H", "T", "Rh"],
  abbreviated: [
    "Ion",
    "Chwe",
    "Maw",
    "Ebr",
    "Mai",
    "Meh",
    "Gor",
    "Aws",
    "Med",
    "Hyd",
    "Tach",
    "Rhag"
  ],
  wide: [
    "Ionawr",
    "Chwefror",
    "Mawrth",
    "Ebrill",
    "Mai",
    "Mehefin",
    "Gorffennaf",
    "Awst",
    "Medi",
    "Hydref",
    "Tachwedd",
    "Rhagfyr"
  ]
}, dayValues$14 = {
  narrow: ["S", "Ll", "M", "M", "I", "G", "S"],
  short: ["Su", "Ll", "Ma", "Me", "Ia", "Gw", "Sa"],
  abbreviated: ["Sul", "Llun", "Maw", "Mer", "Iau", "Gwe", "Sad"],
  wide: [
    "dydd Sul",
    "dydd Llun",
    "dydd Mawrth",
    "dydd Mercher",
    "dydd Iau",
    "dydd Gwener",
    "dydd Sadwrn"
  ]
}, dayPeriodValues$14 = {
  narrow: {
    am: "b",
    pm: "h",
    midnight: "hn",
    noon: "hd",
    morning: "bore",
    afternoon: "prynhawn",
    evening: "gyda'r nos",
    night: "nos"
  },
  abbreviated: {
    am: "yb",
    pm: "yh",
    midnight: "hanner nos",
    noon: "hanner dydd",
    morning: "bore",
    afternoon: "prynhawn",
    evening: "gyda'r nos",
    night: "nos"
  },
  wide: {
    am: "y.b.",
    pm: "y.h.",
    midnight: "hanner nos",
    noon: "hanner dydd",
    morning: "bore",
    afternoon: "prynhawn",
    evening: "gyda'r nos",
    night: "nos"
  }
}, formattingDayPeriodValues$R = {
  narrow: {
    am: "b",
    pm: "h",
    midnight: "hn",
    noon: "hd",
    morning: "yn y bore",
    afternoon: "yn y prynhawn",
    evening: "gyda'r nos",
    night: "yn y nos"
  },
  abbreviated: {
    am: "yb",
    pm: "yh",
    midnight: "hanner nos",
    noon: "hanner dydd",
    morning: "yn y bore",
    afternoon: "yn y prynhawn",
    evening: "gyda'r nos",
    night: "yn y nos"
  },
  wide: {
    am: "y.b.",
    pm: "y.h.",
    midnight: "hanner nos",
    noon: "hanner dydd",
    morning: "yn y bore",
    afternoon: "yn y prynhawn",
    evening: "gyda'r nos",
    night: "yn y nos"
  }
}, ordinalNumber$14 = (u, l) => {
  const f = Number(u);
  if (f < 20)
    switch (f) {
      case 0:
        return f + "fed";
      case 1:
        return f + "af";
      case 2:
        return f + "ail";
      case 3:
      case 4:
        return f + "ydd";
      case 5:
      case 6:
        return f + "ed";
      case 7:
      case 8:
      case 9:
      case 10:
      case 12:
      case 15:
      case 18:
        return f + "fed";
      case 11:
      case 13:
      case 14:
      case 16:
      case 17:
      case 19:
        return f + "eg";
    }
  else if (f >= 50 && f <= 60 || f === 80 || f >= 100)
    return f + "fed";
  return f + "ain";
}, localize$14 = {
  ordinalNumber: ordinalNumber$14,
  era: buildLocalizeFn({
    values: eraValues$14,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$14,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$14,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$14,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$14,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$R,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$13 = /^(\d+)(af|ail|ydd|ed|fed|eg|ain)?/i, parseOrdinalNumberPattern$13 = /\d+/i, matchEraPatterns$13 = {
  narrow: /^(c|o)/i,
  abbreviated: /^(c\.?\s?c\.?|o\.?\s?c\.?)/i,
  wide: /^(cyn christ|ar ôl crist|ar ol crist)/i
}, parseEraPatterns$13 = {
  wide: [/^c/i, /^(ar ôl crist|ar ol crist)/i],
  any: [/^c/i, /^o/i]
}, matchQuarterPatterns$13 = {
  narrow: /^[1234]/i,
  abbreviated: /^ch[1234]/i,
  wide: /^(chwarter 1af)|([234](ail|ydd)? chwarter)/i
}, parseQuarterPatterns$13 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$13 = {
  narrow: /^(i|ch|m|e|g|a|h|t|rh)/i,
  abbreviated: /^(ion|chwe|maw|ebr|mai|meh|gor|aws|med|hyd|tach|rhag)/i,
  wide: /^(ionawr|chwefror|mawrth|ebrill|mai|mehefin|gorffennaf|awst|medi|hydref|tachwedd|rhagfyr)/i
}, parseMonthPatterns$13 = {
  narrow: [
    /^i/i,
    /^ch/i,
    /^m/i,
    /^e/i,
    /^m/i,
    /^m/i,
    /^g/i,
    /^a/i,
    /^m/i,
    /^h/i,
    /^t/i,
    /^rh/i
  ],
  any: [
    /^io/i,
    /^ch/i,
    /^maw/i,
    /^e/i,
    /^mai/i,
    /^meh/i,
    /^g/i,
    /^a/i,
    /^med/i,
    /^h/i,
    /^t/i,
    /^rh/i
  ]
}, matchDayPatterns$13 = {
  narrow: /^(s|ll|m|i|g)/i,
  short: /^(su|ll|ma|me|ia|gw|sa)/i,
  abbreviated: /^(sul|llun|maw|mer|iau|gwe|sad)/i,
  wide: /^dydd (sul|llun|mawrth|mercher|iau|gwener|sadwrn)/i
}, parseDayPatterns$13 = {
  narrow: [/^s/i, /^ll/i, /^m/i, /^m/i, /^i/i, /^g/i, /^s/i],
  wide: [
    /^dydd su/i,
    /^dydd ll/i,
    /^dydd ma/i,
    /^dydd me/i,
    /^dydd i/i,
    /^dydd g/i,
    /^dydd sa/i
  ],
  any: [/^su/i, /^ll/i, /^ma/i, /^me/i, /^i/i, /^g/i, /^sa/i]
}, matchDayPeriodPatterns$13 = {
  narrow: /^(b|h|hn|hd|(yn y|y|yr|gyda'r) (bore|prynhawn|nos|hwyr))/i,
  any: /^(y\.?\s?[bh]\.?|hanner nos|hanner dydd|(yn y|y|yr|gyda'r) (bore|prynhawn|nos|hwyr))/i
}, parseDayPeriodPatterns$13 = {
  any: {
    am: /^b|(y\.?\s?b\.?)/i,
    pm: /^h|(y\.?\s?h\.?)|(yr hwyr)/i,
    midnight: /^hn|hanner nos/i,
    noon: /^hd|hanner dydd/i,
    morning: /bore/i,
    afternoon: /prynhawn/i,
    evening: /^gyda'r nos$/i,
    night: /blah/i
  }
}, match$14 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$13,
    parsePattern: parseOrdinalNumberPattern$13,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$13,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$13,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$13,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$13,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$13,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$13,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$13,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$13,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$13,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$13,
    defaultParseWidth: "any"
  })
}, cy = {
  code: "cy",
  formatDistance: formatDistance$14,
  formatLong: formatLong$1c,
  formatRelative: formatRelative$14,
  localize: localize$14,
  match: match$14,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$12 = {
  lessThanXSeconds: {
    one: "mindre end ét sekund",
    other: "mindre end {{count}} sekunder"
  },
  xSeconds: {
    one: "1 sekund",
    other: "{{count}} sekunder"
  },
  halfAMinute: "ét halvt minut",
  lessThanXMinutes: {
    one: "mindre end ét minut",
    other: "mindre end {{count}} minutter"
  },
  xMinutes: {
    one: "1 minut",
    other: "{{count}} minutter"
  },
  aboutXHours: {
    one: "cirka 1 time",
    other: "cirka {{count}} timer"
  },
  xHours: {
    one: "1 time",
    other: "{{count}} timer"
  },
  xDays: {
    one: "1 dag",
    other: "{{count}} dage"
  },
  aboutXWeeks: {
    one: "cirka 1 uge",
    other: "cirka {{count}} uger"
  },
  xWeeks: {
    one: "1 uge",
    other: "{{count}} uger"
  },
  aboutXMonths: {
    one: "cirka 1 måned",
    other: "cirka {{count}} måneder"
  },
  xMonths: {
    one: "1 måned",
    other: "{{count}} måneder"
  },
  aboutXYears: {
    one: "cirka 1 år",
    other: "cirka {{count}} år"
  },
  xYears: {
    one: "1 år",
    other: "{{count}} år"
  },
  overXYears: {
    one: "over 1 år",
    other: "over {{count}} år"
  },
  almostXYears: {
    one: "næsten 1 år",
    other: "næsten {{count}} år"
  }
}, formatDistance$13 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$12[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "om " + p : p + " siden" : p;
}, dateFormats$1b = {
  full: "EEEE 'den' d. MMMM y",
  long: "d. MMMM y",
  medium: "d. MMM y",
  short: "dd/MM/y"
}, timeFormats$1b = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1b = {
  full: "{{date}} 'kl'. {{time}}",
  long: "{{date}} 'kl'. {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$1b = {
  date: buildFormatLongFn({
    formats: dateFormats$1b,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1b,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1b,
    defaultWidth: "full"
  })
}, formatRelativeLocale$13 = {
  lastWeek: "'sidste' eeee 'kl.' p",
  yesterday: "'i går kl.' p",
  today: "'i dag kl.' p",
  tomorrow: "'i morgen kl.' p",
  nextWeek: "'på' eeee 'kl.' p",
  other: "P"
}, formatRelative$13 = (u, l, f, p) => formatRelativeLocale$13[u], eraValues$13 = {
  narrow: ["fvt", "vt"],
  abbreviated: ["f.v.t.", "v.t."],
  wide: ["før vesterlandsk tidsregning", "vesterlandsk tidsregning"]
}, quarterValues$13 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1. kvt.", "2. kvt.", "3. kvt.", "4. kvt."],
  wide: ["1. kvartal", "2. kvartal", "3. kvartal", "4. kvartal"]
}, monthValues$13 = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "jan.",
    "feb.",
    "mar.",
    "apr.",
    "maj",
    "jun.",
    "jul.",
    "aug.",
    "sep.",
    "okt.",
    "nov.",
    "dec."
  ],
  wide: [
    "januar",
    "februar",
    "marts",
    "april",
    "maj",
    "juni",
    "juli",
    "august",
    "september",
    "oktober",
    "november",
    "december"
  ]
}, dayValues$13 = {
  narrow: ["S", "M", "T", "O", "T", "F", "L"],
  short: ["sø", "ma", "ti", "on", "to", "fr", "lø"],
  abbreviated: ["søn.", "man.", "tir.", "ons.", "tor.", "fre.", "lør."],
  wide: [
    "søndag",
    "mandag",
    "tirsdag",
    "onsdag",
    "torsdag",
    "fredag",
    "lørdag"
  ]
}, dayPeriodValues$13 = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnat",
    noon: "middag",
    morning: "morgen",
    afternoon: "eftermiddag",
    evening: "aften",
    night: "nat"
  }
}, formattingDayPeriodValues$Q = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnat",
    noon: "middag",
    morning: "om morgenen",
    afternoon: "om eftermiddagen",
    evening: "om aftenen",
    night: "om natten"
  }
}, ordinalNumber$13 = (u, l) => Number(u) + ".", localize$13 = {
  ordinalNumber: ordinalNumber$13,
  era: buildLocalizeFn({
    values: eraValues$13,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$13,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$13,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$13,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$13,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$Q,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$12 = /^(\d+)(\.)?/i, parseOrdinalNumberPattern$12 = /\d+/i, matchEraPatterns$12 = {
  narrow: /^(fKr|fvt|eKr|vt)/i,
  abbreviated: /^(f\.Kr\.?|f\.v\.t\.?|e\.Kr\.?|v\.t\.)/i,
  wide: /^(f.Kr.|før vesterlandsk tidsregning|e.Kr.|vesterlandsk tidsregning)/i
}, parseEraPatterns$12 = {
  any: [/^f/i, /^(v|e)/i]
}, matchQuarterPatterns$12 = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]. kvt\./i,
  wide: /^[1234]\.? kvartal/i
}, parseQuarterPatterns$12 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$12 = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan.|feb.|mar.|apr.|maj|jun.|jul.|aug.|sep.|okt.|nov.|dec.)/i,
  wide: /^(januar|februar|marts|april|maj|juni|juli|august|september|oktober|november|december)/i
}, parseMonthPatterns$12 = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^maj/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$12 = {
  narrow: /^[smtofl]/i,
  short: /^(søn.|man.|tir.|ons.|tor.|fre.|lør.)/i,
  abbreviated: /^(søn|man|tir|ons|tor|fre|lør)/i,
  wide: /^(søndag|mandag|tirsdag|onsdag|torsdag|fredag|lørdag)/i
}, parseDayPatterns$12 = {
  narrow: [/^s/i, /^m/i, /^t/i, /^o/i, /^t/i, /^f/i, /^l/i],
  any: [/^s/i, /^m/i, /^ti/i, /^o/i, /^to/i, /^f/i, /^l/i]
}, matchDayPeriodPatterns$12 = {
  narrow: /^(a|p|midnat|middag|(om) (morgenen|eftermiddagen|aftenen|natten))/i,
  any: /^([ap]\.?\s?m\.?|midnat|middag|(om) (morgenen|eftermiddagen|aftenen|natten))/i
}, parseDayPeriodPatterns$12 = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /midnat/i,
    noon: /middag/i,
    morning: /morgen/i,
    afternoon: /eftermiddag/i,
    evening: /aften/i,
    night: /nat/i
  }
}, match$13 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$12,
    parsePattern: parseOrdinalNumberPattern$12,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$12,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$12,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$12,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$12,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$12,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$12,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$12,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$12,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$12,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$12,
    defaultParseWidth: "any"
  })
}, da = {
  code: "da",
  formatDistance: formatDistance$13,
  formatLong: formatLong$1b,
  formatRelative: formatRelative$13,
  localize: localize$13,
  match: match$13,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$11 = {
  lessThanXSeconds: {
    standalone: {
      one: "weniger als 1 Sekunde",
      other: "weniger als {{count}} Sekunden"
    },
    withPreposition: {
      one: "weniger als 1 Sekunde",
      other: "weniger als {{count}} Sekunden"
    }
  },
  xSeconds: {
    standalone: {
      one: "1 Sekunde",
      other: "{{count}} Sekunden"
    },
    withPreposition: {
      one: "1 Sekunde",
      other: "{{count}} Sekunden"
    }
  },
  halfAMinute: {
    standalone: "eine halbe Minute",
    withPreposition: "einer halben Minute"
  },
  lessThanXMinutes: {
    standalone: {
      one: "weniger als 1 Minute",
      other: "weniger als {{count}} Minuten"
    },
    withPreposition: {
      one: "weniger als 1 Minute",
      other: "weniger als {{count}} Minuten"
    }
  },
  xMinutes: {
    standalone: {
      one: "1 Minute",
      other: "{{count}} Minuten"
    },
    withPreposition: {
      one: "1 Minute",
      other: "{{count}} Minuten"
    }
  },
  aboutXHours: {
    standalone: {
      one: "etwa 1 Stunde",
      other: "etwa {{count}} Stunden"
    },
    withPreposition: {
      one: "etwa 1 Stunde",
      other: "etwa {{count}} Stunden"
    }
  },
  xHours: {
    standalone: {
      one: "1 Stunde",
      other: "{{count}} Stunden"
    },
    withPreposition: {
      one: "1 Stunde",
      other: "{{count}} Stunden"
    }
  },
  xDays: {
    standalone: {
      one: "1 Tag",
      other: "{{count}} Tage"
    },
    withPreposition: {
      one: "1 Tag",
      other: "{{count}} Tagen"
    }
  },
  aboutXWeeks: {
    standalone: {
      one: "etwa 1 Woche",
      other: "etwa {{count}} Wochen"
    },
    withPreposition: {
      one: "etwa 1 Woche",
      other: "etwa {{count}} Wochen"
    }
  },
  xWeeks: {
    standalone: {
      one: "1 Woche",
      other: "{{count}} Wochen"
    },
    withPreposition: {
      one: "1 Woche",
      other: "{{count}} Wochen"
    }
  },
  aboutXMonths: {
    standalone: {
      one: "etwa 1 Monat",
      other: "etwa {{count}} Monate"
    },
    withPreposition: {
      one: "etwa 1 Monat",
      other: "etwa {{count}} Monaten"
    }
  },
  xMonths: {
    standalone: {
      one: "1 Monat",
      other: "{{count}} Monate"
    },
    withPreposition: {
      one: "1 Monat",
      other: "{{count}} Monaten"
    }
  },
  aboutXYears: {
    standalone: {
      one: "etwa 1 Jahr",
      other: "etwa {{count}} Jahre"
    },
    withPreposition: {
      one: "etwa 1 Jahr",
      other: "etwa {{count}} Jahren"
    }
  },
  xYears: {
    standalone: {
      one: "1 Jahr",
      other: "{{count}} Jahre"
    },
    withPreposition: {
      one: "1 Jahr",
      other: "{{count}} Jahren"
    }
  },
  overXYears: {
    standalone: {
      one: "mehr als 1 Jahr",
      other: "mehr als {{count}} Jahre"
    },
    withPreposition: {
      one: "mehr als 1 Jahr",
      other: "mehr als {{count}} Jahren"
    }
  },
  almostXYears: {
    standalone: {
      one: "fast 1 Jahr",
      other: "fast {{count}} Jahre"
    },
    withPreposition: {
      one: "fast 1 Jahr",
      other: "fast {{count}} Jahren"
    }
  }
}, formatDistance$12 = (u, l, f) => {
  let p;
  const m = f?.addSuffix ? formatDistanceLocale$11[u].withPreposition : formatDistanceLocale$11[u].standalone;
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "in " + p : "vor " + p : p;
}, dateFormats$1a = {
  full: "EEEE, do MMMM y",
  // Montag, 7. Januar 2018
  long: "do MMMM y",
  // 7. Januar 2018
  medium: "do MMM y",
  // 7. Jan. 2018
  short: "dd.MM.y"
  // 07.01.2018
}, timeFormats$1a = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$1a = {
  full: "{{date}} 'um' {{time}}",
  long: "{{date}} 'um' {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$1a = {
  date: buildFormatLongFn({
    formats: dateFormats$1a,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$1a,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$1a,
    defaultWidth: "full"
  })
}, formatRelativeLocale$12 = {
  lastWeek: "'letzten' eeee 'um' p",
  yesterday: "'gestern um' p",
  today: "'heute um' p",
  tomorrow: "'morgen um' p",
  nextWeek: "eeee 'um' p",
  other: "P"
}, formatRelative$12 = (u, l, f, p) => formatRelativeLocale$12[u], eraValues$12 = {
  narrow: ["v.Chr.", "n.Chr."],
  abbreviated: ["v.Chr.", "n.Chr."],
  wide: ["vor Christus", "nach Christus"]
}, quarterValues$12 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1. Quartal", "2. Quartal", "3. Quartal", "4. Quartal"]
}, monthValues$12 = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mär",
    "Apr",
    "Mai",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Okt",
    "Nov",
    "Dez"
  ],
  wide: [
    "Januar",
    "Februar",
    "März",
    "April",
    "Mai",
    "Juni",
    "Juli",
    "August",
    "September",
    "Oktober",
    "November",
    "Dezember"
  ]
}, formattingMonthValues$e = {
  narrow: monthValues$12.narrow,
  abbreviated: [
    "Jan.",
    "Feb.",
    "März",
    "Apr.",
    "Mai",
    "Juni",
    "Juli",
    "Aug.",
    "Sep.",
    "Okt.",
    "Nov.",
    "Dez."
  ],
  wide: monthValues$12.wide
}, dayValues$12 = {
  narrow: ["S", "M", "D", "M", "D", "F", "S"],
  short: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"],
  abbreviated: ["So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa."],
  wide: [
    "Sonntag",
    "Montag",
    "Dienstag",
    "Mittwoch",
    "Donnerstag",
    "Freitag",
    "Samstag"
  ]
}, dayPeriodValues$12 = {
  narrow: {
    am: "vm.",
    pm: "nm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachm.",
    evening: "Abend",
    night: "Nacht"
  },
  abbreviated: {
    am: "vorm.",
    pm: "nachm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachmittag",
    evening: "Abend",
    night: "Nacht"
  },
  wide: {
    am: "vormittags",
    pm: "nachmittags",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachmittag",
    evening: "Abend",
    night: "Nacht"
  }
}, formattingDayPeriodValues$P = {
  narrow: {
    am: "vm.",
    pm: "nm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachm.",
    evening: "abends",
    night: "nachts"
  },
  abbreviated: {
    am: "vorm.",
    pm: "nachm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachmittags",
    evening: "abends",
    night: "nachts"
  },
  wide: {
    am: "vormittags",
    pm: "nachmittags",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachmittags",
    evening: "abends",
    night: "nachts"
  }
}, ordinalNumber$12 = (u) => Number(u) + ".", localize$12 = {
  ordinalNumber: ordinalNumber$12,
  era: buildLocalizeFn({
    values: eraValues$12,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$12,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$12,
    formattingValues: formattingMonthValues$e,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$12,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$12,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$P,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$11 = /^(\d+)(\.)?/i, parseOrdinalNumberPattern$11 = /\d+/i, matchEraPatterns$11 = {
  narrow: /^(v\.? ?Chr\.?|n\.? ?Chr\.?)/i,
  abbreviated: /^(v\.? ?Chr\.?|n\.? ?Chr\.?)/i,
  wide: /^(vor Christus|vor unserer Zeitrechnung|nach Christus|unserer Zeitrechnung)/i
}, parseEraPatterns$11 = {
  any: [/^v/i, /^n/i]
}, matchQuarterPatterns$11 = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](\.)? Quartal/i
}, parseQuarterPatterns$11 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$11 = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(j[aä]n|feb|mär[z]?|apr|mai|jun[i]?|jul[i]?|aug|sep|okt|nov|dez)\.?/i,
  wide: /^(januar|februar|märz|april|mai|juni|juli|august|september|oktober|november|dezember)/i
}, parseMonthPatterns$11 = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^j[aä]/i,
    /^f/i,
    /^mär/i,
    /^ap/i,
    /^mai/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$11 = {
  narrow: /^[smdmf]/i,
  short: /^(so|mo|di|mi|do|fr|sa)/i,
  abbreviated: /^(son?|mon?|die?|mit?|don?|fre?|sam?)\.?/i,
  wide: /^(sonntag|montag|dienstag|mittwoch|donnerstag|freitag|samstag)/i
}, parseDayPatterns$11 = {
  any: [/^so/i, /^mo/i, /^di/i, /^mi/i, /^do/i, /^f/i, /^sa/i]
}, matchDayPeriodPatterns$11 = {
  narrow: /^(vm\.?|nm\.?|Mitternacht|Mittag|morgens|nachm\.?|abends|nachts)/i,
  abbreviated: /^(vorm\.?|nachm\.?|Mitternacht|Mittag|morgens|nachm\.?|abends|nachts)/i,
  wide: /^(vormittags|nachmittags|Mitternacht|Mittag|morgens|nachmittags|abends|nachts)/i
}, parseDayPeriodPatterns$11 = {
  any: {
    am: /^v/i,
    pm: /^n/i,
    midnight: /^Mitte/i,
    noon: /^Mitta/i,
    morning: /morgens/i,
    afternoon: /nachmittags/i,
    // will never be matched. Afternoon is matched by `pm`
    evening: /abends/i,
    night: /nachts/i
    // will never be matched. Night is matched by `pm`
  }
}, match$12 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$11,
    parsePattern: parseOrdinalNumberPattern$11,
    valueCallback: (u) => parseInt(u)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$11,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$11,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$11,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$11,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$11,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$11,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$11,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$11,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$11,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$11,
    defaultParseWidth: "any"
  })
}, de = {
  code: "de",
  formatDistance: formatDistance$12,
  formatLong: formatLong$1a,
  formatRelative: formatRelative$12,
  localize: localize$12,
  match: match$12,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, eraValues$11 = {
  narrow: ["v.Chr.", "n.Chr."],
  abbreviated: ["v.Chr.", "n.Chr."],
  wide: ["vor Christus", "nach Christus"]
}, quarterValues$11 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1. Quartal", "2. Quartal", "3. Quartal", "4. Quartal"]
}, monthValues$11 = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jän",
    "Feb",
    "Mär",
    "Apr",
    "Mai",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Okt",
    "Nov",
    "Dez"
  ],
  wide: [
    "Jänner",
    "Februar",
    "März",
    "April",
    "Mai",
    "Juni",
    "Juli",
    "August",
    "September",
    "Oktober",
    "November",
    "Dezember"
  ]
}, formattingMonthValues$d = {
  narrow: monthValues$11.narrow,
  abbreviated: [
    "Jän.",
    "Feb.",
    "März",
    "Apr.",
    "Mai",
    "Juni",
    "Juli",
    "Aug.",
    "Sep.",
    "Okt.",
    "Nov.",
    "Dez."
  ],
  wide: monthValues$11.wide
}, dayValues$11 = {
  narrow: ["S", "M", "D", "M", "D", "F", "S"],
  short: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"],
  abbreviated: ["So.", "Mo.", "Di.", "Mi.", "Do.", "Fr.", "Sa."],
  wide: [
    "Sonntag",
    "Montag",
    "Dienstag",
    "Mittwoch",
    "Donnerstag",
    "Freitag",
    "Samstag"
  ]
}, dayPeriodValues$11 = {
  narrow: {
    am: "vm.",
    pm: "nm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachm.",
    evening: "Abend",
    night: "Nacht"
  },
  abbreviated: {
    am: "vorm.",
    pm: "nachm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachmittag",
    evening: "Abend",
    night: "Nacht"
  },
  wide: {
    am: "vormittags",
    pm: "nachmittags",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "Morgen",
    afternoon: "Nachmittag",
    evening: "Abend",
    night: "Nacht"
  }
}, formattingDayPeriodValues$O = {
  narrow: {
    am: "vm.",
    pm: "nm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachm.",
    evening: "abends",
    night: "nachts"
  },
  abbreviated: {
    am: "vorm.",
    pm: "nachm.",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachmittags",
    evening: "abends",
    night: "nachts"
  },
  wide: {
    am: "vormittags",
    pm: "nachmittags",
    midnight: "Mitternacht",
    noon: "Mittag",
    morning: "morgens",
    afternoon: "nachmittags",
    evening: "abends",
    night: "nachts"
  }
}, ordinalNumber$11 = (u) => Number(u) + ".", localize$11 = {
  ordinalNumber: ordinalNumber$11,
  era: buildLocalizeFn({
    values: eraValues$11,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$11,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$11,
    formattingValues: formattingMonthValues$d,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$11,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$11,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$O,
    defaultFormattingWidth: "wide"
  })
}, deAT = {
  code: "de-AT",
  formatDistance: formatDistance$12,
  formatLong: formatLong$1a,
  formatRelative: formatRelative$12,
  localize: localize$11,
  match: match$12,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$10 = {
  lessThanXSeconds: {
    one: "λιγότερο από ένα δευτερόλεπτο",
    other: "λιγότερο από {{count}} δευτερόλεπτα"
  },
  xSeconds: {
    one: "1 δευτερόλεπτο",
    other: "{{count}} δευτερόλεπτα"
  },
  halfAMinute: "μισό λεπτό",
  lessThanXMinutes: {
    one: "λιγότερο από ένα λεπτό",
    other: "λιγότερο από {{count}} λεπτά"
  },
  xMinutes: {
    one: "1 λεπτό",
    other: "{{count}} λεπτά"
  },
  aboutXHours: {
    one: "περίπου 1 ώρα",
    other: "περίπου {{count}} ώρες"
  },
  xHours: {
    one: "1 ώρα",
    other: "{{count}} ώρες"
  },
  xDays: {
    one: "1 ημέρα",
    other: "{{count}} ημέρες"
  },
  aboutXWeeks: {
    one: "περίπου 1 εβδομάδα",
    other: "περίπου {{count}} εβδομάδες"
  },
  xWeeks: {
    one: "1 εβδομάδα",
    other: "{{count}} εβδομάδες"
  },
  aboutXMonths: {
    one: "περίπου 1 μήνας",
    other: "περίπου {{count}} μήνες"
  },
  xMonths: {
    one: "1 μήνας",
    other: "{{count}} μήνες"
  },
  aboutXYears: {
    one: "περίπου 1 χρόνο",
    other: "περίπου {{count}} χρόνια"
  },
  xYears: {
    one: "1 χρόνο",
    other: "{{count}} χρόνια"
  },
  overXYears: {
    one: "πάνω από 1 χρόνο",
    other: "πάνω από {{count}} χρόνια"
  },
  almostXYears: {
    one: "περίπου 1 χρόνο",
    other: "περίπου {{count}} χρόνια"
  }
}, formatDistance$11 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$10[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "σε " + p : p + " πριν" : p;
}, dateFormats$19 = {
  full: "EEEE, d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "d/M/yy"
}, timeFormats$19 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$19 = {
  full: "{{date}} - {{time}}",
  long: "{{date}} - {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$19 = {
  date: buildFormatLongFn({
    formats: dateFormats$19,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$19,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$19,
    defaultWidth: "full"
  })
}, formatRelativeLocale$11 = {
  lastWeek: (u) => u.getDay() === 6 ? "'το προηγούμενο' eeee 'στις' p" : "'την προηγούμενη' eeee 'στις' p",
  yesterday: "'χθες στις' p",
  today: "'σήμερα στις' p",
  tomorrow: "'αύριο στις' p",
  nextWeek: "eeee 'στις' p",
  other: "P"
}, formatRelative$11 = (u, l) => {
  const f = formatRelativeLocale$11[u];
  return typeof f == "function" ? f(l) : f;
}, eraValues$10 = {
  narrow: ["πΧ", "μΧ"],
  abbreviated: ["π.Χ.", "μ.Χ."],
  wide: ["προ Χριστού", "μετά Χριστόν"]
}, quarterValues$10 = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Τ1", "Τ2", "Τ3", "Τ4"],
  wide: ["1ο τρίμηνο", "2ο τρίμηνο", "3ο τρίμηνο", "4ο τρίμηνο"]
}, monthValues$10 = {
  narrow: ["Ι", "Φ", "Μ", "Α", "Μ", "Ι", "Ι", "Α", "Σ", "Ο", "Ν", "Δ"],
  abbreviated: [
    "Ιαν",
    "Φεβ",
    "Μάρ",
    "Απρ",
    "Μάι",
    "Ιούν",
    "Ιούλ",
    "Αύγ",
    "Σεπ",
    "Οκτ",
    "Νοέ",
    "Δεκ"
  ],
  wide: [
    "Ιανουάριος",
    "Φεβρουάριος",
    "Μάρτιος",
    "Απρίλιος",
    "Μάιος",
    "Ιούνιος",
    "Ιούλιος",
    "Αύγουστος",
    "Σεπτέμβριος",
    "Οκτώβριος",
    "Νοέμβριος",
    "Δεκέμβριος"
  ]
}, formattingMonthValues$c = {
  narrow: ["Ι", "Φ", "Μ", "Α", "Μ", "Ι", "Ι", "Α", "Σ", "Ο", "Ν", "Δ"],
  abbreviated: [
    "Ιαν",
    "Φεβ",
    "Μαρ",
    "Απρ",
    "Μαΐ",
    "Ιουν",
    "Ιουλ",
    "Αυγ",
    "Σεπ",
    "Οκτ",
    "Νοε",
    "Δεκ"
  ],
  wide: [
    "Ιανουαρίου",
    "Φεβρουαρίου",
    "Μαρτίου",
    "Απριλίου",
    "Μαΐου",
    "Ιουνίου",
    "Ιουλίου",
    "Αυγούστου",
    "Σεπτεμβρίου",
    "Οκτωβρίου",
    "Νοεμβρίου",
    "Δεκεμβρίου"
  ]
}, dayValues$10 = {
  narrow: ["Κ", "Δ", "T", "Τ", "Π", "Π", "Σ"],
  short: ["Κυ", "Δε", "Τρ", "Τε", "Πέ", "Πα", "Σά"],
  abbreviated: ["Κυρ", "Δευ", "Τρί", "Τετ", "Πέμ", "Παρ", "Σάβ"],
  wide: [
    "Κυριακή",
    "Δευτέρα",
    "Τρίτη",
    "Τετάρτη",
    "Πέμπτη",
    "Παρασκευή",
    "Σάββατο"
  ]
}, dayPeriodValues$10 = {
  narrow: {
    am: "πμ",
    pm: "μμ",
    midnight: "μεσάνυχτα",
    noon: "μεσημέρι",
    morning: "πρωί",
    afternoon: "απόγευμα",
    evening: "βράδυ",
    night: "νύχτα"
  },
  abbreviated: {
    am: "π.μ.",
    pm: "μ.μ.",
    midnight: "μεσάνυχτα",
    noon: "μεσημέρι",
    morning: "πρωί",
    afternoon: "απόγευμα",
    evening: "βράδυ",
    night: "νύχτα"
  },
  wide: {
    am: "π.μ.",
    pm: "μ.μ.",
    midnight: "μεσάνυχτα",
    noon: "μεσημέρι",
    morning: "πρωί",
    afternoon: "απόγευμα",
    evening: "βράδυ",
    night: "νύχτα"
  }
}, ordinalNumber$10 = (u, l) => {
  const f = Number(u), p = l?.unit;
  let m;
  return p === "year" || p === "month" ? m = "ος" : p === "week" || p === "dayOfYear" || p === "day" || p === "hour" || p === "date" ? m = "η" : m = "ο", f + m;
}, localize$10 = {
  ordinalNumber: ordinalNumber$10,
  era: buildLocalizeFn({
    values: eraValues$10,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$10,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$10,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$c,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$10,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$10,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$10 = /^(\d+)(ος|η|ο)?/i, parseOrdinalNumberPattern$10 = /\d+/i, matchEraPatterns$10 = {
  narrow: /^(πΧ|μΧ)/i,
  abbreviated: /^(π\.?\s?χ\.?|π\.?\s?κ\.?\s?χ\.?|μ\.?\s?χ\.?|κ\.?\s?χ\.?)/i,
  wide: /^(προ Χριστο(ύ|υ)|πριν απ(ό|ο) την Κοιν(ή|η) Χρονολογ(ί|ι)α|μετ(ά|α) Χριστ(ό|ο)ν|Κοιν(ή|η) Χρονολογ(ί|ι)α)/i
}, parseEraPatterns$10 = {
  any: [/^π/i, /^(μ|κ)/i]
}, matchQuarterPatterns$10 = {
  narrow: /^[1234]/i,
  abbreviated: /^τ[1234]/i,
  wide: /^[1234]ο? τρ(ί|ι)μηνο/i
}, parseQuarterPatterns$10 = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$10 = {
  narrow: /^[ιφμαμιιασονδ]/i,
  abbreviated: /^(ιαν|φεβ|μ[άα]ρ|απρ|μ[άα][ιΐ]|ιο[ύυ]ν|ιο[ύυ]λ|α[ύυ]γ|σεπ|οκτ|νο[έε]|δεκ)/i,
  wide: /^(μ[άα][ιΐ]|α[ύυ]γο[υύ]στ)(ος|ου)|(ιανου[άα]ρ|φεβρου[άα]ρ|μ[άα]ρτ|απρ[ίι]λ|ιο[ύυ]ν|ιο[ύυ]λ|σεπτ[έε]μβρ|οκτ[ώω]βρ|νο[έε]μβρ|δεκ[έε]μβρ)(ιος|ίου)/i
}, parseMonthPatterns$10 = {
  narrow: [
    /^ι/i,
    /^φ/i,
    /^μ/i,
    /^α/i,
    /^μ/i,
    /^ι/i,
    /^ι/i,
    /^α/i,
    /^σ/i,
    /^ο/i,
    /^ν/i,
    /^δ/i
  ],
  any: [
    /^ια/i,
    /^φ/i,
    /^μ[άα]ρ/i,
    /^απ/i,
    /^μ[άα][ιΐ]/i,
    /^ιο[ύυ]ν/i,
    /^ιο[ύυ]λ/i,
    /^α[ύυ]/i,
    /^σ/i,
    /^ο/i,
    /^ν/i,
    /^δ/i
  ]
}, matchDayPatterns$10 = {
  narrow: /^[κδτπσ]/i,
  short: /^(κυ|δε|τρ|τε|π[εέ]|π[αά]|σ[αά])/i,
  abbreviated: /^(κυρ|δευ|τρι|τετ|πεμ|παρ|σαβ)/i,
  wide: /^(κυριακ(ή|η)|δευτ(έ|ε)ρα|τρ(ί|ι)τη|τετ(ά|α)ρτη|π(έ|ε)μπτη|παρασκευ(ή|η)|σ(ά|α)ββατο)/i
}, parseDayPatterns$10 = {
  narrow: [/^κ/i, /^δ/i, /^τ/i, /^τ/i, /^π/i, /^π/i, /^σ/i],
  any: [/^κ/i, /^δ/i, /^τρ/i, /^τε/i, /^π[εέ]/i, /^π[αά]/i, /^σ/i]
}, matchDayPeriodPatterns$10 = {
  narrow: /^(πμ|μμ|μεσ(ά|α)νυχτα|μεσημ(έ|ε)ρι|πρω(ί|ι)|απ(ό|ο)γευμα|βρ(ά|α)δυ|ν(ύ|υ)χτα)/i,
  any: /^([πμ]\.?\s?μ\.?|μεσ(ά|α)νυχτα|μεσημ(έ|ε)ρι|πρω(ί|ι)|απ(ό|ο)γευμα|βρ(ά|α)δυ|ν(ύ|υ)χτα)/i
}, parseDayPeriodPatterns$10 = {
  any: {
    am: /^πμ|π\.\s?μ\./i,
    pm: /^μμ|μ\.\s?μ\./i,
    midnight: /^μεσάν/i,
    noon: /^μεσημ(έ|ε)/i,
    morning: /πρω(ί|ι)/i,
    afternoon: /απ(ό|ο)γευμα/i,
    evening: /βρ(ά|α)δυ/i,
    night: /ν(ύ|υ)χτα/i
  }
}, match$11 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$10,
    parsePattern: parseOrdinalNumberPattern$10,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$10,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$10,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$10,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$10,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$10,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$10,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$10,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$10,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$10,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$10,
    defaultParseWidth: "any"
  })
}, el = {
  code: "el",
  formatDistance: formatDistance$11,
  formatLong: formatLong$19,
  formatRelative: formatRelative$11,
  localize: localize$10,
  match: match$11,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$$ = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "1 hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "1 day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "1 month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "1 year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years"
  }
}, formatDistance$10 = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$$[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "in " + p : p + " ago" : p;
}, dateFormats$18 = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "dd/MM/yyyy"
}, timeFormats$18 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$18 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$18 = {
  date: buildFormatLongFn({
    formats: dateFormats$18,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$18,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$18,
    defaultWidth: "full"
  })
}, formatRelativeLocale$10 = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P"
}, formatRelative$10 = (u, l, f, p) => formatRelativeLocale$10[u], eraValues$$ = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"]
}, quarterValues$$ = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
}, monthValues$$ = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  wide: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ]
}, dayValues$$ = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ]
}, dayPeriodValues$$ = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  }
}, formattingDayPeriodValues$N = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  }
}, ordinalNumber$$ = (u, l) => {
  const f = Number(u), p = f % 100;
  if (p > 20 || p < 10)
    switch (p % 10) {
      case 1:
        return f + "st";
      case 2:
        return f + "nd";
      case 3:
        return f + "rd";
    }
  return f + "th";
}, localize$$ = {
  ordinalNumber: ordinalNumber$$,
  era: buildLocalizeFn({
    values: eraValues$$,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$$,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$$,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$$,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$$,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$N,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$$ = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$$ = /\d+/i, matchEraPatterns$$ = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i
}, parseEraPatterns$$ = {
  any: [/^b/i, /^(a|c)/i]
}, matchQuarterPatterns$$ = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i
}, parseQuarterPatterns$$ = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$$ = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
}, parseMonthPatterns$$ = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$$ = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
}, parseDayPatterns$$ = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, matchDayPeriodPatterns$$ = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
}, parseDayPeriodPatterns$$ = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
}, match$10 = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$$,
    parsePattern: parseOrdinalNumberPattern$$,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$$,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$$,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$$,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$$,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$$,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$$,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$$,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$$,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$$,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$$,
    defaultParseWidth: "any"
  })
}, enAU = {
  code: "en-AU",
  formatDistance: formatDistance$10,
  formatLong: formatLong$18,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$_ = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "a second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "a minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about an hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "an hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "a day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about a week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "a week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about a month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "a month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about a year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "a year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over a year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost a year",
    other: "almost {{count}} years"
  }
}, formatDistance$$ = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$_[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "in " + p : p + " ago" : p;
}, dateFormats$17 = {
  full: "EEEE, MMMM do, yyyy",
  long: "MMMM do, yyyy",
  medium: "MMM d, yyyy",
  short: "yyyy-MM-dd"
}, timeFormats$17 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$17 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$17 = {
  date: buildFormatLongFn({
    formats: dateFormats$17,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$17,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$17,
    defaultWidth: "full"
  })
}, enCA = {
  code: "en-CA",
  formatDistance: formatDistance$$,
  formatLong: formatLong$17,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, dateFormats$16 = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "dd/MM/yyyy"
}, timeFormats$16 = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$16 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$16 = {
  date: buildFormatLongFn({
    formats: dateFormats$16,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$16,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$16,
    defaultWidth: "full"
  })
}, enGB = {
  code: "en-GB",
  formatDistance: formatDistance$10,
  formatLong: formatLong$16,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, enIE = {
  code: "en-IE",
  formatDistance: formatDistance$10,
  formatLong: formatLong$16,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, dateFormats$15 = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM, yyyy",
  medium: "d MMM, yyyy",
  short: "dd/MM/yyyy"
}, timeFormats$15 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$15 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$15 = {
  date: buildFormatLongFn({
    formats: dateFormats$15,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$15,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$15,
    defaultWidth: "full"
  })
}, enIN = {
  code: "en-IN",
  formatDistance: formatDistance$10,
  formatLong: formatLong$15,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 1,
    // Monday is the first day of the week.
    firstWeekContainsDate: 4
    // The week that contains Jan 4th is the first week of the year.
  }
}, dateFormats$14 = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "dd/MM/yyyy"
}, timeFormats$14 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$14 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$14 = {
  date: buildFormatLongFn({
    formats: dateFormats$14,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$14,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$14,
    defaultWidth: "full"
  })
}, enNZ = {
  code: "en-NZ",
  formatDistance: formatDistance$10,
  formatLong: formatLong$14,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, dateFormats$13 = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$13 = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$13 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$13 = {
  date: buildFormatLongFn({
    formats: dateFormats$13,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$13,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$13,
    defaultWidth: "full"
  })
}, enUS = {
  code: "en-US",
  formatDistance: formatDistance$10,
  formatLong: formatLong$13,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, dateFormats$12 = {
  full: "EEEE, dd MMMM yyyy",
  long: "dd MMMM yyyy",
  medium: "dd MMM yyyy",
  short: "yyyy/MM/dd"
}, timeFormats$12 = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$12 = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$12 = {
  date: buildFormatLongFn({
    formats: dateFormats$12,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$12,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$12,
    defaultWidth: "full"
  })
}, enZA = {
  code: "en-ZA",
  formatDistance: formatDistance$10,
  formatLong: formatLong$12,
  formatRelative: formatRelative$10,
  localize: localize$$,
  match: match$10,
  options: {
    weekStartsOn: 0,
    // Sunday is the first day of the week.
    firstWeekContainsDate: 1
    // The week that contains Jan 1st is the first week of the year.
  }
}, formatDistanceLocale$Z = {
  lessThanXSeconds: {
    one: "malpli ol sekundo",
    other: "malpli ol {{count}} sekundoj"
  },
  xSeconds: {
    one: "1 sekundo",
    other: "{{count}} sekundoj"
  },
  halfAMinute: "duonminuto",
  lessThanXMinutes: {
    one: "malpli ol minuto",
    other: "malpli ol {{count}} minutoj"
  },
  xMinutes: {
    one: "1 minuto",
    other: "{{count}} minutoj"
  },
  aboutXHours: {
    one: "proksimume 1 horo",
    other: "proksimume {{count}} horoj"
  },
  xHours: {
    one: "1 horo",
    other: "{{count}} horoj"
  },
  xDays: {
    one: "1 tago",
    other: "{{count}} tagoj"
  },
  aboutXMonths: {
    one: "proksimume 1 monato",
    other: "proksimume {{count}} monatoj"
  },
  xWeeks: {
    one: "1 semajno",
    other: "{{count}} semajnoj"
  },
  aboutXWeeks: {
    one: "proksimume 1 semajno",
    other: "proksimume {{count}} semajnoj"
  },
  xMonths: {
    one: "1 monato",
    other: "{{count}} monatoj"
  },
  aboutXYears: {
    one: "proksimume 1 jaro",
    other: "proksimume {{count}} jaroj"
  },
  xYears: {
    one: "1 jaro",
    other: "{{count}} jaroj"
  },
  overXYears: {
    one: "pli ol 1 jaro",
    other: "pli ol {{count}} jaroj"
  },
  almostXYears: {
    one: "preskaŭ 1 jaro",
    other: "preskaŭ {{count}} jaroj"
  }
}, formatDistance$_ = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$Z[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f?.comparison && f.comparison > 0 ? "post " + p : "antaŭ " + p : p;
}, dateFormats$11 = {
  full: "EEEE, do 'de' MMMM y",
  long: "y-MMMM-dd",
  medium: "y-MMM-dd",
  short: "yyyy-MM-dd"
}, timeFormats$11 = {
  full: "Ho 'horo kaj' m:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$11 = {
  any: "{{date}} {{time}}"
}, formatLong$11 = {
  date: buildFormatLongFn({
    formats: dateFormats$11,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$11,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$11,
    defaultWidth: "any"
  })
}, formatRelativeLocale$$ = {
  lastWeek: "'pasinta' eeee 'je' p",
  yesterday: "'hieraŭ je' p",
  today: "'hodiaŭ je' p",
  tomorrow: "'morgaŭ je' p",
  nextWeek: "eeee 'je' p",
  other: "P"
}, formatRelative$$ = (u, l, f, p) => formatRelativeLocale$$[u], eraValues$_ = {
  narrow: ["aK", "pK"],
  abbreviated: ["a.K.E.", "p.K.E."],
  wide: ["antaŭ Komuna Erao", "Komuna Erao"]
}, quarterValues$_ = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: [
    "1-a kvaronjaro",
    "2-a kvaronjaro",
    "3-a kvaronjaro",
    "4-a kvaronjaro"
  ]
}, monthValues$_ = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "jan",
    "feb",
    "mar",
    "apr",
    "maj",
    "jun",
    "jul",
    "aŭg",
    "sep",
    "okt",
    "nov",
    "dec"
  ],
  wide: [
    "januaro",
    "februaro",
    "marto",
    "aprilo",
    "majo",
    "junio",
    "julio",
    "aŭgusto",
    "septembro",
    "oktobro",
    "novembro",
    "decembro"
  ]
}, dayValues$_ = {
  narrow: ["D", "L", "M", "M", "Ĵ", "V", "S"],
  short: ["di", "lu", "ma", "me", "ĵa", "ve", "sa"],
  abbreviated: ["dim", "lun", "mar", "mer", "ĵaŭ", "ven", "sab"],
  wide: [
    "dimanĉo",
    "lundo",
    "mardo",
    "merkredo",
    "ĵaŭdo",
    "vendredo",
    "sabato"
  ]
}, dayPeriodValues$_ = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "noktomezo",
    noon: "tagmezo",
    morning: "matene",
    afternoon: "posttagmeze",
    evening: "vespere",
    night: "nokte"
  },
  abbreviated: {
    am: "a.t.m.",
    pm: "p.t.m.",
    midnight: "noktomezo",
    noon: "tagmezo",
    morning: "matene",
    afternoon: "posttagmeze",
    evening: "vespere",
    night: "nokte"
  },
  wide: {
    am: "antaŭtagmeze",
    pm: "posttagmeze",
    midnight: "noktomezo",
    noon: "tagmezo",
    morning: "matene",
    afternoon: "posttagmeze",
    evening: "vespere",
    night: "nokte"
  }
}, ordinalNumber$_ = (u) => Number(u) + "-a", localize$_ = {
  ordinalNumber: ordinalNumber$_,
  era: buildLocalizeFn({
    values: eraValues$_,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$_,
    defaultWidth: "wide",
    argumentCallback: function(u) {
      return Number(u) - 1;
    }
  }),
  month: buildLocalizeFn({
    values: monthValues$_,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$_,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$_,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$_ = /^(\d+)(-?a)?/i, parseOrdinalNumberPattern$_ = /\d+/i, matchEraPatterns$_ = {
  narrow: /^([ap]k)/i,
  abbreviated: /^([ap]\.?\s?k\.?\s?e\.?)/i,
  wide: /^((antaǔ |post )?komuna erao)/i
}, parseEraPatterns$_ = {
  any: [/^a/i, /^[kp]/i]
}, matchQuarterPatterns$_ = {
  narrow: /^[1234]/i,
  abbreviated: /^k[1234]/i,
  wide: /^[1234](-?a)? kvaronjaro/i
}, parseQuarterPatterns$_ = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$_ = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|maj|jun|jul|a(ŭ|ux|uh|u)g|sep|okt|nov|dec)/i,
  wide: /^(januaro|februaro|marto|aprilo|majo|junio|julio|a(ŭ|ux|uh|u)gusto|septembro|oktobro|novembro|decembro)/i
}, parseMonthPatterns$_ = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^maj/i,
    /^jun/i,
    /^jul/i,
    /^a(u|ŭ)/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$_ = {
  narrow: /^[dlmĵjvs]/i,
  short: /^(di|lu|ma|me|(ĵ|jx|jh|j)a|ve|sa)/i,
  abbreviated: /^(dim|lun|mar|mer|(ĵ|jx|jh|j)a(ŭ|ux|uh|u)|ven|sab)/i,
  wide: /^(diman(ĉ|cx|ch|c)o|lundo|mardo|merkredo|(ĵ|jx|jh|j)a(ŭ|ux|uh|u)do|vendredo|sabato)/i
}, parseDayPatterns$_ = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^(j|ĵ)/i, /^v/i, /^s/i],
  any: [/^d/i, /^l/i, /^ma/i, /^me/i, /^(j|ĵ)/i, /^v/i, /^s/i]
}, matchDayPeriodPatterns$_ = {
  narrow: /^([ap]|(posttagmez|noktomez|tagmez|maten|vesper|nokt)[eo])/i,
  abbreviated: /^([ap][.\s]?t[.\s]?m[.\s]?|(posttagmez|noktomez|tagmez|maten|vesper|nokt)[eo])/i,
  wide: /^(anta(ŭ|ux)tagmez|posttagmez|noktomez|tagmez|maten|vesper|nokt)[eo]/i
}, parseDayPeriodPatterns$_ = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^noktom/i,
    noon: /^t/i,
    morning: /^m/i,
    afternoon: /^posttagmeze/i,
    evening: /^v/i,
    night: /^n/i
  }
}, match$$ = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$_,
    parsePattern: parseOrdinalNumberPattern$_,
    valueCallback: function(u) {
      return parseInt(u, 10);
    }
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$_,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$_,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$_,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$_,
    defaultParseWidth: "any",
    valueCallback: function(u) {
      return u + 1;
    }
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$_,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$_,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$_,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$_,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$_,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$_,
    defaultParseWidth: "any"
  })
}, eo = {
  code: "eo",
  formatDistance: formatDistance$_,
  formatLong: formatLong$11,
  formatRelative: formatRelative$$,
  localize: localize$_,
  match: match$$,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$Y = {
  lessThanXSeconds: {
    one: "menos de un segundo",
    other: "menos de {{count}} segundos"
  },
  xSeconds: {
    one: "1 segundo",
    other: "{{count}} segundos"
  },
  halfAMinute: "medio minuto",
  lessThanXMinutes: {
    one: "menos de un minuto",
    other: "menos de {{count}} minutos"
  },
  xMinutes: {
    one: "1 minuto",
    other: "{{count}} minutos"
  },
  aboutXHours: {
    one: "alrededor de 1 hora",
    other: "alrededor de {{count}} horas"
  },
  xHours: {
    one: "1 hora",
    other: "{{count}} horas"
  },
  xDays: {
    one: "1 día",
    other: "{{count}} días"
  },
  aboutXWeeks: {
    one: "alrededor de 1 semana",
    other: "alrededor de {{count}} semanas"
  },
  xWeeks: {
    one: "1 semana",
    other: "{{count}} semanas"
  },
  aboutXMonths: {
    one: "alrededor de 1 mes",
    other: "alrededor de {{count}} meses"
  },
  xMonths: {
    one: "1 mes",
    other: "{{count}} meses"
  },
  aboutXYears: {
    one: "alrededor de 1 año",
    other: "alrededor de {{count}} años"
  },
  xYears: {
    one: "1 año",
    other: "{{count}} años"
  },
  overXYears: {
    one: "más de 1 año",
    other: "más de {{count}} años"
  },
  almostXYears: {
    one: "casi 1 año",
    other: "casi {{count}} años"
  }
}, formatDistance$Z = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$Y[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "en " + p : "hace " + p : p;
}, dateFormats$10 = {
  full: "EEEE, d 'de' MMMM 'de' y",
  long: "d 'de' MMMM 'de' y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$10 = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$10 = {
  full: "{{date}} 'a las' {{time}}",
  long: "{{date}} 'a las' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$10 = {
  date: buildFormatLongFn({
    formats: dateFormats$10,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$10,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$10,
    defaultWidth: "full"
  })
}, formatRelativeLocale$_ = {
  lastWeek: "'el' eeee 'pasado a la' p",
  yesterday: "'ayer a la' p",
  today: "'hoy a la' p",
  tomorrow: "'mañana a la' p",
  nextWeek: "eeee 'a la' p",
  other: "P"
}, formatRelativeLocalePlural$2 = {
  lastWeek: "'el' eeee 'pasado a las' p",
  yesterday: "'ayer a las' p",
  today: "'hoy a las' p",
  tomorrow: "'mañana a las' p",
  nextWeek: "eeee 'a las' p",
  other: "P"
}, formatRelative$_ = (u, l, f, p) => l.getHours() !== 1 ? formatRelativeLocalePlural$2[u] : formatRelativeLocale$_[u], eraValues$Z = {
  narrow: ["AC", "DC"],
  abbreviated: ["AC", "DC"],
  wide: ["antes de cristo", "después de cristo"]
}, quarterValues$Z = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1º trimestre", "2º trimestre", "3º trimestre", "4º trimestre"]
}, monthValues$Z = {
  narrow: ["e", "f", "m", "a", "m", "j", "j", "a", "s", "o", "n", "d"],
  abbreviated: [
    "ene",
    "feb",
    "mar",
    "abr",
    "may",
    "jun",
    "jul",
    "ago",
    "sep",
    "oct",
    "nov",
    "dic"
  ],
  wide: [
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre"
  ]
}, dayValues$Z = {
  narrow: ["d", "l", "m", "m", "j", "v", "s"],
  short: ["do", "lu", "ma", "mi", "ju", "vi", "sá"],
  abbreviated: ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"],
  wide: [
    "domingo",
    "lunes",
    "martes",
    "miércoles",
    "jueves",
    "viernes",
    "sábado"
  ]
}, dayPeriodValues$Z = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mn",
    noon: "md",
    morning: "mañana",
    afternoon: "tarde",
    evening: "tarde",
    night: "noche"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "medianoche",
    noon: "mediodia",
    morning: "mañana",
    afternoon: "tarde",
    evening: "tarde",
    night: "noche"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "medianoche",
    noon: "mediodia",
    morning: "mañana",
    afternoon: "tarde",
    evening: "tarde",
    night: "noche"
  }
}, formattingDayPeriodValues$M = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mn",
    noon: "md",
    morning: "de la mañana",
    afternoon: "de la tarde",
    evening: "de la tarde",
    night: "de la noche"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "medianoche",
    noon: "mediodia",
    morning: "de la mañana",
    afternoon: "de la tarde",
    evening: "de la tarde",
    night: "de la noche"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "medianoche",
    noon: "mediodia",
    morning: "de la mañana",
    afternoon: "de la tarde",
    evening: "de la tarde",
    night: "de la noche"
  }
}, ordinalNumber$Z = (u, l) => Number(u) + "º", localize$Z = {
  ordinalNumber: ordinalNumber$Z,
  era: buildLocalizeFn({
    values: eraValues$Z,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$Z,
    defaultWidth: "wide",
    argumentCallback: (u) => Number(u) - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$Z,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$Z,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$Z,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$M,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$Z = /^(\d+)(º)?/i, parseOrdinalNumberPattern$Z = /\d+/i, matchEraPatterns$Z = {
  narrow: /^(ac|dc|a|d)/i,
  abbreviated: /^(a\.?\s?c\.?|a\.?\s?e\.?\s?c\.?|d\.?\s?c\.?|e\.?\s?c\.?)/i,
  wide: /^(antes de cristo|antes de la era com[uú]n|despu[eé]s de cristo|era com[uú]n)/i
}, parseEraPatterns$Z = {
  any: [/^ac/i, /^dc/i],
  wide: [
    /^(antes de cristo|antes de la era com[uú]n)/i,
    /^(despu[eé]s de cristo|era com[uú]n)/i
  ]
}, matchQuarterPatterns$Z = {
  narrow: /^[1234]/i,
  abbreviated: /^T[1234]/i,
  wide: /^[1234](º)? trimestre/i
}, parseQuarterPatterns$Z = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$Z = {
  narrow: /^[efmajsond]/i,
  abbreviated: /^(ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic)/i,
  wide: /^(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)/i
}, parseMonthPatterns$Z = {
  narrow: [
    /^e/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^en/i,
    /^feb/i,
    /^mar/i,
    /^abr/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^ago/i,
    /^sep/i,
    /^oct/i,
    /^nov/i,
    /^dic/i
  ]
}, matchDayPatterns$Z = {
  narrow: /^[dlmjvs]/i,
  short: /^(do|lu|ma|mi|ju|vi|s[áa])/i,
  abbreviated: /^(dom|lun|mar|mi[ée]|jue|vie|s[áa]b)/i,
  wide: /^(domingo|lunes|martes|mi[ée]rcoles|jueves|viernes|s[áa]bado)/i
}, parseDayPatterns$Z = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^j/i, /^v/i, /^s/i],
  any: [/^do/i, /^lu/i, /^ma/i, /^mi/i, /^ju/i, /^vi/i, /^sa/i]
}, matchDayPeriodPatterns$Z = {
  narrow: /^(a|p|mn|md|(de la|a las) (mañana|tarde|noche))/i,
  any: /^([ap]\.?\s?m\.?|medianoche|mediodia|(de la|a las) (mañana|tarde|noche))/i
}, parseDayPeriodPatterns$Z = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mn/i,
    noon: /^md/i,
    morning: /mañana/i,
    afternoon: /tarde/i,
    evening: /tarde/i,
    night: /noche/i
  }
}, match$_ = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$Z,
    parsePattern: parseOrdinalNumberPattern$Z,
    valueCallback: function(u) {
      return parseInt(u, 10);
    }
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$Z,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$Z,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$Z,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$Z,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$Z,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$Z,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$Z,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$Z,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$Z,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$Z,
    defaultParseWidth: "any"
  })
}, es = {
  code: "es",
  formatDistance: formatDistance$Z,
  formatLong: formatLong$10,
  formatRelative: formatRelative$_,
  localize: localize$Z,
  match: match$_,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$X = {
  lessThanXSeconds: {
    standalone: {
      one: "vähem kui üks sekund",
      other: "vähem kui {{count}} sekundit"
    },
    withPreposition: {
      one: "vähem kui ühe sekundi",
      other: "vähem kui {{count}} sekundi"
    }
  },
  xSeconds: {
    standalone: {
      one: "üks sekund",
      other: "{{count}} sekundit"
    },
    withPreposition: {
      one: "ühe sekundi",
      other: "{{count}} sekundi"
    }
  },
  halfAMinute: {
    standalone: "pool minutit",
    withPreposition: "poole minuti"
  },
  lessThanXMinutes: {
    standalone: {
      one: "vähem kui üks minut",
      other: "vähem kui {{count}} minutit"
    },
    withPreposition: {
      one: "vähem kui ühe minuti",
      other: "vähem kui {{count}} minuti"
    }
  },
  xMinutes: {
    standalone: {
      one: "üks minut",
      other: "{{count}} minutit"
    },
    withPreposition: {
      one: "ühe minuti",
      other: "{{count}} minuti"
    }
  },
  aboutXHours: {
    standalone: {
      one: "umbes üks tund",
      other: "umbes {{count}} tundi"
    },
    withPreposition: {
      one: "umbes ühe tunni",
      other: "umbes {{count}} tunni"
    }
  },
  xHours: {
    standalone: {
      one: "üks tund",
      other: "{{count}} tundi"
    },
    withPreposition: {
      one: "ühe tunni",
      other: "{{count}} tunni"
    }
  },
  xDays: {
    standalone: {
      one: "üks päev",
      other: "{{count}} päeva"
    },
    withPreposition: {
      one: "ühe päeva",
      other: "{{count}} päeva"
    }
  },
  aboutXWeeks: {
    standalone: {
      one: "umbes üks nädal",
      other: "umbes {{count}} nädalat"
    },
    withPreposition: {
      one: "umbes ühe nädala",
      other: "umbes {{count}} nädala"
    }
  },
  xWeeks: {
    standalone: {
      one: "üks nädal",
      other: "{{count}} nädalat"
    },
    withPreposition: {
      one: "ühe nädala",
      other: "{{count}} nädala"
    }
  },
  aboutXMonths: {
    standalone: {
      one: "umbes üks kuu",
      other: "umbes {{count}} kuud"
    },
    withPreposition: {
      one: "umbes ühe kuu",
      other: "umbes {{count}} kuu"
    }
  },
  xMonths: {
    standalone: {
      one: "üks kuu",
      other: "{{count}} kuud"
    },
    withPreposition: {
      one: "ühe kuu",
      other: "{{count}} kuu"
    }
  },
  aboutXYears: {
    standalone: {
      one: "umbes üks aasta",
      other: "umbes {{count}} aastat"
    },
    withPreposition: {
      one: "umbes ühe aasta",
      other: "umbes {{count}} aasta"
    }
  },
  xYears: {
    standalone: {
      one: "üks aasta",
      other: "{{count}} aastat"
    },
    withPreposition: {
      one: "ühe aasta",
      other: "{{count}} aasta"
    }
  },
  overXYears: {
    standalone: {
      one: "rohkem kui üks aasta",
      other: "rohkem kui {{count}} aastat"
    },
    withPreposition: {
      one: "rohkem kui ühe aasta",
      other: "rohkem kui {{count}} aasta"
    }
  },
  almostXYears: {
    standalone: {
      one: "peaaegu üks aasta",
      other: "peaaegu {{count}} aastat"
    },
    withPreposition: {
      one: "peaaegu ühe aasta",
      other: "peaaegu {{count}} aasta"
    }
  }
}, formatDistance$Y = (u, l, f) => {
  const p = f?.addSuffix ? formatDistanceLocale$X[u].withPreposition : formatDistanceLocale$X[u].standalone;
  let m;
  return typeof p == "string" ? m = p : l === 1 ? m = p.one : m = p.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? m + " pärast" : m + " eest" : m;
}, dateFormats$$ = {
  full: "EEEE, d. MMMM y",
  long: "d. MMMM y",
  medium: "d. MMM y",
  short: "dd.MM.y"
}, timeFormats$$ = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$$ = {
  full: "{{date}} 'kell' {{time}}",
  long: "{{date}} 'kell' {{time}}",
  medium: "{{date}}. {{time}}",
  short: "{{date}}. {{time}}"
}, formatLong$$ = {
  date: buildFormatLongFn({
    formats: dateFormats$$,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$$,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$$,
    defaultWidth: "full"
  })
}, formatRelativeLocale$Z = {
  lastWeek: "'eelmine' eeee 'kell' p",
  yesterday: "'eile kell' p",
  today: "'täna kell' p",
  tomorrow: "'homme kell' p",
  nextWeek: "'järgmine' eeee 'kell' p",
  other: "P"
}, formatRelative$Z = (u, l, f, p) => formatRelativeLocale$Z[u], eraValues$Y = {
  narrow: ["e.m.a", "m.a.j"],
  abbreviated: ["e.m.a", "m.a.j"],
  wide: ["enne meie ajaarvamist", "meie ajaarvamise järgi"]
}, quarterValues$Y = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: ["1. kvartal", "2. kvartal", "3. kvartal", "4. kvartal"]
}, monthValues$Y = {
  narrow: ["J", "V", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "jaan",
    "veebr",
    "märts",
    "apr",
    "mai",
    "juuni",
    "juuli",
    "aug",
    "sept",
    "okt",
    "nov",
    "dets"
  ],
  wide: [
    "jaanuar",
    "veebruar",
    "märts",
    "aprill",
    "mai",
    "juuni",
    "juuli",
    "august",
    "september",
    "oktoober",
    "november",
    "detsember"
  ]
}, dayValues$Y = {
  narrow: ["P", "E", "T", "K", "N", "R", "L"],
  short: ["P", "E", "T", "K", "N", "R", "L"],
  abbreviated: [
    "pühap.",
    "esmasp.",
    "teisip.",
    "kolmap.",
    "neljap.",
    "reede.",
    "laup."
  ],
  wide: [
    "pühapäev",
    "esmaspäev",
    "teisipäev",
    "kolmapäev",
    "neljapäev",
    "reede",
    "laupäev"
  ]
}, dayPeriodValues$Y = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "kesköö",
    noon: "keskpäev",
    morning: "hommik",
    afternoon: "pärastlõuna",
    evening: "õhtu",
    night: "öö"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "kesköö",
    noon: "keskpäev",
    morning: "hommik",
    afternoon: "pärastlõuna",
    evening: "õhtu",
    night: "öö"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "kesköö",
    noon: "keskpäev",
    morning: "hommik",
    afternoon: "pärastlõuna",
    evening: "õhtu",
    night: "öö"
  }
}, formattingDayPeriodValues$L = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "keskööl",
    noon: "keskpäeval",
    morning: "hommikul",
    afternoon: "pärastlõunal",
    evening: "õhtul",
    night: "öösel"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "keskööl",
    noon: "keskpäeval",
    morning: "hommikul",
    afternoon: "pärastlõunal",
    evening: "õhtul",
    night: "öösel"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "keskööl",
    noon: "keskpäeval",
    morning: "hommikul",
    afternoon: "pärastlõunal",
    evening: "õhtul",
    night: "öösel"
  }
}, ordinalNumber$Y = (u, l) => Number(u) + ".", localize$Y = {
  ordinalNumber: ordinalNumber$Y,
  era: buildLocalizeFn({
    values: eraValues$Y,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$Y,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$Y,
    defaultWidth: "wide",
    formattingValues: monthValues$Y,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$Y,
    defaultWidth: "wide",
    formattingValues: dayValues$Y,
    defaultFormattingWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$Y,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$L,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$Y = /^\d+\./i, parseOrdinalNumberPattern$Y = /\d+/i, matchEraPatterns$Y = {
  narrow: /^(e\.m\.a|m\.a\.j|eKr|pKr)/i,
  abbreviated: /^(e\.m\.a|m\.a\.j|eKr|pKr)/i,
  wide: /^(enne meie ajaarvamist|meie ajaarvamise järgi|enne Kristust|pärast Kristust)/i
}, parseEraPatterns$Y = {
  any: [/^e/i, /^(m|p)/i]
}, matchQuarterPatterns$Y = {
  narrow: /^[1234]/i,
  abbreviated: /^K[1234]/i,
  wide: /^[1234](\.)? kvartal/i
}, parseQuarterPatterns$Y = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$Y = {
  narrow: /^[jvmasond]/i,
  abbreviated: /^(jaan|veebr|märts|apr|mai|juuni|juuli|aug|sept|okt|nov|dets)/i,
  wide: /^(jaanuar|veebruar|märts|aprill|mai|juuni|juuli|august|september|oktoober|november|detsember)/i
}, parseMonthPatterns$Y = {
  narrow: [
    /^j/i,
    /^v/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^v/i,
    /^mär/i,
    /^ap/i,
    /^mai/i,
    /^juun/i,
    /^juul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$Y = {
  narrow: /^[petknrl]/i,
  short: /^[petknrl]/i,
  abbreviated: /^(püh?|esm?|tei?|kolm?|nel?|ree?|laup?)\.?/i,
  wide: /^(pühapäev|esmaspäev|teisipäev|kolmapäev|neljapäev|reede|laupäev)/i
}, parseDayPatterns$Y = {
  any: [/^p/i, /^e/i, /^t/i, /^k/i, /^n/i, /^r/i, /^l/i]
}, matchDayPeriodPatterns$Y = {
  any: /^(am|pm|keskööl?|keskpäev(al)?|hommik(ul)?|pärastlõunal?|õhtul?|öö(sel)?)/i
}, parseDayPeriodPatterns$Y = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^keskö/i,
    noon: /^keskp/i,
    morning: /hommik/i,
    afternoon: /pärastlõuna/i,
    evening: /õhtu/i,
    night: /öö/i
  }
}, match$Z = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$Y,
    parsePattern: parseOrdinalNumberPattern$Y,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$Y,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$Y,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$Y,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$Y,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$Y,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$Y,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$Y,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$Y,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$Y,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$Y,
    defaultParseWidth: "any"
  })
}, et = {
  code: "et",
  formatDistance: formatDistance$Y,
  formatLong: formatLong$$,
  formatRelative: formatRelative$Z,
  localize: localize$Y,
  match: match$Z,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$W = {
  lessThanXSeconds: {
    one: "segundo bat baino gutxiago",
    other: "{{count}} segundo baino gutxiago"
  },
  xSeconds: {
    one: "1 segundo",
    other: "{{count}} segundo"
  },
  halfAMinute: "minutu erdi",
  lessThanXMinutes: {
    one: "minutu bat baino gutxiago",
    other: "{{count}} minutu baino gutxiago"
  },
  xMinutes: {
    one: "1 minutu",
    other: "{{count}} minutu"
  },
  aboutXHours: {
    one: "1 ordu gutxi gorabehera",
    other: "{{count}} ordu gutxi gorabehera"
  },
  xHours: {
    one: "1 ordu",
    other: "{{count}} ordu"
  },
  xDays: {
    one: "1 egun",
    other: "{{count}} egun"
  },
  aboutXWeeks: {
    one: "aste 1 inguru",
    other: "{{count}} aste inguru"
  },
  xWeeks: {
    one: "1 aste",
    other: "{{count}} astean"
  },
  aboutXMonths: {
    one: "1 hilabete gutxi gorabehera",
    other: "{{count}} hilabete gutxi gorabehera"
  },
  xMonths: {
    one: "1 hilabete",
    other: "{{count}} hilabete"
  },
  aboutXYears: {
    one: "1 urte gutxi gorabehera",
    other: "{{count}} urte gutxi gorabehera"
  },
  xYears: {
    one: "1 urte",
    other: "{{count}} urte"
  },
  overXYears: {
    one: "1 urte baino gehiago",
    other: "{{count}} urte baino gehiago"
  },
  almostXYears: {
    one: "ia 1 urte",
    other: "ia {{count}} urte"
  }
}, formatDistance$X = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$W[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "en " + p : "duela " + p : p;
}, dateFormats$_ = {
  full: "EEEE, y'ko' MMMM'ren' d'a' y'ren'",
  long: "y'ko' MMMM'ren' d'a'",
  medium: "y MMM d",
  short: "yy/MM/dd"
}, timeFormats$_ = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$_ = {
  full: "{{date}} 'tan' {{time}}",
  long: "{{date}} 'tan' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$_ = {
  date: buildFormatLongFn({
    formats: dateFormats$_,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$_,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$_,
    defaultWidth: "full"
  })
}, formatRelativeLocale$Y = {
  lastWeek: "'joan den' eeee, LT",
  yesterday: "'atzo,' p",
  today: "'gaur,' p",
  tomorrow: "'bihar,' p",
  nextWeek: "eeee, p",
  other: "P"
}, formatRelativeLocalePlural$1 = {
  lastWeek: "'joan den' eeee, p",
  yesterday: "'atzo,' p",
  today: "'gaur,' p",
  tomorrow: "'bihar,' p",
  nextWeek: "eeee, p",
  other: "P"
}, formatRelative$Y = (u, l) => l.getHours() !== 1 ? formatRelativeLocalePlural$1[u] : formatRelativeLocale$Y[u], eraValues$X = {
  narrow: ["k.a.", "k.o."],
  abbreviated: ["k.a.", "k.o."],
  wide: ["kristo aurretik", "kristo ondoren"]
}, quarterValues$X = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1H", "2H", "3H", "4H"],
  wide: [
    "1. hiruhilekoa",
    "2. hiruhilekoa",
    "3. hiruhilekoa",
    "4. hiruhilekoa"
  ]
}, monthValues$X = {
  narrow: ["u", "o", "m", "a", "m", "e", "u", "a", "i", "u", "a", "a"],
  abbreviated: [
    "urt",
    "ots",
    "mar",
    "api",
    "mai",
    "eka",
    "uzt",
    "abu",
    "ira",
    "urr",
    "aza",
    "abe"
  ],
  wide: [
    "urtarrila",
    "otsaila",
    "martxoa",
    "apirila",
    "maiatza",
    "ekaina",
    "uztaila",
    "abuztua",
    "iraila",
    "urria",
    "azaroa",
    "abendua"
  ]
}, dayValues$X = {
  narrow: ["i", "a", "a", "a", "o", "o", "l"],
  short: ["ig", "al", "as", "az", "og", "or", "lr"],
  abbreviated: ["iga", "ast", "ast", "ast", "ost", "ost", "lar"],
  wide: [
    "igandea",
    "astelehena",
    "asteartea",
    "asteazkena",
    "osteguna",
    "ostirala",
    "larunbata"
  ]
}, dayPeriodValues$X = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "ge",
    noon: "eg",
    morning: "goiza",
    afternoon: "arratsaldea",
    evening: "arratsaldea",
    night: "gaua"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "gauerdia",
    noon: "eguerdia",
    morning: "goiza",
    afternoon: "arratsaldea",
    evening: "arratsaldea",
    night: "gaua"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "gauerdia",
    noon: "eguerdia",
    morning: "goiza",
    afternoon: "arratsaldea",
    evening: "arratsaldea",
    night: "gaua"
  }
}, formattingDayPeriodValues$K = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "ge",
    noon: "eg",
    morning: "goizean",
    afternoon: "arratsaldean",
    evening: "arratsaldean",
    night: "gauean"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "gauerdia",
    noon: "eguerdia",
    morning: "goizean",
    afternoon: "arratsaldean",
    evening: "arratsaldean",
    night: "gauean"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "gauerdia",
    noon: "eguerdia",
    morning: "goizean",
    afternoon: "arratsaldean",
    evening: "arratsaldean",
    night: "gauean"
  }
}, ordinalNumber$X = (u, l) => Number(u) + ".", localize$X = {
  ordinalNumber: ordinalNumber$X,
  era: buildLocalizeFn({
    values: eraValues$X,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$X,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$X,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$X,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$X,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$K,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$X = /^(\d+)(.)?/i, parseOrdinalNumberPattern$X = /\d+/i, matchEraPatterns$X = {
  narrow: /^(k.a.|k.o.)/i,
  abbreviated: /^(k.a.|k.o.)/i,
  wide: /^(kristo aurretik|kristo ondoren)/i
}, parseEraPatterns$X = {
  narrow: [/^k.a./i, /^k.o./i],
  abbreviated: [/^(k.a.)/i, /^(k.o.)/i],
  wide: [/^(kristo aurretik)/i, /^(kristo ondoren)/i]
}, matchQuarterPatterns$X = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]H/i,
  wide: /^[1234](.)? hiruhilekoa/i
}, parseQuarterPatterns$X = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$X = {
  narrow: /^[uomaei]/i,
  abbreviated: /^(urt|ots|mar|api|mai|eka|uzt|abu|ira|urr|aza|abe)/i,
  wide: /^(urtarrila|otsaila|martxoa|apirila|maiatza|ekaina|uztaila|abuztua|iraila|urria|azaroa|abendua)/i
}, parseMonthPatterns$X = {
  narrow: [
    /^u/i,
    /^o/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^e/i,
    /^u/i,
    /^a/i,
    /^i/i,
    /^u/i,
    /^a/i,
    /^a/i
  ],
  any: [
    /^urt/i,
    /^ots/i,
    /^mar/i,
    /^api/i,
    /^mai/i,
    /^eka/i,
    /^uzt/i,
    /^abu/i,
    /^ira/i,
    /^urr/i,
    /^aza/i,
    /^abe/i
  ]
}, matchDayPatterns$X = {
  narrow: /^[iaol]/i,
  short: /^(ig|al|as|az|og|or|lr)/i,
  abbreviated: /^(iga|ast|ast|ast|ost|ost|lar)/i,
  wide: /^(igandea|astelehena|asteartea|asteazkena|osteguna|ostirala|larunbata)/i
}, parseDayPatterns$X = {
  narrow: [/^i/i, /^a/i, /^a/i, /^a/i, /^o/i, /^o/i, /^l/i],
  short: [/^ig/i, /^al/i, /^as/i, /^az/i, /^og/i, /^or/i, /^lr/i],
  abbreviated: [/^iga/i, /^ast/i, /^ast/i, /^ast/i, /^ost/i, /^ost/i, /^lar/i],
  wide: [
    /^igandea/i,
    /^astelehena/i,
    /^asteartea/i,
    /^asteazkena/i,
    /^osteguna/i,
    /^ostirala/i,
    /^larunbata/i
  ]
}, matchDayPeriodPatterns$X = {
  narrow: /^(a|p|ge|eg|((goiza|goizean)|arratsaldea|(gaua|gauean)))/i,
  any: /^([ap]\.?\s?m\.?|gauerdia|eguerdia|((goiza|goizean)|arratsaldea|(gaua|gauean)))/i
}, parseDayPeriodPatterns$X = {
  narrow: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^ge/i,
    noon: /^eg/i,
    morning: /goiz/i,
    afternoon: /arratsaldea/i,
    evening: /arratsaldea/i,
    night: /gau/i
  },
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^gauerdia/i,
    noon: /^eguerdia/i,
    morning: /goiz/i,
    afternoon: /arratsaldea/i,
    evening: /arratsaldea/i,
    night: /gau/i
  }
}, match$Y = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$X,
    parsePattern: parseOrdinalNumberPattern$X,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$X,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$X,
    defaultParseWidth: "wide"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$X,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$X,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$X,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$X,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$X,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$X,
    defaultParseWidth: "wide"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$X,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$X,
    defaultParseWidth: "any"
  })
}, eu = {
  code: "eu",
  formatDistance: formatDistance$X,
  formatLong: formatLong$_,
  formatRelative: formatRelative$Y,
  localize: localize$X,
  match: match$Y,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$V = {
  lessThanXSeconds: {
    one: "کمتر از یک ثانیه",
    other: "کمتر از {{count}} ثانیه"
  },
  xSeconds: {
    one: "1 ثانیه",
    other: "{{count}} ثانیه"
  },
  halfAMinute: "نیم دقیقه",
  lessThanXMinutes: {
    one: "کمتر از یک دقیقه",
    other: "کمتر از {{count}} دقیقه"
  },
  xMinutes: {
    one: "1 دقیقه",
    other: "{{count}} دقیقه"
  },
  aboutXHours: {
    one: "حدود 1 ساعت",
    other: "حدود {{count}} ساعت"
  },
  xHours: {
    one: "1 ساعت",
    other: "{{count}} ساعت"
  },
  xDays: {
    one: "1 روز",
    other: "{{count}} روز"
  },
  aboutXWeeks: {
    one: "حدود 1 هفته",
    other: "حدود {{count}} هفته"
  },
  xWeeks: {
    one: "1 هفته",
    other: "{{count}} هفته"
  },
  aboutXMonths: {
    one: "حدود 1 ماه",
    other: "حدود {{count}} ماه"
  },
  xMonths: {
    one: "1 ماه",
    other: "{{count}} ماه"
  },
  aboutXYears: {
    one: "حدود 1 سال",
    other: "حدود {{count}} سال"
  },
  xYears: {
    one: "1 سال",
    other: "{{count}} سال"
  },
  overXYears: {
    one: "بیشتر از 1 سال",
    other: "بیشتر از {{count}} سال"
  },
  almostXYears: {
    one: "نزدیک 1 سال",
    other: "نزدیک {{count}} سال"
  }
}, formatDistance$W = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$V[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "در " + p : p + " قبل" : p;
}, dateFormats$Z = {
  full: "EEEE do MMMM y",
  long: "do MMMM y",
  medium: "d MMM y",
  short: "yyyy/MM/dd"
}, timeFormats$Z = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$Z = {
  full: "{{date}} 'در' {{time}}",
  long: "{{date}} 'در' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$Z = {
  date: buildFormatLongFn({
    formats: dateFormats$Z,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$Z,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$Z,
    defaultWidth: "full"
  })
}, formatRelativeLocale$X = {
  lastWeek: "eeee 'گذشته در' p",
  yesterday: "'دیروز در' p",
  today: "'امروز در' p",
  tomorrow: "'فردا در' p",
  nextWeek: "eeee 'در' p",
  other: "P"
}, formatRelative$X = (u, l, f, p) => formatRelativeLocale$X[u], eraValues$W = {
  narrow: ["ق", "ب"],
  abbreviated: ["ق.م.", "ب.م."],
  wide: ["قبل از میلاد", "بعد از میلاد"]
}, quarterValues$W = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["س‌م1", "س‌م2", "س‌م3", "س‌م4"],
  wide: ["سه‌ماهه 1", "سه‌ماهه 2", "سه‌ماهه 3", "سه‌ماهه 4"]
}, monthValues$W = {
  narrow: ["ژ", "ف", "م", "آ", "م", "ج", "ج", "آ", "س", "ا", "ن", "د"],
  abbreviated: [
    "ژانـ",
    "فور",
    "مارس",
    "آپر",
    "می",
    "جون",
    "جولـ",
    "آگو",
    "سپتـ",
    "اکتـ",
    "نوامـ",
    "دسامـ"
  ],
  wide: [
    "ژانویه",
    "فوریه",
    "مارس",
    "آپریل",
    "می",
    "جون",
    "جولای",
    "آگوست",
    "سپتامبر",
    "اکتبر",
    "نوامبر",
    "دسامبر"
  ]
}, dayValues$W = {
  narrow: ["ی", "د", "س", "چ", "پ", "ج", "ش"],
  short: ["1ش", "2ش", "3ش", "4ش", "5ش", "ج", "ش"],
  abbreviated: [
    "یکشنبه",
    "دوشنبه",
    "سه‌شنبه",
    "چهارشنبه",
    "پنجشنبه",
    "جمعه",
    "شنبه"
  ],
  wide: ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"]
}, dayPeriodValues$W = {
  narrow: {
    am: "ق",
    pm: "ب",
    midnight: "ن",
    noon: "ظ",
    morning: "ص",
    afternoon: "ب.ظ.",
    evening: "ع",
    night: "ش"
  },
  abbreviated: {
    am: "ق.ظ.",
    pm: "ب.ظ.",
    midnight: "نیمه‌شب",
    noon: "ظهر",
    morning: "صبح",
    afternoon: "بعدازظهر",
    evening: "عصر",
    night: "شب"
  },
  wide: {
    am: "قبل‌ازظهر",
    pm: "بعدازظهر",
    midnight: "نیمه‌شب",
    noon: "ظهر",
    morning: "صبح",
    afternoon: "بعدازظهر",
    evening: "عصر",
    night: "شب"
  }
}, formattingDayPeriodValues$J = {
  narrow: {
    am: "ق",
    pm: "ب",
    midnight: "ن",
    noon: "ظ",
    morning: "ص",
    afternoon: "ب.ظ.",
    evening: "ع",
    night: "ش"
  },
  abbreviated: {
    am: "ق.ظ.",
    pm: "ب.ظ.",
    midnight: "نیمه‌شب",
    noon: "ظهر",
    morning: "صبح",
    afternoon: "بعدازظهر",
    evening: "عصر",
    night: "شب"
  },
  wide: {
    am: "قبل‌ازظهر",
    pm: "بعدازظهر",
    midnight: "نیمه‌شب",
    noon: "ظهر",
    morning: "صبح",
    afternoon: "بعدازظهر",
    evening: "عصر",
    night: "شب"
  }
}, ordinalNumber$W = (u, l) => String(u), localize$W = {
  ordinalNumber: ordinalNumber$W,
  era: buildLocalizeFn({
    values: eraValues$W,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$W,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$W,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$W,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$W,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$J,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$W = /^(\d+)(th|st|nd|rd)?/i, parseOrdinalNumberPattern$W = /\d+/i, matchEraPatterns$W = {
  narrow: /^(ق|ب)/i,
  abbreviated: /^(ق\.?\s?م\.?|ق\.?\s?د\.?\s?م\.?|م\.?\s?|د\.?\s?م\.?)/i,
  wide: /^(قبل از میلاد|قبل از دوران مشترک|میلادی|دوران مشترک|بعد از میلاد)/i
}, parseEraPatterns$W = {
  any: [/^قبل/i, /^بعد/i]
}, matchQuarterPatterns$W = {
  narrow: /^[1234]/i,
  abbreviated: /^س‌م[1234]/i,
  wide: /^سه‌ماهه [1234]/i
}, parseQuarterPatterns$W = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$W = {
  narrow: /^[جژفمآاماسند]/i,
  abbreviated: /^(جنو|ژانـ|ژانویه|فوریه|فور|مارس|آوریل|آپر|مه|می|ژوئن|جون|جول|جولـ|ژوئیه|اوت|آگو|سپتمبر|سپتامبر|اکتبر|اکتوبر|نوامبر|نوامـ|دسامبر|دسامـ|دسم)/i,
  wide: /^(ژانویه|جنوری|فبروری|فوریه|مارچ|مارس|آپریل|اپریل|ایپریل|آوریل|مه|می|ژوئن|جون|جولای|ژوئیه|آگست|اگست|آگوست|اوت|سپتمبر|سپتامبر|اکتبر|اکتوبر|نوامبر|نومبر|دسامبر|دسمبر)/i
}, parseMonthPatterns$W = {
  narrow: [
    /^(ژ|ج)/i,
    /^ف/i,
    /^م/i,
    /^(آ|ا)/i,
    /^م/i,
    /^(ژ|ج)/i,
    /^(ج|ژ)/i,
    /^(آ|ا)/i,
    /^س/i,
    /^ا/i,
    /^ن/i,
    /^د/i
  ],
  any: [
    /^ژا/i,
    /^ف/i,
    /^ما/i,
    /^آپ/i,
    /^(می|مه)/i,
    /^(ژوئن|جون)/i,
    /^(ژوئی|جول)/i,
    /^(اوت|آگ)/i,
    /^س/i,
    /^(اوک|اک)/i,
    /^ن/i,
    /^د/i
  ]
}, matchDayPatterns$W = {
  narrow: /^[شیدسچپج]/i,
  short: /^(ش|ج|1ش|2ش|3ش|4ش|5ش)/i,
  abbreviated: /^(یکشنبه|دوشنبه|سه‌شنبه|چهارشنبه|پنج‌شنبه|جمعه|شنبه)/i,
  wide: /^(یکشنبه|دوشنبه|سه‌شنبه|چهارشنبه|پنج‌شنبه|جمعه|شنبه)/i
}, parseDayPatterns$W = {
  narrow: [/^ی/i, /^دو/i, /^س/i, /^چ/i, /^پ/i, /^ج/i, /^ش/i],
  any: [
    /^(ی|1ش|یکشنبه)/i,
    /^(د|2ش|دوشنبه)/i,
    /^(س|3ش|سه‌شنبه)/i,
    /^(چ|4ش|چهارشنبه)/i,
    /^(پ|5ش|پنجشنبه)/i,
    /^(ج|جمعه)/i,
    /^(ش|شنبه)/i
  ]
}, matchDayPeriodPatterns$W = {
  narrow: /^(ب|ق|ن|ظ|ص|ب.ظ.|ع|ش)/i,
  abbreviated: /^(ق.ظ.|ب.ظ.|نیمه‌شب|ظهر|صبح|بعدازظهر|عصر|شب)/i,
  wide: /^(قبل‌ازظهر|نیمه‌شب|ظهر|صبح|بعدازظهر|عصر|شب)/i
}, parseDayPeriodPatterns$W = {
  any: {
    am: /^(ق|ق.ظ.|قبل‌ازظهر)/i,
    pm: /^(ب|ب.ظ.|بعدازظهر)/i,
    midnight: /^(‌نیمه‌شب|ن)/i,
    noon: /^(ظ|ظهر)/i,
    morning: /(ص|صبح)/i,
    afternoon: /(ب|ب.ظ.|بعدازظهر)/i,
    evening: /(ع|عصر)/i,
    night: /(ش|شب)/i
  }
}, match$X = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$W,
    parsePattern: parseOrdinalNumberPattern$W,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$W,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$W,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$W,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$W,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$W,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$W,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$W,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$W,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$W,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPeriodPatterns$W,
    defaultParseWidth: "any"
  })
}, faIR = {
  code: "fa-IR",
  formatDistance: formatDistance$W,
  formatLong: formatLong$Z,
  formatRelative: formatRelative$X,
  localize: localize$W,
  match: match$X,
  options: {
    weekStartsOn: 6,
    firstWeekContainsDate: 1
  }
};
function futureSeconds(u) {
  return u.replace(/sekuntia?/, "sekunnin");
}
function futureMinutes(u) {
  return u.replace(/minuuttia?/, "minuutin");
}
function futureHours(u) {
  return u.replace(/tuntia?/, "tunnin");
}
function futureDays(u) {
  return u.replace(/päivää?/, "päivän");
}
function futureWeeks(u) {
  return u.replace(/(viikko|viikkoa)/, "viikon");
}
function futureMonths(u) {
  return u.replace(/(kuukausi|kuukautta)/, "kuukauden");
}
function futureYears(u) {
  return u.replace(/(vuosi|vuotta)/, "vuoden");
}
const formatDistanceLocale$U = {
  lessThanXSeconds: {
    one: "alle sekunti",
    other: "alle {{count}} sekuntia",
    futureTense: futureSeconds
  },
  xSeconds: {
    one: "sekunti",
    other: "{{count}} sekuntia",
    futureTense: futureSeconds
  },
  halfAMinute: {
    one: "puoli minuuttia",
    other: "puoli minuuttia",
    futureTense: (u) => "puolen minuutin"
  },
  lessThanXMinutes: {
    one: "alle minuutti",
    other: "alle {{count}} minuuttia",
    futureTense: futureMinutes
  },
  xMinutes: {
    one: "minuutti",
    other: "{{count}} minuuttia",
    futureTense: futureMinutes
  },
  aboutXHours: {
    one: "noin tunti",
    other: "noin {{count}} tuntia",
    futureTense: futureHours
  },
  xHours: {
    one: "tunti",
    other: "{{count}} tuntia",
    futureTense: futureHours
  },
  xDays: {
    one: "päivä",
    other: "{{count}} päivää",
    futureTense: futureDays
  },
  aboutXWeeks: {
    one: "noin viikko",
    other: "noin {{count}} viikkoa",
    futureTense: futureWeeks
  },
  xWeeks: {
    one: "viikko",
    other: "{{count}} viikkoa",
    futureTense: futureWeeks
  },
  aboutXMonths: {
    one: "noin kuukausi",
    other: "noin {{count}} kuukautta",
    futureTense: futureMonths
  },
  xMonths: {
    one: "kuukausi",
    other: "{{count}} kuukautta",
    futureTense: futureMonths
  },
  aboutXYears: {
    one: "noin vuosi",
    other: "noin {{count}} vuotta",
    futureTense: futureYears
  },
  xYears: {
    one: "vuosi",
    other: "{{count}} vuotta",
    futureTense: futureYears
  },
  overXYears: {
    one: "yli vuosi",
    other: "yli {{count}} vuotta",
    futureTense: futureYears
  },
  almostXYears: {
    one: "lähes vuosi",
    other: "lähes {{count}} vuotta",
    futureTense: futureYears
  }
}, formatDistance$V = (u, l, f) => {
  const p = formatDistanceLocale$U[u], m = l === 1 ? p.one : p.other.replace("{{count}}", String(l));
  return f?.addSuffix ? f.comparison && f.comparison > 0 ? p.futureTense(m) + " kuluttua" : m + " sitten" : m;
}, dateFormats$Y = {
  full: "eeee d. MMMM y",
  long: "d. MMMM y",
  medium: "d. MMM y",
  short: "d.M.y"
}, timeFormats$Y = {
  full: "HH.mm.ss zzzz",
  long: "HH.mm.ss z",
  medium: "HH.mm.ss",
  short: "HH.mm"
}, dateTimeFormats$Y = {
  full: "{{date}} 'klo' {{time}}",
  long: "{{date}} 'klo' {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$Y = {
  date: buildFormatLongFn({
    formats: dateFormats$Y,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$Y,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$Y,
    defaultWidth: "full"
  })
}, formatRelativeLocale$W = {
  lastWeek: "'viime' eeee 'klo' p",
  yesterday: "'eilen klo' p",
  today: "'tänään klo' p",
  tomorrow: "'huomenna klo' p",
  nextWeek: "'ensi' eeee 'klo' p",
  other: "P"
}, formatRelative$W = (u, l, f, p) => formatRelativeLocale$W[u], eraValues$V = {
  narrow: ["eaa.", "jaa."],
  abbreviated: ["eaa.", "jaa."],
  wide: ["ennen ajanlaskun alkua", "jälkeen ajanlaskun alun"]
}, quarterValues$V = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1. kvartaali", "2. kvartaali", "3. kvartaali", "4. kvartaali"]
}, monthValues$V = {
  narrow: ["T", "H", "M", "H", "T", "K", "H", "E", "S", "L", "M", "J"],
  abbreviated: [
    "tammi",
    "helmi",
    "maalis",
    "huhti",
    "touko",
    "kesä",
    "heinä",
    "elo",
    "syys",
    "loka",
    "marras",
    "joulu"
  ],
  wide: [
    "tammikuu",
    "helmikuu",
    "maaliskuu",
    "huhtikuu",
    "toukokuu",
    "kesäkuu",
    "heinäkuu",
    "elokuu",
    "syyskuu",
    "lokakuu",
    "marraskuu",
    "joulukuu"
  ]
}, formattingMonthValues$b = {
  narrow: monthValues$V.narrow,
  abbreviated: monthValues$V.abbreviated,
  wide: [
    "tammikuuta",
    "helmikuuta",
    "maaliskuuta",
    "huhtikuuta",
    "toukokuuta",
    "kesäkuuta",
    "heinäkuuta",
    "elokuuta",
    "syyskuuta",
    "lokakuuta",
    "marraskuuta",
    "joulukuuta"
  ]
}, dayValues$V = {
  narrow: ["S", "M", "T", "K", "T", "P", "L"],
  short: ["su", "ma", "ti", "ke", "to", "pe", "la"],
  abbreviated: ["sunn.", "maan.", "tiis.", "kesk.", "torst.", "perj.", "la"],
  wide: [
    "sunnuntai",
    "maanantai",
    "tiistai",
    "keskiviikko",
    "torstai",
    "perjantai",
    "lauantai"
  ]
}, formattingDayValues$3 = {
  narrow: dayValues$V.narrow,
  short: dayValues$V.short,
  abbreviated: dayValues$V.abbreviated,
  wide: [
    "sunnuntaina",
    "maanantaina",
    "tiistaina",
    "keskiviikkona",
    "torstaina",
    "perjantaina",
    "lauantaina"
  ]
}, dayPeriodValues$V = {
  narrow: {
    am: "ap",
    pm: "ip",
    midnight: "keskiyö",
    noon: "keskipäivä",
    morning: "ap",
    afternoon: "ip",
    evening: "illalla",
    night: "yöllä"
  },
  abbreviated: {
    am: "ap",
    pm: "ip",
    midnight: "keskiyö",
    noon: "keskipäivä",
    morning: "ap",
    afternoon: "ip",
    evening: "illalla",
    night: "yöllä"
  },
  wide: {
    am: "ap",
    pm: "ip",
    midnight: "keskiyöllä",
    noon: "keskipäivällä",
    morning: "aamupäivällä",
    afternoon: "iltapäivällä",
    evening: "illalla",
    night: "yöllä"
  }
}, ordinalNumber$V = (u, l) => Number(u) + ".", localize$V = {
  ordinalNumber: ordinalNumber$V,
  era: buildLocalizeFn({
    values: eraValues$V,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$V,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$V,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$b,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$V,
    defaultWidth: "wide",
    formattingValues: formattingDayValues$3,
    defaultFormattingWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$V,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$V = /^(\d+)(\.)/i, parseOrdinalNumberPattern$V = /\d+/i, matchEraPatterns$V = {
  narrow: /^(e|j)/i,
  abbreviated: /^(eaa.|jaa.)/i,
  wide: /^(ennen ajanlaskun alkua|jälkeen ajanlaskun alun)/i
}, parseEraPatterns$V = {
  any: [/^e/i, /^j/i]
}, matchQuarterPatterns$V = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234]\.? kvartaali/i
}, parseQuarterPatterns$V = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$V = {
  narrow: /^[thmkeslj]/i,
  abbreviated: /^(tammi|helmi|maalis|huhti|touko|kesä|heinä|elo|syys|loka|marras|joulu)/i,
  wide: /^(tammikuu|helmikuu|maaliskuu|huhtikuu|toukokuu|kesäkuu|heinäkuu|elokuu|syyskuu|lokakuu|marraskuu|joulukuu)(ta)?/i
}, parseMonthPatterns$V = {
  narrow: [
    /^t/i,
    /^h/i,
    /^m/i,
    /^h/i,
    /^t/i,
    /^k/i,
    /^h/i,
    /^e/i,
    /^s/i,
    /^l/i,
    /^m/i,
    /^j/i
  ],
  any: [
    /^ta/i,
    /^hel/i,
    /^maa/i,
    /^hu/i,
    /^to/i,
    /^k/i,
    /^hei/i,
    /^e/i,
    /^s/i,
    /^l/i,
    /^mar/i,
    /^j/i
  ]
}, matchDayPatterns$V = {
  narrow: /^[smtkpl]/i,
  short: /^(su|ma|ti|ke|to|pe|la)/i,
  abbreviated: /^(sunn.|maan.|tiis.|kesk.|torst.|perj.|la)/i,
  wide: /^(sunnuntai|maanantai|tiistai|keskiviikko|torstai|perjantai|lauantai)(na)?/i
}, parseDayPatterns$V = {
  narrow: [/^s/i, /^m/i, /^t/i, /^k/i, /^t/i, /^p/i, /^l/i],
  any: [/^s/i, /^m/i, /^ti/i, /^k/i, /^to/i, /^p/i, /^l/i]
}, matchDayPeriodPatterns$V = {
  narrow: /^(ap|ip|keskiyö|keskipäivä|aamupäivällä|iltapäivällä|illalla|yöllä)/i,
  any: /^(ap|ip|keskiyöllä|keskipäivällä|aamupäivällä|iltapäivällä|illalla|yöllä)/i
}, parseDayPeriodPatterns$V = {
  any: {
    am: /^ap/i,
    pm: /^ip/i,
    midnight: /^keskiyö/i,
    noon: /^keskipäivä/i,
    morning: /aamupäivällä/i,
    afternoon: /iltapäivällä/i,
    evening: /illalla/i,
    night: /yöllä/i
  }
}, match$W = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$V,
    parsePattern: parseOrdinalNumberPattern$V,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$V,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$V,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$V,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$V,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$V,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$V,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$V,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$V,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$V,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$V,
    defaultParseWidth: "any"
  })
}, fi = {
  code: "fi",
  formatDistance: formatDistance$V,
  formatLong: formatLong$Y,
  formatRelative: formatRelative$W,
  localize: localize$V,
  match: match$W,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$T = {
  lessThanXSeconds: {
    one: "moins d’une seconde",
    other: "moins de {{count}} secondes"
  },
  xSeconds: {
    one: "1 seconde",
    other: "{{count}} secondes"
  },
  halfAMinute: "30 secondes",
  lessThanXMinutes: {
    one: "moins d’une minute",
    other: "moins de {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "environ 1 heure",
    other: "environ {{count}} heures"
  },
  xHours: {
    one: "1 heure",
    other: "{{count}} heures"
  },
  xDays: {
    one: "1 jour",
    other: "{{count}} jours"
  },
  aboutXWeeks: {
    one: "environ 1 semaine",
    other: "environ {{count}} semaines"
  },
  xWeeks: {
    one: "1 semaine",
    other: "{{count}} semaines"
  },
  aboutXMonths: {
    one: "environ 1 mois",
    other: "environ {{count}} mois"
  },
  xMonths: {
    one: "1 mois",
    other: "{{count}} mois"
  },
  aboutXYears: {
    one: "environ 1 an",
    other: "environ {{count}} ans"
  },
  xYears: {
    one: "1 an",
    other: "{{count}} ans"
  },
  overXYears: {
    one: "plus d’un an",
    other: "plus de {{count}} ans"
  },
  almostXYears: {
    one: "presqu’un an",
    other: "presque {{count}} ans"
  }
}, formatDistance$U = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$T[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "dans " + p : "il y a " + p : p;
}, dateFormats$X = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$X = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$X = {
  full: "{{date}} 'à' {{time}}",
  long: "{{date}} 'à' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$X = {
  date: buildFormatLongFn({
    formats: dateFormats$X,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$X,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$X,
    defaultWidth: "full"
  })
}, formatRelativeLocale$V = {
  lastWeek: "eeee 'dernier à' p",
  yesterday: "'hier à' p",
  today: "'aujourd’hui à' p",
  tomorrow: "'demain à' p'",
  nextWeek: "eeee 'prochain à' p",
  other: "P"
}, formatRelative$V = (u, l, f, p) => formatRelativeLocale$V[u], eraValues$U = {
  narrow: ["av. J.-C", "ap. J.-C"],
  abbreviated: ["av. J.-C", "ap. J.-C"],
  wide: ["avant Jésus-Christ", "après Jésus-Christ"]
}, quarterValues$U = {
  narrow: ["T1", "T2", "T3", "T4"],
  abbreviated: ["1er trim.", "2ème trim.", "3ème trim.", "4ème trim."],
  wide: ["1er trimestre", "2ème trimestre", "3ème trimestre", "4ème trimestre"]
}, monthValues$U = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "janv.",
    "févr.",
    "mars",
    "avr.",
    "mai",
    "juin",
    "juil.",
    "août",
    "sept.",
    "oct.",
    "nov.",
    "déc."
  ],
  wide: [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre"
  ]
}, dayValues$U = {
  narrow: ["D", "L", "M", "M", "J", "V", "S"],
  short: ["di", "lu", "ma", "me", "je", "ve", "sa"],
  abbreviated: ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."],
  wide: [
    "dimanche",
    "lundi",
    "mardi",
    "mercredi",
    "jeudi",
    "vendredi",
    "samedi"
  ]
}, dayPeriodValues$U = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "minuit",
    noon: "midi",
    morning: "mat.",
    afternoon: "ap.m.",
    evening: "soir",
    night: "mat."
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "minuit",
    noon: "midi",
    morning: "matin",
    afternoon: "après-midi",
    evening: "soir",
    night: "matin"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "minuit",
    noon: "midi",
    morning: "du matin",
    afternoon: "de l’après-midi",
    evening: "du soir",
    night: "du matin"
  }
}, ordinalNumber$U = (u, l) => {
  const f = Number(u), p = l?.unit;
  if (f === 0) return "0";
  const m = ["year", "week", "hour", "minute", "second"];
  let b;
  return f === 1 ? b = p && m.includes(p) ? "ère" : "er" : b = "ème", f + b;
}, LONG_MONTHS_TOKENS = ["MMM", "MMMM"], localize$U = {
  preprocessor: (u, l) => u.getDate() === 1 || !l.some(
    (p) => p.isToken && LONG_MONTHS_TOKENS.includes(p.value)
  ) ? l : l.map(
    (p) => p.isToken && p.value === "do" ? { isToken: !0, value: "d" } : p
  ),
  ordinalNumber: ordinalNumber$U,
  era: buildLocalizeFn({
    values: eraValues$U,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$U,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$U,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$U,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$U,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$U = /^(\d+)(ième|ère|ème|er|e)?/i, parseOrdinalNumberPattern$U = /\d+/i, matchEraPatterns$U = {
  narrow: /^(av\.J\.C|ap\.J\.C|ap\.J\.-C)/i,
  abbreviated: /^(av\.J\.-C|av\.J-C|apr\.J\.-C|apr\.J-C|ap\.J-C)/i,
  wide: /^(avant Jésus-Christ|après Jésus-Christ)/i
}, parseEraPatterns$U = {
  any: [/^av/i, /^ap/i]
}, matchQuarterPatterns$U = {
  narrow: /^T?[1234]/i,
  abbreviated: /^[1234](er|ème|e)? trim\.?/i,
  wide: /^[1234](er|ème|e)? trimestre/i
}, parseQuarterPatterns$U = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$U = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(janv|févr|mars|avr|mai|juin|juill|juil|août|sept|oct|nov|déc)\.?/i,
  wide: /^(janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)/i
}, parseMonthPatterns$U = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^av/i,
    /^ma/i,
    /^juin/i,
    /^juil/i,
    /^ao/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$U = {
  narrow: /^[lmjvsd]/i,
  short: /^(di|lu|ma|me|je|ve|sa)/i,
  abbreviated: /^(dim|lun|mar|mer|jeu|ven|sam)\.?/i,
  wide: /^(dimanche|lundi|mardi|mercredi|jeudi|vendredi|samedi)/i
}, parseDayPatterns$U = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^j/i, /^v/i, /^s/i],
  any: [/^di/i, /^lu/i, /^ma/i, /^me/i, /^je/i, /^ve/i, /^sa/i]
}, matchDayPeriodPatterns$U = {
  narrow: /^(a|p|minuit|midi|mat\.?|ap\.?m\.?|soir|nuit)/i,
  any: /^([ap]\.?\s?m\.?|du matin|de l'après[-\s]midi|du soir|de la nuit)/i
}, parseDayPeriodPatterns$U = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^min/i,
    noon: /^mid/i,
    morning: /mat/i,
    afternoon: /ap/i,
    evening: /soir/i,
    night: /nuit/i
  }
}, match$V = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$U,
    parsePattern: parseOrdinalNumberPattern$U,
    valueCallback: (u) => parseInt(u)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$U,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$U,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$U,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$U,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$U,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$U,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$U,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$U,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$U,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$U,
    defaultParseWidth: "any"
  })
}, fr = {
  code: "fr",
  formatDistance: formatDistance$U,
  formatLong: formatLong$X,
  formatRelative: formatRelative$V,
  localize: localize$U,
  match: match$V,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, dateFormats$W = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "yy-MM-dd"
}, timeFormats$W = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$W = {
  full: "{{date}} 'à' {{time}}",
  long: "{{date}} 'à' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$W = {
  date: buildFormatLongFn({
    formats: dateFormats$W,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$W,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$W,
    defaultWidth: "full"
  })
}, frCA = {
  code: "fr-CA",
  formatDistance: formatDistance$U,
  formatLong: formatLong$W,
  formatRelative: formatRelative$V,
  localize: localize$U,
  match: match$V,
  // Unique for fr-CA
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, dateFormats$V = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd.MM.y"
}, timeFormats$V = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$V = {
  full: "{{date}} 'à' {{time}}",
  long: "{{date}} 'à' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$V = {
  date: buildFormatLongFn({
    formats: dateFormats$V,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$V,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$V,
    defaultWidth: "full"
  })
}, formatRelativeLocale$U = {
  lastWeek: "eeee 'la semaine dernière à' p",
  yesterday: "'hier à' p",
  today: "'aujourd’hui à' p",
  tomorrow: "'demain à' p'",
  nextWeek: "eeee 'la semaine prochaine à' p",
  other: "P"
}, formatRelative$U = (u, l, f, p) => formatRelativeLocale$U[u], frCH = {
  code: "fr-CH",
  formatDistance: formatDistance$U,
  formatLong: formatLong$V,
  formatRelative: formatRelative$U,
  localize: localize$U,
  match: match$V,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$S = {
  lessThanXSeconds: {
    one: "minder as 1 sekonde",
    other: "minder as {{count}} sekonden"
  },
  xSeconds: {
    one: "1 sekonde",
    other: "{{count}} sekonden"
  },
  halfAMinute: "oardel minút",
  lessThanXMinutes: {
    one: "minder as 1 minút",
    other: "minder as {{count}} minuten"
  },
  xMinutes: {
    one: "1 minút",
    other: "{{count}} minuten"
  },
  aboutXHours: {
    one: "sawat 1 oere",
    other: "sawat {{count}} oere"
  },
  xHours: {
    one: "1 oere",
    other: "{{count}} oere"
  },
  xDays: {
    one: "1 dei",
    other: "{{count}} dagen"
  },
  aboutXWeeks: {
    one: "sawat 1 wike",
    other: "sawat {{count}} wiken"
  },
  xWeeks: {
    one: "1 wike",
    other: "{{count}} wiken"
  },
  aboutXMonths: {
    one: "sawat 1 moanne",
    other: "sawat {{count}} moannen"
  },
  xMonths: {
    one: "1 moanne",
    other: "{{count}} moannen"
  },
  aboutXYears: {
    one: "sawat 1 jier",
    other: "sawat {{count}} jier"
  },
  xYears: {
    one: "1 jier",
    other: "{{count}} jier"
  },
  overXYears: {
    one: "mear as 1 jier",
    other: "mear as {{count}}s jier"
  },
  almostXYears: {
    one: "hast 1 jier",
    other: "hast {{count}} jier"
  }
}, formatDistance$T = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$S[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "oer " + p : p + " lyn" : p;
}, dateFormats$U = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd-MM-y"
}, timeFormats$U = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$U = {
  full: "{{date}} 'om' {{time}}",
  long: "{{date}} 'om' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$U = {
  date: buildFormatLongFn({
    formats: dateFormats$U,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$U,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$U,
    defaultWidth: "full"
  })
}, formatRelativeLocale$T = {
  lastWeek: "'ôfrûne' eeee 'om' p",
  yesterday: "'juster om' p",
  today: "'hjoed om' p",
  tomorrow: "'moarn om' p",
  nextWeek: "eeee 'om' p",
  other: "P"
}, formatRelative$T = (u, l, f, p) => formatRelativeLocale$T[u], eraValues$T = {
  narrow: ["f.K.", "n.K."],
  abbreviated: ["f.Kr.", "n.Kr."],
  wide: ["foar Kristus", "nei Kristus"]
}, quarterValues$T = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: ["1e fearnsjier", "2e fearnsjier", "3e fearnsjier", "4e fearnsjier"]
}, monthValues$T = {
  narrow: ["j", "f", "m", "a", "m", "j", "j", "a", "s", "o", "n", "d"],
  abbreviated: [
    "jan.",
    "feb.",
    "mrt.",
    "apr.",
    "mai.",
    "jun.",
    "jul.",
    "aug.",
    "sep.",
    "okt.",
    "nov.",
    "des."
  ],
  wide: [
    "jannewaris",
    "febrewaris",
    "maart",
    "april",
    "maaie",
    "juny",
    "july",
    "augustus",
    "septimber",
    "oktober",
    "novimber",
    "desimber"
  ]
}, dayValues$T = {
  narrow: ["s", "m", "t", "w", "t", "f", "s"],
  short: ["si", "mo", "ti", "wo", "to", "fr", "so"],
  abbreviated: ["snein", "moa", "tii", "woa", "ton", "fre", "sneon"],
  wide: [
    "snein",
    "moandei",
    "tiisdei",
    "woansdei",
    "tongersdei",
    "freed",
    "sneon"
  ]
}, dayPeriodValues$T = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "middernacht",
    noon: "middei",
    morning: "moarns",
    afternoon: "middeis",
    evening: "jûns",
    night: "nachts"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "middernacht",
    noon: "middei",
    morning: "moarns",
    afternoon: "middeis",
    evening: "jûns",
    night: "nachts"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "middernacht",
    noon: "middei",
    morning: "moarns",
    afternoon: "middeis",
    evening: "jûns",
    night: "nachts"
  }
}, ordinalNumber$T = (u, l) => Number(u) + "e", localize$T = {
  ordinalNumber: ordinalNumber$T,
  era: buildLocalizeFn({
    values: eraValues$T,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$T,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$T,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$T,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$T,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$T = /^(\d+)e?/i, parseOrdinalNumberPattern$T = /\d+/i, matchEraPatterns$T = {
  narrow: /^([fn]\.? ?K\.?)/,
  abbreviated: /^([fn]\. ?Kr\.?)/,
  wide: /^((foar|nei) Kristus)/
}, parseEraPatterns$T = {
  any: [/^f/, /^n/]
}, matchQuarterPatterns$T = {
  narrow: /^[1234]/i,
  abbreviated: /^K[1234]/i,
  wide: /^[1234]e fearnsjier/i
}, parseQuarterPatterns$T = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$T = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan.|feb.|mrt.|apr.|mai.|jun.|jul.|aug.|sep.|okt.|nov.|des.)/i,
  wide: /^(jannewaris|febrewaris|maart|april|maaie|juny|july|augustus|septimber|oktober|novimber|desimber)/i
}, parseMonthPatterns$T = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^jan/i,
    /^feb/i,
    /^m(r|a)/i,
    /^apr/i,
    /^mai/i,
    /^jun/i,
    /^jul/i,
    /^aug/i,
    /^sep/i,
    /^okt/i,
    /^nov/i,
    /^des/i
  ]
}, matchDayPatterns$T = {
  narrow: /^[smtwf]/i,
  short: /^(si|mo|ti|wo|to|fr|so)/i,
  abbreviated: /^(snein|moa|tii|woa|ton|fre|sneon)/i,
  wide: /^(snein|moandei|tiisdei|woansdei|tongersdei|freed|sneon)/i
}, parseDayPatterns$T = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^sn/i, /^mo/i, /^ti/i, /^wo/i, /^to/i, /^fr/i, /^sn/i]
}, matchDayPeriodPatterns$T = {
  any: /^(am|pm|middernacht|middeis|moarns|middei|jûns|nachts)/i
}, parseDayPeriodPatterns$T = {
  any: {
    am: /^am/i,
    pm: /^pm/i,
    midnight: /^middernacht/i,
    noon: /^middei/i,
    morning: /moarns/i,
    afternoon: /^middeis/i,
    evening: /jûns/i,
    night: /nachts/i
  }
}, match$U = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$T,
    parsePattern: parseOrdinalNumberPattern$T,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$T,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$T,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$T,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$T,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$T,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$T,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$T,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$T,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$T,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$T,
    defaultParseWidth: "any"
  })
}, fy = {
  code: "fy",
  formatDistance: formatDistance$T,
  formatLong: formatLong$U,
  formatRelative: formatRelative$T,
  localize: localize$T,
  match: match$U,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$R = {
  lessThanXSeconds: {
    one: "nas lugha na diog",
    other: "nas lugha na {{count}} diogan"
  },
  xSeconds: {
    one: "1 diog",
    two: "2 dhiog",
    twenty: "20 diog",
    other: "{{count}} diogan"
  },
  halfAMinute: "leth mhionaid",
  lessThanXMinutes: {
    one: "nas lugha na mionaid",
    other: "nas lugha na {{count}} mionaidean"
  },
  xMinutes: {
    one: "1 mionaid",
    two: "2 mhionaid",
    twenty: "20 mionaid",
    other: "{{count}} mionaidean"
  },
  aboutXHours: {
    one: "mu uair de thìde",
    other: "mu {{count}} uairean de thìde"
  },
  xHours: {
    one: "1 uair de thìde",
    two: "2 uair de thìde",
    twenty: "20 uair de thìde",
    other: "{{count}} uairean de thìde"
  },
  xDays: {
    one: "1 là",
    other: "{{count}} là"
  },
  aboutXWeeks: {
    one: "mu 1 seachdain",
    other: "mu {{count}} seachdainean"
  },
  xWeeks: {
    one: "1 seachdain",
    other: "{{count}} seachdainean"
  },
  aboutXMonths: {
    one: "mu mhìos",
    other: "mu {{count}} mìosan"
  },
  xMonths: {
    one: "1 mìos",
    other: "{{count}} mìosan"
  },
  aboutXYears: {
    one: "mu bhliadhna",
    other: "mu {{count}} bliadhnaichean"
  },
  xYears: {
    one: "1 bhliadhna",
    other: "{{count}} bliadhna"
  },
  overXYears: {
    one: "còrr is bliadhna",
    other: "còrr is {{count}} bliadhnaichean"
  },
  almostXYears: {
    one: "cha mhòr bliadhna",
    other: "cha mhòr {{count}} bliadhnaichean"
  }
}, formatDistance$S = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$R[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 2 && m.two ? p = m.two : l === 20 && m.twenty ? p = m.twenty : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "ann an " + p : "o chionn " + p : p;
}, dateFormats$T = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
}, timeFormats$T = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
}, dateTimeFormats$T = {
  full: "{{date}} 'aig' {{time}}",
  long: "{{date}} 'aig' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$T = {
  date: buildFormatLongFn({
    formats: dateFormats$T,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$T,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$T,
    defaultWidth: "full"
  })
}, formatRelativeLocale$S = {
  lastWeek: "'mu dheireadh' eeee 'aig' p",
  //FIX
  yesterday: "'an-dè aig' p",
  today: "'an-diugh aig' p",
  tomorrow: "'a-màireach aig' p",
  nextWeek: "eeee 'aig' p",
  other: "P"
}, formatRelative$S = (u, l, f, p) => formatRelativeLocale$S[u], eraValues$S = {
  narrow: ["R", "A"],
  abbreviated: ["RC", "AD"],
  wide: ["ro Chrìosta", "anno domini"]
}, quarterValues$S = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["C1", "C2", "C3", "C4"],
  wide: [
    "a' chiad chairteal",
    "an dàrna cairteal",
    "an treas cairteal",
    "an ceathramh cairteal"
  ]
}, monthValues$S = {
  narrow: ["F", "G", "M", "G", "C", "Ò", "I", "L", "S", "D", "S", "D"],
  abbreviated: [
    "Faoi",
    "Gear",
    "Màrt",
    "Gibl",
    "Cèit",
    "Ògmh",
    "Iuch",
    "Lùn",
    "Sult",
    "Dàmh",
    "Samh",
    "Dùbh"
  ],
  wide: [
    "Am Faoilleach",
    "An Gearran",
    "Am Màrt",
    "An Giblean",
    "An Cèitean",
    "An t-Ògmhios",
    "An t-Iuchar",
    "An Lùnastal",
    "An t-Sultain",
    "An Dàmhair",
    "An t-Samhain",
    "An Dùbhlachd"
  ]
}, dayValues$S = {
  narrow: ["D", "L", "M", "C", "A", "H", "S"],
  short: ["Dò", "Lu", "Mà", "Ci", "Ar", "Ha", "Sa"],
  abbreviated: ["Did", "Dil", "Dim", "Dic", "Dia", "Dih", "Dis"],
  wide: [
    "Didòmhnaich",
    "Diluain",
    "Dimàirt",
    "Diciadain",
    "Diardaoin",
    "Dihaoine",
    "Disathairne"
  ]
}, dayPeriodValues$S = {
  narrow: {
    am: "m",
    pm: "f",
    midnight: "m.o.",
    noon: "m.l.",
    morning: "madainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "oidhche"
  },
  abbreviated: {
    am: "M.",
    pm: "F.",
    midnight: "meadhan oidhche",
    noon: "meadhan là",
    morning: "madainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "oidhche"
  },
  wide: {
    am: "m.",
    pm: "f.",
    midnight: "meadhan oidhche",
    noon: "meadhan là",
    morning: "madainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "oidhche"
  }
}, formattingDayPeriodValues$I = {
  narrow: {
    am: "m",
    pm: "f",
    midnight: "m.o.",
    noon: "m.l.",
    morning: "sa mhadainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "air an oidhche"
  },
  abbreviated: {
    am: "M.",
    pm: "F.",
    midnight: "meadhan oidhche",
    noon: "meadhan là",
    morning: "sa mhadainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "air an oidhche"
  },
  wide: {
    am: "m.",
    pm: "f.",
    midnight: "meadhan oidhche",
    noon: "meadhan là",
    morning: "sa mhadainn",
    afternoon: "feasgar",
    evening: "feasgar",
    night: "air an oidhche"
  }
}, ordinalNumber$S = (u) => {
  const l = Number(u), f = l % 100;
  if (f > 20 || f < 10)
    switch (f % 10) {
      case 1:
        return l + "d";
      case 2:
        return l + "na";
    }
  return f === 12 ? l + "na" : l + "mh";
}, localize$S = {
  ordinalNumber: ordinalNumber$S,
  era: buildLocalizeFn({
    values: eraValues$S,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$S,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$S,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$S,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$S,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$I,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$S = /^(\d+)(d|na|tr|mh)?/i, parseOrdinalNumberPattern$S = /\d+/i, matchEraPatterns$S = {
  narrow: /^(r|a)/i,
  abbreviated: /^(r\.?\s?c\.?|r\.?\s?a\.?\s?c\.?|a\.?\s?d\.?|a\.?\s?c\.?)/i,
  wide: /^(ro Chrìosta|ron aois choitchinn|anno domini|aois choitcheann)/i
}, parseEraPatterns$S = {
  any: [/^b/i, /^(a|c)/i]
}, matchQuarterPatterns$S = {
  narrow: /^[1234]/i,
  abbreviated: /^c[1234]/i,
  wide: /^[1234](cd|na|tr|mh)? cairteal/i
}, parseQuarterPatterns$S = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$S = {
  narrow: /^[fgmcòilsd]/i,
  abbreviated: /^(faoi|gear|màrt|gibl|cèit|ògmh|iuch|lùn|sult|dàmh|samh|dùbh)/i,
  wide: /^(am faoilleach|an gearran|am màrt|an giblean|an cèitean|an t-Ògmhios|an t-Iuchar|an lùnastal|an t-Sultain|an dàmhair|an t-Samhain|an dùbhlachd)/i
}, parseMonthPatterns$S = {
  narrow: [
    /^f/i,
    /^g/i,
    /^m/i,
    /^g/i,
    /^c/i,
    /^ò/i,
    /^i/i,
    /^l/i,
    /^s/i,
    /^d/i,
    /^s/i,
    /^d/i
  ],
  any: [
    /^fa/i,
    /^ge/i,
    /^mà/i,
    /^gi/i,
    /^c/i,
    /^ò/i,
    /^i/i,
    /^l/i,
    /^su/i,
    /^d/i,
    /^sa/i,
    /^d/i
  ]
}, matchDayPatterns$S = {
  narrow: /^[dlmcahs]/i,
  short: /^(dò|lu|mà|ci|ar|ha|sa)/i,
  abbreviated: /^(did|dil|dim|dic|dia|dih|dis)/i,
  wide: /^(didòmhnaich|diluain|dimàirt|diciadain|diardaoin|dihaoine|disathairne)/i
}, parseDayPatterns$S = {
  narrow: [/^d/i, /^l/i, /^m/i, /^c/i, /^a/i, /^h/i, /^s/i],
  any: [/^d/i, /^l/i, /^m/i, /^c/i, /^a/i, /^h/i, /^s/i]
}, matchDayPeriodPatterns$S = {
  narrow: /^(a|p|mi|n|(san|aig) (madainn|feasgar|feasgar|oidhche))/i,
  any: /^([ap]\.?\s?m\.?|meadhan oidhche|meadhan là|(san|aig) (madainn|feasgar|feasgar|oidhche))/i
}, parseDayPeriodPatterns$S = {
  any: {
    am: /^m/i,
    pm: /^f/i,
    midnight: /^meadhan oidhche/i,
    noon: /^meadhan là/i,
    morning: /sa mhadainn/i,
    afternoon: /feasgar/i,
    evening: /feasgar/i,
    night: /air an oidhche/i
  }
}, match$T = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$S,
    parsePattern: parseOrdinalNumberPattern$S,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$S,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$S,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$S,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$S,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$S,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$S,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$S,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$S,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$S,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$S,
    defaultParseWidth: "any"
  })
}, gd = {
  code: "gd",
  formatDistance: formatDistance$S,
  formatLong: formatLong$T,
  formatRelative: formatRelative$S,
  localize: localize$S,
  match: match$T,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$Q = {
  lessThanXSeconds: {
    one: "menos dun segundo",
    other: "menos de {{count}} segundos"
  },
  xSeconds: {
    one: "1 segundo",
    other: "{{count}} segundos"
  },
  halfAMinute: "medio minuto",
  lessThanXMinutes: {
    one: "menos dun minuto",
    other: "menos de {{count}} minutos"
  },
  xMinutes: {
    one: "1 minuto",
    other: "{{count}} minutos"
  },
  aboutXHours: {
    one: "arredor dunha hora",
    other: "arredor de {{count}} horas"
  },
  xHours: {
    one: "1 hora",
    other: "{{count}} horas"
  },
  xDays: {
    one: "1 día",
    other: "{{count}} días"
  },
  aboutXWeeks: {
    one: "arredor dunha semana",
    other: "arredor de {{count}} semanas"
  },
  xWeeks: {
    one: "1 semana",
    other: "{{count}} semanas"
  },
  aboutXMonths: {
    one: "arredor de 1 mes",
    other: "arredor de {{count}} meses"
  },
  xMonths: {
    one: "1 mes",
    other: "{{count}} meses"
  },
  aboutXYears: {
    one: "arredor dun ano",
    other: "arredor de {{count}} anos"
  },
  xYears: {
    one: "1 ano",
    other: "{{count}} anos"
  },
  overXYears: {
    one: "máis dun ano",
    other: "máis de {{count}} anos"
  },
  almostXYears: {
    one: "case un ano",
    other: "case {{count}} anos"
  }
}, formatDistance$R = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$Q[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "en " + p : "hai " + p : p;
}, dateFormats$S = {
  full: "EEEE, d 'de' MMMM y",
  long: "d 'de' MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$S = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$S = {
  full: "{{date}} 'ás' {{time}}",
  long: "{{date}} 'ás' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$S = {
  date: buildFormatLongFn({
    formats: dateFormats$S,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$S,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$S,
    defaultWidth: "full"
  })
}, formatRelativeLocale$R = {
  lastWeek: "'o' eeee 'pasado á' LT",
  yesterday: "'onte á' p",
  today: "'hoxe á' p",
  tomorrow: "'mañá á' p",
  nextWeek: "eeee 'á' p",
  other: "P"
}, formatRelativeLocalePlural = {
  lastWeek: "'o' eeee 'pasado ás' p",
  yesterday: "'onte ás' p",
  today: "'hoxe ás' p",
  tomorrow: "'mañá ás' p",
  nextWeek: "eeee 'ás' p",
  other: "P"
}, formatRelative$R = (u, l, f, p) => l.getHours() !== 1 ? formatRelativeLocalePlural[u] : formatRelativeLocale$R[u], eraValues$R = {
  narrow: ["AC", "DC"],
  abbreviated: ["AC", "DC"],
  wide: ["antes de cristo", "despois de cristo"]
}, quarterValues$R = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1º trimestre", "2º trimestre", "3º trimestre", "4º trimestre"]
}, monthValues$R = {
  narrow: ["e", "f", "m", "a", "m", "j", "j", "a", "s", "o", "n", "d"],
  abbreviated: [
    "xan",
    "feb",
    "mar",
    "abr",
    "mai",
    "xun",
    "xul",
    "ago",
    "set",
    "out",
    "nov",
    "dec"
  ],
  wide: [
    "xaneiro",
    "febreiro",
    "marzo",
    "abril",
    "maio",
    "xuño",
    "xullo",
    "agosto",
    "setembro",
    "outubro",
    "novembro",
    "decembro"
  ]
}, dayValues$R = {
  narrow: ["d", "l", "m", "m", "j", "v", "s"],
  short: ["do", "lu", "ma", "me", "xo", "ve", "sa"],
  abbreviated: ["dom", "lun", "mar", "mer", "xov", "ven", "sab"],
  wide: ["domingo", "luns", "martes", "mércores", "xoves", "venres", "sábado"]
}, dayPeriodValues$R = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mn",
    noon: "md",
    morning: "mañá",
    afternoon: "tarde",
    evening: "tarde",
    night: "noite"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "medianoite",
    noon: "mediodía",
    morning: "mañá",
    afternoon: "tarde",
    evening: "tardiña",
    night: "noite"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "medianoite",
    noon: "mediodía",
    morning: "mañá",
    afternoon: "tarde",
    evening: "tardiña",
    night: "noite"
  }
}, formattingDayPeriodValues$H = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mn",
    noon: "md",
    morning: "da mañá",
    afternoon: "da tarde",
    evening: "da tardiña",
    night: "da noite"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "medianoite",
    noon: "mediodía",
    morning: "da mañá",
    afternoon: "da tarde",
    evening: "da tardiña",
    night: "da noite"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "medianoite",
    noon: "mediodía",
    morning: "da mañá",
    afternoon: "da tarde",
    evening: "da tardiña",
    night: "da noite"
  }
}, ordinalNumber$R = (u, l) => Number(u) + "º", localize$R = {
  ordinalNumber: ordinalNumber$R,
  era: buildLocalizeFn({
    values: eraValues$R,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$R,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$R,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$R,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$R,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$H,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$R = /^(\d+)(º)?/i, parseOrdinalNumberPattern$R = /\d+/i, matchEraPatterns$R = {
  narrow: /^(ac|dc|a|d)/i,
  abbreviated: /^(a\.?\s?c\.?|a\.?\s?e\.?\s?c\.?|d\.?\s?c\.?|e\.?\s?c\.?)/i,
  wide: /^(antes de cristo|antes da era com[uú]n|despois de cristo|era com[uú]n)/i
}, parseEraPatterns$R = {
  any: [/^ac/i, /^dc/i],
  wide: [
    /^(antes de cristo|antes da era com[uú]n)/i,
    /^(despois de cristo|era com[uú]n)/i
  ]
}, matchQuarterPatterns$R = {
  narrow: /^[1234]/i,
  abbreviated: /^T[1234]/i,
  wide: /^[1234](º)? trimestre/i
}, parseQuarterPatterns$R = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$R = {
  narrow: /^[xfmasond]/i,
  abbreviated: /^(xan|feb|mar|abr|mai|xun|xul|ago|set|out|nov|dec)/i,
  wide: /^(xaneiro|febreiro|marzo|abril|maio|xuño|xullo|agosto|setembro|outubro|novembro|decembro)/i
}, parseMonthPatterns$R = {
  narrow: [
    /^x/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^x/i,
    /^x/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^xan/i,
    /^feb/i,
    /^mar/i,
    /^abr/i,
    /^mai/i,
    /^xun/i,
    /^xul/i,
    /^ago/i,
    /^set/i,
    /^out/i,
    /^nov/i,
    /^dec/i
  ]
}, matchDayPatterns$R = {
  narrow: /^[dlmxvs]/i,
  short: /^(do|lu|ma|me|xo|ve|sa)/i,
  abbreviated: /^(dom|lun|mar|mer|xov|ven|sab)/i,
  wide: /^(domingo|luns|martes|m[eé]rcores|xoves|venres|s[áa]bado)/i
}, parseDayPatterns$R = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^x/i, /^v/i, /^s/i],
  any: [/^do/i, /^lu/i, /^ma/i, /^me/i, /^xo/i, /^ve/i, /^sa/i]
}, matchDayPeriodPatterns$R = {
  narrow: /^(a|p|mn|md|(da|[aá]s) (mañ[aá]|tarde|noite))/i,
  any: /^([ap]\.?\s?m\.?|medianoite|mediod[ií]a|(da|[aá]s) (mañ[aá]|tarde|noite))/i
}, parseDayPeriodPatterns$R = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mn/i,
    noon: /^md/i,
    morning: /mañ[aá]/i,
    afternoon: /tarde/i,
    evening: /tardiña/i,
    night: /noite/i
  }
}, match$S = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$R,
    parsePattern: parseOrdinalNumberPattern$R,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$R,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$R,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$R,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$R,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$R,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$R,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$R,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$R,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$R,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$R,
    defaultParseWidth: "any"
  })
}, gl = {
  code: "gl",
  formatDistance: formatDistance$R,
  formatLong: formatLong$S,
  formatRelative: formatRelative$R,
  localize: localize$R,
  match: match$S,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$P = {
  lessThanXSeconds: {
    one: "હમણાં",
    // CLDR #1461
    other: "​આશરે {{count}} સેકંડ"
  },
  xSeconds: {
    one: "1 સેકંડ",
    other: "{{count}} સેકંડ"
  },
  halfAMinute: "અડધી મિનિટ",
  lessThanXMinutes: {
    one: "આ મિનિટ",
    // CLDR #1448
    other: "​આશરે {{count}} મિનિટ"
  },
  xMinutes: {
    one: "1 મિનિટ",
    other: "{{count}} મિનિટ"
  },
  aboutXHours: {
    one: "​આશરે 1 કલાક",
    other: "​આશરે {{count}} કલાક"
  },
  xHours: {
    one: "1 કલાક",
    other: "{{count}} કલાક"
  },
  xDays: {
    one: "1 દિવસ",
    other: "{{count}} દિવસ"
  },
  aboutXWeeks: {
    one: "આશરે 1 અઠવાડિયું",
    other: "આશરે {{count}} અઠવાડિયા"
  },
  xWeeks: {
    one: "1 અઠવાડિયું",
    other: "{{count}} અઠવાડિયા"
  },
  aboutXMonths: {
    one: "આશરે 1 મહિનો",
    other: "આશરે {{count}} મહિના"
  },
  xMonths: {
    one: "1 મહિનો",
    other: "{{count}} મહિના"
  },
  aboutXYears: {
    one: "આશરે 1 વર્ષ",
    other: "આશરે {{count}} વર્ષ"
  },
  xYears: {
    one: "1 વર્ષ",
    other: "{{count}} વર્ષ"
  },
  overXYears: {
    one: "1 વર્ષથી વધુ",
    other: "{{count}} વર્ષથી વધુ"
  },
  almostXYears: {
    one: "લગભગ 1 વર્ષ",
    other: "લગભગ {{count}} વર્ષ"
  }
}, formatDistance$Q = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$P[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? p + "માં" : p + " પહેલાં" : p;
}, dateFormats$R = {
  full: "EEEE, d MMMM, y",
  // CLDR #1825
  long: "d MMMM, y",
  // CLDR #1826
  medium: "d MMM, y",
  // CLDR #1827
  short: "d/M/yy"
  // CLDR #1828
}, timeFormats$R = {
  full: "hh:mm:ss a zzzz",
  // CLDR #1829
  long: "hh:mm:ss a z",
  // CLDR #1830
  medium: "hh:mm:ss a",
  // CLDR #1831
  short: "hh:mm a"
  // CLDR #1832
}, dateTimeFormats$R = {
  full: "{{date}} {{time}}",
  // CLDR #1833
  long: "{{date}} {{time}}",
  // CLDR #1834
  medium: "{{date}} {{time}}",
  // CLDR #1835
  short: "{{date}} {{time}}"
  // CLDR #1836
}, formatLong$R = {
  date: buildFormatLongFn({
    formats: dateFormats$R,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$R,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$R,
    defaultWidth: "full"
  })
}, formatRelativeLocale$Q = {
  lastWeek: "'પાછલા' eeee p",
  // CLDR #1384
  yesterday: "'ગઈકાલે' p",
  // CLDR #1409
  today: "'આજે' p",
  // CLDR #1410
  tomorrow: "'આવતીકાલે' p",
  // CLDR #1411
  nextWeek: "eeee p",
  // CLDR #1386
  other: "P"
}, formatRelative$Q = (u, l, f, p) => formatRelativeLocale$Q[u], eraValues$Q = {
  narrow: ["ઈસપૂ", "ઈસ"],
  abbreviated: ["ઈ.સ.પૂર્વે", "ઈ.સ."],
  wide: ["ઈસવીસન પૂર્વે", "ઈસવીસન"]
}, quarterValues$Q = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1લો ત્રિમાસ", "2જો ત્રિમાસ", "3જો ત્રિમાસ", "4થો ત્રિમાસ"]
}, monthValues$Q = {
  narrow: ["જા", "ફે", "મા", "એ", "મે", "જૂ", "જુ", "ઓ", "સ", "ઓ", "ન", "ડિ"],
  abbreviated: [
    "જાન્યુ",
    "ફેબ્રુ",
    "માર્ચ",
    "એપ્રિલ",
    "મે",
    "જૂન",
    "જુલાઈ",
    "ઑગસ્ટ",
    "સપ્ટે",
    "ઓક્ટો",
    "નવે",
    "ડિસે"
  ],
  wide: [
    "જાન્યુઆરી",
    "ફેબ્રુઆરી",
    "માર્ચ",
    "એપ્રિલ",
    "મે",
    "જૂન",
    "જુલાઇ",
    "ઓગસ્ટ",
    "સપ્ટેમ્બર",
    "ઓક્ટોબર",
    "નવેમ્બર",
    "ડિસેમ્બર"
  ]
}, dayValues$Q = {
  narrow: ["ર", "સો", "મં", "બુ", "ગુ", "શુ", "શ"],
  short: ["ર", "સો", "મં", "બુ", "ગુ", "શુ", "શ"],
  abbreviated: ["રવિ", "સોમ", "મંગળ", "બુધ", "ગુરુ", "શુક્ર", "શનિ"],
  wide: [
    "રવિવાર",
    "સોમવાર",
    "મંગળવાર",
    "બુધવાર",
    "ગુરુવાર",
    "શુક્રવાર",
    "શનિવાર"
  ]
}, dayPeriodValues$Q = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "મ.રાત્રિ",
    noon: "બ.",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "​મધ્યરાત્રિ",
    noon: "બપોરે",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "​મધ્યરાત્રિ",
    noon: "બપોરે",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  }
}, formattingDayPeriodValues$G = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "મ.રાત્રિ",
    noon: "બપોરે",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "મધ્યરાત્રિ",
    noon: "બપોરે",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "​મધ્યરાત્રિ",
    noon: "બપોરે",
    morning: "સવારે",
    afternoon: "બપોરે",
    evening: "સાંજે",
    night: "રાત્રે"
  }
}, ordinalNumber$Q = (u, l) => String(u), localize$Q = {
  ordinalNumber: ordinalNumber$Q,
  era: buildLocalizeFn({
    values: eraValues$Q,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$Q,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$Q,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$Q,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$Q,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$G,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$Q = /^(\d+)(લ|જ|થ|ઠ્ઠ|મ)?/i, parseOrdinalNumberPattern$Q = /\d+/i, matchEraPatterns$Q = {
  narrow: /^(ઈસપૂ|ઈસ)/i,
  abbreviated: /^(ઈ\.સ\.પૂર્વે|ઈ\.સ\.)/i,
  wide: /^(ઈસવીસન\sપૂર્વે|ઈસવીસન)/i
}, parseEraPatterns$Q = {
  any: [/^ઈસપૂ/i, /^ઈસ/i]
}, matchQuarterPatterns$Q = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](લો|જો|થો)? ત્રિમાસ/i
}, parseQuarterPatterns$Q = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$Q = {
  // eslint-disable-next-line no-misleading-character-class
  narrow: /^[જાફેમાએમેજૂજુઓસઓનડિ]/i,
  abbreviated: /^(જાન્યુ|ફેબ્રુ|માર્ચ|એપ્રિલ|મે|જૂન|જુલાઈ|ઑગસ્ટ|સપ્ટે|ઓક્ટો|નવે|ડિસે)/i,
  wide: /^(જાન્યુઆરી|ફેબ્રુઆરી|માર્ચ|એપ્રિલ|મે|જૂન|જુલાઇ|ઓગસ્ટ|સપ્ટેમ્બર|ઓક્ટોબર|નવેમ્બર|ડિસેમ્બર)/i
}, parseMonthPatterns$Q = {
  narrow: [
    /^જા/i,
    /^ફે/i,
    /^મા/i,
    /^એ/i,
    /^મે/i,
    /^જૂ/i,
    /^જુ/i,
    /^ઑગ/i,
    /^સ/i,
    /^ઓક્ટો/i,
    /^ન/i,
    /^ડિ/i
  ],
  any: [
    /^જા/i,
    /^ફે/i,
    /^મા/i,
    /^એ/i,
    /^મે/i,
    /^જૂ/i,
    /^જુ/i,
    /^ઑગ/i,
    /^સ/i,
    /^ઓક્ટો/i,
    /^ન/i,
    /^ડિ/i
  ]
}, matchDayPatterns$Q = {
  narrow: /^(ર|સો|મં|બુ|ગુ|શુ|શ)/i,
  short: /^(ર|સો|મં|બુ|ગુ|શુ|શ)/i,
  abbreviated: /^(રવિ|સોમ|મંગળ|બુધ|ગુરુ|શુક્ર|શનિ)/i,
  wide: /^(રવિવાર|સોમવાર|મંગળવાર|બુધવાર|ગુરુવાર|શુક્રવાર|શનિવાર)/i
}, parseDayPatterns$Q = {
  narrow: [/^ર/i, /^સો/i, /^મં/i, /^બુ/i, /^ગુ/i, /^શુ/i, /^શ/i],
  any: [/^ર/i, /^સો/i, /^મં/i, /^બુ/i, /^ગુ/i, /^શુ/i, /^શ/i]
}, matchDayPeriodPatterns$Q = {
  narrow: /^(a|p|મ\.?|સ|બ|સાં|રા)/i,
  any: /^(a|p|મ\.?|સ|બ|સાં|રા)/i
}, parseDayPeriodPatterns$Q = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^મ\.?/i,
    noon: /^બ/i,
    morning: /સ/i,
    afternoon: /બ/i,
    evening: /સાં/i,
    night: /રા/i
  }
}, match$R = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$Q,
    parsePattern: parseOrdinalNumberPattern$Q,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$Q,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$Q,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$Q,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$Q,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$Q,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$Q,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$Q,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$Q,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$Q,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$Q,
    defaultParseWidth: "any"
  })
}, gu = {
  code: "gu",
  formatDistance: formatDistance$Q,
  formatLong: formatLong$R,
  formatRelative: formatRelative$Q,
  localize: localize$Q,
  match: match$R,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$O = {
  lessThanXSeconds: {
    one: "פחות משנייה",
    two: "פחות משתי שניות",
    other: "פחות מ־{{count}} שניות"
  },
  xSeconds: {
    one: "שנייה",
    two: "שתי שניות",
    other: "{{count}} שניות"
  },
  halfAMinute: "חצי דקה",
  lessThanXMinutes: {
    one: "פחות מדקה",
    two: "פחות משתי דקות",
    other: "פחות מ־{{count}} דקות"
  },
  xMinutes: {
    one: "דקה",
    two: "שתי דקות",
    other: "{{count}} דקות"
  },
  aboutXHours: {
    one: "כשעה",
    two: "כשעתיים",
    other: "כ־{{count}} שעות"
  },
  xHours: {
    one: "שעה",
    two: "שעתיים",
    other: "{{count}} שעות"
  },
  xDays: {
    one: "יום",
    two: "יומיים",
    other: "{{count}} ימים"
  },
  aboutXWeeks: {
    one: "כשבוע",
    two: "כשבועיים",
    other: "כ־{{count}} שבועות"
  },
  xWeeks: {
    one: "שבוע",
    two: "שבועיים",
    other: "{{count}} שבועות"
  },
  aboutXMonths: {
    one: "כחודש",
    two: "כחודשיים",
    other: "כ־{{count}} חודשים"
  },
  xMonths: {
    one: "חודש",
    two: "חודשיים",
    other: "{{count}} חודשים"
  },
  aboutXYears: {
    one: "כשנה",
    two: "כשנתיים",
    other: "כ־{{count}} שנים"
  },
  xYears: {
    one: "שנה",
    two: "שנתיים",
    other: "{{count}} שנים"
  },
  overXYears: {
    one: "יותר משנה",
    two: "יותר משנתיים",
    other: "יותר מ־{{count}} שנים"
  },
  almostXYears: {
    one: "כמעט שנה",
    two: "כמעט שנתיים",
    other: "כמעט {{count}} שנים"
  }
}, formatDistance$P = (u, l, f) => {
  if (u === "xDays" && f?.addSuffix && l <= 2)
    return f.comparison && f.comparison > 0 ? l === 1 ? "מחר" : "מחרתיים" : l === 1 ? "אתמול" : "שלשום";
  let p;
  const m = formatDistanceLocale$O[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : l === 2 ? p = m.two : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "בעוד " + p : "לפני " + p : p;
}, dateFormats$Q = {
  full: "EEEE, d בMMMM y",
  long: "d בMMMM y",
  medium: "d בMMM y",
  short: "d.M.y"
}, timeFormats$Q = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$Q = {
  full: "{{date}} 'בשעה' {{time}}",
  long: "{{date}} 'בשעה' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$Q = {
  date: buildFormatLongFn({
    formats: dateFormats$Q,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$Q,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$Q,
    defaultWidth: "full"
  })
}, formatRelativeLocale$P = {
  lastWeek: "eeee 'שעבר בשעה' p",
  yesterday: "'אתמול בשעה' p",
  today: "'היום בשעה' p",
  tomorrow: "'מחר בשעה' p",
  nextWeek: "eeee 'בשעה' p",
  other: "P"
}, formatRelative$P = (u, l, f, p) => formatRelativeLocale$P[u], eraValues$P = {
  narrow: ["לפנה״ס", "לספירה"],
  abbreviated: ["לפנה״ס", "לספירה"],
  wide: ["לפני הספירה", "לספירה"]
}, quarterValues$P = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["רבעון 1", "רבעון 2", "רבעון 3", "רבעון 4"]
}, monthValues$P = {
  narrow: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
  abbreviated: [
    "ינו׳",
    "פבר׳",
    "מרץ",
    "אפר׳",
    "מאי",
    "יוני",
    "יולי",
    "אוג׳",
    "ספט׳",
    "אוק׳",
    "נוב׳",
    "דצמ׳"
  ],
  wide: [
    "ינואר",
    "פברואר",
    "מרץ",
    "אפריל",
    "מאי",
    "יוני",
    "יולי",
    "אוגוסט",
    "ספטמבר",
    "אוקטובר",
    "נובמבר",
    "דצמבר"
  ]
}, dayValues$P = {
  narrow: ["א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"],
  short: ["א׳", "ב׳", "ג׳", "ד׳", "ה׳", "ו׳", "ש׳"],
  abbreviated: [
    "יום א׳",
    "יום ב׳",
    "יום ג׳",
    "יום ד׳",
    "יום ה׳",
    "יום ו׳",
    "שבת"
  ],
  wide: [
    "יום ראשון",
    "יום שני",
    "יום שלישי",
    "יום רביעי",
    "יום חמישי",
    "יום שישי",
    "יום שבת"
  ]
}, dayPeriodValues$P = {
  narrow: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בוקר",
    afternoon: "אחר הצהריים",
    evening: "ערב",
    night: "לילה"
  },
  abbreviated: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בוקר",
    afternoon: "אחר הצהריים",
    evening: "ערב",
    night: "לילה"
  },
  wide: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בוקר",
    afternoon: "אחר הצהריים",
    evening: "ערב",
    night: "לילה"
  }
}, formattingDayPeriodValues$F = {
  narrow: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בבוקר",
    afternoon: "בצהריים",
    evening: "בערב",
    night: "בלילה"
  },
  abbreviated: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בבוקר",
    afternoon: "אחר הצהריים",
    evening: "בערב",
    night: "בלילה"
  },
  wide: {
    am: "לפנה״צ",
    pm: "אחה״צ",
    midnight: "חצות",
    noon: "צהריים",
    morning: "בבוקר",
    afternoon: "אחר הצהריים",
    evening: "בערב",
    night: "בלילה"
  }
}, ordinalNumber$P = (u, l) => {
  const f = Number(u);
  if (f <= 0 || f > 10) return String(f);
  const p = String(l?.unit), m = ["year", "hour", "minute", "second"].indexOf(p) >= 0, b = [
    "ראשון",
    "שני",
    "שלישי",
    "רביעי",
    "חמישי",
    "שישי",
    "שביעי",
    "שמיני",
    "תשיעי",
    "עשירי"
  ], y = [
    "ראשונה",
    "שנייה",
    "שלישית",
    "רביעית",
    "חמישית",
    "שישית",
    "שביעית",
    "שמינית",
    "תשיעית",
    "עשירית"
  ], v = f - 1;
  return m ? y[v] : b[v];
}, localize$P = {
  ordinalNumber: ordinalNumber$P,
  era: buildLocalizeFn({
    values: eraValues$P,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$P,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$P,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$P,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$P,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$F,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$P = /^(\d+|(ראשון|שני|שלישי|רביעי|חמישי|שישי|שביעי|שמיני|תשיעי|עשירי|ראשונה|שנייה|שלישית|רביעית|חמישית|שישית|שביעית|שמינית|תשיעית|עשירית))/i, parseOrdinalNumberPattern$P = /^(\d+|רא|שנ|של|רב|ח|שי|שב|שמ|ת|ע)/i, matchEraPatterns$P = {
  narrow: /^ל(ספירה|פנה״ס)/i,
  abbreviated: /^ל(ספירה|פנה״ס)/i,
  wide: /^ל(פני ה)?ספירה/i
}, parseEraPatterns$P = {
  any: [/^לפ/i, /^לס/i]
}, matchQuarterPatterns$P = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^רבעון [1234]/i
}, parseQuarterPatterns$P = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$P = {
  narrow: /^\d+/i,
  abbreviated: /^(ינו|פבר|מרץ|אפר|מאי|יוני|יולי|אוג|ספט|אוק|נוב|דצמ)׳?/i,
  wide: /^(ינואר|פברואר|מרץ|אפריל|מאי|יוני|יולי|אוגוסט|ספטמבר|אוקטובר|נובמבר|דצמבר)/i
}, parseMonthPatterns$P = {
  narrow: [
    /^1$/i,
    /^2/i,
    /^3/i,
    /^4/i,
    /^5/i,
    /^6/i,
    /^7/i,
    /^8/i,
    /^9/i,
    /^10/i,
    /^11/i,
    /^12/i
  ],
  any: [
    /^ינ/i,
    /^פ/i,
    /^מר/i,
    /^אפ/i,
    /^מא/i,
    /^יונ/i,
    /^יול/i,
    /^אוג/i,
    /^ס/i,
    /^אוק/i,
    /^נ/i,
    /^ד/i
  ]
}, matchDayPatterns$P = {
  narrow: /^[אבגדהוש]׳/i,
  short: /^[אבגדהוש]׳/i,
  abbreviated: /^(שבת|יום (א|ב|ג|ד|ה|ו)׳)/i,
  wide: /^יום (ראשון|שני|שלישי|רביעי|חמישי|שישי|שבת)/i
}, parseDayPatterns$P = {
  abbreviated: [/א׳$/i, /ב׳$/i, /ג׳$/i, /ד׳$/i, /ה׳$/i, /ו׳$/i, /^ש/i],
  wide: [/ן$/i, /ני$/i, /לישי$/i, /עי$/i, /מישי$/i, /שישי$/i, /ת$/i],
  any: [/^א/i, /^ב/i, /^ג/i, /^ד/i, /^ה/i, /^ו/i, /^ש/i]
}, matchDayPeriodPatterns$P = {
  any: /^(אחר ה|ב)?(חצות|צהריים|בוקר|ערב|לילה|אחה״צ|לפנה״צ)/i
}, parseDayPeriodPatterns$P = {
  any: {
    am: /^לפ/i,
    pm: /^אחה/i,
    midnight: /^ח/i,
    noon: /^צ/i,
    morning: /בוקר/i,
    afternoon: /בצ|אחר/i,
    evening: /ערב/i,
    night: /לילה/i
  }
}, ordinalName = ["רא", "שנ", "של", "רב", "ח", "שי", "שב", "שמ", "ת", "ע"], match$Q = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$P,
    parsePattern: parseOrdinalNumberPattern$P,
    valueCallback: (u) => {
      const l = parseInt(u, 10);
      return isNaN(l) ? ordinalName.indexOf(u) + 1 : l;
    }
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$P,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$P,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$P,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$P,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$P,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$P,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$P,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$P,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$P,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$P,
    defaultParseWidth: "any"
  })
}, he = {
  code: "he",
  formatDistance: formatDistance$P,
  formatLong: formatLong$Q,
  formatRelative: formatRelative$P,
  localize: localize$P,
  match: match$Q,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, numberValues = {
  locale: {
    1: "१",
    2: "२",
    3: "३",
    4: "४",
    5: "५",
    6: "६",
    7: "७",
    8: "८",
    9: "९",
    0: "०"
  },
  number: {
    "१": "1",
    "२": "2",
    "३": "3",
    "४": "4",
    "५": "5",
    "६": "6",
    "७": "7",
    "८": "8",
    "९": "9",
    "०": "0"
  }
}, eraValues$O = {
  narrow: ["ईसा-पूर्व", "ईस्वी"],
  abbreviated: ["ईसा-पूर्व", "ईस्वी"],
  wide: ["ईसा-पूर्व", "ईसवी सन"]
}, quarterValues$O = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["ति1", "ति2", "ति3", "ति4"],
  wide: ["पहली तिमाही", "दूसरी तिमाही", "तीसरी तिमाही", "चौथी तिमाही"]
}, monthValues$O = {
  narrow: [
    "ज",
    "फ़",
    "मा",
    "अ",
    "मई",
    "जू",
    "जु",
    "अग",
    "सि",
    "अक्टू",
    "न",
    "दि"
  ],
  abbreviated: [
    "जन",
    "फ़र",
    "मार्च",
    "अप्रैल",
    "मई",
    "जून",
    "जुल",
    "अग",
    "सित",
    "अक्टू",
    "नव",
    "दिस"
  ],
  wide: [
    "जनवरी",
    "फ़रवरी",
    "मार्च",
    "अप्रैल",
    "मई",
    "जून",
    "जुलाई",
    "अगस्त",
    "सितंबर",
    "अक्टूबर",
    "नवंबर",
    "दिसंबर"
  ]
}, dayValues$O = {
  narrow: ["र", "सो", "मं", "बु", "गु", "शु", "श"],
  short: ["र", "सो", "मं", "बु", "गु", "शु", "श"],
  abbreviated: ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"],
  wide: [
    "रविवार",
    "सोमवार",
    "मंगलवार",
    "बुधवार",
    "गुरुवार",
    "शुक्रवार",
    "शनिवार"
  ]
}, dayPeriodValues$O = {
  narrow: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  },
  abbreviated: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  },
  wide: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  }
}, formattingDayPeriodValues$E = {
  narrow: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  },
  abbreviated: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  },
  wide: {
    am: "पूर्वाह्न",
    pm: "अपराह्न",
    midnight: "मध्यरात्रि",
    noon: "दोपहर",
    morning: "सुबह",
    afternoon: "दोपहर",
    evening: "शाम",
    night: "रात"
  }
}, ordinalNumber$O = (u, l) => {
  const f = Number(u);
  return numberToLocale(f);
};
function localeToNumber(u) {
  const l = u.toString().replace(/[१२३४५६७८९०]/g, function(f) {
    return numberValues.number[f];
  });
  return Number(l);
}
function numberToLocale(u) {
  return u.toString().replace(/\d/g, function(l) {
    return numberValues.locale[l];
  });
}
const localize$O = {
  ordinalNumber: ordinalNumber$O,
  era: buildLocalizeFn({
    values: eraValues$O,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$O,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$O,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$O,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$O,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$E,
    defaultFormattingWidth: "wide"
  })
}, formatDistanceLocale$N = {
  lessThanXSeconds: {
    one: "१ सेकंड से कम",
    // CLDR #1310
    other: "{{count}} सेकंड से कम"
  },
  xSeconds: {
    one: "१ सेकंड",
    other: "{{count}} सेकंड"
  },
  halfAMinute: "आधा मिनट",
  lessThanXMinutes: {
    one: "१ मिनट से कम",
    other: "{{count}} मिनट से कम"
  },
  xMinutes: {
    one: "१ मिनट",
    // CLDR #1307
    other: "{{count}} मिनट"
  },
  aboutXHours: {
    one: "लगभग १ घंटा",
    other: "लगभग {{count}} घंटे"
  },
  xHours: {
    one: "१ घंटा",
    // CLDR #1304
    other: "{{count}} घंटे"
    // CLDR #4467
  },
  xDays: {
    one: "१ दिन",
    // CLDR #1286
    other: "{{count}} दिन"
  },
  aboutXWeeks: {
    one: "लगभग १ सप्ताह",
    other: "लगभग {{count}} सप्ताह"
  },
  xWeeks: {
    one: "१ सप्ताह",
    other: "{{count}} सप्ताह"
  },
  aboutXMonths: {
    one: "लगभग १ महीना",
    other: "लगभग {{count}} महीने"
  },
  xMonths: {
    one: "१ महीना",
    other: "{{count}} महीने"
  },
  aboutXYears: {
    one: "लगभग १ वर्ष",
    other: "लगभग {{count}} वर्ष"
    // CLDR #4823
  },
  xYears: {
    one: "१ वर्ष",
    other: "{{count}} वर्ष"
  },
  overXYears: {
    one: "१ वर्ष से अधिक",
    other: "{{count}} वर्ष से अधिक"
  },
  almostXYears: {
    one: "लगभग १ वर्ष",
    other: "लगभग {{count}} वर्ष"
  }
}, formatDistance$O = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$N[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", numberToLocale(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? p + "मे " : p + " पहले" : p;
}, dateFormats$P = {
  full: "EEEE, do MMMM, y",
  // CLDR #1787
  long: "do MMMM, y",
  // CLDR #1788
  medium: "d MMM, y",
  // CLDR #1789
  short: "dd/MM/yyyy"
  // CLDR #1790
}, timeFormats$P = {
  full: "h:mm:ss a zzzz",
  // CLDR #1791
  long: "h:mm:ss a z",
  // CLDR #1792
  medium: "h:mm:ss a",
  // CLDR #1793
  short: "h:mm a"
  // CLDR #1794
}, dateTimeFormats$P = {
  full: "{{date}} 'को' {{time}}",
  // CLDR #1795
  long: "{{date}} 'को' {{time}}",
  // CLDR #1796
  medium: "{{date}}, {{time}}",
  // CLDR #1797
  short: "{{date}}, {{time}}"
  // CLDR #1798
}, formatLong$P = {
  date: buildFormatLongFn({
    formats: dateFormats$P,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$P,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$P,
    defaultWidth: "full"
  })
}, formatRelativeLocale$O = {
  lastWeek: "'पिछले' eeee p",
  yesterday: "'कल' p",
  today: "'आज' p",
  tomorrow: "'कल' p",
  nextWeek: "eeee 'को' p",
  other: "P"
}, formatRelative$O = (u, l, f, p) => formatRelativeLocale$O[u], matchOrdinalNumberPattern$O = /^[०१२३४५६७८९]+/i, parseOrdinalNumberPattern$O = /^[०१२३४५६७८९]+/i, matchEraPatterns$O = {
  narrow: /^(ईसा-पूर्व|ईस्वी)/i,
  abbreviated: /^(ईसा\.?\s?पूर्व\.?|ईसा\.?)/i,
  wide: /^(ईसा-पूर्व|ईसवी पूर्व|ईसवी सन|ईसवी)/i
}, parseEraPatterns$O = {
  any: [/^b/i, /^(a|c)/i]
}, matchQuarterPatterns$O = {
  narrow: /^[1234]/i,
  abbreviated: /^ति[1234]/i,
  wide: /^[1234](पहली|दूसरी|तीसरी|चौथी)? तिमाही/i
}, parseQuarterPatterns$O = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$O = {
  // eslint-disable-next-line no-misleading-character-class
  narrow: /^[जफ़माअप्मईजूनजुअगसिअक्तनदि]/i,
  abbreviated: /^(जन|फ़र|मार्च|अप्|मई|जून|जुल|अग|सित|अक्तू|नव|दिस)/i,
  wide: /^(जनवरी|फ़रवरी|मार्च|अप्रैल|मई|जून|जुलाई|अगस्त|सितंबर|अक्तूबर|नवंबर|दिसंबर)/i
}, parseMonthPatterns$O = {
  narrow: [
    /^ज/i,
    /^फ़/i,
    /^मा/i,
    /^अप्/i,
    /^मई/i,
    /^जू/i,
    /^जु/i,
    /^अग/i,
    /^सि/i,
    /^अक्तू/i,
    /^न/i,
    /^दि/i
  ],
  any: [
    /^जन/i,
    /^फ़/i,
    /^मा/i,
    /^अप्/i,
    /^मई/i,
    /^जू/i,
    /^जु/i,
    /^अग/i,
    /^सि/i,
    /^अक्तू/i,
    /^नव/i,
    /^दिस/i
  ]
}, matchDayPatterns$O = {
  // eslint-disable-next-line no-misleading-character-class
  narrow: /^[रविसोममंगलबुधगुरुशुक्रशनि]/i,
  short: /^(रवि|सोम|मंगल|बुध|गुरु|शुक्र|शनि)/i,
  abbreviated: /^(रवि|सोम|मंगल|बुध|गुरु|शुक्र|शनि)/i,
  wide: /^(रविवार|सोमवार|मंगलवार|बुधवार|गुरुवार|शुक्रवार|शनिवार)/i
}, parseDayPatterns$O = {
  narrow: [/^रवि/i, /^सोम/i, /^मंगल/i, /^बुध/i, /^गुरु/i, /^शुक्र/i, /^शनि/i],
  any: [/^रवि/i, /^सोम/i, /^मंगल/i, /^बुध/i, /^गुरु/i, /^शुक्र/i, /^शनि/i]
}, matchDayPeriodPatterns$O = {
  narrow: /^(पू|अ|म|द.\?|सु|दो|शा|रा)/i,
  any: /^(पूर्वाह्न|अपराह्न|म|द.\?|सु|दो|शा|रा)/i
}, parseDayPeriodPatterns$O = {
  any: {
    am: /^पूर्वाह्न/i,
    pm: /^अपराह्न/i,
    midnight: /^मध्य/i,
    noon: /^दो/i,
    morning: /सु/i,
    afternoon: /दो/i,
    evening: /शा/i,
    night: /रा/i
  }
}, match$P = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$O,
    parsePattern: parseOrdinalNumberPattern$O,
    valueCallback: localeToNumber
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$O,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$O,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$O,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$O,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$O,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$O,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$O,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$O,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$O,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$O,
    defaultParseWidth: "any"
  })
}, hi = {
  code: "hi",
  formatDistance: formatDistance$O,
  formatLong: formatLong$P,
  formatRelative: formatRelative$O,
  localize: localize$O,
  match: match$P,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$M = {
  lessThanXSeconds: {
    one: {
      standalone: "manje od 1 sekunde",
      withPrepositionAgo: "manje od 1 sekunde",
      withPrepositionIn: "manje od 1 sekundu"
    },
    dual: "manje od {{count}} sekunde",
    other: "manje od {{count}} sekundi"
  },
  xSeconds: {
    one: {
      standalone: "1 sekunda",
      withPrepositionAgo: "1 sekunde",
      withPrepositionIn: "1 sekundu"
    },
    dual: "{{count}} sekunde",
    other: "{{count}} sekundi"
  },
  halfAMinute: "pola minute",
  lessThanXMinutes: {
    one: {
      standalone: "manje od 1 minute",
      withPrepositionAgo: "manje od 1 minute",
      withPrepositionIn: "manje od 1 minutu"
    },
    dual: "manje od {{count}} minute",
    other: "manje od {{count}} minuta"
  },
  xMinutes: {
    one: {
      standalone: "1 minuta",
      withPrepositionAgo: "1 minute",
      withPrepositionIn: "1 minutu"
    },
    dual: "{{count}} minute",
    other: "{{count}} minuta"
  },
  aboutXHours: {
    one: {
      standalone: "oko 1 sat",
      withPrepositionAgo: "oko 1 sat",
      withPrepositionIn: "oko 1 sat"
    },
    dual: "oko {{count}} sata",
    other: "oko {{count}} sati"
  },
  xHours: {
    one: {
      standalone: "1 sat",
      withPrepositionAgo: "1 sat",
      withPrepositionIn: "1 sat"
    },
    dual: "{{count}} sata",
    other: "{{count}} sati"
  },
  xDays: {
    one: {
      standalone: "1 dan",
      withPrepositionAgo: "1 dan",
      withPrepositionIn: "1 dan"
    },
    dual: "{{count}} dana",
    other: "{{count}} dana"
  },
  aboutXWeeks: {
    one: {
      standalone: "oko 1 tjedan",
      withPrepositionAgo: "oko 1 tjedan",
      withPrepositionIn: "oko 1 tjedan"
    },
    dual: "oko {{count}} tjedna",
    other: "oko {{count}} tjedana"
  },
  xWeeks: {
    one: {
      standalone: "1 tjedan",
      withPrepositionAgo: "1 tjedan",
      withPrepositionIn: "1 tjedan"
    },
    dual: "{{count}} tjedna",
    other: "{{count}} tjedana"
  },
  aboutXMonths: {
    one: {
      standalone: "oko 1 mjesec",
      withPrepositionAgo: "oko 1 mjesec",
      withPrepositionIn: "oko 1 mjesec"
    },
    dual: "oko {{count}} mjeseca",
    other: "oko {{count}} mjeseci"
  },
  xMonths: {
    one: {
      standalone: "1 mjesec",
      withPrepositionAgo: "1 mjesec",
      withPrepositionIn: "1 mjesec"
    },
    dual: "{{count}} mjeseca",
    other: "{{count}} mjeseci"
  },
  aboutXYears: {
    one: {
      standalone: "oko 1 godinu",
      withPrepositionAgo: "oko 1 godinu",
      withPrepositionIn: "oko 1 godinu"
    },
    dual: "oko {{count}} godine",
    other: "oko {{count}} godina"
  },
  xYears: {
    one: {
      standalone: "1 godina",
      withPrepositionAgo: "1 godine",
      withPrepositionIn: "1 godinu"
    },
    dual: "{{count}} godine",
    other: "{{count}} godina"
  },
  overXYears: {
    one: {
      standalone: "preko 1 godinu",
      withPrepositionAgo: "preko 1 godinu",
      withPrepositionIn: "preko 1 godinu"
    },
    dual: "preko {{count}} godine",
    other: "preko {{count}} godina"
  },
  almostXYears: {
    one: {
      standalone: "gotovo 1 godinu",
      withPrepositionAgo: "gotovo 1 godinu",
      withPrepositionIn: "gotovo 1 godinu"
    },
    dual: "gotovo {{count}} godine",
    other: "gotovo {{count}} godina"
  }
}, formatDistance$N = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$M[u];
  return typeof m == "string" ? p = m : l === 1 ? f?.addSuffix ? f.comparison && f.comparison > 0 ? p = m.one.withPrepositionIn : p = m.one.withPrepositionAgo : p = m.one.standalone : l % 10 > 1 && l % 10 < 5 && // if last digit is between 2 and 4
  String(l).substr(-2, 1) !== "1" ? p = m.dual.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "za " + p : "prije " + p : p;
}, dateFormats$O = {
  full: "EEEE, d. MMMM y.",
  long: "d. MMMM y.",
  medium: "d. MMM y.",
  short: "dd. MM. y."
}, timeFormats$O = {
  full: "HH:mm:ss (zzzz)",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$O = {
  full: "{{date}} 'u' {{time}}",
  long: "{{date}} 'u' {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$O = {
  date: buildFormatLongFn({
    formats: dateFormats$O,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$O,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$O,
    defaultWidth: "full"
  })
}, formatRelativeLocale$N = {
  lastWeek: (u) => {
    switch (u.getDay()) {
      case 0:
        return "'prošlu nedjelju u' p";
      case 3:
        return "'prošlu srijedu u' p";
      case 6:
        return "'prošlu subotu u' p";
      default:
        return "'prošli' EEEE 'u' p";
    }
  },
  yesterday: "'jučer u' p",
  today: "'danas u' p",
  tomorrow: "'sutra u' p",
  nextWeek: (u) => {
    switch (u.getDay()) {
      case 0:
        return "'iduću nedjelju u' p";
      case 3:
        return "'iduću srijedu u' p";
      case 6:
        return "'iduću subotu u' p";
      default:
        return "'prošli' EEEE 'u' p";
    }
  },
  other: "P"
}, formatRelative$N = (u, l, f, p) => {
  const m = formatRelativeLocale$N[u];
  return typeof m == "function" ? m(l) : m;
}, eraValues$N = {
  narrow: ["pr.n.e.", "AD"],
  abbreviated: ["pr. Kr.", "po. Kr."],
  wide: ["Prije Krista", "Poslije Krista"]
}, quarterValues$N = {
  narrow: ["1.", "2.", "3.", "4."],
  abbreviated: ["1. kv.", "2. kv.", "3. kv.", "4. kv."],
  wide: ["1. kvartal", "2. kvartal", "3. kvartal", "4. kvartal"]
}, monthValues$N = {
  narrow: [
    "1.",
    "2.",
    "3.",
    "4.",
    "5.",
    "6.",
    "7.",
    "8.",
    "9.",
    "10.",
    "11.",
    "12."
  ],
  abbreviated: [
    "sij",
    "velj",
    "ožu",
    "tra",
    "svi",
    "lip",
    "srp",
    "kol",
    "ruj",
    "lis",
    "stu",
    "pro"
  ],
  wide: [
    "siječanj",
    "veljača",
    "ožujak",
    "travanj",
    "svibanj",
    "lipanj",
    "srpanj",
    "kolovoz",
    "rujan",
    "listopad",
    "studeni",
    "prosinac"
  ]
}, formattingMonthValues$a = {
  narrow: [
    "1.",
    "2.",
    "3.",
    "4.",
    "5.",
    "6.",
    "7.",
    "8.",
    "9.",
    "10.",
    "11.",
    "12."
  ],
  abbreviated: [
    "sij",
    "velj",
    "ožu",
    "tra",
    "svi",
    "lip",
    "srp",
    "kol",
    "ruj",
    "lis",
    "stu",
    "pro"
  ],
  wide: [
    "siječnja",
    "veljače",
    "ožujka",
    "travnja",
    "svibnja",
    "lipnja",
    "srpnja",
    "kolovoza",
    "rujna",
    "listopada",
    "studenog",
    "prosinca"
  ]
}, dayValues$N = {
  narrow: ["N", "P", "U", "S", "Č", "P", "S"],
  short: ["ned", "pon", "uto", "sri", "čet", "pet", "sub"],
  abbreviated: ["ned", "pon", "uto", "sri", "čet", "pet", "sub"],
  wide: [
    "nedjelja",
    "ponedjeljak",
    "utorak",
    "srijeda",
    "četvrtak",
    "petak",
    "subota"
  ]
}, formattingDayPeriodValues$D = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "popodne",
    evening: "navečer",
    night: "noću"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "popodne",
    evening: "navečer",
    night: "noću"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "poslije podne",
    evening: "navečer",
    night: "noću"
  }
}, dayPeriodValues$N = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "popodne",
    evening: "navečer",
    night: "noću"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "popodne",
    evening: "navečer",
    night: "noću"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "ponoć",
    noon: "podne",
    morning: "ujutro",
    afternoon: "poslije podne",
    evening: "navečer",
    night: "noću"
  }
}, ordinalNumber$N = (u, l) => Number(u) + ".", localize$N = {
  ordinalNumber: ordinalNumber$N,
  era: buildLocalizeFn({
    values: eraValues$N,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$N,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$N,
    defaultWidth: "wide",
    formattingValues: formattingMonthValues$a,
    defaultFormattingWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$N,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$N,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$D,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$N = /^(\d+)\./i, parseOrdinalNumberPattern$N = /\d+/i, matchEraPatterns$N = {
  narrow: /^(pr\.n\.e\.|AD)/i,
  abbreviated: /^(pr\.\s?Kr\.|po\.\s?Kr\.)/i,
  wide: /^(Prije Krista|prije nove ere|Poslije Krista|nova era)/i
}, parseEraPatterns$N = {
  any: [/^pr/i, /^(po|nova)/i]
}, matchQuarterPatterns$N = {
  narrow: /^[1234]/i,
  abbreviated: /^[1234]\.\s?kv\.?/i,
  wide: /^[1234]\. kvartal/i
}, parseQuarterPatterns$N = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$N = {
  narrow: /^(10|11|12|[123456789])\./i,
  abbreviated: /^(sij|velj|(ožu|ozu)|tra|svi|lip|srp|kol|ruj|lis|stu|pro)/i,
  wide: /^((siječanj|siječnja|sijecanj|sijecnja)|(veljača|veljače|veljaca|veljace)|(ožujak|ožujka|ozujak|ozujka)|(travanj|travnja)|(svibanj|svibnja)|(lipanj|lipnja)|(srpanj|srpnja)|(kolovoz|kolovoza)|(rujan|rujna)|(listopad|listopada)|(studeni|studenog)|(prosinac|prosinca))/i
}, parseMonthPatterns$N = {
  narrow: [
    /1/i,
    /2/i,
    /3/i,
    /4/i,
    /5/i,
    /6/i,
    /7/i,
    /8/i,
    /9/i,
    /10/i,
    /11/i,
    /12/i
  ],
  abbreviated: [
    /^sij/i,
    /^velj/i,
    /^(ožu|ozu)/i,
    /^tra/i,
    /^svi/i,
    /^lip/i,
    /^srp/i,
    /^kol/i,
    /^ruj/i,
    /^lis/i,
    /^stu/i,
    /^pro/i
  ],
  wide: [
    /^sij/i,
    /^velj/i,
    /^(ožu|ozu)/i,
    /^tra/i,
    /^svi/i,
    /^lip/i,
    /^srp/i,
    /^kol/i,
    /^ruj/i,
    /^lis/i,
    /^stu/i,
    /^pro/i
  ]
}, matchDayPatterns$N = {
  narrow: /^[npusčc]/i,
  short: /^(ned|pon|uto|sri|(čet|cet)|pet|sub)/i,
  abbreviated: /^(ned|pon|uto|sri|(čet|cet)|pet|sub)/i,
  wide: /^(nedjelja|ponedjeljak|utorak|srijeda|(četvrtak|cetvrtak)|petak|subota)/i
}, parseDayPatterns$N = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
}, matchDayPeriodPatterns$N = {
  any: /^(am|pm|ponoc|ponoć|(po)?podne|navecer|navečer|noću|poslije podne|ujutro)/i
}, parseDayPeriodPatterns$N = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^pono/i,
    noon: /^pod/i,
    morning: /jutro/i,
    afternoon: /(poslije\s|po)+podne/i,
    evening: /(navece|naveče)/i,
    night: /(nocu|noću)/i
  }
}, match$O = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$N,
    parsePattern: parseOrdinalNumberPattern$N,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$N,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$N,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$N,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$N,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$N,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$N,
    defaultParseWidth: "wide"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$N,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$N,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$N,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$N,
    defaultParseWidth: "any"
  })
}, hr = {
  code: "hr",
  formatDistance: formatDistance$N,
  formatLong: formatLong$O,
  formatRelative: formatRelative$N,
  localize: localize$N,
  match: match$O,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$L = {
  lessThanXSeconds: {
    one: "mwens pase yon segond",
    other: "mwens pase {{count}} segond"
  },
  xSeconds: {
    one: "1 segond",
    other: "{{count}} segond"
  },
  halfAMinute: "30 segond",
  lessThanXMinutes: {
    one: "mwens pase yon minit",
    other: "mwens pase {{count}} minit"
  },
  xMinutes: {
    one: "1 minit",
    other: "{{count}} minit"
  },
  aboutXHours: {
    one: "anviwon inè",
    other: "anviwon {{count}} è"
  },
  xHours: {
    one: "1 lè",
    other: "{{count}} lè"
  },
  xDays: {
    one: "1 jou",
    other: "{{count}} jou"
  },
  aboutXWeeks: {
    one: "anviwon 1 semèn",
    other: "anviwon {{count}} semèn"
  },
  xWeeks: {
    one: "1 semèn",
    other: "{{count}} semèn"
  },
  aboutXMonths: {
    one: "anviwon 1 mwa",
    other: "anviwon {{count}} mwa"
  },
  xMonths: {
    one: "1 mwa",
    other: "{{count}} mwa"
  },
  aboutXYears: {
    one: "anviwon 1 an",
    other: "anviwon {{count}} an"
  },
  xYears: {
    one: "1 an",
    other: "{{count}} an"
  },
  overXYears: {
    one: "plis pase 1 an",
    other: "plis pase {{count}} an"
  },
  almostXYears: {
    one: "prèske 1 an",
    other: "prèske {{count}} an"
  }
}, formatDistance$M = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$L[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? "nan " + p : "sa fè " + p : p;
}, dateFormats$N = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$N = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$N = {
  full: "{{date}} 'nan lè' {{time}}",
  long: "{{date}} 'nan lè' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$N = {
  date: buildFormatLongFn({
    formats: dateFormats$N,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$N,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$N,
    defaultWidth: "full"
  })
}, formatRelativeLocale$M = {
  lastWeek: "eeee 'pase nan lè' p",
  yesterday: "'yè nan lè' p",
  today: "'jodi a' p",
  tomorrow: "'demen nan lè' p'",
  nextWeek: "eeee 'pwochen nan lè' p",
  other: "P"
}, formatRelative$M = (u, l, f, p) => formatRelativeLocale$M[u], eraValues$M = {
  narrow: ["av. J.-K", "ap. J.-K"],
  abbreviated: ["av. J.-K", "ap. J.-K"],
  wide: ["anvan Jezi Kris", "apre Jezi Kris"]
}, quarterValues$M = {
  narrow: ["T1", "T2", "T3", "T4"],
  abbreviated: ["1ye trim.", "2yèm trim.", "3yèm trim.", "4yèm trim."],
  wide: ["1ye trimès", "2yèm trimès", "3yèm trimès", "4yèm trimès"]
}, monthValues$M = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "O", "S", "O", "N", "D"],
  abbreviated: [
    "janv.",
    "fevr.",
    "mas",
    "avr.",
    "me",
    "jen",
    "jiyè",
    "out",
    "sept.",
    "okt.",
    "nov.",
    "des."
  ],
  wide: [
    "janvye",
    "fevrye",
    "mas",
    "avril",
    "me",
    "jen",
    "jiyè",
    "out",
    "septanm",
    "oktòb",
    "novanm",
    "desanm"
  ]
}, dayValues$M = {
  narrow: ["D", "L", "M", "M", "J", "V", "S"],
  short: ["di", "le", "ma", "mè", "je", "va", "sa"],
  abbreviated: ["dim.", "len.", "mad.", "mèk.", "jed.", "van.", "sam."],
  wide: ["dimanch", "lendi", "madi", "mèkredi", "jedi", "vandredi", "samdi"]
}, dayPeriodValues$M = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "minwit",
    noon: "midi",
    morning: "mat.",
    afternoon: "ap.m.",
    evening: "swa",
    night: "mat."
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "minwit",
    noon: "midi",
    morning: "maten",
    afternoon: "aprèmidi",
    evening: "swa",
    night: "maten"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "minwit",
    noon: "midi",
    morning: "nan maten",
    afternoon: "nan aprèmidi",
    evening: "nan aswè",
    night: "nan maten"
  }
}, ordinalNumber$M = (u, l) => {
  const f = Number(u);
  return f === 0 ? String(f) : f + (f === 1 ? "ye" : "yèm");
}, localize$M = {
  ordinalNumber: ordinalNumber$M,
  era: buildLocalizeFn({
    values: eraValues$M,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$M,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$M,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$M,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$M,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$M = /^(\d+)(ye|yèm)?/i, parseOrdinalNumberPattern$M = /\d+/i, matchEraPatterns$M = {
  narrow: /^(av\.J\.K|ap\.J\.K|ap\.J\.-K)/i,
  abbreviated: /^(av\.J\.-K|av\.J-K|apr\.J\.-K|apr\.J-K|ap\.J-K)/i,
  wide: /^(avan Jezi Kris|apre Jezi Kris)/i
}, parseEraPatterns$M = {
  any: [/^av/i, /^ap/i]
}, matchQuarterPatterns$M = {
  narrow: /^[1234]/i,
  abbreviated: /^t[1234]/i,
  wide: /^[1234](ye|yèm)? trimès/i
}, parseQuarterPatterns$M = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$M = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(janv|fevr|mas|avr|me|jen|jiyè|out|sept|okt|nov|des)\.?/i,
  wide: /^(janvye|fevrye|mas|avril|me|jen|jiyè|out|septanm|oktòb|novanm|desanm)/i
}, parseMonthPatterns$M = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^o/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^ma/i,
    /^av/i,
    /^me/i,
    /^je/i,
    /^ji/i,
    /^ou/i,
    /^s/i,
    /^ok/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$M = {
  narrow: /^[lmjvsd]/i,
  short: /^(di|le|ma|me|je|va|sa)/i,
  abbreviated: /^(dim|len|mad|mèk|jed|van|sam)\.?/i,
  wide: /^(dimanch|lendi|madi|mèkredi|jedi|vandredi|samdi)/i
}, parseDayPatterns$M = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^j/i, /^v/i, /^s/i],
  any: [/^di/i, /^le/i, /^ma/i, /^mè/i, /^je/i, /^va/i, /^sa/i]
}, matchDayPeriodPatterns$M = {
  narrow: /^(a|p|minwit|midi|mat\.?|ap\.?m\.?|swa)/i,
  any: /^([ap]\.?\s?m\.?|nan maten|nan aprèmidi|nan aswè)/i
}, parseDayPeriodPatterns$M = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^min/i,
    noon: /^mid/i,
    morning: /mat/i,
    afternoon: /ap/i,
    evening: /sw/i,
    night: /nwit/i
  }
}, match$N = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$M,
    parsePattern: parseOrdinalNumberPattern$M,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$M,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$M,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$M,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$M,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$M,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$M,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$M,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$M,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$M,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$M,
    defaultParseWidth: "any"
  })
}, ht = {
  code: "ht",
  formatDistance: formatDistance$M,
  formatLong: formatLong$N,
  formatRelative: formatRelative$M,
  localize: localize$M,
  match: match$N,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, translations$1 = {
  about: "körülbelül",
  over: "több mint",
  almost: "majdnem",
  lessthan: "kevesebb mint"
}, withoutSuffixes = {
  xseconds: " másodperc",
  halfaminute: "fél perc",
  xminutes: " perc",
  xhours: " óra",
  xdays: " nap",
  xweeks: " hét",
  xmonths: " hónap",
  xyears: " év"
}, withSuffixes = {
  xseconds: {
    "-1": " másodperccel ezelőtt",
    1: " másodperc múlva",
    0: " másodperce"
  },
  halfaminute: {
    "-1": "fél perccel ezelőtt",
    1: "fél perc múlva",
    0: "fél perce"
  },
  xminutes: {
    "-1": " perccel ezelőtt",
    1: " perc múlva",
    0: " perce"
  },
  xhours: {
    "-1": " órával ezelőtt",
    1: " óra múlva",
    0: " órája"
  },
  xdays: {
    "-1": " nappal ezelőtt",
    1: " nap múlva",
    0: " napja"
  },
  xweeks: {
    "-1": " héttel ezelőtt",
    1: " hét múlva",
    0: " hete"
  },
  xmonths: {
    "-1": " hónappal ezelőtt",
    1: " hónap múlva",
    0: " hónapja"
  },
  xyears: {
    "-1": " évvel ezelőtt",
    1: " év múlva",
    0: " éve"
  }
}, formatDistance$L = (u, l, f) => {
  const p = u.match(/about|over|almost|lessthan/i), m = p ? u.replace(p[0], "") : u, b = f?.addSuffix === !0, y = m.toLowerCase(), v = f?.comparison || 0, $ = b ? withSuffixes[y][v] : withoutSuffixes[y];
  let w = y === "halfaminute" ? $ : l + $;
  if (p) {
    const P = p[0].toLowerCase();
    w = translations$1[P] + " " + w;
  }
  return w;
}, dateFormats$M = {
  full: "y. MMMM d., EEEE",
  long: "y. MMMM d.",
  medium: "y. MMM d.",
  short: "y. MM. dd."
}, timeFormats$M = {
  full: "H:mm:ss zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$M = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$M = {
  date: buildFormatLongFn({
    formats: dateFormats$M,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$M,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$M,
    defaultWidth: "full"
  })
}, accusativeWeekdays$4 = [
  "vasárnap",
  "hétfőn",
  "kedden",
  "szerdán",
  "csütörtökön",
  "pénteken",
  "szombaton"
];
function week(u) {
  return (l) => {
    const f = accusativeWeekdays$4[l.getDay()];
    return `${u ? "" : "'múlt' "}'${f}' p'-kor'`;
  };
}
const formatRelativeLocale$L = {
  lastWeek: week(!1),
  yesterday: "'tegnap' p'-kor'",
  today: "'ma' p'-kor'",
  tomorrow: "'holnap' p'-kor'",
  nextWeek: week(!0),
  other: "P"
}, formatRelative$L = (u, l) => {
  const f = formatRelativeLocale$L[u];
  return typeof f == "function" ? f(l) : f;
}, eraValues$L = {
  narrow: ["ie.", "isz."],
  abbreviated: ["i. e.", "i. sz."],
  wide: ["Krisztus előtt", "időszámításunk szerint"]
}, quarterValues$L = {
  narrow: ["1.", "2.", "3.", "4."],
  abbreviated: ["1. n.év", "2. n.év", "3. n.év", "4. n.év"],
  wide: ["1. negyedév", "2. negyedév", "3. negyedév", "4. negyedév"]
}, formattingQuarterValues$3 = {
  narrow: ["I.", "II.", "III.", "IV."],
  abbreviated: ["I. n.év", "II. n.év", "III. n.év", "IV. n.év"],
  wide: ["I. negyedév", "II. negyedév", "III. negyedév", "IV. negyedév"]
}, monthValues$L = {
  narrow: ["J", "F", "M", "Á", "M", "J", "J", "A", "Sz", "O", "N", "D"],
  abbreviated: [
    "jan.",
    "febr.",
    "márc.",
    "ápr.",
    "máj.",
    "jún.",
    "júl.",
    "aug.",
    "szept.",
    "okt.",
    "nov.",
    "dec."
  ],
  wide: [
    "január",
    "február",
    "március",
    "április",
    "május",
    "június",
    "július",
    "augusztus",
    "szeptember",
    "október",
    "november",
    "december"
  ]
}, dayValues$L = {
  narrow: ["V", "H", "K", "Sz", "Cs", "P", "Sz"],
  short: ["V", "H", "K", "Sze", "Cs", "P", "Szo"],
  abbreviated: ["V", "H", "K", "Sze", "Cs", "P", "Szo"],
  wide: [
    "vasárnap",
    "hétfő",
    "kedd",
    "szerda",
    "csütörtök",
    "péntek",
    "szombat"
  ]
}, dayPeriodValues$L = {
  narrow: {
    am: "de.",
    pm: "du.",
    midnight: "éjfél",
    noon: "dél",
    morning: "reggel",
    afternoon: "du.",
    evening: "este",
    night: "éjjel"
  },
  abbreviated: {
    am: "de.",
    pm: "du.",
    midnight: "éjfél",
    noon: "dél",
    morning: "reggel",
    afternoon: "du.",
    evening: "este",
    night: "éjjel"
  },
  wide: {
    am: "de.",
    pm: "du.",
    midnight: "éjfél",
    noon: "dél",
    morning: "reggel",
    afternoon: "délután",
    evening: "este",
    night: "éjjel"
  }
}, ordinalNumber$L = (u, l) => Number(u) + ".", localize$L = {
  ordinalNumber: ordinalNumber$L,
  era: buildLocalizeFn({
    values: eraValues$L,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$L,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1,
    formattingValues: formattingQuarterValues$3,
    defaultFormattingWidth: "wide"
  }),
  month: buildLocalizeFn({
    values: monthValues$L,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$L,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$L,
    defaultWidth: "wide"
  })
}, matchOrdinalNumberPattern$L = /^(\d+)\.?/i, parseOrdinalNumberPattern$L = /\d+/i, matchEraPatterns$L = {
  narrow: /^(ie\.|isz\.)/i,
  abbreviated: /^(i\.\s?e\.?|b?\s?c\s?e|i\.\s?sz\.?)/i,
  wide: /^(Krisztus előtt|időszámításunk előtt|időszámításunk szerint|i\. sz\.)/i
}, parseEraPatterns$L = {
  narrow: [/ie/i, /isz/i],
  abbreviated: [/^(i\.?\s?e\.?|b\s?ce)/i, /^(i\.?\s?sz\.?|c\s?e)/i],
  any: [/előtt/i, /(szerint|i. sz.)/i]
}, matchQuarterPatterns$L = {
  narrow: /^[1234]\.?/i,
  abbreviated: /^[1234]?\.?\s?n\.év/i,
  wide: /^([1234]|I|II|III|IV)?\.?\s?negyedév/i
}, parseQuarterPatterns$L = {
  any: [/1|I$/i, /2|II$/i, /3|III/i, /4|IV/i]
}, matchMonthPatterns$L = {
  narrow: /^[jfmaásond]|sz/i,
  abbreviated: /^(jan\.?|febr\.?|márc\.?|ápr\.?|máj\.?|jún\.?|júl\.?|aug\.?|szept\.?|okt\.?|nov\.?|dec\.?)/i,
  wide: /^(január|február|március|április|május|június|július|augusztus|szeptember|október|november|december)/i
}, parseMonthPatterns$L = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a|á/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s|sz/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^már/i,
    /^áp/i,
    /^máj/i,
    /^jún/i,
    /^júl/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$L = {
  narrow: /^([vhkpc]|sz|cs|sz)/i,
  short: /^([vhkp]|sze|cs|szo)/i,
  abbreviated: /^([vhkp]|sze|cs|szo)/i,
  wide: /^(vasárnap|hétfő|kedd|szerda|csütörtök|péntek|szombat)/i
}, parseDayPatterns$L = {
  narrow: [/^v/i, /^h/i, /^k/i, /^sz/i, /^c/i, /^p/i, /^sz/i],
  any: [/^v/i, /^h/i, /^k/i, /^sze/i, /^c/i, /^p/i, /^szo/i]
}, matchDayPeriodPatterns$L = {
  any: /^((de|du)\.?|éjfél|délután|dél|reggel|este|éjjel)/i
}, parseDayPeriodPatterns$L = {
  any: {
    am: /^de\.?/i,
    pm: /^du\.?/i,
    midnight: /^éjf/i,
    noon: /^dé/i,
    morning: /reg/i,
    afternoon: /^délu\.?/i,
    evening: /es/i,
    night: /éjj/i
  }
}, match$M = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$L,
    parsePattern: parseOrdinalNumberPattern$L,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$L,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$L,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$L,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$L,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$L,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$L,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$L,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$L,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$L,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$L,
    defaultParseWidth: "any"
  })
}, hu = {
  code: "hu",
  formatDistance: formatDistance$L,
  formatLong: formatLong$M,
  formatRelative: formatRelative$L,
  localize: localize$L,
  match: match$M,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$K = {
  lessThanXSeconds: {
    one: "ավելի քիչ քան 1 վայրկյան",
    other: "ավելի քիչ քան {{count}} վայրկյան"
  },
  xSeconds: {
    one: "1 վայրկյան",
    other: "{{count}} վայրկյան"
  },
  halfAMinute: "կես րոպե",
  lessThanXMinutes: {
    one: "ավելի քիչ քան 1 րոպե",
    other: "ավելի քիչ քան {{count}} րոպե"
  },
  xMinutes: {
    one: "1 րոպե",
    other: "{{count}} րոպե"
  },
  aboutXHours: {
    one: "մոտ 1 ժամ",
    other: "մոտ {{count}} ժամ"
  },
  xHours: {
    one: "1 ժամ",
    other: "{{count}} ժամ"
  },
  xDays: {
    one: "1 օր",
    other: "{{count}} օր"
  },
  aboutXWeeks: {
    one: "մոտ 1 շաբաթ",
    other: "մոտ {{count}} շաբաթ"
  },
  xWeeks: {
    one: "1 շաբաթ",
    other: "{{count}} շաբաթ"
  },
  aboutXMonths: {
    one: "մոտ 1 ամիս",
    other: "մոտ {{count}} ամիս"
  },
  xMonths: {
    one: "1 ամիս",
    other: "{{count}} ամիս"
  },
  aboutXYears: {
    one: "մոտ 1 տարի",
    other: "մոտ {{count}} տարի"
  },
  xYears: {
    one: "1 տարի",
    other: "{{count}} տարի"
  },
  overXYears: {
    one: "ավելի քան 1 տարի",
    other: "ավելի քան {{count}} տարի"
  },
  almostXYears: {
    one: "համարյա 1 տարի",
    other: "համարյա {{count}} տարի"
  }
}, formatDistance$K = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$K[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", String(l)), f?.addSuffix ? f.comparison && f.comparison > 0 ? p + " հետո" : p + " առաջ" : p;
}, dateFormats$L = {
  full: "d MMMM, y, EEEE",
  long: "d MMMM, y",
  medium: "d MMM, y",
  short: "dd.MM.yyyy"
}, timeFormats$L = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$L = {
  full: "{{date}} 'ժ․'{{time}}",
  long: "{{date}} 'ժ․'{{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$L = {
  date: buildFormatLongFn({
    formats: dateFormats$L,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$L,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$L,
    defaultWidth: "full"
  })
}, formatRelativeLocale$K = {
  lastWeek: "'նախորդ' eeee p'֊ին'",
  yesterday: "'երեկ' p'֊ին'",
  today: "'այսօր' p'֊ին'",
  tomorrow: "'վաղը' p'֊ին'",
  nextWeek: "'հաջորդ' eeee p'֊ին'",
  other: "P"
}, formatRelative$K = (u, l, f, p) => formatRelativeLocale$K[u], eraValues$K = {
  narrow: ["Ք", "Մ"],
  abbreviated: ["ՔԱ", "ՄԹ"],
  wide: ["Քրիստոսից առաջ", "Մեր թվարկության"]
}, quarterValues$K = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Ք1", "Ք2", "Ք3", "Ք4"],
  wide: ["1֊ին քառորդ", "2֊րդ քառորդ", "3֊րդ քառորդ", "4֊րդ քառորդ"]
}, monthValues$K = {
  narrow: ["Հ", "Փ", "Մ", "Ա", "Մ", "Հ", "Հ", "Օ", "Ս", "Հ", "Ն", "Դ"],
  abbreviated: [
    "հուն",
    "փետ",
    "մար",
    "ապր",
    "մայ",
    "հուն",
    "հուլ",
    "օգս",
    "սեպ",
    "հոկ",
    "նոյ",
    "դեկ"
  ],
  wide: [
    "հունվար",
    "փետրվար",
    "մարտ",
    "ապրիլ",
    "մայիս",
    "հունիս",
    "հուլիս",
    "օգոստոս",
    "սեպտեմբեր",
    "հոկտեմբեր",
    "նոյեմբեր",
    "դեկտեմբեր"
  ]
}, dayValues$K = {
  narrow: ["Կ", "Ե", "Ե", "Չ", "Հ", "Ո", "Շ"],
  short: ["կր", "եր", "եք", "չք", "հգ", "ուր", "շբ"],
  abbreviated: ["կիր", "երկ", "երք", "չոր", "հնգ", "ուրբ", "շաբ"],
  wide: [
    "կիրակի",
    "երկուշաբթի",
    "երեքշաբթի",
    "չորեքշաբթի",
    "հինգշաբթի",
    "ուրբաթ",
    "շաբաթ"
  ]
}, dayPeriodValues$K = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "կեսգշ",
    noon: "կեսօր",
    morning: "առավոտ",
    afternoon: "ցերեկ",
    evening: "երեկո",
    night: "գիշեր"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "կեսգիշեր",
    noon: "կեսօր",
    morning: "առավոտ",
    afternoon: "ցերեկ",
    evening: "երեկո",
    night: "գիշեր"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "կեսգիշեր",
    noon: "կեսօր",
    morning: "առավոտ",
    afternoon: "ցերեկ",
    evening: "երեկո",
    night: "գիշեր"
  }
}, formattingDayPeriodValues$C = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "կեսգշ",
    noon: "կեսօր",
    morning: "առավոտը",
    afternoon: "ցերեկը",
    evening: "երեկոյան",
    night: "գիշերը"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "կեսգիշերին",
    noon: "կեսօրին",
    morning: "առավոտը",
    afternoon: "ցերեկը",
    evening: "երեկոյան",
    night: "գիշերը"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "կեսգիշերին",
    noon: "կեսօրին",
    morning: "առավոտը",
    afternoon: "ցերեկը",
    evening: "երեկոյան",
    night: "գիշերը"
  }
}, ordinalNumber$K = (u, l) => {
  const f = Number(u), p = f % 100;
  return p < 10 && p % 10 === 1 ? f + "֊ին" : f + "֊րդ";
}, localize$K = {
  ordinalNumber: ordinalNumber$K,
  era: buildLocalizeFn({
    values: eraValues$K,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$K,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$K,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$K,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$K,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$C,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$K = /^(\d+)((-|֊)?(ին|րդ))?/i, parseOrdinalNumberPattern$K = /\d+/i, matchEraPatterns$K = {
  narrow: /^(Ք|Մ)/i,
  abbreviated: /^(Ք\.?\s?Ա\.?|Մ\.?\s?Թ\.?\s?Ա\.?|Մ\.?\s?Թ\.?|Ք\.?\s?Հ\.?)/i,
  wide: /^(քրիստոսից առաջ|մեր թվարկությունից առաջ|մեր թվարկության|քրիստոսից հետո)/i
}, parseEraPatterns$K = {
  any: [/^ք/i, /^մ/i]
}, matchQuarterPatterns$K = {
  narrow: /^[1234]/i,
  abbreviated: /^ք[1234]/i,
  wide: /^[1234]((-|֊)?(ին|րդ)) քառորդ/i
}, parseQuarterPatterns$K = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$K = {
  narrow: /^[հփմաօսնդ]/i,
  abbreviated: /^(հուն|փետ|մար|ապր|մայ|հուն|հուլ|օգս|սեպ|հոկ|նոյ|դեկ)/i,
  wide: /^(հունվար|փետրվար|մարտ|ապրիլ|մայիս|հունիս|հուլիս|օգոստոս|սեպտեմբեր|հոկտեմբեր|նոյեմբեր|դեկտեմբեր)/i
}, parseMonthPatterns$K = {
  narrow: [
    /^հ/i,
    /^փ/i,
    /^մ/i,
    /^ա/i,
    /^մ/i,
    /^հ/i,
    /^հ/i,
    /^օ/i,
    /^ս/i,
    /^հ/i,
    /^ն/i,
    /^դ/i
  ],
  any: [
    /^հու/i,
    /^փ/i,
    /^մար/i,
    /^ա/i,
    /^մայ/i,
    /^հուն/i,
    /^հուլ/i,
    /^օ/i,
    /^ս/i,
    /^հոկ/i,
    /^ն/i,
    /^դ/i
  ]
}, matchDayPatterns$K = {
  narrow: /^[եչհոշկ]/i,
  short: /^(կր|եր|եք|չք|հգ|ուր|շբ)/i,
  abbreviated: /^(կիր|երկ|երք|չոր|հնգ|ուրբ|շաբ)/i,
  wide: /^(կիրակի|երկուշաբթի|երեքշաբթի|չորեքշաբթի|հինգշաբթի|ուրբաթ|շաբաթ)/i
}, parseDayPatterns$K = {
  narrow: [/^կ/i, /^ե/i, /^ե/i, /^չ/i, /^հ/i, /^(ո|Ո)/, /^շ/i],
  short: [/^կ/i, /^եր/i, /^եք/i, /^չ/i, /^հ/i, /^(ո|Ո)/, /^շ/i],
  abbreviated: [/^կ/i, /^երկ/i, /^երք/i, /^չ/i, /^հ/i, /^(ո|Ո)/, /^շ/i],
  wide: [/^կ/i, /^երկ/i, /^երե/i, /^չ/i, /^հ/i, /^(ո|Ո)/, /^շ/i]
}, matchDayPeriodPatterns$K = {
  narrow: /^([ap]|կեսգշ|կեսօր|(առավոտը?|ցերեկը?|երեկո(յան)?|գիշերը?))/i,
  any: /^([ap]\.?\s?m\.?|կեսգիշեր(ին)?|կեսօր(ին)?|(առավոտը?|ցերեկը?|երեկո(յան)?|գիշերը?))/i
}, parseDayPeriodPatterns$K = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /կեսգիշեր/i,
    noon: /կեսօր/i,
    morning: /առավոտ/i,
    afternoon: /ցերեկ/i,
    evening: /երեկո/i,
    night: /գիշեր/i
  }
}, match$L = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$K,
    parsePattern: parseOrdinalNumberPattern$K,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$K,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$K,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$K,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$K,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$K,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$K,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$K,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$K,
    defaultParseWidth: "wide"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$K,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$K,
    defaultParseWidth: "any"
  })
}, hy = {
  code: "hy",
  formatDistance: formatDistance$K,
  formatLong: formatLong$L,
  formatRelative: formatRelative$K,
  localize: localize$K,
  match: match$L,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$J = {
  lessThanXSeconds: {
    one: "kurang dari 1 detik",
    other: "kurang dari {{count}} detik"
  },
  xSeconds: {
    one: "1 detik",
    other: "{{count}} detik"
  },
  halfAMinute: "setengah menit",
  lessThanXMinutes: {
    one: "kurang dari 1 menit",
    other: "kurang dari {{count}} menit"
  },
  xMinutes: {
    one: "1 menit",
    other: "{{count}} menit"
  },
  aboutXHours: {
    one: "sekitar 1 jam",
    other: "sekitar {{count}} jam"
  },
  xHours: {
    one: "1 jam",
    other: "{{count}} jam"
  },
  xDays: {
    one: "1 hari",
    other: "{{count}} hari"
  },
  aboutXWeeks: {
    one: "sekitar 1 minggu",
    other: "sekitar {{count}} minggu"
  },
  xWeeks: {
    one: "1 minggu",
    other: "{{count}} minggu"
  },
  aboutXMonths: {
    one: "sekitar 1 bulan",
    other: "sekitar {{count}} bulan"
  },
  xMonths: {
    one: "1 bulan",
    other: "{{count}} bulan"
  },
  aboutXYears: {
    one: "sekitar 1 tahun",
    other: "sekitar {{count}} tahun"
  },
  xYears: {
    one: "1 tahun",
    other: "{{count}} tahun"
  },
  overXYears: {
    one: "lebih dari 1 tahun",
    other: "lebih dari {{count}} tahun"
  },
  almostXYears: {
    one: "hampir 1 tahun",
    other: "hampir {{count}} tahun"
  }
}, formatDistance$J = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$J[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "dalam waktu " + p : p + " yang lalu" : p;
}, dateFormats$K = {
  full: "EEEE, d MMMM yyyy",
  long: "d MMMM yyyy",
  medium: "d MMM yyyy",
  short: "d/M/yyyy"
}, timeFormats$K = {
  full: "HH.mm.ss",
  long: "HH.mm.ss",
  medium: "HH.mm",
  short: "HH.mm"
}, dateTimeFormats$K = {
  full: "{{date}} 'pukul' {{time}}",
  long: "{{date}} 'pukul' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
}, formatLong$K = {
  date: buildFormatLongFn({
    formats: dateFormats$K,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$K,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$K,
    defaultWidth: "full"
  })
}, formatRelativeLocale$J = {
  lastWeek: "eeee 'lalu pukul' p",
  yesterday: "'Kemarin pukul' p",
  today: "'Hari ini pukul' p",
  tomorrow: "'Besok pukul' p",
  nextWeek: "eeee 'pukul' p",
  other: "P"
}, formatRelative$J = (u, l, f, p) => formatRelativeLocale$J[u], eraValues$J = {
  narrow: ["SM", "M"],
  abbreviated: ["SM", "M"],
  wide: ["Sebelum Masehi", "Masehi"]
}, quarterValues$J = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["K1", "K2", "K3", "K4"],
  wide: ["Kuartal ke-1", "Kuartal ke-2", "Kuartal ke-3", "Kuartal ke-4"]
}, monthValues$J = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "Mei",
    "Jun",
    "Jul",
    "Agt",
    "Sep",
    "Okt",
    "Nov",
    "Des"
  ],
  wide: [
    "Januari",
    "Februari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "November",
    "Desember"
  ]
}, dayValues$J = {
  narrow: ["M", "S", "S", "R", "K", "J", "S"],
  short: ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"],
  abbreviated: ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"],
  wide: ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
}, dayPeriodValues$J = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  }
}, formattingDayPeriodValues$B = {
  narrow: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "tengah malam",
    noon: "tengah hari",
    morning: "pagi",
    afternoon: "siang",
    evening: "sore",
    night: "malam"
  }
}, ordinalNumber$J = (u, l) => "ke-" + Number(u), localize$J = {
  ordinalNumber: ordinalNumber$J,
  era: buildLocalizeFn({
    values: eraValues$J,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$J,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$J,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$J,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$J,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$B,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$J = /^ke-(\d+)?/i, parseOrdinalNumberPattern$J = /\d+/i, matchEraPatterns$J = {
  narrow: /^(sm|m)/i,
  abbreviated: /^(s\.?\s?m\.?|s\.?\s?e\.?\s?u\.?|m\.?|e\.?\s?u\.?)/i,
  wide: /^(sebelum masehi|sebelum era umum|masehi|era umum)/i
}, parseEraPatterns$J = {
  any: [/^s/i, /^(m|e)/i]
}, matchQuarterPatterns$J = {
  narrow: /^[1234]/i,
  abbreviated: /^K-?\s[1234]/i,
  wide: /^Kuartal ke-?\s?[1234]/i
}, parseQuarterPatterns$J = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$J = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|mei|jun|jul|agt|sep|okt|nov|des)/i,
  wide: /^(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)/i
}, parseMonthPatterns$J = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^ma/i,
    /^ap/i,
    /^me/i,
    /^jun/i,
    /^jul/i,
    /^ag/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$J = {
  narrow: /^[srkjm]/i,
  short: /^(min|sen|sel|rab|kam|jum|sab)/i,
  abbreviated: /^(min|sen|sel|rab|kam|jum|sab)/i,
  wide: /^(minggu|senin|selasa|rabu|kamis|jumat|sabtu)/i
}, parseDayPatterns$J = {
  narrow: [/^m/i, /^s/i, /^s/i, /^r/i, /^k/i, /^j/i, /^s/i],
  any: [/^m/i, /^sen/i, /^sel/i, /^r/i, /^k/i, /^j/i, /^sa/i]
}, matchDayPeriodPatterns$J = {
  narrow: /^(a|p|tengah m|tengah h|(di(\swaktu)?) (pagi|siang|sore|malam))/i,
  any: /^([ap]\.?\s?m\.?|tengah malam|tengah hari|(di(\swaktu)?) (pagi|siang|sore|malam))/i
}, parseDayPeriodPatterns$J = {
  any: {
    am: /^a/i,
    pm: /^pm/i,
    midnight: /^tengah m/i,
    noon: /^tengah h/i,
    morning: /pagi/i,
    afternoon: /siang/i,
    evening: /sore/i,
    night: /malam/i
  }
}, match$K = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$J,
    parsePattern: parseOrdinalNumberPattern$J,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$J,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$J,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$J,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$J,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$J,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$J,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$J,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$J,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$J,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$J,
    defaultParseWidth: "any"
  })
}, id$2 = {
  code: "id",
  formatDistance: formatDistance$J,
  formatLong: formatLong$K,
  formatRelative: formatRelative$J,
  localize: localize$J,
  match: match$K,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$I = {
  lessThanXSeconds: {
    one: "minna en 1 sekúnda",
    other: "minna en {{count}} sekúndur"
  },
  xSeconds: {
    one: "1 sekúnda",
    other: "{{count}} sekúndur"
  },
  halfAMinute: "hálf mínúta",
  lessThanXMinutes: {
    one: "minna en 1 mínúta",
    other: "minna en {{count}} mínútur"
  },
  xMinutes: {
    one: "1 mínúta",
    other: "{{count}} mínútur"
  },
  aboutXHours: {
    one: "u.þ.b. 1 klukkustund",
    other: "u.þ.b. {{count}} klukkustundir"
  },
  xHours: {
    one: "1 klukkustund",
    other: "{{count}} klukkustundir"
  },
  xDays: {
    one: "1 dagur",
    other: "{{count}} dagar"
  },
  aboutXWeeks: {
    one: "um viku",
    other: "um {{count}} vikur"
  },
  xWeeks: {
    one: "1 viku",
    other: "{{count}} vikur"
  },
  aboutXMonths: {
    one: "u.þ.b. 1 mánuður",
    other: "u.þ.b. {{count}} mánuðir"
  },
  xMonths: {
    one: "1 mánuður",
    other: "{{count}} mánuðir"
  },
  aboutXYears: {
    one: "u.þ.b. 1 ár",
    other: "u.þ.b. {{count}} ár"
  },
  xYears: {
    one: "1 ár",
    other: "{{count}} ár"
  },
  overXYears: {
    one: "meira en 1 ár",
    other: "meira en {{count}} ár"
  },
  almostXYears: {
    one: "næstum 1 ár",
    other: "næstum {{count}} ár"
  }
}, formatDistance$I = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$I[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "í " + p : p + " síðan" : p;
}, dateFormats$J = {
  full: "EEEE, do MMMM y",
  long: "do MMMM y",
  medium: "do MMM y",
  short: "d.MM.y"
}, timeFormats$J = {
  full: "'kl'. HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$J = {
  full: "{{date}} 'kl.' {{time}}",
  long: "{{date}} 'kl.' {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$J = {
  date: buildFormatLongFn({
    formats: dateFormats$J,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$J,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$J,
    defaultWidth: "full"
  })
}, formatRelativeLocale$I = {
  lastWeek: "'síðasta' dddd 'kl.' p",
  yesterday: "'í gær kl.' p",
  today: "'í dag kl.' p",
  tomorrow: "'á morgun kl.' p",
  nextWeek: "dddd 'kl.' p",
  other: "P"
}, formatRelative$I = (u, l, f, p) => formatRelativeLocale$I[u], eraValues$I = {
  narrow: ["f.Kr.", "e.Kr."],
  abbreviated: ["f.Kr.", "e.Kr."],
  wide: ["fyrir Krist", "eftir Krist"]
}, quarterValues$I = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["1F", "2F", "3F", "4F"],
  wide: ["1. fjórðungur", "2. fjórðungur", "3. fjórðungur", "4. fjórðungur"]
}, monthValues$I = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "Á", "S", "Ó", "N", "D"],
  abbreviated: [
    "jan.",
    "feb.",
    "mars",
    "apríl",
    "maí",
    "júní",
    "júlí",
    "ágúst",
    "sept.",
    "okt.",
    "nóv.",
    "des."
  ],
  wide: [
    "janúar",
    "febrúar",
    "mars",
    "apríl",
    "maí",
    "júní",
    "júlí",
    "ágúst",
    "september",
    "október",
    "nóvember",
    "desember"
  ]
}, dayValues$I = {
  narrow: ["S", "M", "Þ", "M", "F", "F", "L"],
  short: ["Su", "Má", "Þr", "Mi", "Fi", "Fö", "La"],
  abbreviated: ["sun.", "mán.", "þri.", "mið.", "fim.", "fös.", "lau."],
  wide: [
    "sunnudagur",
    "mánudagur",
    "þriðjudagur",
    "miðvikudagur",
    "fimmtudagur",
    "föstudagur",
    "laugardagur"
  ]
}, dayPeriodValues$I = {
  narrow: {
    am: "f",
    pm: "e",
    midnight: "miðnætti",
    noon: "hádegi",
    morning: "morgunn",
    afternoon: "síðdegi",
    evening: "kvöld",
    night: "nótt"
  },
  abbreviated: {
    am: "f.h.",
    pm: "e.h.",
    midnight: "miðnætti",
    noon: "hádegi",
    morning: "morgunn",
    afternoon: "síðdegi",
    evening: "kvöld",
    night: "nótt"
  },
  wide: {
    am: "fyrir hádegi",
    pm: "eftir hádegi",
    midnight: "miðnætti",
    noon: "hádegi",
    morning: "morgunn",
    afternoon: "síðdegi",
    evening: "kvöld",
    night: "nótt"
  }
}, formattingDayPeriodValues$A = {
  narrow: {
    am: "f",
    pm: "e",
    midnight: "á miðnætti",
    noon: "á hádegi",
    morning: "að morgni",
    afternoon: "síðdegis",
    evening: "um kvöld",
    night: "um nótt"
  },
  abbreviated: {
    am: "f.h.",
    pm: "e.h.",
    midnight: "á miðnætti",
    noon: "á hádegi",
    morning: "að morgni",
    afternoon: "síðdegis",
    evening: "um kvöld",
    night: "um nótt"
  },
  wide: {
    am: "fyrir hádegi",
    pm: "eftir hádegi",
    midnight: "á miðnætti",
    noon: "á hádegi",
    morning: "að morgni",
    afternoon: "síðdegis",
    evening: "um kvöld",
    night: "um nótt"
  }
}, ordinalNumber$I = (u, l) => Number(u) + ".", localize$I = {
  ordinalNumber: ordinalNumber$I,
  era: buildLocalizeFn({
    values: eraValues$I,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$I,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$I,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$I,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$I,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$A,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$I = /^(\d+)(\.)?/i, parseOrdinalNumberPattern$I = /\d+(\.)?/i, matchEraPatterns$I = {
  narrow: /^(f\.Kr\.|e\.Kr\.)/i,
  abbreviated: /^(f\.Kr\.|e\.Kr\.)/i,
  wide: /^(fyrir Krist|eftir Krist)/i
}, parseEraPatterns$I = {
  any: [/^(f\.Kr\.)/i, /^(e\.Kr\.)/i]
}, matchQuarterPatterns$I = {
  narrow: /^[1234]\.?/i,
  abbreviated: /^q[1234]\.?/i,
  wide: /^[1234]\.? fjórðungur/i
}, parseQuarterPatterns$I = {
  any: [/1\.?/i, /2\.?/i, /3\.?/i, /4\.?/i]
}, matchMonthPatterns$I = {
  narrow: /^[jfmásónd]/i,
  abbreviated: /^(jan\.|feb\.|mars\.|apríl\.|maí|júní|júlí|águst|sep\.|oct\.|nov\.|dec\.)/i,
  wide: /^(januar|febrúar|mars|apríl|maí|júní|júlí|águst|september|október|nóvember|desember)/i
}, parseMonthPatterns$I = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^á/i,
    /^s/i,
    /^ó/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^maí/i,
    /^jún/i,
    /^júl/i,
    /^áu/i,
    /^s/i,
    /^ó/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$I = {
  narrow: /^[smtwf]/i,
  short: /^(su|má|þr|mi|fi|fö|la)/i,
  abbreviated: /^(sun|mán|þri|mið|fim|fös|lau)\.?/i,
  wide: /^(sunnudagur|mánudagur|þriðjudagur|miðvikudagur|fimmtudagur|föstudagur|laugardagur)/i
}, parseDayPatterns$I = {
  narrow: [/^s/i, /^m/i, /^þ/i, /^m/i, /^f/i, /^f/i, /^l/i],
  any: [/^su/i, /^má/i, /^þr/i, /^mi/i, /^fi/i, /^fö/i, /^la/i]
}, matchDayPeriodPatterns$I = {
  narrow: /^(f|e|síðdegis|(á|að|um) (morgni|kvöld|nótt|miðnætti))/i,
  any: /^(fyrir hádegi|eftir hádegi|[ef]\.?h\.?|síðdegis|morgunn|(á|að|um) (morgni|kvöld|nótt|miðnætti))/i
}, parseDayPeriodPatterns$I = {
  any: {
    am: /^f/i,
    pm: /^e/i,
    midnight: /^mi/i,
    noon: /^há/i,
    morning: /morgunn/i,
    afternoon: /síðdegi/i,
    evening: /kvöld/i,
    night: /nótt/i
  }
}, match$J = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$I,
    parsePattern: parseOrdinalNumberPattern$I,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$I,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$I,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$I,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$I,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$I,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$I,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$I,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$I,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$I,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$I,
    defaultParseWidth: "any"
  })
}, is = {
  code: "is",
  formatDistance: formatDistance$I,
  formatLong: formatLong$J,
  formatRelative: formatRelative$I,
  localize: localize$I,
  match: match$J,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$H = {
  lessThanXSeconds: {
    one: "meno di un secondo",
    other: "meno di {{count}} secondi"
  },
  xSeconds: {
    one: "un secondo",
    other: "{{count}} secondi"
  },
  halfAMinute: "alcuni secondi",
  lessThanXMinutes: {
    one: "meno di un minuto",
    other: "meno di {{count}} minuti"
  },
  xMinutes: {
    one: "un minuto",
    other: "{{count}} minuti"
  },
  aboutXHours: {
    one: "circa un'ora",
    other: "circa {{count}} ore"
  },
  xHours: {
    one: "un'ora",
    other: "{{count}} ore"
  },
  xDays: {
    one: "un giorno",
    other: "{{count}} giorni"
  },
  aboutXWeeks: {
    one: "circa una settimana",
    other: "circa {{count}} settimane"
  },
  xWeeks: {
    one: "una settimana",
    other: "{{count}} settimane"
  },
  aboutXMonths: {
    one: "circa un mese",
    other: "circa {{count}} mesi"
  },
  xMonths: {
    one: "un mese",
    other: "{{count}} mesi"
  },
  aboutXYears: {
    one: "circa un anno",
    other: "circa {{count}} anni"
  },
  xYears: {
    one: "un anno",
    other: "{{count}} anni"
  },
  overXYears: {
    one: "più di un anno",
    other: "più di {{count}} anni"
  },
  almostXYears: {
    one: "quasi un anno",
    other: "quasi {{count}} anni"
  }
}, formatDistance$H = (u, l, f) => {
  let p;
  const m = formatDistanceLocale$H[u];
  return typeof m == "string" ? p = m : l === 1 ? p = m.one : p = m.other.replace("{{count}}", l.toString()), f?.addSuffix ? f.comparison && f.comparison > 0 ? "tra " + p : p + " fa" : p;
}, dateFormats$I = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd/MM/y"
}, timeFormats$I = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$I = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$I = {
  date: buildFormatLongFn({
    formats: dateFormats$I,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$I,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$I,
    defaultWidth: "full"
  })
}, weekdays$2 = [
  "domenica",
  "lunedì",
  "martedì",
  "mercoledì",
  "giovedì",
  "venerdì",
  "sabato"
];
function lastWeek$5(u) {
  return u === 0 ? "'domenica scorsa alle' p" : "'" + weekdays$2[u] + " scorso alle' p";
}
function thisWeek$5(u) {
  return "'" + weekdays$2[u] + " alle' p";
}
function nextWeek$5(u) {
  return u === 0 ? "'domenica prossima alle' p" : "'" + weekdays$2[u] + " prossimo alle' p";
}
const formatRelativeLocale$H = {
  lastWeek: (u, l, f) => {
    const p = u.getDay();
    return isSameWeek(u, l, f) ? thisWeek$5(p) : lastWeek$5(p);
  },
  yesterday: "'ieri alle' p",
  today: "'oggi alle' p",
  tomorrow: "'domani alle' p",
  nextWeek: (u, l, f) => {
    const p = u.getDay();
    return isSameWeek(u, l, f) ? thisWeek$5(p) : nextWeek$5(p);
  },
  other: "P"
}, formatRelative$H = (u, l, f, p) => {
  const m = formatRelativeLocale$H[u];
  return typeof m == "function" ? m(l, f, p) : m;
}, eraValues$H = {
  narrow: ["aC", "dC"],
  abbreviated: ["a.C.", "d.C."],
  wide: ["avanti Cristo", "dopo Cristo"]
}, quarterValues$H = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["T1", "T2", "T3", "T4"],
  wide: ["1º trimestre", "2º trimestre", "3º trimestre", "4º trimestre"]
}, monthValues$H = {
  narrow: ["G", "F", "M", "A", "M", "G", "L", "A", "S", "O", "N", "D"],
  abbreviated: [
    "gen",
    "feb",
    "mar",
    "apr",
    "mag",
    "giu",
    "lug",
    "ago",
    "set",
    "ott",
    "nov",
    "dic"
  ],
  wide: [
    "gennaio",
    "febbraio",
    "marzo",
    "aprile",
    "maggio",
    "giugno",
    "luglio",
    "agosto",
    "settembre",
    "ottobre",
    "novembre",
    "dicembre"
  ]
}, dayValues$H = {
  narrow: ["D", "L", "M", "M", "G", "V", "S"],
  short: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  abbreviated: ["dom", "lun", "mar", "mer", "gio", "ven", "sab"],
  wide: [
    "domenica",
    "lunedì",
    "martedì",
    "mercoledì",
    "giovedì",
    "venerdì",
    "sabato"
  ]
}, dayPeriodValues$H = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "mattina",
    afternoon: "pomeriggio",
    evening: "sera",
    night: "notte"
  }
}, formattingDayPeriodValues$z = {
  narrow: {
    am: "m.",
    pm: "p.",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  },
  wide: {
    am: "AM",
    pm: "PM",
    midnight: "mezzanotte",
    noon: "mezzogiorno",
    morning: "di mattina",
    afternoon: "del pomeriggio",
    evening: "di sera",
    night: "di notte"
  }
}, ordinalNumber$H = (u, l) => {
  const f = Number(u);
  return String(f);
}, localize$H = {
  ordinalNumber: ordinalNumber$H,
  era: buildLocalizeFn({
    values: eraValues$H,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$H,
    defaultWidth: "wide",
    argumentCallback: (u) => u - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$H,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$H,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$H,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$z,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$H = /^(\d+)(º)?/i, parseOrdinalNumberPattern$H = /\d+/i, matchEraPatterns$H = {
  narrow: /^(aC|dC)/i,
  abbreviated: /^(a\.?\s?C\.?|a\.?\s?e\.?\s?v\.?|d\.?\s?C\.?|e\.?\s?v\.?)/i,
  wide: /^(avanti Cristo|avanti Era Volgare|dopo Cristo|Era Volgare)/i
}, parseEraPatterns$H = {
  any: [/^a/i, /^(d|e)/i]
}, matchQuarterPatterns$H = {
  narrow: /^[1234]/i,
  abbreviated: /^t[1234]/i,
  wide: /^[1234](º)? trimestre/i
}, parseQuarterPatterns$H = {
  any: [/1/i, /2/i, /3/i, /4/i]
}, matchMonthPatterns$H = {
  narrow: /^[gfmalsond]/i,
  abbreviated: /^(gen|feb|mar|apr|mag|giu|lug|ago|set|ott|nov|dic)/i,
  wide: /^(gennaio|febbraio|marzo|aprile|maggio|giugno|luglio|agosto|settembre|ottobre|novembre|dicembre)/i
}, parseMonthPatterns$H = {
  narrow: [
    /^g/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^g/i,
    /^l/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ge/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^mag/i,
    /^gi/i,
    /^l/i,
    /^ag/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
}, matchDayPatterns$H = {
  narrow: /^[dlmgvs]/i,
  short: /^(do|lu|ma|me|gi|ve|sa)/i,
  abbreviated: /^(dom|lun|mar|mer|gio|ven|sab)/i,
  wide: /^(domenica|luned[i|ì]|marted[i|ì]|mercoled[i|ì]|gioved[i|ì]|venerd[i|ì]|sabato)/i
}, parseDayPatterns$H = {
  narrow: [/^d/i, /^l/i, /^m/i, /^m/i, /^g/i, /^v/i, /^s/i],
  any: [/^d/i, /^l/i, /^ma/i, /^me/i, /^g/i, /^v/i, /^s/i]
}, matchDayPeriodPatterns$H = {
  narrow: /^(a|m\.|p|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i,
  any: /^([ap]\.?\s?m\.?|mezzanotte|mezzogiorno|(di|del) (mattina|pomeriggio|sera|notte))/i
}, parseDayPeriodPatterns$H = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mezza/i,
    noon: /^mezzo/i,
    morning: /mattina/i,
    afternoon: /pomeriggio/i,
    evening: /sera/i,
    night: /notte/i
  }
}, match$I = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$H,
    parsePattern: parseOrdinalNumberPattern$H,
    valueCallback: (u) => parseInt(u, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$H,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$H,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$H,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$H,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$H,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$H,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$H,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$H,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$H,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$H,
    defaultParseWidth: "any"
  })
}, it = {
  code: "it",
  formatDistance: formatDistance$H,
  formatLong: formatLong$I,
  formatRelative: formatRelative$H,
  localize: localize$H,
  match: match$I,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, dateFormats$H = {
  full: "EEEE d MMMM y",
  long: "d MMMM y",
  medium: "d MMM y",
  short: "dd.MM.y"
}, timeFormats$H = {
  full: "HH:mm:ss zzzz",
  long: "HH:mm:ss z",
  medium: "HH:mm:ss",
  short: "HH:mm"
}, dateTimeFormats$H = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$H = {
  date: buildFormatLongFn({
    formats: dateFormats$H,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$H,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$H,
    defaultWidth: "full"
  })
}, itCH = {
  code: "it-CH",
  formatDistance: formatDistance$H,
  formatLong: formatLong$H,
  formatRelative: formatRelative$H,
  localize: localize$H,
  match: match$I,
  options: {
    weekStartsOn: 1,
    firstWeekContainsDate: 4
  }
}, formatDistanceLocale$G = {
  lessThanXSeconds: {
    one: "1秒未満",
    other: "{{count}}秒未満",
    oneWithSuffix: "約1秒",
    otherWithSuffix: "約{{count}}秒"
  },
  xSeconds: {
    one: "1秒",
    other: "{{count}}秒"
  },
  halfAMinute: "30秒",
  lessThanXMinutes: {
    one: "1分未満",
    other: "{{count}}分未満",
    oneWithSuffix: "約1分",
    otherWithSuffix: "約{{count}}分"
  },
  xMinutes: {
    one: "1分",
    other: "{{count}}分"
  },
  aboutXHours: {
    one: "約1時間",
    other: "約{{count}}時間"
  },
  xHours: {
    one: "1時間",
    other: "{{count}}時間"
  },
  xDays: {
    one: "1日",
    other: "{{count}}日"
  },
  aboutXWeeks: {
    one: "約1週間",
    other: "約{{count}}週間"
  },
  xWeeks: {
    one: "1週間",
    other: "{{count}}週間"
  },
  aboutXMonths: {
    one: "約1か月",
    other: "約{{count}}か月"
  },
  xMonths: {
    one: "1か月",
    other: "{{count}}か月"
  },
  aboutXYears: {
    one: "約1年",
    other: "約{{count}}年"
  },
  xYears: {
    one: "1年",
    other: "{{count}}年"
  },
  overXYears: {
    one: "1年以上",
    other: "{{count}}年以上"
  },
  almostXYears: {
    one: "1年近く",
    other: "{{count}}年近く"
  }
}, formatDistance$G = (u, l, f) => {
  f = f || {};
  let p;
  const m = formatDistanceLocale$G[u];
  return typeof m == "string" ? p = m : l === 1 ? f.addSuffix && m.oneWithSuffix ? p = m.oneWithSuffix : p = m.one : f.addSuffix && m.otherWithSuffix ? p = m.otherWithSuffix.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f.addSuffix ? f.comparison && f.comparison > 0 ? p + "後" : p + "前" : p;
}, dateFormats$G = {
  full: "y年M月d日EEEE",
  long: "y年M月d日",
  medium: "y/MM/dd",
  short: "y/MM/dd"
}, timeFormats$G = {
  full: "H時mm分ss秒 zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$G = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$G = {
  date: buildFormatLongFn({
    formats: dateFormats$G,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$G,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$G,
    defaultWidth: "full"
  })
}, formatRelativeLocale$G = {
  lastWeek: "先週のeeeeのp",
  yesterday: "昨日のp",
  today: "今日のp",
  tomorrow: "明日のp",
  nextWeek: "翌週のeeeeのp",
  other: "P"
}, formatRelative$G = (u, l, f, p) => formatRelativeLocale$G[u], eraValues$G = {
  narrow: ["BC", "AC"],
  abbreviated: ["紀元前", "西暦"],
  wide: ["紀元前", "西暦"]
}, quarterValues$G = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["第1四半期", "第2四半期", "第3四半期", "第4四半期"]
}, monthValues$G = {
  narrow: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
  abbreviated: [
    "1月",
    "2月",
    "3月",
    "4月",
    "5月",
    "6月",
    "7月",
    "8月",
    "9月",
    "10月",
    "11月",
    "12月"
  ],
  wide: [
    "1月",
    "2月",
    "3月",
    "4月",
    "5月",
    "6月",
    "7月",
    "8月",
    "9月",
    "10月",
    "11月",
    "12月"
  ]
}, dayValues$G = {
  narrow: ["日", "月", "火", "水", "木", "金", "土"],
  short: ["日", "月", "火", "水", "木", "金", "土"],
  abbreviated: ["日", "月", "火", "水", "木", "金", "土"],
  wide: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"]
}, dayPeriodValues$G = {
  narrow: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  },
  abbreviated: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  },
  wide: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  }
}, formattingDayPeriodValues$y = {
  narrow: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  },
  abbreviated: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  },
  wide: {
    am: "午前",
    pm: "午後",
    midnight: "深夜",
    noon: "正午",
    morning: "朝",
    afternoon: "午後",
    evening: "夜",
    night: "深夜"
  }
}, ordinalNumber$G = (u, l) => {
  const f = Number(u);
  switch (String(l?.unit)) {
    case "year":
      return `${f}年`;
    case "quarter":
      return `第${f}四半期`;
    case "month":
      return `${f}月`;
    case "week":
      return `第${f}週`;
    case "date":
      return `${f}日`;
    case "hour":
      return `${f}時`;
    case "minute":
      return `${f}分`;
    case "second":
      return `${f}秒`;
    default:
      return `${f}`;
  }
}, localize$G = {
  ordinalNumber: ordinalNumber$G,
  era: buildLocalizeFn({
    values: eraValues$G,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues$G,
    defaultWidth: "wide",
    argumentCallback: (u) => Number(u) - 1
  }),
  month: buildLocalizeFn({
    values: monthValues$G,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues$G,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues$G,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues$y,
    defaultFormattingWidth: "wide"
  })
}, matchOrdinalNumberPattern$G = /^第?\d+(年|四半期|月|週|日|時|分|秒)?/i, parseOrdinalNumberPattern$G = /\d+/i, matchEraPatterns$G = {
  narrow: /^(B\.?C\.?|A\.?D\.?)/i,
  abbreviated: /^(紀元[前後]|西暦)/i,
  wide: /^(紀元[前後]|西暦)/i
}, parseEraPatterns$G = {
  narrow: [/^B/i, /^A/i],
  any: [/^(紀元前)/i, /^(西暦|紀元後)/i]
}, matchQuarterPatterns$G = {
  narrow: /^[1234]/i,
  abbreviated: /^Q[1234]/i,
  wide: /^第[1234一二三四１２３４]四半期/i
}, parseQuarterPatterns$G = {
  any: [/(1|一|１)/i, /(2|二|２)/i, /(3|三|３)/i, /(4|四|４)/i]
}, matchMonthPatterns$G = {
  narrow: /^([123456789]|1[012])/,
  abbreviated: /^([123456789]|1[012])月/i,
  wide: /^([123456789]|1[012])月/i
}, parseMonthPatterns$G = {
  any: [
    /^1\D/,
    /^2/,
    /^3/,
    /^4/,
    /^5/,
    /^6/,
    /^7/,
    /^8/,
    /^9/,
    /^10/,
    /^11/,
    /^12/
  ]
}, matchDayPatterns$G = {
  narrow: /^[日月火水木金土]/,
  short: /^[日月火水木金土]/,
  abbreviated: /^[日月火水木金土]/,
  wide: /^[日月火水木金土]曜日/
}, parseDayPatterns$G = {
  any: [/^日/, /^月/, /^火/, /^水/, /^木/, /^金/, /^土/]
}, matchDayPeriodPatterns$G = {
  any: /^(AM|PM|午前|午後|正午|深夜|真夜中|夜|朝)/i
}, parseDayPeriodPatterns$G = {
  any: {
    am: /^(A|午前)/i,
    pm: /^(P|午後)/i,
    midnight: /^深夜|真夜中/i,
    noon: /^正午/i,
    morning: /^朝/i,
    afternoon: /^午後/i,
    evening: /^夜/i,
    night: /^深夜/i
  }
}, match$H = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern$G,
    parsePattern: parseOrdinalNumberPattern$G,
    valueCallback: function(u) {
      return parseInt(u, 10);
    }
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns$G,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns$G,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns$G,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns$G,
    defaultParseWidth: "any",
    valueCallback: (u) => u + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns$G,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns$G,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns$G,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns$G,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns$G,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns$G,
    defaultParseWidth: "any"
  })
}, ja = {
  code: "ja",
  formatDistance: formatDistance$G,
  formatLong: formatLong$G,
  formatRelative: formatRelative$G,
  localize: localize$G,
  match: match$H,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
}, formatDistanceLocale$F = {
  lessThanXSeconds: {
    one: "1びょうみまん",
    other: "{{count}}びょうみまん",
    oneWithSuffix: "やく1びょう",
    otherWithSuffix: "やく{{count}}びょう"
  },
  xSeconds: {
    one: "1びょう",
    other: "{{count}}びょう"
  },
  halfAMinute: "30びょう",
  lessThanXMinutes: {
    one: "1ぷんみまん",
    other: "{{count}}ふんみまん",
    oneWithSuffix: "やく1ぷん",
    otherWithSuffix: "やく{{count}}ふん"
  },
  xMinutes: {
    one: "1ぷん",
    other: "{{count}}ふん"
  },
  aboutXHours: {
    one: "やく1じかん",
    other: "やく{{count}}じかん"
  },
  xHours: {
    one: "1じかん",
    other: "{{count}}じかん"
  },
  xDays: {
    one: "1にち",
    other: "{{count}}にち"
  },
  aboutXWeeks: {
    one: "やく1しゅうかん",
    other: "やく{{count}}しゅうかん"
  },
  xWeeks: {
    one: "1しゅうかん",
    other: "{{count}}しゅうかん"
  },
  aboutXMonths: {
    one: "やく1かげつ",
    other: "やく{{count}}かげつ"
  },
  xMonths: {
    one: "1かげつ",
    other: "{{count}}かげつ"
  },
  aboutXYears: {
    one: "やく1ねん",
    other: "やく{{count}}ねん"
  },
  xYears: {
    one: "1ねん",
    other: "{{count}}ねん"
  },
  overXYears: {
    one: "1ねんいじょう",
    other: "{{count}}ねんいじょう"
  },
  almostXYears: {
    one: "1ねんちかく",
    other: "{{count}}ねんちかく"
  }
}, formatDistance$F = (u, l, f) => {
  f = f || {};
  let p;
  const m = formatDistanceLocale$F[u];
  return typeof m == "string" ? p = m : l === 1 ? f.addSuffix && m.oneWithSuffix ? p = m.oneWithSuffix : p = m.one : f.addSuffix && m.otherWithSuffix ? p = m.otherWithSuffix.replace("{{count}}", String(l)) : p = m.other.replace("{{count}}", String(l)), f.addSuffix ? f.comparison && f.comparison > 0 ? p + "あと" : p + "まえ" : p;
}, dateFormats$F = {
  full: "yねんMがつdにちEEEE",
  long: "yねんMがつdにち",
  medium: "y/MM/dd",
  short: "y/MM/dd"
}, timeFormats$F = {
  full: "Hじmmふんssびょう zzzz",
  long: "H:mm:ss z",
  medium: "H:mm:ss",
  short: "H:mm"
}, dateTimeFormats$F = {
  full: "{{date}} {{time}}",
  long: "{{date}} {{time}}",
  medium: "{{date}} {{time}}",
  short: "{{date}} {{time}}"
}, formatLong$F = {
  date: buildFormatLongFn({
    formats: dateFormats$F,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats$F,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats$F,
    defaultWidth: "full"
  })
}, formatRelativeLocale$F = {
  lastWeek: "せんしゅうのeeeeのp",
  yesterday: "きのうのp",
  today: "きょうのp",
  tomorrow: "あしたのp",
  nextWeek: "よくしゅうのeeeeのp",
  other: "P"
}, formatRelative$F = (u, l, f, p) => formatRelativeLocale$F[u], eraValues$F = {
  narrow: ["BC", "AC"],
  abbreviated: ["きげんぜん", "せいれき"],
  wide: ["きげんぜん", "せいれき"]
}, quarterValues$F = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["だい1しはんき", "だい2しはんき", "だい3しはんき", "だい4しはんき"]
}, monthValues$F = {
  narrow: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
  abbreviated: [
    "1がつ",
    "2がつ",
    "3がつ",
    "4がつ",
    "5がつ",
    "6がつ",
    "7がつ",
    "8がつ",
    "9がつ",
    "10がつ",
    "11がつ",
    "12がつ"
  ],
  wide: [
    "1がつ",
    "2がつ",
    "3がつ",
    "4がつ",
    "5がつ",
    "6がつ",
    "7がつ",
    "8がつ",
    "9がつ",
    "10がつ",
    "11がつ",
    "12がつ"
  ]
}, dayValues$F = {
  narrow: ["にち", "げつ", "か", "すい", "もく", "きん", "ど"],
  short: ["にち", "げつ", "か", "すい", "もく", "きん", "ど"],
  abbreviated: ["にち", "げつ", "か", "すい", "もく", "きん", "ど"],
  wide: [
    "にちようび"